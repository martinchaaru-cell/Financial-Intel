function rpHeaderSelect(key, label, options, selected, change) {
  const slot = document.getElementById('rpHeaderSelectors');
  if (!slot) return;
  let select = document.getElementById('rp-select-' + key);
  if (!select) {
    select = document.createElement('select'); select.id = 'rp-select-' + key;
    slot.appendChild(select);
  }
  select.setAttribute('aria-label', label); select.title = label;
  select.replaceChildren(...options.map(t => new Option(t.label, t.id)));
  select.value = String(selected); select.onchange = () => change(select.value);
}
function rpClearHeader() { document.getElementById('rpHeaderSelectors').replaceChildren(); }
function rpClearCompanyControls() { document.getElementById('rpCompanyControls').replaceChildren(); }
function rpRemoveSelect(key) { document.getElementById('rp-select-' + key)?.remove(); }
// feature: what a member's package must include to open the page (billing.py TIER_FEATURES). Staff see everything.
const PAGES = [
  {id:'overview', label:'Dashboard Overview', adminOnly:true},
  {id:'home', label:'Dashboard', memberOnly:true, feature:'home'},
  {id:'survey-timeline', label:'Survey Administration', adminOnly:true},
  {id:'survey-report', label:'Companies Survey Reports', userOnly:true, feature:'reports'},
  {id:'survey-analytics', label:'Survey Analytics & Reporting', userOnly:true, feature:'analytics'},
  {id:'data-quality', label:'Data Quality', userOnly:true, feature:'data_quality'},
  {id:'intelligence-layer', label:'Intelligence Report', userOnly:true, feature:'intelligence'},
  {id:'documents', label:'Documents & Reports', userOnly:true, feature:'documents'},
  // AI, Review and Manual Entry used to be tabs inside Settings - promoted to their
  // own top-level nav items (2026-09-25, per explicit user request) so they are one
  // click away instead of buried behind Settings. Still admin-only (adminOnly:true),
  // same gating Settings itself always had - see renderNav()/render() below.
  {id:'ai', label:'AI Backfilling', adminOnly:true},
  {id:'review', label:'Report Reviews', adminOnly:true},
  {id:'manual-entry', label:'Report Manual Entry', adminOnly:true},
  {id:'activity', label:'Activity Log', adminOnly:true},
  {id:'billing', label:'Billing & Plan', userOnly:true, feature:'billing'},
];
// Which features this member's package includes. Until /api/billing/me answers, nothing is shown as locked.
function memberFeatures(){
  const b = window.billingStatus;
  return b && Array.isArray(b.features) ? new Set(b.features) : null;
}
function pageAllowed(p){
  const role = window.currentUser.role;
  if (role === 'admin') return !p.memberOnly;
  if (p.adminOnly) return false;
  const f = memberFeatures();
  return !p.feature || !f || f.has(p.feature);
}
function pageLockedTier(p){
  const b = window.billingStatus || {};
  return (b.feature_min_tier || {})[p.feature] || 'a paid';
}
// Settings is rendered separately at the very bottom of the sidebar (below the Help card),
// not in the scrolling nav list. Still admin-only; goTo('settings') / render() are unchanged.
const SETTINGS_PAGE = {id:'settings', label:'Settings', icon:'⚙️', adminOnly:true};
// Removed from the visible nav (2026-09-12/13 sessions): Compare
// Companies, Rankings, Sectors, Watchlist, Saved Views, Data Explorer,
// Financial Analytics, Exports - render functions kept as unreachable
// dead code (no remaining call sites removed those - only Compare/
// Rankings/Sectors/Analytics/Exports had zero callers left and were
// actually deleted, 2026-09-13 cleanup).
// 2026-09-18: Companies, Intelligence Report, Alerts, and Reports (and
// Company Detail, which only existed to host Intelligence Report) were
// FULLY DELETED per explicit user request - not just hidden from nav.
// Financial-statement analysis (ratios/peer comparison/risk/trends) and
// the Alerts risk/opportunity feed built on it are out of scope for a
// board/remuneration survey tool, per that discussion. Every place that
// used to link into those pages now goes straight to that company's
// Survey Report instead (goToCompanySurveyData()). Company management
// (add/delete) and Import Activity moved into Settings
// (renderSettingsCompaniesPanel/renderSettingsActivityPanel) rather
// than staying separate pages. The underlying FinancialPeriod/
// FinancialStatement data model was NOT deleted - DirectorRemunerationRow
// (Survey Report's Directors' Register) is anchored to FinancialPeriod,
// so that storage is still needed even with no page presenting it.
let currentPage = 'overview';
let currentCompanyId = null;
let currentCompanyName = '';
let allCompaniesCache = [];

// ---- full FY report state (company detail page) ----
let currentPeriodsCache = [];
let currentPeriodLabel = null;
let currentPeriodDetail = null;
let currentStatementTab = null;

// ---- manual report builder state (replaces the old flat "Add Financials" form) ----
let builderPeriod = '';
let builderTab = 'income_statement';
let builderRows = { income_statement: [], balance_sheet: [], cash_flow: [], equity: [] };

const STATEMENT_LABELS = {
  income_statement: 'Income Statement', balance_sheet: 'Balance Sheet',
  cash_flow: 'Cash Flow', equity: 'Equity'
};
const METRIC_LABELS = {
  net_margin: 'Net Margin', roe: 'ROE', roa: 'ROA',
  debt_equity: 'Debt/Equity', debt_assets: 'Debt/Assets'
};
const PCT_METRICS = new Set(['net_margin', 'roe', 'roa']);

// ---------- AUTH ----------
// Three-tier access, mirroring app.py's require_role: 'admin' can
// upload/edit/delete/view/download, 'user' can view/download, and an
// unauthenticated visitor - the default - is treated as 'guest'
// (view only), never redirected to a login wall. currentUser is
// populated once at boot (see the bottom of this script) from
// GET /api/me and kept in sync on login/register/logout.
window.currentUser = {logged_in: false, role: 'guest', name: null, email: null};
// Public sign-up is closed by default (only a super admin creates accounts); /api/me says if it was re-opened.
window.selfRegistrationOpen = false;

window.fiOffline = false;
async function loadCurrentUser(){
  try {
    const res = await fetch('/api/me');
    if (!res.ok) throw new Error('server unavailable');
    window.currentUser = await res.json();     // throws if a host's "not running" page came back instead
    window.fiOffline = false;
    window.selfRegistrationOpen = !!window.currentUser.self_registration;
    try { localStorage.setItem('fi_user', JSON.stringify(window.currentUser)); } catch (e) {}
    const reg = document.getElementById('loginRegisterLink');
    if (reg) reg.style.display = window.selfRegistrationOpen ? '' : 'none';
  } catch (e) {
    // Server unreachable: keep the header and navigation the person last saw, and say so in the page body.
    window.fiOffline = true;
    let cached = null;
    try { cached = JSON.parse(localStorage.getItem('fi_user') || 'null'); } catch (e2) {}
    window.currentUser = cached || {logged_in: false, role: 'guest', name: null, email: null};
  }
}

async function fiRetryConnection(){
  await loadCurrentUser();
  updateUserBadge(); renderNav(); render();
}
window.addEventListener('online', () => { if (window.fiOffline) fiRetryConnection(); });

function canEdit(){ return window.currentUser.role === 'admin'; }
function canDownload(){ return window.currentUser.role === 'admin' || window.currentUser.role === 'user'; }

// Name tag in the top bar: 'two' = first + last name (e.g. "Jane Wanjiku Kithela" -> "Jane Kithela"),
// 'first' = first name only. The full name stays in My Profile and shows on hover.
const NAME_TAG_MODE = 'two';
function shortName(name){
  const parts = (name || '').trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '';
  if (NAME_TAG_MODE === 'first' || parts.length === 1) return parts[0];
  return parts[0] + ' ' + parts[parts.length - 1];
}

// Display label for an account: super admins are shown as "Super Admin", not just "Admin".
function roleLabelFor(u){
  if (!u || !u.logged_in) return 'Viewing only';
  if (u.role === 'admin') return u.is_super_admin ? 'Super Admin' : 'Admin';
  return 'Member';
}

function themePref(){
  try { return localStorage.getItem('fi_theme') || 'light'; } catch (e) { return 'light'; }
}
function applyTheme(){
  const pref = themePref();
  const t = pref === 'system' ? (window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') : pref;
  document.documentElement.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t === 'light' ? '#f7f8f4' : '#101c18');
}
function setThemePref(pref){
  try { localStorage.setItem('fi_theme', pref); } catch (e) {}
  applyTheme();
  updateUserBadge();
  document.getElementById('userDropdown').classList.add('open');   // keep the menu open to show the choice
  if (typeof render === 'function') render();                       // redraw charts in the new colours
}
if (window.matchMedia) {
  try { matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => { if (themePref() === 'system') { applyTheme(); render(); } }); } catch (e) {}
}
function themeChartColors(){
  const light = document.documentElement.getAttribute('data-theme') === 'light';
  return {tick: light ? '#5b826f' : '#79a38e', grid: light ? 'rgba(20,37,29,.08)' : 'rgba(255,255,255,.05)'};
}
function updateUserBadge(){
  const u = window.currentUser;
  const nameEl = document.getElementById('userNameLabel');
  nameEl.textContent = u.logged_in ? shortName(u.name) : 'Guest';
  nameEl.title = u.logged_in ? (u.name || '') : '';
  document.getElementById('userRoleLabel').textContent = roleLabelFor(u);
  const dd = document.getElementById('userDropdown');
  if (u.logged_in) {
    dd.innerHTML = `
      <button onclick="openProfileModal()">My Profile</button>
      ${(u.role === 'admin' || u.role === 'user') ? `<button onclick="goTo('settings')">Settings</button>` : ''}
      <button onclick="location.href='/'">Back to website</button>
      <div class="dd-theme" onclick="event.stopPropagation()"><span>Appearance</span><div class="seg">
        ${[['light', '☀ Light'], ['dark', '☾ Dark'], ['system', 'System']].map(([k, l]) => `<button class="${themePref() === k ? 'on' : ''}" onclick="setThemePref('${k}')">${l}</button>`).join('')}
      </div></div>
      ${(typeof installAppAvailable === 'function' && installAppAvailable()) ? `<button onclick="installApp()">Install app</button>` : ''}
      <button onclick="logout()">Log Out</button>`;
  } else {
    dd.innerHTML = `
      <button onclick="openLoginModal()">Log In</button>
      ${window.selfRegistrationOpen ? `<button onclick="openRegisterModal()">Register</button>` : ''}
      ${(typeof installAppAvailable === 'function' && installAppAvailable()) ? `<button onclick="installApp()">Install app</button>` : ''}`;
  }
  if (window.currentUser.role === 'user' && typeof loadBillingStatus === 'function') loadBillingStatus(false);
  else { window.billingStatus = null; if (typeof renderBillingBanner === 'function') renderBillingBanner(); }
}

function openLoginModal(){
  document.getElementById('login-error').textContent = '';
  const codeEl = document.getElementById('login-code');
  codeEl.value = ''; codeEl.style.display = 'none';
  document.getElementById('loginModal').classList.add('open');
}
function openRegisterModal(){
  document.getElementById('register-error').textContent = '';
  ['register-name','register-email','register-organization','register-job-title','register-phone','register-password']
    .forEach(id => { document.getElementById(id).value = ''; });
  document.getElementById('registerModal').classList.add('open');
}
function closeAuthModals(){
  document.getElementById('loginModal').classList.remove('open');
  document.getElementById('registerModal').classList.remove('open');
}
function switchToRegister(e){ e.preventDefault(); closeAuthModals(); openRegisterModal(); }
function switchToLogin(e){ e.preventDefault(); closeAuthModals(); openLoginModal(); }

async function submitLogin(){
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const codeEl = document.getElementById('login-code');
  const code = codeEl.value.trim();
  const errEl = document.getElementById('login-error');
  errEl.textContent = '';
  try {
    const res = await fetch('/api/login', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({email, password, code}),
    });
    const data = await res.json();
    if (data.mfa_required) { codeEl.style.display = ''; codeEl.focus(); }
    if (!res.ok) { errEl.textContent = data.error || 'Login failed.'; return; }
    window.currentUser = {...data, logged_in: true};
    closeAuthModals();
    updateUserBadge();
    renderNav();
    render();
  } catch (e) { errEl.textContent = 'Login failed - please try again.'; }
}

async function submitRegister(){
  const name = document.getElementById('register-name').value.trim();
  const email = document.getElementById('register-email').value.trim();
  const organization = document.getElementById('register-organization').value.trim();
  const job_title = document.getElementById('register-job-title').value.trim();
  const phone = document.getElementById('register-phone').value.trim();
  const password = document.getElementById('register-password').value;
  const errEl = document.getElementById('register-error');
  errEl.textContent = '';
  try {
    const res = await fetch('/api/register', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({name, email, organization, job_title, phone, password}),
    });
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error || 'Registration failed.'; return; }
    window.currentUser = {...data, logged_in: true};
    closeAuthModals();
    updateUserBadge();
    renderNav();
    render();
  } catch (e) { errEl.textContent = 'Registration failed - please try again.'; }
}

async function openProfileModal(){
  const errEl = document.getElementById('profile-error');
  const savedEl = document.getElementById('profile-saved');
  errEl.textContent = '';
  savedEl.style.display = 'none';
  document.getElementById('profileModal').classList.add('open');
  try {
    const res = await fetch('/api/profile');
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error || 'Could not load profile.'; return; }
    document.getElementById('profile-name').value = data.name || '';
    document.getElementById('profile-email').value = data.email || '';
    document.getElementById('profile-organization').value = data.organization || '';
    document.getElementById('profile-job-title').value = data.job_title || '';
    document.getElementById('profile-phone').value = data.phone || '';
    const roleLabel = roleLabelFor({...data, logged_in: true});
    const since = data.created_at ? new Date(data.created_at).toLocaleDateString() : null;
    document.getElementById('profile-meta').textContent =
      `${roleLabel}${since ? ' · Member since ' + since : ''}`;
    renderMfaState(!!data.mfa_enabled);
  } catch (e) { errEl.textContent = 'Could not load profile - please try again.'; }
}
let _mfaOn = false;
function renderMfaState(on){
  _mfaOn = on;
  document.getElementById('mfa-status').textContent = on
    ? 'On - you will be asked for a code from your authenticator app each time you log in.'
    : 'Off - recommended for admin accounts.';
  document.getElementById('mfa-main-btn').textContent = on ? 'Turn off' : 'Set up';
  document.getElementById('mfa-setup-box').style.display = 'none';
  document.getElementById('mfa-disable-box').style.display = 'none';
  document.getElementById('mfa-main-btn').style.display = '';
  document.getElementById('mfa-error').textContent = '';
}
async function mfaMainClick(){
  const errEl = document.getElementById('mfa-error');
  errEl.textContent = '';
  if (_mfaOn) {
    document.getElementById('mfa-disable-box').style.display = '';
    document.getElementById('mfa-main-btn').style.display = 'none';
    return;
  }
  try {
    const res = await fetch('/api/mfa/setup', {method: 'POST'});
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error || 'Could not start setup.'; return; }
    document.getElementById('mfa-secret').textContent = data.secret;
    document.getElementById('mfa-link').href = data.otpauth_uri;
    document.getElementById('mfa-code').value = '';
    document.getElementById('mfa-setup-box').style.display = '';
    document.getElementById('mfa-main-btn').style.display = 'none';
  } catch (e) { errEl.textContent = 'Could not start setup - please try again.'; }
}
async function mfaEnable(){
  const errEl = document.getElementById('mfa-error');
  errEl.textContent = '';
  try {
    const res = await fetch('/api/mfa/enable', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({code: document.getElementById('mfa-code').value.trim()}),
    });
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error || 'Could not turn on.'; return; }
    window.currentUser = {...window.currentUser, mfa_enabled: true};
    renderMfaState(true);
  } catch (e) { errEl.textContent = 'Could not turn on - please try again.'; }
}
async function mfaDisable(){
  const errEl = document.getElementById('mfa-error');
  errEl.textContent = '';
  try {
    const res = await fetch('/api/mfa/disable', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        password: document.getElementById('mfa-off-password').value,
        code: document.getElementById('mfa-off-code').value.trim(),
      }),
    });
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error || 'Could not turn off.'; return; }
    document.getElementById('mfa-off-password').value = '';
    document.getElementById('mfa-off-code').value = '';
    window.currentUser = {...window.currentUser, mfa_enabled: false};
    renderMfaState(false);
  } catch (e) { errEl.textContent = 'Could not turn off - please try again.'; }
}
function closeProfileModal(){
  document.getElementById('profileModal').classList.remove('open');
}
async function submitProfile(){
  const name = document.getElementById('profile-name').value.trim();
  const organization = document.getElementById('profile-organization').value.trim();
  const job_title = document.getElementById('profile-job-title').value.trim();
  const phone = document.getElementById('profile-phone').value.trim();
  const errEl = document.getElementById('profile-error');
  const savedEl = document.getElementById('profile-saved');
  errEl.textContent = '';
  savedEl.style.display = 'none';
  if (['admin', 'administrator'].includes(name.toLowerCase())) { errEl.textContent = 'Please enter your own full name.'; return; }
  try {
    const res = await fetch('/api/profile', {
      method: 'PUT', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({name, organization, job_title, phone}),
    });
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error || 'Could not save profile.'; return; }
    window.currentUser = {...window.currentUser, ...data};
    updateUserBadge();
    savedEl.style.display = 'block';

  } catch (e) { errEl.textContent = 'Could not save profile - please try again.'; }
}

async function logout(){
  try { await fetch('/api/logout', {method: 'POST'}); } catch (e) {}
  location.href = '/';        // back to the public website
}

// Buttons/panels marked data-perm="admin" or data-perm="user" (the
// latter meaning "admin or user, not guest") are shown/hidden to match
// the current role every time the page content changes - covers
// dynamically-rendered buttons (delete, committee edit, field review,
// uploads) that aren't already covered by setPageActions' own
// filtering below. This is UI convenience only; the actual enforcement
// is server-side (require_role in app.py) since a guest could still
// call an API route directly.
function applyPermGating(){
  const role = window.currentUser.role;
  document.querySelectorAll('[data-perm]').forEach(el => {
    const need = el.getAttribute('data-perm');
    const allowed = need === 'admin' ? role === 'admin' : (role === 'admin' || role === 'user');
    el.style.display = allowed ? '' : 'none';
  });
}
(function(){
  const appEl = document.getElementById('app');
  if (!appEl) return;
  new MutationObserver(() => applyPermGating()).observe(appEl, {childList: true, subtree: true});
})();

function renderNav(){
  const role = window.currentUser.role;
  const pages = PAGES.filter(p => !['activity','billing'].includes(p.id) && (!p.adminOnly || role === 'admin') && (!p.userOnly || role === 'admin' || role === 'user')
    && (!p.memberOnly || role === 'user'));
  document.getElementById('navList').innerHTML = pages.map(p => (role === 'user' && !pageAllowed(p)) ? `
    <button class="nav-btn locked" onclick="showUpgrade('${p.id}')" title="Included in the ${escapeHtml(pageLockedTier(p))} plan">
      <span>${p.label}</span><span class="lock-tag" aria-label="Locked">🔒</span>
    </button>` : p.soon ? `
    <button class="nav-btn disabled" title="Coming soon" onclick="return false;">
      ${p.icon ? `<span class="ic">${p.icon}</span>` : ''}<span>${p.label}</span><span class="soon-tag">Soon</span>
    </button>` : `
    <button class="nav-btn ${p.id===currentPage?'active':''}" onclick="goTo('${p.id}')">
      ${p.icon ? `<span class="ic">${p.icon}</span>` : ''}<span>${p.label}</span>
    </button>`).join('');

  // Settings: pinned at the bottom of the sidebar, admins only.
  const st = document.getElementById('navSettings');
  if (st) {
    st.innerHTML = role === 'admin' || role === 'user' ? `
      <button class="nav-btn ${['settings','activity','billing'].includes(currentPage)?'active':''}" onclick="goTo('${SETTINGS_PAGE.id}')">
        <span class="ic">${SETTINGS_PAGE.icon}</span><span>${SETTINGS_PAGE.label}</span>
      </button>` : '';
  }
}

// Guests (not signed in) can only view the Dashboard Overview. Anything else asks them to sign in.
function guestNeedsSignIn(pageId){
  if (window.currentUser.role === 'guest' && !window.fiOffline) { location.href = '/login?next=' + encodeURIComponent('/app'); return true; }
  if (window.currentUser.role !== 'guest' || pageId === 'overview') return false;
  if (typeof showToast === 'function') showToast('Please sign in to view this page.');
  if (typeof openLoginModal === 'function') openLoginModal();
  return true;
}

function goTo(pageId, keepTimelineFilter){
  if (guestNeedsSignIn(pageId)) return;
  // Survey Administration is admin-only; anyone else is sent to the Overview.
  if (pageId === 'survey-timeline' && window.currentUser.role !== 'admin') pageId = 'overview';
  if (pageId === 'survey-timeline' && !keepTimelineFilter) tlFilter = null;
  currentPage = pageId;
  currentCompanyId = null;
  renderNav();
  render();
  closeSidebar();
}

function toggleSidebar(){
  document.querySelector('.sidebar').classList.toggle('open');
  document.getElementById('sidebarBackdrop').classList.toggle('open');
}
function closeSidebar(){
  document.querySelector('.sidebar').classList.remove('open');
  document.getElementById('sidebarBackdrop').classList.remove('open');
}

function toggleUserMenu(e){
  e.stopPropagation();
  document.getElementById('userDropdown').classList.toggle('open');
}
document.addEventListener('click', () => {
  const dd = document.getElementById('userDropdown');
  if (dd) dd.classList.remove('open');
  const cm = document.getElementById('coColumnsMenu');
  if (cm) cm.classList.add('hidden');
  document.querySelectorAll('.row-menu').forEach(m => m.classList.add('hidden'));
});

function goToCompanySurveyData(companyId, fiscalYear){
  if (guestNeedsSignIn('survey-report')) return;
  currentPage = 'survey-report';
  renderNav();
  closeSidebar();
  srSwitchCompany(companyId, fiscalYear);
}

async function render(){
  if (typeof updateUserBadge === 'function' && window.currentUser) updateUserBadge();   // undo the dashboard's greeting
  const app = document.getElementById('app');
  const title = document.getElementById('pageTitle');
  const sub = document.getElementById('pageSub');
  rpClearHeader(); rpClearCompanyControls();
  app.dataset.lockedFor = '';
  app.innerHTML = '<div class="empty">Loading...</div>';

  setPageActions(null);
  if (window.fiOffline) {
    // The header and navigation above still work; only the data needs the server.
    title.textContent = 'Server not reachable';
    sub.textContent = 'The Remuneration Practice server is not running or you are offline';
    app.innerHTML = `<div class="panel" style="text-align:center;padding:36px 18px;">
      <h2 style="margin:0 0 8px;">Can't reach the server</h2>
      <p style="color:var(--text-dim);margin:0 0 18px;">The app is installed, but its data lives on the server, which isn't responding. Start the server (or check your connection), then try again.</p>
      <button class="btn-primary-cta" style="margin:0;" onclick="fiRetryConnection()">Try again</button>
    </div>`;
    return;
  }
  if (window.currentUser.role === 'guest') {           // the app needs an account; the website is for guests
    location.href = '/login?next=' + encodeURIComponent('/app');
    return;
  }
  if (window.currentUser.role === 'user' && currentPage === 'overview') { currentPage = 'home'; renderNav(); }
  if (window.currentUser.role === 'admin' && currentPage === 'home') { currentPage = 'overview'; renderNav(); }
  const inSettings = ['settings','activity','billing'].includes(currentPage);
  const isAdmin = window.currentUser.role === 'admin';
  if (inSettings) rpHeaderSelect('category', 'Settings category', [
    {id:'settings',label:isAdmin?'General settings':'Settings'},
    ...(isAdmin ? [{id:'activity',label:'Activity log'}] : []),
    {id:'billing',label:'Billing & Plan'}], currentPage, goTo);
  if (currentPage === 'activity' && !isAdmin) { goTo('settings'); return; }
  const pageDef = PAGES.find(p => p.id === currentPage);
  if (window.currentUser.role === 'user' && pageDef && !pageAllowed(pageDef)) {
    title.textContent = pageDef.label;
    sub.textContent = 'Not included in your plan';
    renderUpgradePanel(pageDef);
    return;
  }
  if (currentPage === 'home') {
    title.textContent = 'Dashboard';
    sub.textContent = 'Your company against the market';
    await renderMemberHome();
    return;
  }
  if (currentPage === 'survey-timeline' && window.currentUser.role !== 'admin') {
    currentPage = 'overview';
    renderNav();
  }
  if (currentPage === 'overview') {
    title.textContent = 'Dashboard Overview';
    if (window.currentUser.is_super_admin) {
      sub.textContent = 'Customers, revenue and how clients use the app';
      await renderBusinessDashboard();
    } else {
      sub.innerHTML = 'Portfolio Overview · All Companies';
      await renderOverview();
    }
  } else if (currentPage === 'survey-timeline') {
    title.textContent = 'Survey Administration Timeline';
    sub.textContent = 'How far each company has progressed, from setup to report generation';
    await renderSurveyTimelinePage();
  } else if (currentPage === 'field-review') {
    title.textContent = 'Finish Review';
    sub.textContent = 'Approve, correct or reject the extracted fields still waiting for a person';
    await renderFieldReviewPage();
  } else if (currentPage === 'settings') {
    title.textContent = 'Settings';
    sub.textContent = 'Database, companies, users, imports, enquiries and emails';
    await renderSettingsPage();
  } else if (currentPage === 'billing') {
    title.textContent = 'Billing & Plan';
    sub.textContent = window.currentUser.role === 'admin' ? 'Customers, plans, invoices and payments' : 'Your plan, invoices, payment and colleagues';
    await renderBillingPage();
  } else if (currentPage === 'activity') {
    title.textContent = 'Activity Log';
    sub.textContent = 'Everything done in the app, tagged to the account that did it';
    await renderActivityPage();
  } else if (currentPage === 'ai') {
    title.textContent = 'AI Backfilling';
    sub.textContent = 'Run AI extraction for items the rule-based readers could not read';
    await renderAIPage();
  } else if (currentPage === 'review') {
    title.textContent = 'Report Reviews';
    sub.textContent = 'Review uploads, AI results, conflicts and issues';
    await renderReviewPage();
  } else if (currentPage === 'manual-entry') {
    title.textContent = 'Report Manual Entry';
    sub.textContent = 'Type in what a report contains but the app could not read';
    await renderManualEntryPage();
  } else if (currentPage === 'survey-report') {
    // Title/sub set inside renderSurveyReportPage() per-tab, same pattern
    // as Survey Analytics.
    await renderSurveyReportPage();
  } else if (currentPage === 'survey-analytics') {
    // Title/sub are set inside renderSurveyAnalyticsPage() per-tab (each
    // of the 9 tabs has its own heading/subtitle per the design images).
    await renderSurveyAnalyticsPage();
  } else if (currentPage === 'documents') {
    await renderDocumentsPage();
  } else if (currentPage === 'data-quality') {
    await renderDataQualityPage();
  } else if (currentPage === 'intelligence-layer') {
    await renderIntelligenceLayerPage();
  }
}

// Shared small top-right "Actions ▾" dropdown, rendered into the fixed
// topbar's pageActionsSlot. Each page calls setPageActions(items) at the
// start of its render function (or setPageActions(null) for pages with
// no page-level actions) so export/upload controls live in one
// consistent place instead of scattered panels or inline header rows.
// items: [{label, icon, onClick, disabled}]
function setPageActions(rawItems, extraHtml){
  const slot = document.getElementById('pageActionsSlot');
  if (!slot) return;
  const role = window.currentUser.role;
  // perm: 'admin' -> admin only (uploads/edits); 'user' -> admin or
  // user, not guest (downloads); no perm -> everyone (plain views).
  const items = (rawItems || []).filter(it => {
    if (!it.perm) return true;
    if (it.perm === 'admin') return role === 'admin';
    if (it.perm === 'user') return role === 'admin' || role === 'user';
    return true;
  });
  const extra = extraHtml ? `<div class="pa-extra">${extraHtml}</div>` : '';
  if (!items.length) { slot.innerHTML = extra ? `<div class="pa-wrap">${extra}</div>` : ''; return; }
  slot.innerHTML = `<div class="pa-wrap">${extra}
    <div class="page-actions">
      <button class="page-actions-btn" onclick="togglePageActionsMenu(event)">Actions ▾</button>
      <div class="page-actions-menu hidden" id="pageActionsMenu" onclick="event.stopPropagation()">
        ${items.map(it => `
          <div class="pa-item ${it.disabled ? 'disabled' : ''}" onclick="${it.disabled ? '' : it.onClick + "; document.getElementById('pageActionsMenu').classList.add('hidden')"}">
            <span>${it.icon || ''}</span><span>${escapeHtml(it.label)}</span>
          </div>`).join('')}
      </div>
    </div></div>`;
}
function togglePageActionsMenu(e){
  e.stopPropagation();
  document.getElementById('pageActionsMenu').classList.toggle('hidden');
}
document.addEventListener('click', () => {
  const m = document.getElementById('pageActionsMenu');
  if (m) m.classList.add('hidden');
});


// ============================================================================
// Activity Log (admin) - every action tagged to the account that did it.
// Data: GET /api/activity (activity_log.py). "Per day" follows the viewer's own
// calendar day: the browser's timezone offset is sent with every request.
// ============================================================================
const ACT_COLORS = {
  'Sign-in & Accounts':'blue', 'User Management':'purple', 'Uploads & Extraction':'teal',
  'Review & Corrections':'amber', 'Data Entry & Edits':'green', 'Companies':'pink',
  'AI':'purple', 'Exports & Downloads':'blue', 'Other':'blue',
};
let actState = {view:'overall', days:'7', user:'', category:'', q:'', data:null, open:new Set(), openInit:false};
let actSearchTimer = null;

function actChip(cat){
  const c = ACT_COLORS[cat] || 'blue';
  return `<span class="act-chip" style="background:var(--${c}-soft);color:var(--${c});">${escapeHtml(cat)}</span>`;
}
function actQuery(extra){
  const p = new URLSearchParams();
  p.set('days', actState.days);
  if (actState.user) p.set('user_id', actState.user);
  if (actState.category) p.set('category', actState.category);
  if (actState.q) p.set('q', actState.q);
  p.set('tz_offset', String(new Date().getTimezoneOffset()));
  return p.toString() + (extra || '');
}
function actFmtDay(iso){
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-GB', {weekday:'long', day:'numeric', month:'long', year:'numeric'});
}
function actFmtStamp(iso){
  if (!iso) return '—';
  return new Date(iso).toLocaleString('en-GB', {day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit'});
}
function actExportCsv(){ window.location.href = '/api/activity/export.csv?' + actQuery(); }

async function renderActivityPage(){
  const app = document.getElementById('app');
  setPageActions([{label:'Export CSV', icon:'⬇️', perm:'admin', onClick:'actExportCsv()'}]);
  app.innerHTML = `
    <div class="act-filters" id="actFilters"></div>
    <div id="actBody"><div class="panel"><div class="empty">Loading activity&hellip;</div></div></div>`;
  rpHeaderSelect('section','Activity view',[{id:'overall',label:'Overall activities'},{id:'days',label:'Per day'}],actState.view,actSetView);
  actRenderFilters();
  await actLoad();
}

function actRenderFilters(){
  const el = document.getElementById('actFilters');
  if (!el) return;
  const f = (actState.data && actState.data.filters) || {accounts:[], categories:[]};
  const sel = (v, cur) => v === cur ? 'selected' : '';
  el.innerHTML = `
    <select onchange="actState.days=this.value;actLoad()" title="Time range">
      ${[['1','Last 24 hours'],['7','Last 7 days'],['30','Last 30 days'],['90','Last 90 days'],['all','All time']]
        .map(([v,l]) => `<option value="${v}" ${sel(v, actState.days)}>${l}</option>`).join('')}
    </select>
    <select onchange="actState.user=this.value;actLoad()" title="Account">
      <option value="">All accounts</option>
      ${f.accounts.map(a => `<option value="${escapeHtml(a.value)}" ${sel(a.value, actState.user)}>${escapeHtml(a.label)}${a.email ? ' — ' + escapeHtml(a.email) : ''}</option>`).join('')}
    </select>
    <select onchange="actState.category=this.value;actLoad()" title="Category">
      <option value="">All categories</option>
      ${f.categories.map(c => `<option value="${escapeHtml(c)}" ${sel(c, actState.category)}>${escapeHtml(c)}</option>`).join('')}
    </select>
    <input type="search" placeholder="Search activity, account or email" value="${escapeHtml(actState.q)}"
      oninput="actState.q=this.value;clearTimeout(actSearchTimer);actSearchTimer=setTimeout(actLoad,350)">`;
}

function actSetView(v){
  actState.view = v;
  rpHeaderSelect('section','Activity view',[{id:'overall',label:'Overall activities'},{id:'days',label:'Per day'}],v,actSetView);
  document.querySelectorAll('.tab-bar .tab-btn').forEach(b => b.classList.toggle('active',
    (v === 'overall') === (b.textContent.trim().startsWith('Overall'))));
  actRenderBody();
}

async function actLoad(){
  const body = document.getElementById('actBody');
  if (body && !actState.data) body.innerHTML = '<div class="panel"><div class="empty">Loading activity&hellip;</div></div>';
  const res = await fetch('/api/activity?' + actQuery());
  if (!res.ok) {
    if (body) body.innerHTML = `<div class="panel"><div class="empty">${res.status === 403 ? 'Only admins can view the activity log.' : 'Could not load the activity log.'}</div></div>`;
    return;
  }
  actState.data = await res.json();
  actState.open = new Set();
  actState.openInit = false;
  actRenderFilters();
  actRenderBody();
}

function actRenderBody(){
  const body = document.getElementById('actBody');
  const d = actState.data;
  if (!body || !d) return;
  if (!d.overall.total) {
    body.innerHTML = `<div class="panel"><div class="empty">No activity recorded for these filters yet. Actions such as sign-ins, uploads, edits, reviews and downloads will appear here, tagged to the account that did them.</div></div>`;
    return;
  }
  body.innerHTML = actState.view === 'overall' ? actOverallHtml(d) : actDaysHtml(d);
}

function actOverallHtml(d){
  const o = d.overall;
  const maxCat = Math.max(...o.by_category.map(c => c.count), 1);
  const catRows = o.by_category.map(c => {
    const col = ACT_COLORS[c.category] || 'blue';
    return `<div class="act-bar-row"><span>${escapeHtml(c.category)}</span>
      <div class="act-bar"><i style="width:${Math.max(3, c.count / maxCat * 100)}%;background:var(--${col});"></i></div>
      <b style="text-align:right;">${c.count}</b></div>`;
  }).join('');
  const acctRows = o.by_account.map(a => `<tr>
      <td><div class="act-acct">${escapeHtml(a.account)}</div><div class="act-sub">${escapeHtml(a.email || (a.role === 'guest' ? 'Not signed in' : ''))}${a.role ? ' · ' + escapeHtml(a.role) : ''}</div></td>
      <td style="text-align:right;"><b>${a.count}</b></td>
      <td style="text-align:right;">${a.active_days}</td>
      <td>${a.categories.slice(0, 4).map(c => actChip(c.category) + ' <span class="act-sub">' + c.count + '</span>').join(' ')}</td>
      <td class="act-time">${actFmtStamp(a.last_at)}</td></tr>`).join('');
  return `
    <div class="stat-grid">
      <div class="panel stat-card"><div class="stat-card-body"><div class="stat-label">Total activities</div><div class="stat-value">${o.total}</div></div></div>
      <div class="panel stat-card"><div class="stat-card-body"><div class="stat-label">Active accounts</div><div class="stat-value">${o.accounts_active}</div></div></div>
      <div class="panel stat-card"><div class="stat-card-body"><div class="stat-label">Days with activity</div><div class="stat-value">${d.days.length}</div></div></div>
      <div class="panel stat-card"><div class="stat-card-body"><div class="stat-label">Latest activity</div><div class="stat-value" style="font-size:12.5px;">${actFmtStamp(o.last_at)}</div></div></div>
    </div>
    <div class="act-grid">
      <div class="panel"><div class="panel-head"><h2>By category</h2></div>${catRows}</div>
      <div class="panel"><div class="panel-head"><h2>Most recent activity</h2></div>
        ${actEntriesTable(d.days.flatMap(x => x.entries).slice(0, 8), true)}</div>
    </div>
    <div class="panel"><div class="panel-head"><h2>By account</h2></div>
      <div style="overflow-x:auto;"><table>
        <thead><tr><th>Account</th><th style="text-align:right;">Activities</th><th style="text-align:right;">Active days</th><th>What they did</th><th>Last active</th></tr></thead>
        <tbody>${acctRows}</tbody></table></div></div>`;
}

function actEntriesTable(entries, withDate){
  if (!entries.length) return '<div class="empty">Nothing to show.</div>';
  return `<div style="overflow-x:auto;"><table>
    <thead><tr><th>${withDate ? 'When' : 'Time'}</th><th>Account</th><th>Category</th><th>Activity</th><th>Company</th><th>Detail</th></tr></thead>
    <tbody>${entries.map(e => `<tr>
      <td class="act-time">${withDate ? actFmtStamp(e.at) : escapeHtml(e.time_local)}</td>
      <td><div class="act-acct">${escapeHtml(e.account)}</div><div class="act-sub">${escapeHtml(e.email || '')}</div></td>
      <td>${actChip(e.category)}</td>
      <td>${escapeHtml(e.label)}</td>
      <td>${e.company ? escapeHtml(e.company) + (e.fiscal_year ? ' <span class="act-sub">' + escapeHtml(e.fiscal_year) + '</span>' : '') : '<span class="act-sub">—</span>'}</td>
      <td class="act-sub" style="max-width:340px;">${escapeHtml(e.detail || '')}</td></tr>`).join('')}</tbody></table></div>`;
}

function actToggleDay(date){
  if (actState.open.has(date)) actState.open.delete(date); else actState.open.add(date);
  actState.openInit = true;
  actRenderBody();
}

function actDaysHtml(d){
  if (!actState.openInit && d.days.length) { actState.open.add(d.days[0].date); }
  return d.days.map(day => {
    const open = actState.open.has(day.date);
    return `<div class="act-day">
      <div class="act-day-head" onclick="actToggleDay('${day.date}')">
        <span class="act-caret">${open ? '▾' : '▸'}</span>
        <span class="act-day-date">${escapeHtml(actFmtDay(day.date))}</span>
        <span class="act-day-count">${day.total} ${day.total === 1 ? 'activity' : 'activities'}</span>
        <span>${day.by_category.slice(0, 5).map(c => actChip(c.category) + ' <span class="act-sub">' + c.count + '</span>').join(' ')}</span>
        <span class="act-sub" style="margin-left:auto;">${day.by_account.map(a => escapeHtml(a.account) + ' (' + a.count + ')').join(' · ')}</span>
      </div>
      ${open ? `<div class="act-day-body">${actEntriesTable(day.entries, false)}
        ${day.entries_truncated ? '<div class="act-sub" style="padding-top:8px;">Showing the newest entries for this day — export the CSV for the full list.</div>' : ''}</div>` : ''}
    </div>`;
  }).join('');
}

// The app works in full financial years only: half-year / quarterly labels (H1 2025, Q3 2025,
// Interim ...) are never offered in any year selector.
function isFullYear(y){ return !!y && !/(^|[^A-Za-z])(H[12]|[12]H|HY|Q[1-4]|half|interim|semi)/i.test(String(y)); }
function fullYears(list){ return (list || []).filter(isFullYear); }

async function safeJson(res, fallback){
  // Never blindly call res.json() on a fetch result: a 500 (or any
  // non-2xx) response can come back as an HTML error page, and parsing
  // that as JSON throws "Unexpected token '<'" and kills the caller.
  // Returning a fallback instead lets the rest of the page still render.
  if (!res.ok) {
    console.error('Request failed:', res.status, res.url);
    return fallback;
  }
  try {
    return await res.json();
  } catch (err) {
    console.error('Invalid JSON from', res.url, err);
    return fallback;
  }
}

// ---------- Survey Administration Timeline ----------
// Every number here is derived from data the app really holds (survey rows, field review
// progress, import jobs) - there is no separate stage-tracking table. A company's "stage" is the
// furthest stage it has evidence for; the step counts are cumulative ("reached this stage").
const SURVEY_STAGES = [
  {icon:'🏢', title:'1. Company Setup',      short:'Company Setup',      def:'The company is on file.'},
  {icon:'📄', title:'2. Data Collection',    short:'Data Collection',    def:'Survey data has been imported or extracted from a report.'},
  {icon:'✔️', title:'3. Data Validation',    short:'Data Validation',    def:'Survey data is on file and the latest import did not fail or score low.'},
  {icon:'👤', title:'4. Analyst Review',     short:'Analyst Review',     def:'An analyst has reviewed at least one extracted field.'},
  {icon:'✅', title:'5. Final Approval',     short:'Final Approval',     def:'Every extracted field has been reviewed.'},
  {icon:'📋', title:'6. Report Generation',  short:'Report Generation',  def:'Approved and ready for report generation.'},
];

function computeSurveyStages(companies, surveyCompanies, importJobs){
  const surveyBy = {};
  surveyCompanies.forEach(sc => { surveyBy[sc.company_id] = sc; });
  const latestImport = {};
  importJobs.forEach(j => { if (j.company_id && !latestImport[j.company_id]) latestImport[j.company_id] = j; });
  const rows = companies.map(c => {
    const sc = surveyBy[c.id] || null;
    const imp = latestImport[c.id];
    const attention = !!(imp && (imp.status === 'failed' || imp.needs_attention === true || imp.extraction_score_low === true ||
      (typeof imp.extraction_score === 'number' && imp.extraction_score < 70)));
    let stage = 1;
    if (sc) {
      stage = 2;
      if (!attention) {
        stage = 3;
        if (sc.review_progress_pct > 0) stage = 4;
        if (sc.review_status === 'completed') stage = 6;
      }
    }
    return {company: c, sc, stage, attention};
  });
  // counts[i] = companies that have reached stage i+1 or later; here[i] = companies currently AT stage i+1
  const counts = SURVEY_STAGES.map((_, i) => rows.filter(r => r.stage >= i + 1).length);
  const here = SURVEY_STAGES.map((_, i) => rows.filter(r => r.stage === i + 1).length);
  return {rows, counts, here, attention: rows.filter(r => r.attention).length};
}

let tlData = null;
let tlFilter = null; // null = all, 1..6 = currently at that stage, 'attention'

function openSurveyTimeline(stage){
  tlFilter = stage || null;
  goTo('survey-timeline', true);
}

async function renderSurveyTimelinePage(){
  const app = document.getElementById('app');
  if (window.currentUser.role !== 'admin') { goTo('overview'); return; }
  const [cRes, sRes, jRes, aRes] = await Promise.all([
    fetch('/api/companies'), fetch('/api/survey/companies'), fetch('/api/import-jobs'), fetch('/api/survey/activity?limit=15')
  ]);
  const companies = await safeJson(cRes, []);
  const surveyCompanies = await safeJson(sRes, []);
  const importJobs = await safeJson(jRes, []);
  const activity = await safeJson(aRes, []);
  tlData = {companies, stages: computeSurveyStages(companies, surveyCompanies, importJobs), activity};
  drawSurveyTimeline();
}

function setTimelineFilter(f){
  tlFilter = (tlFilter === f) ? null : f;
  drawSurveyTimeline();
}

function drawSurveyTimeline(){
  const app = document.getElementById('app');
  if (!tlData) return;
  const {companies, stages, activity} = tlData;
  const tones = ['blue','green','amber','purple','teal','pink'];

  const steps = SURVEY_STAGES.map((st, i) => `
    <div class="ov-timeline-step tl-step ${tlFilter === i + 1 ? 'active' : ''}" onclick="setTimelineFilter(${i + 1})" title="${escapeHtml(st.def)}">
      <div class="ov-timeline-icon" style="${statTone(tones[i % 6])}">${st.icon}</div>
      <div class="ov-timeline-title">${escapeHtml(st.title)}</div>
      <div class="ov-timeline-count">${stages.counts[i]} of ${companies.length} reached</div>
      <div class="tl-here">${stages.here[i]} currently here</div>
    </div>`).join('');

  let rows = stages.rows.slice();
  if (tlFilter === 'attention') rows = rows.filter(r => r.attention);
  else if (tlFilter) rows = rows.filter(r => r.stage === tlFilter);
  rows.sort((a, b) => (a.stage - b.stage) || a.company.name.localeCompare(b.company.name));

  const tableRows = rows.map(r => {
    const dots = SURVEY_STAGES.map((_, i) => `<span class="tl-dot ${i < r.stage ? (r.attention ? 'flag' : 'on') : ''}"></span>`).join('');
    const label = SURVEY_STAGES[r.stage - 1].short;
    const pill = r.attention ? `<span class="ov-status-pill failed">Needs attention</span>`
      : `<span class="ov-status-pill ${r.stage >= 5 ? 'completed' : r.stage >= 3 ? 'in-progress' : 'pending'}">${escapeHtml(label)}</span>`;
    const pct = r.sc ? r.sc.review_progress_pct : 0;
    const upd = r.sc && r.sc.last_updated
      ? new Date(r.sc.last_updated).toLocaleDateString('en-US', {year:'numeric', month:'short', day:'numeric'}) : naSpan('\u2014');
    return `
      <tr class="clickable" title="${r.sc && window.currentUser.role === 'admin' ? 'Open the review page' : 'Open the survey report'}" onclick="${r.sc && window.currentUser.role === 'admin' ? `openFieldReview(${r.company.id})` : `goToCompanySurveyData(${r.company.id})`}">
        <td>${escapeHtml(r.company.name)}</td>
        <td>${escapeHtml(r.company.sector || '-')}</td>
        <td><span class="tl-track" title="Stage ${r.stage} of 6">${dots}</span>${pill}</td>
        <td><span class="ov-mini-bar-track"><span class="ov-mini-bar-fill" style="width:${pct}%;background:var(--blue);"></span></span>${pct}%</td>
        <td style="color:var(--text-faint);font-size:11.5px;">${upd}</td>
      </tr>`;
  }).join('');

  const iconMap = {
    survey_uploaded:['📤'], survey_updated:['✏️'], survey_pdf_extracted:['📄'], field_approved:['✅'],
    field_rejected:['⚠️'], field_corrected:['✏️'], committees_updated:['🛡️'],
  };
  const events = activity.map(a => {
    const icon = (iconMap[a.action] || ['•'])[0];
    const co = companies.find(c => c.id === a.company_id);
    const label = a.detail || String(a.action || '').replace(/_/g, ' ');
    const when = a.created_at ? new Date(a.created_at).toLocaleDateString('en-US', {month:'short', day:'numeric', hour:'numeric', minute:'2-digit'}) : '';
    return `
      <div class="ov-activity-item">
        <div class="ov-activity-icon" style="background:var(--blue-soft);color:var(--blue);">${icon}</div>
        <div>
          <div class="ov-activity-label">${escapeHtml(label)}${co ? ' \u2014 ' + escapeHtml(co.name) : ''}</div>
          <div class="ov-activity-meta">${a.actor ? 'By ' + escapeHtml(a.actor) : ''}${a.actor && when ? ' \u00b7 ' : ''}${when}</div>
        </div>
      </div>`;
  }).join('');

  const filterLabel = tlFilter === 'attention' ? 'needing attention'
    : tlFilter ? 'currently at ' + SURVEY_STAGES[tlFilter - 1].short : 'all companies';

  app.innerHTML = `
    <span class="ov-panel-link tl-back" onclick="goTo('overview')">&larr; Back to Dashboard Overview</span>
    <div class="panel ov-boxed">
      <div class="ov-panel-head"><h2>Where each company stands</h2></div>
      <div class="ov-timeline">${steps}</div>
      <div class="tl-chips">
        <button class="tl-chip ${tlFilter === null ? 'active' : ''}" onclick="tlFilter=null;drawSurveyTimeline()">All companies (${companies.length})</button>
        <button class="tl-chip ${tlFilter === 'attention' ? 'active' : ''}" onclick="setTimelineFilter('attention')">Needs attention (${stages.attention})</button>
        <span style="font-size:11px;color:var(--text-faint);">Click a stage above to see only the companies currently at it.</span>
      </div>
      <div class="tl-def">Stages are worked out from the data on file: survey data imported, the latest import result, and how many extracted fields an analyst has reviewed. Hand-typed survey data has nothing to review, so it counts as fully reviewed.</div>
    </div>

    <div class="ov-row" style="grid-template-columns:1.7fr 1fr;margin-top:14px;">
      <div class="panel ov-boxed">
        <div class="ov-panel-head"><h2>Companies \u2014 ${escapeHtml(filterLabel)} (${rows.length})</h2></div>
        ${rows.length ? `
        <table>
          <thead><tr><th>Company</th><th>Sector</th><th>Stage</th><th>Review</th><th>Last Updated</th></tr></thead>
          <tbody>${tableRows}</tbody>
        </table>` : `<div class="empty">No companies match this filter.</div>`}
      </div>
      <div class="panel ov-boxed">
        <div class="ov-panel-head"><h2>Latest activity</h2></div>
        ${events || `<div class="empty">No recorded activity yet.</div>`}
      </div>
    </div>`;
}


async function renderOverview(){
  // Survey Administration Dashboard - rebuilt from user's design image
  // (2026-09-12). REAL data wired in: total companies, sector breakdown
  // (derived from /api/companies), the survey company list/fiscal
  // years (from /api/survey/companies), Data Quality Overview (from
  // /api/survey/data-quality), and (added 2026-09-16) real per-company
  // review status/progress and a real Recent Activities feed - both
  // now backed by ActivityLogEntry and field_review_status (see
  // list_survey_companies/survey_activity_feed/log_activity in
  // app.py). Still honestly unavailable: Analyst Workload - this app
  // has no user/authentication system anywhere in its backend, so
  // there is no real "analyst" identity to assign work to or measure;
  // building that would mean inventing a user model and auth flow
  // that isn't a data-mapping fix, it's a separate feature decision.
  const [companiesRes, surveyCompaniesRes, dataQualityRes, importJobsRes] = await Promise.all([
    fetch('/api/companies'), fetch('/api/survey/companies'), fetch('/api/survey/data-quality'),
    fetch('/api/import-jobs')
  ]);
  const companies = await safeJson(companiesRes, []);
  const surveyCompanies = await safeJson(surveyCompaniesRes, []);
  const dataQuality = await safeJson(dataQualityRes, {has_data: false});
  const importJobs = await safeJson(importJobsRes, []);
  const app = document.getElementById('app');

  const sub = document.getElementById('pageSub');
  if (sub) sub.textContent = 'Track survey progress, manage companies, monitor data quality and oversee analyst activities.';

  setPageActions([
    {label: 'Upload Annual Reports', icon: '⭱', perm: 'admin', onClick: 'openUploadReportsModal()'},
    {label: 'Documents & Reports', icon: '🗂️', perm: 'user', onClick: "goTo('documents')"},
  ]);

  const totalCompanies = companies.length;

  // ---- Real: sector breakdown from actual companies on file ----
  const sectorCounts = {};
  companies.forEach(c => {
    const sec = c.sector || 'Unclassified';
    sectorCounts[sec] = (sectorCounts[sec] || 0) + 1;
  });
  const sectorEntries = Object.entries(sectorCounts).sort((a,b) => b[1]-a[1]);
  const sectorColors = ['#48cfa0','#3ddc84','#ffb020','#ff6161','#b79bfc','#22d3ee','#f472b6','#a3e635','#fb923c','#94b8a6'];
  let sectorDonutStyle = 'background:var(--bg-panel-2);';
  if (totalCompanies > 0) {
    let acc = 0;
    const stops = sectorEntries.map(([name, count], i) => {
      const start = acc / totalCompanies * 360;
      acc += count;
      const end = acc / totalCompanies * 360;
      return `${sectorColors[i % sectorColors.length]} ${start}deg ${end}deg`;
    });
    sectorDonutStyle = `background:conic-gradient(${stops.join(', ')});`;
  }
  const sectorLegend = sectorEntries.map(([name, count], i) => `
    <div class="ov-sector-legend-item">
      <span class="dot" style="background:${sectorColors[i % sectorColors.length]};"></span>
      <span class="name">${escapeHtml(name)}</span>
      <span>${count}</span>
      <span class="pct">${totalCompanies ? Math.round(count/totalCompanies*100) : 0}%</span>
    </div>`).join('');

  // ---- REAL (2026-09-16): per-company review status/progress, from
  // /api/survey/companies - see that route's own docstring for exactly
  // how "Completed"/"In Progress"/"Pending Review" and the progress %
  // are derived from field_review_status vs field_confidence. ----
  const surveyByCompanyId = {};
  surveyCompanies.forEach(sc => { surveyByCompanyId[sc.company_id] = sc; });

  // The KPI cards combine the two real workflow sources in this app:
  // field-level survey review state and the import-job audit trail. A
  // company with no SurveyCompanyData row is still counted as pending data,
  // while a failed import or low extraction score is surfaced as attention
  // rather than silently disappearing from the dashboard.
  const latestImportByCompanyId = {};
  importJobs.forEach(job => {
    if (job.company_id && !latestImportByCompanyId[job.company_id]) {
      latestImportByCompanyId[job.company_id] = job;
    }
  });
  const statusCounts = {completed: 0, inProgress: 0, pending: 0, attention: 0};
  companies.forEach(company => {
    const survey = surveyByCompanyId[company.id];
    const latestImport = latestImportByCompanyId[company.id];
    const lowScore = latestImport && (
      latestImport.needs_attention === true ||
      latestImport.extraction_score_low === true ||
      (typeof latestImport.extraction_score === 'number' && latestImport.extraction_score < 70)
    );
    if (latestImport && (latestImport.status === 'failed' || lowScore)) {
      statusCounts.attention++;
    } else if (survey && survey.review_status === 'completed') {
      statusCounts.completed++;
    } else if (
      (survey && survey.review_status === 'in-progress') ||
      (latestImport && ['pending', 'parsed', 'reviewed'].includes(latestImport.status))
    ) {
      statusCounts.inProgress++;
    } else {
      // This includes companies with no survey row yet and rows that have
      // extracted fields waiting for someone to review them.
      statusCounts.pending++;
    }
  });

  const companyRows = companies.slice(0, 8).map(c => {
    const sc = surveyByCompanyId[c.id];
    if (!sc) {
      return `
        <tr class="clickable" onclick="goToCompanySurveyData(${c.id})">
          <td>${escapeHtml(c.name)}</td>
          <td>${escapeHtml(c.sector || '-')}</td>
          <td><span class="ov-status-pill pending">No Survey Data</span></td>
          <td style="color:var(--text-faint);font-size:11.5px;">${naSpan('\u2014')}</td>
          <td><span class="ov-mini-bar-track"><span class="ov-mini-bar-fill" style="width:0%;background:var(--text-faint);"></span></span>0%</td>
        </tr>`;
    }
    const statusLabel = sc.review_status === 'completed' ? 'Completed' : sc.review_status === 'in-progress' ? 'In Progress' : 'Pending Review';
    const barColor = sc.review_status === 'completed' ? 'var(--green)' : sc.review_status === 'in-progress' ? 'var(--blue)' : 'var(--amber)';
    const lastUpdated = sc.last_updated ? new Date(sc.last_updated).toLocaleDateString('en-US', {year:'numeric', month:'short', day:'numeric'}) : naSpan('\u2014');
    return `
      <tr class="clickable" title="${window.currentUser.role === 'admin' ? 'Open the review page' : 'Open the survey report'}" onclick="${window.currentUser.role === 'admin' ? `openFieldReview(${c.id})` : `goToCompanySurveyData(${c.id})`}">
        <td>${escapeHtml(c.name)}</td>
        <td>${escapeHtml(c.sector || '-')}</td>
        <td><span class="ov-status-pill ${sc.review_status}">${statusLabel}</span></td>
        <td style="color:var(--text-faint);font-size:11.5px;">${lastUpdated}</td>
        <td><span class="ov-mini-bar-track"><span class="ov-mini-bar-fill" style="width:${sc.review_progress_pct}%;background:${barColor};"></span></span>${sc.review_progress_pct}%</td>
      </tr>`;
  }).join('');

  // ---- REAL (2026-09-13): data quality, from /api/survey/data-quality
  // (build_portfolio_data_quality() in survey_aggregate.py) - complete/
  // needs-review/missing field counts across every company's latest
  // survey data row, using the same per-field confidence logic Survey
  // Report's Data Quality tab applies to one company at a time. ----
  const dq = {complete: dataQuality.complete || 0, missing: dataQuality.missing || 0, partial: dataQuality.needs_review || 0};
  const dqTotal = dataQuality.total_fields || 0;

  const stageInfo = computeSurveyStages(companies, surveyCompanies, importJobs);
  const timelineSteps = SURVEY_STAGES.map((st, i) => ({icon: st.icon, title: st.title, count: stageInfo.counts[i]}));

  app.innerHTML = `
    <div class="ov-stat-grid">
      <div class="ov-stat-card">
        <div class="ov-stat-top"><div class="ov-stat-icon" style="background:var(--blue-box);color:var(--blue);border:1px solid var(--blue-line);">🏢</div><div class="ov-stat-label">Total Companies</div></div>
        <div class="ov-stat-value">${totalCompanies}</div>
        <div class="ov-stat-sub">Across all sectors</div>
      </div>
      <div class="ov-stat-card">
        <div class="ov-stat-top"><div class="ov-stat-icon" style="background:var(--green-box);color:var(--green);border:1px solid var(--green-line);">✅</div><div class="ov-stat-label">Completed Surveys</div></div>
        <div class="ov-stat-value">${statusCounts.completed}</div>
        <div class="ov-stat-sub">${totalCompanies ? Math.round(statusCounts.completed/totalCompanies*100) : 0}% completion rate</div>
        <div class="ov-stat-bar-track"><div class="ov-stat-bar-fill" style="width:${totalCompanies ? Math.round(statusCounts.completed/totalCompanies*100) : 0}%;background:var(--green);"></div></div>
      </div>
      <div class="ov-stat-card">
        <div class="ov-stat-top"><div class="ov-stat-icon" style="background:var(--amber-box);color:var(--amber);border:1px solid var(--amber-line);">⏱️</div><div class="ov-stat-label">In Progress</div></div>
        <div class="ov-stat-value">${statusCounts.inProgress}</div>
        <div class="ov-stat-sub">Active import or review</div>
        <div class="ov-stat-bar-track"><div class="ov-stat-bar-fill" style="width:${totalCompanies ? Math.round(statusCounts.inProgress/totalCompanies*100) : 0}%;background:var(--amber);"></div></div>
      </div>
      <div class="ov-stat-card">
        <div class="ov-stat-top"><div class="ov-stat-icon" style="background:var(--red-box);color:var(--red);border:1px solid var(--red-line);">❗</div><div class="ov-stat-label">Pending Review</div></div>
        <div class="ov-stat-value">${statusCounts.pending}</div>
        <div class="ov-stat-sub">Awaiting survey data or review</div>
        <div class="ov-stat-bar-track"><div class="ov-stat-bar-fill" style="width:${totalCompanies ? Math.round(statusCounts.pending/totalCompanies*100) : 0}%;background:var(--red);"></div></div>
      </div>
      <div class="ov-stat-card">
        <div class="ov-stat-top"><div class="ov-stat-icon" style="background:var(--purple-box);color:var(--purple);border:1px solid var(--purple-line);">✖️</div><div class="ov-stat-label">Failed / Needs Attention</div></div>
        <div class="ov-stat-value">${statusCounts.attention}</div>
        <div class="ov-stat-sub">Failed imports or low scores</div>
        <div class="ov-stat-bar-track"><div class="ov-stat-bar-fill" style="width:${totalCompanies ? Math.round(statusCounts.attention/totalCompanies*100) : 0}%;background:var(--purple);"></div></div>
      </div>
    </div>

    <div class="ov-row ov-row-3col">
      <div class="panel ov-boxed">
        <div class="ov-panel-head"><h2>Survey Progress by Sector</h2></div>
        ${totalCompanies > 0 ? `
        <div class="ov-donut-wrap">
          <div class="ov-donut" style="${sectorDonutStyle}">
            <div class="ov-donut-hole"><div class="n">${totalCompanies}</div><div class="l">Companies</div></div>
          </div>
          <div class="ov-sector-legend">${sectorLegend}</div>
        </div>` : `<div class="empty">Add companies to see the sector breakdown here.</div>`}
      </div>

      <div class="panel ov-boxed">
        <div class="ov-panel-head"><h2>Company Survey Status</h2></div>
        ${companyRows ? `
        <table>
          <thead><tr><th>Company</th><th>Sector</th><th>Status</th><th>Last Updated</th><th>Progress</th></tr></thead>
          <tbody>${companyRows}</tbody>
        </table>
        <div style="margin-top:10px;font-size:10.5px;color:var(--text-faint);">Status reflects field-level review activity on each company's latest survey data (see the Data Quality tab for full detail).</div>
        <span class="ov-panel-link" onclick="goTo('settings')" style="display:inline-block;margin-top:8px;">Manage companies &rarr;</span>
        ` : `<div class="empty">No companies on file yet.</div>`}
      </div>
    </div>

    <div class="ov-row ov-row-2col">
      <div class="panel ov-boxed">
        <div class="ov-panel-head"><h2>Data Quality Overview</h2><span class="ov-panel-link" onclick="goTo('data-quality')">View details &rarr;</span></div>
        ${dataQuality.has_data ? `
        <div class="ov-dq-grid">
          <div class="ov-dq-card">
            <div class="ov-dq-icon" style="background:var(--green-soft);color:var(--green);">✅</div>
            <div class="ov-dq-label">Complete Disclosures</div>
            <div class="ov-dq-value">${dq.complete}</div>
            <div class="ov-dq-sub">${dqTotal ? Math.round(dq.complete/dqTotal*100) : 0}% of total</div>
          </div>
          <div class="ov-dq-card">
            <div class="ov-dq-icon" style="background:var(--amber-soft);color:var(--amber);">⚠️</div>
            <div class="ov-dq-label">Needs Review</div>
            <div class="ov-dq-value">${dq.partial}</div>
            <div class="ov-dq-sub">${dqTotal ? Math.round(dq.partial/dqTotal*100) : 0}% of total</div>
          </div>
          <div class="ov-dq-card">
            <div class="ov-dq-icon" style="background:var(--red-soft);color:var(--red);">ℹ️</div>
            <div class="ov-dq-label">Missing Disclosures</div>
            <div class="ov-dq-value">${dq.missing}</div>
            <div class="ov-dq-sub">${dqTotal ? Math.round(dq.missing/dqTotal*100) : 0}% of total</div>
          </div>
        </div>
        <div style="margin-top:10px;font-size:10.5px;color:var(--text-faint);">Across ${dataQuality.companies_counted} compan${dataQuality.companies_counted === 1 ? 'y' : 'ies'}' latest survey data, ${dqTotal} fields tracked per company.</div>
        ` : `<div class="empty">No survey data on file yet — add company survey data from the Survey Companies page to see quality here.</div>`}
      </div>

      <div class="panel ov-boxed">
        <div class="ov-panel-head"><h2>Analyst Workload</h2></div>
        <div class="empty">${naSpan('This app has no user or authentication system, so there is no real analyst identity to assign work to or measure completion against \u2014 adding this would mean building a user/login system first, not a data-mapping fix')}</div>
      </div>

      <div class="panel ov-boxed">
        <div class="ov-panel-head"><h2>Quick Actions</h2></div>
        <div class="ov-quick-actions">
          <div class="ov-qa-card" onclick="goTo('settings')">
            <div class="ov-qa-icon" style="background:var(--blue-soft);color:var(--blue);">📄</div>
            <div><div class="ov-qa-title">Generate Report</div><div class="ov-qa-desc">Create survey progress or quality report</div></div>
          </div>
        </div>
      </div>
    </div>

    ${window.currentUser.role === 'admin' ? `<div class="panel ov-boxed">
      <div class="ov-panel-head"><h2>Survey Administration Timeline</h2><span class="ov-panel-link" onclick="openSurveyTimeline()">View timeline &rarr;</span></div>
      <div class="ov-timeline">
        ${timelineSteps.map((s, i) => `
          <div class="ov-timeline-step tl-step" onclick="openSurveyTimeline(${i + 1})" title="See companies currently at this stage">
            <div class="ov-timeline-icon" style="${statTone(['blue','green','amber','purple','teal','pink'][i % 6])}">${s.icon}</div>
            <div class="ov-timeline-title">${escapeHtml(s.title)}</div>
            <div class="ov-timeline-count">${s.count} companies</div>
          </div>`).join('')}
      </div>
      <div style="margin-top:8px;font-size:10.5px;color:var(--text-faint);">Each stage shows how many companies have reached it, worked out from the survey data and review progress on file.</div>
    </div>` : ''}
  `;
}

// Shared stat-card markup: icon square on the left, label/value/trend
// stacked to the right - used by every stat-grid across the app.
// `color` picks one of the palette tones defined on :root (blue/green/
// amber/red/purple/teal/pink) - the icon square gets that color's soft
// tint as a background and the full tone as the icon color, so different
// stats in the same row are visually distinguishable at a glance rather
// than all reading as the same flat gray square.
function statTone(color){
  const known = ['blue','green','amber','red','purple','teal','pink'];
  const c = known.includes(color) ? color : 'blue';
  return `background:var(--${c}-box);color:var(--${c});border:1px solid var(--${c}-line);`;
}
function toneVars(color){
  const known = ['blue','green','amber','red','purple','teal','pink'];
  const c = known.includes(color) ? color : 'blue';
  return `--k:var(--${c});--kb:var(--${c}-box);--kl:var(--${c}-line);`;
}
function statCard(color, icon, value, label, trendHtml){
  return `
    <div class="stat-card" style="${toneVars(color)}">
      <div class="stat-icon-square" style="${statTone(color)}">${icon}</div>
      <div class="stat-card-body">
        <div class="stat-label">${escapeHtml(label)}</div>
        <div class="stat-value">${value}</div>
        ${trendHtml || ''}
      </div>
    </div>`;
}








async function addCompany(){
  const errorEl = document.getElementById('add-company-error');
  errorEl.textContent = '';
  const payload = {
    name: document.getElementById('f-name').value,
    ticker: document.getElementById('f-ticker').value,
    exchange: document.getElementById('f-exchange').value,
    sector: document.getElementById('f-sector').value,
    country: document.getElementById('f-country').value
  };
  const res = await fetch('/api/companies', {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!res.ok) { errorEl.textContent = data.error || 'Failed to add company'; return; }
  closeAddCompanyModal();
  render();
}

function openAddCompanyModal(){
  document.getElementById('add-company-error').textContent = '';
  ['f-name','f-ticker','f-exchange','f-sector'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('f-country').value = 'Kenya';
  document.getElementById('addCompanyModal').classList.add('open');
}
function closeAddCompanyModal(){
  document.getElementById('addCompanyModal').classList.remove('open');
}

/* ---------- MULTI-FILE ANNUAL REPORT UPLOAD ---------- */

const UPLOAD_MAX_FILES = 10;
// No total-size cap - only the file-count cap above applies. A batch of
// real integrated reports can comfortably exceed any fixed MB number
// (dense annual reports commonly run past 15-20 MB each), and the
// backend (app.py) no longer enforces one either.
let uploadReportsFiles = [];
// When set, every file in the batch is saved straight to this company
// (no auto-detection/matching) - set by openUploadReportsModal(companyId)
// from the Company Detail page; left null for the general, multi-company
// upload entry point on the Companies page.
let uploadReportsCompanyId = null;
let uploadReportsCompanyName = null;

function openUploadReportsModal(companyId, companyName){
  uploadReportsFiles = [];
  uploadReportsCompanyId = companyId || null;
  uploadReportsCompanyName = companyName || null;
  document.querySelector('#uploadReportsModal .modal-box').classList.remove('upload-activity-only');
  ['uploadReportsDesc', 'uploadReportsInput', 'uploadReportsFileList',
   'uploadReportsSubmitBtn', 'uploadReportsProgressWrap',
   'uploadReportsStatus', 'uploadReportsResults'].forEach(id => {
    document.getElementById(id).style.display = '';
  });
  document.getElementById('uploadBackendLogWrap').style.display = 'none';
  document.getElementById('uploadReportsInput').value = '';
  document.getElementById('uploadReportsFileList').innerHTML = '';
  document.getElementById('uploadBackendLog').innerHTML = '';
  document.getElementById('uploadBackendTimer').textContent = '0.0s';
  document.getElementById('uploadReportsStatus').textContent = '';
  document.getElementById('uploadReportsResults').innerHTML = '';
  document.getElementById('uploadReportsSubmitBtn').disabled = true;
  document.getElementById('uploadReportsSubmitBtn').textContent = 'Upload & Save';
  document.getElementById('uploadReportsProgressWrap').style.display = 'none';

  const titleEl = document.getElementById('uploadReportsTitle');
  const descEl = document.getElementById('uploadReportsDesc');
  if (uploadReportsCompanyId) {
    titleEl.textContent = `Upload Documents — ${uploadReportsCompanyName || 'this company'}`;
    descEl.textContent = `Select up to ${UPLOAD_MAX_FILES} annual report or financial statement PDFs for ` +
      `${uploadReportsCompanyName || 'this company'}. Each file's fiscal year is detected automatically and ` +
      `saved directly to this company - no company matching, so it can't be attributed to the wrong one. ` +
      `Re-uploading a report for a year already on file updates that period instead of duplicating it.`;
  } else {
    titleEl.textContent = 'Upload Annual Reports';
    descEl.textContent = `Select up to ${UPLOAD_MAX_FILES} annual report PDFs — any mix of companies and years. ` +
      `Each file is auto-identified by its own content (company name, fiscal year) and saved directly, no review ` +
      `step. Re-uploading a report for a company/year already on file updates that period instead of duplicating it.`;
  }
  document.getElementById('uploadReportsModal').classList.add('open');
}
function closeUploadReportsModal(){
  document.getElementById('uploadReportsModal').classList.remove('open');
}

function onUploadReportsFilesChosen(fileList){
  const chosen = Array.from(fileList);
  const listEl = document.getElementById('uploadReportsFileList');
  const submitBtn = document.getElementById('uploadReportsSubmitBtn');

  if (chosen.length > UPLOAD_MAX_FILES) {
    uploadReportsFiles = chosen.slice(0, UPLOAD_MAX_FILES);
    listEl.innerHTML = `<div style="color:var(--red,#c0392b);margin-bottom:4px;">
        You selected ${chosen.length} files — only the first ${UPLOAD_MAX_FILES} will be uploaded.
        Do the rest in a second batch.</div>` +
      uploadReportsFiles.map(f => `<div>📄 ${escapeHtml(f.name)} <span style="color:var(--text-secondary,#666);">(${(f.size/1024/1024).toFixed(1)} MB)</span></div>`).join('');
  } else {
    uploadReportsFiles = chosen;
  }

  if (!uploadReportsFiles.length) {
    listEl.innerHTML = '';
    submitBtn.disabled = true;
    return;
  }

  const totalBytes = uploadReportsFiles.reduce((sum, f) => sum + f.size, 0);
  const header = chosen.length > UPLOAD_MAX_FILES ? '' :
    `<div style="color:var(--text-secondary,#666);margin-bottom:4px;">` +
    `${uploadReportsFiles.length} of ${UPLOAD_MAX_FILES} file(s) selected — ${_formatBytes(totalBytes)} total:</div>`;
  listEl.innerHTML = header +
    uploadReportsFiles.map(f => `<div>📄 ${escapeHtml(f.name)} <span style="color:var(--text-secondary,#666);">(${(f.size/1024/1024).toFixed(1)} MB)</span></div>`).join('');
  submitBtn.disabled = false;
}

function _formatBytes(bytes){
  if (bytes >= 1024*1024) return (bytes/1024/1024).toFixed(1) + ' MB';
  if (bytes >= 1024) return (bytes/1024).toFixed(0) + ' KB';
  return bytes + ' B';
}
function _formatEta(seconds){
  if (!isFinite(seconds) || seconds < 0) return '';
  if (seconds < 1) return '<1s left';
  if (seconds < 60) return `${Math.ceil(seconds)}s left`;
  return `${Math.floor(seconds/60)}m ${Math.round(seconds%60)}s left`;
}

function collapseUploadPromptToActivity(){
  const modalBox = document.querySelector('#uploadReportsModal .modal-box');
  modalBox.classList.add('upload-activity-only');
  document.getElementById('uploadReportsTitle').textContent = 'Backend activity';
  ['uploadReportsDesc', 'uploadReportsInput', 'uploadReportsFileList',
   'uploadReportsSubmitBtn', 'uploadReportsProgressWrap',
   'uploadReportsStatus', 'uploadReportsResults'].forEach(id => {
    document.getElementById(id).style.display = 'none';
  });
  document.getElementById('uploadBackendLogWrap').style.display = 'block';
}

// Renders the same {results, saved, failed} shape whether it arrived via
// the SSE 'batch_done' event or the /result polling fallback - the two
// paths must agree on what the user sees, so this is the one place either
// of them calls to finish the job.
function renderUploadBatchResults(data){
  const statusEl = document.getElementById('uploadReportsStatus');
  const resultsEl = document.getElementById('uploadReportsResults');
  statusEl.style.display = 'block';
  const queued = (data.results || []).filter(r => r.review).length;
  statusEl.textContent = queued
    ? `${queued} file(s) queued for review - nothing is saved until you approve them.${data.saved ? ' ' + data.saved + ' saved.' : ''} ${data.failed} failed.`
    : `Done: ${data.saved} saved, ${data.failed} failed.`;
  resultsEl.innerHTML = (data.results || []).map(r => {
    if (r.ok && r.review) {
      return `<div style="padding:6px 0;border-bottom:1px solid var(--border,#eee);">🕒 <strong>${escapeHtml(r.filename)}</strong> — queued for review.
        <a href="#" onclick="closeUploadReportsModal();openReview('uploads');return false;">Open Review</a></div>`;
    }
    if (r.ok) {
      return `<div style="padding:6px 0;border-bottom:1px solid var(--border,#eee);">
        ✅ <strong>${escapeHtml(r.filename)}</strong> → ${escapeHtml(r.company_name || 'Unknown')}
        (${escapeHtml(r.period)})${r.created_company ? ' <span style="color:var(--amber,#b8860b);">— new company created</span>' : ''}
        ${r.match_score !== undefined && r.match_score !== null && !uploadReportsCompanyId ? `<span style="color:var(--text-secondary,#666);"> · match ${(r.match_score*100).toFixed(0)}%</span>` : ''}
      </div>`;
    }
    return `<div style="padding:6px 0;border-bottom:1px solid var(--border,#eee);color:var(--red,#c0392b);">
      ❌ <strong>${r.filename ? escapeHtml(r.filename) : 'Batch'}</strong> — ${escapeHtml(r.error || 'Unknown error')}
    </div>`;
  }).join('');
  if (data.saved > 0 && currentPage === 'settings') {
    renderSettingsCompaniesPanel();
    renderSettingsActivityPanel();
  }
}

// Fallback for when the SSE connection drops before 'batch_done' ever
// arrives (flaky connection, a proxy that kills idle GETs, phone locks and
// the browser suspends the tab, etc.) - without this, a dropped stream on
// a many-minute batch would leave the user staring at a stalled log with
// no way to ever learn whether the upload finished. Polls every 5s, up to
// 40 minutes (10 files at ~3-4 min each, plus margin), then gives up with
// an honest message rather than polling forever.
async function pollBatchResultFallback(batchId, onDone, isSettled){
  // Safety net beside the live log: asks the server every 5 s whether the batch has finished. It stops as
  // soon as the live log (or this poll) settles the batch. A run the server no longer knows about means
  // the server restarted mid-batch, and that run is gone - say so instead of waiting the full 40 minutes.
  const maxAttempts = 480; // 480 * 5s = 40 minutes
  let unknownStreak = 0;
  for (let i = 0; i < maxAttempts; i++) {
    await new Promise(r => setTimeout(r, 5000));
    if (isSettled && isSettled()) return;
    try {
      const res = await fetch(`/api/import/upload-batch/${batchId}/result`);
      const data = await res.json();
      if (data.done) { onDone(data, null); return; }
      unknownStreak = data.unknown ? unknownStreak + 1 : 0;
      if (unknownStreak >= 3) {
        onDone(null, 'The server restarted while this batch was running, so it stopped part-way. Files that finished before the restart are saved (see Import Activity); upload the rest again.');
        return;
      }
    } catch (e) { /* transient network hiccup - just try again next tick */ }
  }
  onDone(null, 'Lost track of this upload — it may still be running on the server. Check Import Activity in a few minutes.');
}

async function submitUploadReports(){
  if (!uploadReportsFiles.length) return;
  const statusEl = document.getElementById('uploadReportsStatus');
  const resultsEl = document.getElementById('uploadReportsResults');
  const btn = document.getElementById('uploadReportsSubmitBtn');
  const progWrap = document.getElementById('uploadReportsProgressWrap');
  const progBar = document.getElementById('uploadReportsProgressBar');
  const progPct = document.getElementById('uploadReportsProgressPct');
  const progSpeed = document.getElementById('uploadReportsProgressSpeed');
  const progEta = document.getElementById('uploadReportsProgressEta');
  const logWrap = document.getElementById('uploadBackendLogWrap');
  const logEl = document.getElementById('uploadBackendLog');
  const timerEl = document.getElementById('uploadBackendTimer');

  btn.disabled = true;
  btn.textContent = 'Uploading...';
  statusEl.textContent = `Uploading ${uploadReportsFiles.length} file(s)...`;
  resultsEl.innerHTML = '';
  progWrap.style.display = 'block';
  progBar.style.width = '0%';
  progPct.textContent = '0%';
  progSpeed.textContent = '';
  progEta.textContent = '';
  logWrap.style.display = 'none';
  logEl.innerHTML = '';

  const fd = new FormData();
  uploadReportsFiles.forEach(f => fd.append('files', f));
  if (uploadReportsCompanyId) fd.append('company_id', uploadReportsCompanyId);

  // batch_id ties this upload's own POST to the live backend-activity
  // log below - the SSE connection opens on the strength of this id
  // alone, before the POST is even sent, so no event from the very
  // first file gets missed.
  const batchId = (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`);
  fd.append('batch_id', batchId);

  const totalBytes = uploadReportsFiles.reduce((sum, f) => sum + f.size, 0);
  const startedAt = Date.now();

  // Live backend-stage log - what's shown here is exactly what the
  // server emits, stage by stage, as it genuinely reaches that point in
  // processing each file. Not a simulated sequence.
  const STAGE_LABELS = {
    reading: 'Reading file', detecting_format: 'Detecting format',
    parsing: 'Parsing document', matching_company: 'Matching company',
    saving: 'Saving to database',
    enriching: 'Extracting supplementary filing sections',
    scoring: 'Scoring extraction quality',
  };
  let timerHandle = null;
  let settledByPoll = false; // true once the polling fallback has already resolved this batch, so a late SSE event (or vice versa) can't finish it twice
  const logLine = (html) => {
    const row = document.createElement('div');
    row.innerHTML = html;
    logEl.appendChild(row);
    logEl.scrollTop = logEl.scrollHeight;
  };
  const fmtTime = (iso) => { try { return new Date(iso).toLocaleTimeString(); } catch(e) { return ''; } };
  // Elapsed time: under a minute -> "42.3s"; from 60s -> "1m 05s"; from an hour -> "1h 02m 05s".
  const fmtElapsed = (secs) => {
    secs = Number(secs);
    if (!isFinite(secs) || secs < 0) return '';
    if (secs < 59.95) return secs.toFixed(1) + 's';
    const total = Math.floor(secs);
    const h = Math.floor(total / 3600), m = Math.floor((total % 3600) / 60), sec = total % 60;
    const pad = n => String(n).padStart(2, '0');
    return h ? `${h}h ${pad(m)}m ${pad(sec)}s` : `${m}m ${pad(sec)}s`;
  };
  const es = new EventSource(`/api/upload-progress/${batchId}`);
  logWrap.style.display = 'block';
  timerHandle = setInterval(() => {
    timerEl.textContent = fmtElapsed((Date.now() - startedAt) / 1000);
  }, 100);

  const finish = (ok, message) => {
    btn.disabled = false;
    btn.textContent = 'Upload & Save';
    if (!ok) {
      statusEl.style.display = 'block';
      statusEl.textContent = message;
    }
    clearInterval(timerHandle);
    es.close();
  };

  es.onmessage = (evt) => {
    let e; try { e = JSON.parse(evt.data); } catch (err) { return; }
    const t = fmtTime(e.ts);
    if (e.type === 'batch_start') {
      logLine(`<span style="color:var(--text-faint);">[${t}]</span> Starting batch — ${e.file_count} file(s)`);
    } else if (e.type === 'stage') {
      logLine(`<span style="color:var(--text-faint);">[${t}]</span> <strong>${escapeHtml(e.filename)}</strong> — ${STAGE_LABELS[e.stage] || e.stage}${e.format ? ` (${e.format})` : ''}`);
    } else if (e.type === 'file_done') {
      const scoreTxt = (e.extraction_score !== null && e.extraction_score !== undefined)
        ? ` — extraction score ${e.extraction_score}/100${e.extraction_score < 70 ? ' ⚠️ low' : ''}` : '';
      logLine(`<span style="color:var(--text-faint);">[${t}]</span> ✅ <strong>${escapeHtml(e.filename)}</strong> done in ${fmtElapsed(e.elapsed_seconds) || e.elapsed_seconds + 's'}${scoreTxt}`);
    } else if (e.type === 'file_failed') {
      logLine(`<span style="color:var(--text-faint);">[${t}]</span> ❌ <strong>${escapeHtml(e.filename)}</strong> — ${escapeHtml(e.error || 'failed')}`);
    } else if (e.type === 'batch_done') {
      logLine(`<span style="color:var(--text-faint);">[${t}]</span> <strong>Batch complete in ${fmtElapsed(e.elapsed_seconds) || e.elapsed_seconds + 's'}</strong> — ${e.saved} saved, ${e.failed} failed`);
      if (!settledByPoll) {
        settledByPoll = true;
        renderUploadBatchResults({results: e.results || [], saved: e.saved, failed: e.failed});
        finish(true);
      }
    } else if (e.type === 'unknown_batch' || e.type === 'timeout') {
      es.close();
      startPoll();
    } else if (e.type === 'batch_failed') {
      logLine(`<span style="color:var(--text-faint);">[${t}]</span> <strong style="color:var(--red,#c0392b);">Batch stopped: ${escapeHtml(e.error || 'unknown error')}</strong> — ${e.saved} saved, ${e.failed} failed`);
      if (!settledByPoll) {
        settledByPoll = true;
        finish(false, `Upload stopped early: ${e.error || 'unknown error'} (${e.saved} saved before this happened).`);
      }
    }
  };
  // A dropped live-log connection is not fatal: the upload runs on the server regardless. The browser
  // reconnects by itself (the server asks for a 3-second retry) and sends back the id of the last line it
  // got, so the server replays whatever was missed and the log carries on with no gaps. The /result poll
  // runs alongside as a safety net in case the live log cannot come back at all.
  let dropNoted = false, pollStarted = false;
  const settleFromPoll = (data, errMsg) => {
    if (settledByPoll) return;
    settledByPoll = true;
    if (data) {
      logLine(`<span style="color:var(--text-faint);">[${fmtTime(new Date().toISOString())}]</span> <strong>Batch complete</strong> — ${data.saved} saved, ${data.failed} failed`);
      renderUploadBatchResults(data); finish(true);
    } else { finish(false, errMsg); }
  };
  const startPoll = () => {
    if (pollStarted) return;
    pollStarted = true;
    pollBatchResultFallback(batchId, settleFromPoll, () => settledByPoll);
  };
  es.onopen = () => {
    if (dropNoted) {
      dropNoted = false;
      logLine(`<span style="color:var(--text-faint);">[${fmtTime(new Date().toISOString())}]</span> Live log reconnected — picking up where it left off.`);
    }
  };
  es.onerror = () => {
    if (settledByPoll) { es.close(); return; }
    if (!dropNoted) {
      dropNoted = true;
      logLine(`<span style="color:var(--text-faint);">[${fmtTime(new Date().toISOString())}]</span> Live log connection dropped — reconnecting. The upload keeps running on the server.`);
    }
    startPoll();
    // CLOSED means the browser gave up (for example the sign-in expired). The poll above finishes the job.
    if (es.readyState === EventSource.CLOSED) es.close();
  };

  try {
    const ack = await new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/import/upload-batch');

      // Upload-phase progress: real bytes-sent/total, actual transfer
      // speed (smoothed over the whole transfer so it doesn't jitter
      // wildly on a bursty connection), and an ETA derived from that
      // speed - all from the browser's own network timing, not guessed.
      xhr.upload.onprogress = (evt) => {
        if (!evt.lengthComputable) return;
        const pct = Math.min(99, Math.round((evt.loaded / evt.total) * 100));
        const elapsedSec = (Date.now() - startedAt) / 1000;
        const bytesPerSec = elapsedSec > 0.2 ? evt.loaded / elapsedSec : 0;
        const remainingSec = bytesPerSec > 0 ? (evt.total - evt.loaded) / bytesPerSec : Infinity;
        progBar.style.width = pct + '%';
        progPct.textContent = pct + '%';
        progSpeed.textContent = bytesPerSec > 0 ? `${_formatBytes(bytesPerSec)}/s` : '';
        progEta.textContent = _formatEta(remainingSec);
      };

      // Once every byte has left the browser, the server hands back an
      // immediate 202 accept (it no longer waits for parsing/saving to
      // finish before responding - see app.py's upload_documents_batch),
      // so this used to say "parsing now, could take a minute" - it no
      // longer needs to, since the actual wait happens below via the live
      // log / poll fallback instead of a held-open request.
      xhr.upload.onload = () => {
        progBar.style.width = '100%';
        progPct.textContent = '100%';
        progSpeed.textContent = '';
        progEta.textContent = '';
        collapseUploadPromptToActivity();
        statusEl.textContent = `Upload received — processing ${uploadReportsFiles.length} file(s) in the background now.`;
      };

      xhr.onload = () => {
        let data;
        try {
          data = JSON.parse(xhr.responseText);
        } catch (e) {
          reject(new Error('The server returned an unexpected (non-JSON) response.'));
          return;
        }
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(data);
        } else {
          reject(new Error(data.error || `Upload failed (HTTP ${xhr.status}).`));
        }
      };
      xhr.onerror = () => reject(new Error('Network error during upload - check your connection and try again.'));
      xhr.ontimeout = () => reject(new Error('Upload timed out.'));

      xhr.send(fd);
    });

    // ack is just {accepted, batch_id, file_count} now - the real result
    // arrives later via the SSE 'batch_done'/'batch_failed' handler above
    // (or the poll fallback if that connection drops), not here. Nothing
    // else to do with this response.
    if (ack && ack.pending_approval) {
      // Not imported: a non-super admin's upload waits for a super admin (Report Reviews > Approvals).
      settledByPoll = true;
      try { es.close(); } catch (e) {}
      showToast('Sent to a super admin for approval - nothing is saved until it is approved.');
      finish(true);
      statusEl.innerHTML = '<b>Sent for approval.</b> A super admin must approve these reports before they are saved. Track them under Report Reviews &gt; Approvals.';
      return;
    }
    if (!ack || !ack.accepted) {
      throw new Error((ack && ack.error) || 'Upload was not accepted.');
    }
  } catch (e) {
    finish(false, 'Upload failed: ' + e.message);
  }
}


async function deleteCompany(companyId, companyName){
  if (!confirm(`Delete ${companyName} and all of its saved financial data? This can't be undone.`)) return;
  try {
    const res = await fetch(`/api/companies/${companyId}`, { method: 'DELETE' });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      alert(data.error || `Delete failed (status ${res.status}).`);
      return;
    }
    allCompaniesCache = allCompaniesCache.filter(c => c.id !== companyId);
    settingsSelectedCompanyIds.delete(companyId);
    await renderSettingsCompaniesPanel();
  } catch (err) {
    console.error('Delete failed:', err);
    alert('Delete failed — check the browser console for details.');
  }
}

let rankSectorFilter = '';
let rankMinScore = '';
let rankOnlyWithData = false;
let rankCategoryCache = [];
let rankTopCategory = 'roe';

function setRankSectorFilter(v){ rankSectorFilter = v; renderRankingsTable(); }
function setRankMinScore(v){ rankMinScore = v; renderRankingsTable(); }
function toggleRankOnlyWithData(el){
  el.classList.toggle('on');
  rankOnlyWithData = el.classList.contains('on');
  renderRankingsTable();
}
function setRankTopCategory(v){ rankTopCategory = v; renderTopCategoryPanel(); }


function renderRankingsTable(){
  const app = document.getElementById('app');
  const byScore = rankCategoryCache;

  if (byScore.length === 0) {
    app.innerHTML = `<div class="panel"><div class="empty">No companies yet. Add one from the Companies page.</div></div>`;
    return;
  }

  const sectors = [...new Set(byScore.map(c => c.sector).filter(Boolean))].sort();
  const withData = byScore.filter(c => c.latest);
  const scored = withData.filter(c => c.latest.financial_score !== null && c.latest.financial_score !== undefined);
  const topPerformer = scored[0]; // already sorted by score desc from the API
  const byRoe = [...withData].filter(c => c.latest.roe !== null && c.latest.roe !== undefined).sort((a, b) => b.latest.roe - a.latest.roe);
  const topRoe = byRoe[0];
  const latestPeriod = withData.length ? withData[0].latest.period : null;

  let filtered = byScore;
  if (rankSectorFilter) filtered = filtered.filter(c => c.sector === rankSectorFilter);
  if (rankOnlyWithData) filtered = filtered.filter(c => !!c.latest);
  if (rankMinScore) filtered = filtered.filter(c => c.latest && c.latest.financial_score !== null && c.latest.financial_score >= Number(rankMinScore));

  const statCards = `
    <div class="stat-grid">
      ${statCard('blue', '🏢', byScore.length, 'Companies Ranked', `<div class="stat-trend neutral">Across all sectors</div>`)}
      ${statCard('amber', '🏆', topPerformer ? escapeHtml(topPerformer.name) : '-', 'Top Performer Overall', `<div class="stat-trend neutral">${topPerformer ? `Score: ${topPerformer.latest.financial_score}/100` : 'No scored companies yet'}</div>`)}
      ${statCard('green', '📈', topRoe ? escapeHtml(topRoe.name) : '-', 'Highest ROE', `<div class="stat-trend neutral">${topRoe ? `ROE: ${fmt(topRoe.latest.roe)}%` : 'No data yet'}</div>`)}
      ${statCard('purple', '📅', latestPeriod ? escapeHtml(latestPeriod) : '-', 'Data Period', `<div class="stat-trend neutral">${withData.length} of ${byScore.length} companies scored</div>`)}
    </div>`;

  const filterBar = `
    <div class="filter-bar">
      <div class="filter-group">
        <label>Sector</label>
        <select class="filter-select" onchange="setRankSectorFilter(this.value)">
          <option value="">All Sectors</option>
          ${sectors.map(s => `<option value="${escapeHtml(s)}" ${s === rankSectorFilter ? 'selected' : ''}>${escapeHtml(s)}</option>`).join('')}
        </select>
      </div>
      <div class="filter-group">
        <label>Min. Financial Score</label>
        <select class="filter-select" onchange="setRankMinScore(this.value)">
          <option value="">All</option>
          <option value="70" ${rankMinScore === '70' ? 'selected' : ''}>70+ (Strong)</option>
          <option value="40" ${rankMinScore === '40' ? 'selected' : ''}>40+ (Moderate or better)</option>
        </select>
      </div>
      <div class="toggle-row" onclick="toggleRankOnlyWithData(document.getElementById('rankOnlyWithDataToggle'))">
        <div class="toggle-switch ${rankOnlyWithData ? 'on' : ''}" id="rankOnlyWithDataToggle"><div class="knob"></div></div>
        Show only companies with data
      </div>
      <div style="flex:1"></div>
      <button class="export-btn" onclick="window.location.href='/api/export/comparison'">⭳ Export</button>
    </div>`;

  const rows = filtered.map((c, i) => {
    const l = c.latest;
    const band = l && l.financial_score !== null ? (l.financial_score >= 70 ? 'strong' : l.financial_score >= 40 ? 'moderate' : 'weak') : null;
    const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i + 1);
    return `
      <tr class="clickable" onclick="goToCompanySurveyData(${c.id})">
        <td class="rank-medal">${medal}</td>
        <td>
          <div class="co-cell">
            <div class="co-avatar" style="background:${coAvatarColor(c.name)};">${coInitials(c.name)}</div>
            <span class="co-name">${escapeHtml(c.name)}</span>
          </div>
        </td>
        <td><span class="badge">${escapeHtml(c.ticker || '-')}</span></td>
        <td>${escapeHtml(c.sector || '-')}</td>
        <td>${band ? `<span class="score-badge score-${band}">${l.financial_score}/100</span>` : '-'}</td>
        <td>${l && l.revenue !== null && l.revenue !== undefined ? fmtAmount(l.revenue) : '-'}</td>
        <td>${l && l.net_income !== null && l.net_income !== undefined ? fmtAmount(l.net_income) : '-'}</td>
        <td><button class="view-btn" onclick="event.stopPropagation();goToCompanySurveyData(${c.id})">View</button></td>
      </tr>`;
  }).join('');

  app.innerHTML = statCards + `
    <div class="row" style="grid-template-columns:2.4fr 1fr;align-items:start;">
      <div class="panel">
        ${filterBar}
        ${rows ? `
        <table>
          <thead>
            <tr><th>Rank</th><th>Company</th><th>Ticker</th><th>Sector</th><th>Financial Score</th>
              <th>Revenue</th><th>Net Income</th><th></th></tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
        <div class="results-footer"><span>Showing ${filtered.length} of ${byScore.length} companies</span></div>
        ` : `<div class="empty">No companies match the current filters.</div>`}
      </div>
      <div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="panel-head"><h2>Ranking Methodology</h2></div>
          <div style="font-size:11.5px;color:var(--text-faint);margin-bottom:10px;line-height:1.5;">
            Financial Score is a weighted blend of margin, profitability, and leverage. A company needs net margin, ROE, and debt/equity on record to produce a score.
          </div>
          <div class="methodology-weight"><span>Net Margin</span><div class="mw-bar"><div class="mw-fill" style="width:40%;background:var(--blue);"></div></div><span>40%</span></div>
          <div class="methodology-weight"><span>ROE</span><div class="mw-bar"><div class="mw-fill" style="width:40%;background:var(--green);"></div></div><span>40%</span></div>
          <div class="methodology-weight"><span>Leverage (inv. Debt/Equity)</span><div class="mw-bar"><div class="mw-fill" style="width:20%;background:var(--amber);"></div></div><span>20%</span></div>
        </div>
        <div class="panel" id="topCategoryPanel"></div>
      </div>
    </div>
  `;
  renderTopCategoryPanel();
}

function renderTopCategoryPanel(){
  const el = document.getElementById('topCategoryPanel');
  if (!el) return;
  const withData = rankCategoryCache.filter(c => c.latest);
  const metricMap = {
    roe: { key: 'roe', label: 'ROE', suffix: '%' },
    net_margin: { key: 'net_margin', label: 'Net Margin', suffix: '%' },
    revenue: { key: 'revenue', label: 'Revenue', suffix: '' },
  };
  const m = metricMap[rankTopCategory];
  const ranked = withData
    .filter(c => c.latest[m.key] !== null && c.latest[m.key] !== undefined)
    .sort((a, b) => b.latest[m.key] - a.latest[m.key])
    .slice(0, 5);

  const rows = ranked.map((c, i) => `
    <div class="data-summary-row">
      <div class="ds-label"><span style="width:16px;display:inline-block;">${i + 1}</span> ${escapeHtml(c.name)}</div>
      <div class="ds-val">${m.suffix === '%' ? fmt(c.latest[m.key]) + '%' : fmtAmount(c.latest[m.key])}</div>
    </div>`).join('');

  el.innerHTML = `
    <div class="panel-head">
      <h2>Top 5 by Category</h2>
      <select class="filter-select" style="min-width:110px;" onchange="setRankTopCategory(this.value)">
        <option value="roe" ${rankTopCategory === 'roe' ? 'selected' : ''}>ROE</option>
        <option value="net_margin" ${rankTopCategory === 'net_margin' ? 'selected' : ''}>Net Margin</option>
        <option value="revenue" ${rankTopCategory === 'revenue' ? 'selected' : ''}>Revenue</option>
      </select>
    </div>
    ${rows || `<div class="empty">Not enough data yet.</div>`}
  `;
}


function filterCompaniesBySector(sector){
  coSectorFilter = sector;
  goTo('companies');
}


async function populateExportsCompanyList(){
  if (!allCompaniesCache.length) {
    const res = await fetch('/api/companies');
    allCompaniesCache = await res.json();
  }
  const el = document.getElementById('exports-company-list');
  if (!el) return;
  if (!allCompaniesCache.length) {
    el.innerHTML = `<div class="empty">No companies yet. Add one from the Companies page.</div>`;
    return;
  }
  el.innerHTML = allCompaniesCache.map(c => `
    <div class="data-summary-row">
      <div class="ds-label"><span class="ds-icon">📄</span>${escapeHtml(c.name)} <span class="badge">${escapeHtml(c.ticker || '-')}</span></div>
      <button class="secondary" onclick="docDownload('/api/companies/${c.id}/export/raw.csv')">Download CSV</button>
    </div>
  `).join('');
}

// ---------- Compare Companies ----------

let compareSelectedIds = [];
let compareSelectedPeriod = '';   // '' = each company's own latest
let comparePeriodOptions = [];


function renderCompareShell(){
  const app = document.getElementById('app');
  const MAX_COMPARE = 6;
  const selected = compareSelectedIds
    .map(id => allCompaniesCache.find(c => c.id === id))
    .filter(Boolean);
  const chips = selected.map(c => `
    <div class="compare-chip">
      <div class="co-avatar" style="background:${coAvatarColor(c.name)};">${coInitials(c.name)}</div>
      <div><div class="cc-name">${escapeHtml(c.name)}</div><div class="cc-ticker">${escapeHtml(c.ticker || '-')}</div></div>
      <span class="cc-remove" onclick="toggleCompareSelect(${c.id}, false)">✕</span>
    </div>`).join('');

  const available = allCompaniesCache.filter(c => !compareSelectedIds.includes(c.id));
  const addOptions = available.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');

  const periodSelect = selected.length >= 2 ? `
    <div style="margin-top:12px;display:flex;gap:8px;align-items:center;">
      <label style="font-size:13px;color:var(--text-secondary,#666);">Compare at:</label>
      <select class="filter-select" id="comparePeriodSelect" onchange="setComparePeriod(this.value)">
        <option value="" ${compareSelectedPeriod === '' ? 'selected' : ''}>Each company's latest period</option>
        ${comparePeriodOptions.map(p => `<option value="${escapeHtml(p)}" ${p === compareSelectedPeriod ? 'selected' : ''}>${escapeHtml(p)}</option>`).join('')}
      </select>
    </div>` : '';

  app.innerHTML = `
    <div class="panel">
      <div class="panel-head">
        <h2>Selected Companies (${selected.length}/${MAX_COMPARE})</h2>
        <button class="export-btn" ${selected.length < 2 ? 'disabled style="opacity:.5;"' : ''} onclick="window.location.href='/api/export/comparison'">⭳ Export</button>
      </div>
      <div class="compare-picker" style="flex-wrap:wrap;">${chips || '<div class="empty" style="padding:6px 0;">No companies selected yet.</div>'}</div>
      ${selected.length < MAX_COMPARE ? `
      <div style="margin-top:12px;display:flex;gap:8px;align-items:center;">
        <select class="filter-select" style="min-width:220px;" id="compareAddSelect">
          <option value="">+ Add a company to compare...</option>
          ${addOptions}
        </select>
        <button class="secondary" style="margin:0;" onclick="addCompareFromSelect()">Add</button>
      </div>` : ''}
      ${periodSelect}
    </div>
    <div id="compare-result"></div>
  `;
}

async function refreshComparePeriodOptions(){
  if (compareSelectedIds.length < 2) { comparePeriodOptions = []; return; }
  try {
    const res = await fetch(`/api/compare/periods?ids=${compareSelectedIds.join(',')}`);
    const data = await res.json();
    comparePeriodOptions = data.periods || [];
    // A period picked for a previous selection might not apply to the
    // new one (e.g. a company that only has FY2025 was removed) - drop
    // back to "each company's latest" rather than silently comparing at
    // a period that's no longer valid for this selection.
    if (compareSelectedPeriod && !comparePeriodOptions.includes(compareSelectedPeriod)) {
      compareSelectedPeriod = '';
    }
  } catch (e) {
    comparePeriodOptions = [];
  }
}

function setComparePeriod(period){
  compareSelectedPeriod = period;
  runCompare();
}

function addCompareFromSelect(){
  const sel = document.getElementById('compareAddSelect');
  const id = Number(sel.value);
  if (!id) return;
  toggleCompareSelect(id, true);
}

function toggleCompareSelect(id, checked){
  if (checked) { if (!compareSelectedIds.includes(id) && compareSelectedIds.length < 6) compareSelectedIds.push(id); }
  else { compareSelectedIds = compareSelectedIds.filter(x => x !== id); }
  refreshComparePeriodOptions().then(() => {
    renderCompareShell();
    if (compareSelectedIds.length >= 2) runCompare();
    else document.getElementById('compare-result').innerHTML = '';
  });
}

function compareBarChart(title, unitLabel, companies, getter, color, isPercent){
  const vals = companies.map(c => getter(c));
  const maxV = Math.max(1, ...vals.map(v => v || 0));
  const cols = companies.map((c, i) => `
    <div class="mini-bar-col">
      <div class="mbc-val">${vals[i] === null || vals[i] === undefined ? '-' : (isPercent ? fmt(vals[i]) + '%' : fmtAmount(vals[i]))}</div>
      <div class="mbc-bar" style="height:${vals[i] ? Math.max(4, vals[i] / maxV * 100) : 2}%;background:${color};"></div>
      <div class="mbc-label">${escapeHtml(c.name)}</div>
    </div>`).join('');
  return `
    <div class="chart-panel mini-bar-panel">
      <div class="mb-title">${title}${unitLabel ? ` — ${unitLabel}` : ''}</div>
      <div class="mini-bar-chart">${cols}</div>
    </div>`;
}

async function runCompare(){
  if (compareSelectedIds.length < 2) return;
  const periodParam = compareSelectedPeriod ? `&period=${encodeURIComponent(compareSelectedPeriod)}` : '';
  const res = await fetch(`/api/compare?ids=${compareSelectedIds.join(',')}${periodParam}`);
  const companies = await res.json();
  const resultEl = document.getElementById('compare-result');
  if (!resultEl) return;

  const withData = companies.filter(c => c.latest);
  const noData = companies.filter(c => !c.latest);
  const totalRevenue = withData.reduce((s, c) => s + (c.latest.revenue || 0), 0);
  const totalNetIncome = withData.reduce((s, c) => s + (c.latest.net_income || 0), 0);
  const margins = withData.filter(c => c.latest.net_margin !== null && c.latest.net_margin !== undefined);
  const roes = withData.filter(c => c.latest.roe !== null && c.latest.roe !== undefined);
  const avgMargin = margins.length ? margins.reduce((s, c) => s + c.latest.net_margin, 0) / margins.length : null;
  const avgRoe = roes.length ? roes.reduce((s, c) => s + c.latest.roe, 0) / roes.length : null;
  const scored = withData.filter(c => c.latest.financial_score !== null && c.latest.financial_score !== undefined);
  const highest = scored.length ? scored.reduce((a, b) => a.latest.financial_score >= b.latest.financial_score ? a : b) : null;
  const lowest = scored.length ? scored.reduce((a, b) => a.latest.financial_score <= b.latest.financial_score ? a : b) : null;

  const summary = `
    <div class="panel">
      <div class="panel-head"><h2>Overview</h2></div>
      <div class="stat-grid" style="grid-template-columns:repeat(6,1fr);">
        <div class="summary-metric"><div class="sm-val">${companies.length}</div><div class="sm-label">Companies Compared</div></div>
        <div class="summary-metric"><div class="sm-val">${totalRevenue ? fmtMoney(totalRevenue) : '-'}</div><div class="sm-label">Total Revenue</div></div>
        <div class="summary-metric"><div class="sm-val">${totalNetIncome ? fmtMoney(totalNetIncome) : '-'}</div><div class="sm-label">Total Net Income</div></div>
        <div class="summary-metric"><div class="sm-val">${avgMargin !== null ? fmt(avgMargin) + '%' : '-'}</div><div class="sm-label">Average Net Margin</div></div>
        <div class="summary-metric"><div class="sm-val" style="color:var(--green);">${highest ? escapeHtml(highest.name) : '-'}</div><div class="sm-label">Highest Score${highest ? ` (${highest.latest.financial_score})` : ''}</div></div>
        <div class="summary-metric"><div class="sm-val" style="color:var(--red);">${lowest ? escapeHtml(lowest.name) : '-'}</div><div class="sm-label">Lowest Score${lowest ? ` (${lowest.latest.financial_score})` : ''}</div></div>
      </div>
    </div>`;

  const charts = withData.length ? `
    <div class="row row-4">
      ${compareBarChart('Revenue Comparison', 'KES', withData, c => c.latest.revenue, 'var(--blue)', false)}
      ${compareBarChart('Net Income Comparison', 'KES', withData, c => c.latest.net_income, 'var(--green)', false)}
      ${compareBarChart('Net Margin Comparison', '%', withData, c => c.latest.net_margin, 'var(--purple)', true)}
      ${compareBarChart('ROE Comparison', '%', withData, c => c.latest.roe, 'var(--amber)', true)}
    </div>` : '';

  const metricRows = [
    ['Sector', c => c.sector || '-'],
    [compareSelectedPeriod ? 'Period' : 'Latest Period', c => c.latest ? c.latest.period : (compareSelectedPeriod ? `No data for ${escapeHtml(compareSelectedPeriod)}` : '-')],
    ['Revenue', c => c.latest ? fmtAmount(c.latest.revenue) : '-'],
    ['Net Income', c => c.latest ? fmtAmount(c.latest.net_income) : '-'],
    ['Net Margin', c => c.latest && c.latest.net_margin !== null ? fmt(c.latest.net_margin) + '%' : '-'],
    ['ROE', c => c.latest && c.latest.roe !== null ? fmt(c.latest.roe) + '%' : '-'],
    ['Debt/Equity', c => c.latest && c.latest.debt_equity !== null ? fmt(c.latest.debt_equity, 2) : '-'],
    ['Financial Score', c => c.latest && c.latest.financial_score !== null
      ? `<span class="score-badge score-${c.latest.score_band}">${c.latest.financial_score}/100</span>` : '-'],
  ];
  const headerCols = companies.map(c => `<th>${escapeHtml(c.name)} <span class="badge">${escapeHtml(c.ticker || '-')}</span></th>`).join('');
  const bodyRows = metricRows.map(([label, getter]) => `
    <tr><td>${label}</td>${companies.map(c => `<td>${getter(c)}</td>`).join('')}</tr>
  `).join('');

  const insights = [];
  if (withData.length) {
    const byRevenue = [...withData].sort((a, b) => (b.latest.revenue || 0) - (a.latest.revenue || 0))[0];
    if (byRevenue) insights.push(`<b>${escapeHtml(byRevenue.name)}</b> leads on scale with revenue of ${fmtAmount(byRevenue.latest.revenue)}.`);
    if (margins.length) {
      const byMargin = [...margins].sort((a, b) => b.latest.net_margin - a.latest.net_margin)[0];
      insights.push(`<b>${escapeHtml(byMargin.name)}</b> shows the strongest net margin at ${fmt(byMargin.latest.net_margin)}%.`);
    }
    if (highest) insights.push(`<b>${escapeHtml(highest.name)}</b> has the strongest financial health score (${highest.latest.financial_score}/100).`);
    if (lowest && lowest.id !== (highest && highest.id)) insights.push(`<b>${escapeHtml(lowest.name)}</b> has the weakest financial health score among those compared (${lowest.latest.financial_score}/100).`);
  }

  const insightsPanel = `
    <div class="panel">
      <div class="panel-head"><h2>Key Insights</h2></div>
      ${insights.length ? insights.map(t => `<div class="insight-item"><span class="ii-icon">📌</span><span>${t}</span></div>`).join('')
        : `<div class="empty">Add financials for these companies to see insights.</div>`}
    </div>`;

  resultEl.innerHTML = `
    ${summary}
    ${charts}
    <div class="row" style="grid-template-columns:2.2fr 1fr;align-items:start;">
      <div class="panel">
        <div class="panel-head"><h2>Metric Comparison</h2></div>
        <table>
          <thead><tr><th></th>${headerCols}</tr></thead>
          <tbody>${bodyRows}</tbody>
        </table>
      </div>
      ${insightsPanel}
    </div>
  `;
}

// ---------- Financial Analytics ----------

let analyticsCompanyId = null;
let analyticsChart1 = null;
let analyticsChart2 = null;
let analyticsChart3 = null;
let sectorsBarChart = null;
let sectorsDonutChart = null;


async function switchAnalyticsCompany(id){
  analyticsCompanyId = parseInt(id, 10);
  await loadAnalyticsTrends();
}

async function loadAnalyticsTrends(){
  const res = await fetch(`/api/companies/${analyticsCompanyId}/trends`);
  const trends = await res.json();
  const bodyEl = document.getElementById('analytics-body');

  if (trends.length < 2) {
    bodyEl.innerHTML = `<div class="empty">Need at least 2 periods of data for this company to show a trend. ${trends.length === 1 ? 'Only 1 period on record so far.' : 'No data on record yet.'}</div>`;
    return;
  }

  bodyEl.innerHTML = `
    <div class="subhead">Revenue &amp; Net Income</div>
    <div class="chart-wrap"><canvas id="analytics-chart-1"></canvas></div>
    <div class="subhead">Net Margin &amp; ROE (%)</div>
    <div class="chart-wrap"><canvas id="analytics-chart-2"></canvas></div>
    <div class="subhead">Financial Score</div>
    <div class="chart-wrap" style="height:180px;"><canvas id="analytics-chart-3"></canvas></div>
  `;

  const labels = trends.map(t => t.period);
  if (analyticsChart1) analyticsChart1.destroy();
  if (analyticsChart2) analyticsChart2.destroy();
  if (analyticsChart3) analyticsChart3.destroy();

  const chartOpts = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { labels: { color: '#aaccbb' } } },
    scales: {
      x: { ticks: { color: themeChartColors().tick }, grid: { color: themeChartColors().grid } },
      y: { ticks: { color: themeChartColors().tick }, grid: { color: themeChartColors().grid } },
    },
  };

  analyticsChart1 = new Chart(document.getElementById('analytics-chart-1'), {
    type: 'line',
    data: { labels, datasets: [
      { label: 'Revenue', data: trends.map(t => t.revenue), borderColor: '#48cfa0', backgroundColor: 'rgba(72,207,160,.15)', tension: .3 },
      { label: 'Net Income', data: trends.map(t => t.net_income), borderColor: '#3ddc84', backgroundColor: 'rgba(61,220,132,.15)', tension: .3 },
    ]},
    options: chartOpts,
  });

  analyticsChart2 = new Chart(document.getElementById('analytics-chart-2'), {
    type: 'line',
    data: { labels, datasets: [
      { label: 'Net Margin %', data: trends.map(t => t.net_margin), borderColor: '#ffb020', backgroundColor: 'rgba(255,176,32,.15)', tension: .3 },
      { label: 'ROE %', data: trends.map(t => t.roe), borderColor: '#b79bfc', backgroundColor: 'rgba(183,155,252,.15)', tension: .3 },
    ]},
    options: chartOpts,
  });

  analyticsChart3 = new Chart(document.getElementById('analytics-chart-3'), {
    type: 'bar',
    data: { labels, datasets: [
      { label: 'Financial Score', data: trends.map(t => t.financial_score), backgroundColor: '#48cfa0' },
    ]},
    options: { ...chartOpts, scales: { ...chartOpts.scales, y: { ...chartOpts.scales.y, max: 100 } } },
  });
}

// ---------- Alerts ----------

// ---------- Survey Report (per-company, 9 tabs) ----------
// One company's own filed board/director/remuneration data - the
// "Company Data Collection and Verification" layer per user's framing.
// Pulls from 3 independently-populated sources via
// /api/companies/<id>/survey-report (see that endpoint's docstring):
// SurveyCompanyData (company-level totals + field_confidence/sources/
// review_status), DirectorRemunerationRow (named directors, shared with
// the Intelligence Report), and Committee/CommitteeMember (new model,
// added 2026-09-13, empty until populated). Defaults to whichever
// company /api/survey-report/default-company scores as most complete.
const SR_TABS = [
  {id:'multi-year', label:'Financial Year Comparison'},
  {id:'company-overview', label:'Company Overview'},
  {id:'board-composition', label:'Board Composition'},
  {id:'directors-register', label:"Directors' Register"},
  {id:'remuneration', label:'Remuneration (Directors)'},
  {id:'committees', label:'Committees'},
  {id:'benefits', label:'Benefits & Allowances'},
  {id:'audit-ownership', label:'Audit & Ownership'},
  {id:'evidence', label:'Evidence & Sources'},
  {id:'survey-mapping', label:'Survey Mapping'},
  {id:'data-quality', label:'Data Quality'},
];
let srTab = 'company-overview';
let srCompanyId = null;
let srFiscalYear = null; // null = let the backend pick this company's own latest survey year
let srDataCache = null;
let srSelectedDirectorIdx = 0;
let srSurveyAvgCache = null; // portfolio-wide averages from /api/survey/overview, for "vs market" comparisons - fetched lazily, once, the first time a tab needs it

let reportRequest = 0;
async function renderSurveyReportPage(){
  const seq = ++reportRequest;
  const app = document.getElementById('app');
  document.getElementById('pageTitle').textContent = 'Companies Survey Reports';
  document.getElementById('pageSub').textContent = "Company data collection and verification \u2014 one company's own filed board and remuneration data";

  if (!srCompanyId) {
    const def = await safeJson(await fetch('/api/survey-report/default-company'), {company_id: null});
    if (seq !== reportRequest || currentPage !== "survey-report") return;
    srCompanyId = def.company_id;
  }
  if (!srCompanyId) {
    setPageActions(null);
    app.innerHTML = `<div class="panel"><div class="empty">No companies on file yet.</div></div>`;
    return;
  }

  const yearQuery = srFiscalYear ? `?fiscal_year=${encodeURIComponent(srFiscalYear)}` : '';
  const [data, allCompaniesRaw, srRanking] = await Promise.all([
    fetch(`/api/companies/${srCompanyId}/survey-report${yearQuery}`).then(r=>safeJson(r,null)).catch(()=>null),
    fetch('/api/companies').then(r=>safeJson(r,[])).catch(()=>[]),
    fetch('/api/survey-report/company-ranking').then(r=>safeJson(r,[])).catch(()=>[])
  ]);
  if (seq !== reportRequest || currentPage !== 'survey-report') return;
  srDataCache = data;
  // Director tables / benefits are stored in the unit the filing printed them in; write them out in full.
  FILED_UNIT_CTX = (data && data.survey) ? (data.survey.director_figures_unit || 'units') : 'units';
  if (!data) {
    app.innerHTML = `<div class="panel"><div class="empty">Could not load this company's survey report.</div></div>`;
    return;
  }
  // The endpoint defaults to this company's own most recent survey year when
  // no fiscal_year is passed - adopt whatever it actually returned as the
  // picker's selected value, so the dropdown reflects reality on first load
  // (and after switching companies) instead of staying blank.
  if (!srFiscalYear && data.survey) srFiscalYear = data.survey.fiscal_year;

  // Drop-down order: fewest missing survey fields first (/api/survey-report/company-ranking), so the most complete
  // reports are on top. A company the ranking doesn't know (shouldn't happen) is appended, never dropped.
  const srMissingById = new Map(srRanking.map(r => [r.company_id, r]));
  const allCompanies = [...allCompaniesRaw].sort((a, b) => {
    const ra = srMissingById.get(a.id), rb = srMissingById.get(b.id);
    if (ra && rb) return ra.rank - rb.rank;
    return ra ? -1 : rb ? 1 : 0;
  });

  setPageActions([
    {label: 'Download Company Report (.pdf)', icon: '⭳', perm: 'user', disabled: !data.has_survey_data,
      onClick: `docDownload('/api/companies/${srCompanyId}/export/report.pdf${srFiscalYear ? '?fiscal_year=' + encodeURIComponent(srFiscalYear) : ''}')`},
    {label: 'View Source Documents', icon: '📄', onClick: `switchSRTab('evidence')`},
    {label: 'Documents & Reports', icon: '🗂️', perm: 'user', onClick: `docOpenFor('${srFiscalYear || ''}', ${srCompanyId})`},
  ]);

  const c = data.company;
  const s = data.survey;

  const availableYears = fullYears(data.available_survey_years);
  document.getElementById('rpCompanyControls').innerHTML = `
    <div class="rp-company-pickers">
      <select id="srCompanyPicker" aria-label="Company" onchange="srSwitchCompany(this.value)" style="max-width:280px;">
        ${allCompanies.map(co => `<option value="${co.id}" ${co.id === srCompanyId ? 'selected' : ''}>${escapeHtml(co.name)}</option>`).join('')}
      </select>
      ${availableYears.length > 1 ? `
      <select id="srYearPicker" aria-label="Financial year" onchange="srSwitchYear(this.value)" style="max-width:160px;">
        ${availableYears.map(y => `<option value="${escapeHtml(y)}" ${y === srFiscalYear ? 'selected' : ''}>${escapeHtml(y)}</option>`).join('')}
      </select>` : ''}
    </div>
`;
  rpHeaderSelect('section','Report section',SR_TABS,srTab,switchSRTab);
  app.innerHTML = `
    <div class="sr-company-card">
      <div class="sr-company-left">
        <div class="sr-logo">🏢</div>
        <div>
          <div class="sr-company-name">${escapeHtml(c.name)} <span style="color:var(--green);">✔️</span></div>
          <div class="sr-company-meta">${escapeHtml(c.sector || 'Sector not set')} ${c.ticker ? '· ' + escapeHtml(c.exchange || 'NSE') + ': ' + escapeHtml(c.ticker) : ''} ${s ? '· ' + escapeHtml(s.fiscal_year) : ''}</div>
        </div>
      </div>
      <div class="sr-kpi-strip">
        ${srKpi('📈', s && s.market_cap !== null && s.market_cap !== undefined ? escapeHtml(s.currency) + ' ' + fmtFull(s.market_cap, s.unit) : naSpan('Not filed in survey data'), 'Market Cap')}
        ${srKpi('👤', s && s.turnover !== null && s.turnover !== undefined ? escapeHtml(s.currency) + ' ' + fmtFull(s.turnover, s.unit) : naSpan('Not filed in survey data'), 'Revenue / Turnover')}
        ${srKpi('💰', s && s.net_profit !== null && s.net_profit !== undefined ? escapeHtml(s.currency) + ' ' + fmtFull(s.net_profit, s.unit) : naSpan('Not filed in survey data'), 'Net Profit')}
        ${srKpi('📅', (s && s.fiscal_year) ? escapeHtml(s.fiscal_year) : (data.period_label ? escapeHtml(data.period_label) : naSpan('No financial period on file')), 'Reporting Period')}
      </div>
    </div>
    <div id="srTabBody"></div>
  `;
  renderSRTabBody();
}
// ---- Extended survey fields on the company report (tab_modules.EXTENDED_GROUPS) --------------------------------
// The server sends the groups (labels) and how each field is measured (field_kinds), so these helpers never
// hard-code a field list. Calculated rows are labelled "calculated" and never stored.
function srExtLabel(l){ return String(l || '').replace(/ \((Yes \/ No|Unmodified[^)]*|firm|number of people|number)\)$/i, ''); }
function srExtFmt(data, k){
  const s = data.survey;
  if (!s) return null;
  const v = s[k];
  if (v === null || v === undefined || v === '') return null;
  const kind = (data.field_kinds || {})[k], cur = escapeHtml(s.currency || 'KES');
  if (kind === 'pay') return `${cur} ${fmtFull(v, surveyDirectorFiguresUnit(s))}`;
  if (kind === 'headline') return `${cur} ${fmtFull(v, s.unit || 'millions')}`;
  if (kind === 'pershare') return `${cur} ${Number(v).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  if (kind === 'pct') return `${Number(v).toLocaleString('en-US', {maximumFractionDigits: 1})}%`;
  if (kind === 'count') return Number(v).toLocaleString('en-US');
  if (kind === 'years') return `${Number(v).toLocaleString('en-US')} year${Number(v) === 1 ? '' : 's'}`;
  if (kind === 'yesno') {
    const t = String(v);
    return t === 'Yes' ? '<span style="color:var(--green);font-weight:600;">Yes</span>' : t === 'No' ? '<span style="color:var(--text-dim);font-weight:600;">No</span>' : escapeHtml(t);
  }
  return escapeHtml(String(v));
}
function srExtFields(data, groupId, only){
  const g = (data.extended_groups || []).find(x => x.id === groupId);
  if (!g) return [];
  return only ? only.map(k => g.fields.find(f => f[0] === k)).filter(Boolean) : g.fields;
}
const SR_CALC_BADGE = `<span style="font-size:10px;color:var(--text-faint);" title="Worked out from other figures on this page, not stated in the report">calculated</span>`;
function srExtTable(data, groupId, only, calcRows){
  const s = data.survey;
  if (!s) return `<div class="empty">${naSpan('No survey data on file for this company yet')}</div>`;
  const rows = srExtFields(data, groupId, only).map(([k, l]) => {
    const v = srExtFmt(data, k);
    return `<tr><td>${escapeHtml(srExtLabel(l))}</td><td style="font-weight:600;">${v !== null ? v : naSpan('Not filed')}</td><td>${v !== null ? srConfBadge(s, k) : ''}</td></tr>`;
  });
  (calcRows || []).filter(r => r && r[1] !== null && r[1] !== undefined).forEach(([label, value]) => {
    rows.push(`<tr><td>${escapeHtml(label)}</td><td style="font-weight:600;">${value}</td><td>${SR_CALC_BADGE}</td></tr>`);
  });
  return `<table><tbody>${rows.join('')}</tbody></table>`;
}
function srNum(v){ return v === null || v === undefined || v === '' || Number.isNaN(Number(v)) ? null : Number(v); }
function srWhole(v){ return v === null ? null : Math.round(v).toLocaleString('en-US'); }
// Calculated measures
function srCostPerEmployee(s){
  const sc = srNum(s && s.staff_costs), n = srNum(s && s.employees_count);
  return sc !== null && n ? sc * unitMultiplier(s.unit || 'millions') / n : null;
}
function srCeoPayRatio(s){
  const ceo = srNum(s && s.ceo_monthly_cost_of_employment), cpe = srCostPerEmployee(s);
  return ceo !== null && cpe ? ceo * 12 * unitMultiplier(surveyDirectorFiguresUnit(s)) / cpe : null;
}
function srFyYear(fy){ const m = String(fy || '').match(/(19|20)\d\d/); return m ? Number(m[0]) : null; }
function srTenureYears(d, fyYear){
  const m = String(d.appointed_date || '').match(/(19|20)\d\d/);
  return m && fyYear ? Math.max(0, fyYear - Number(m[0])) : null;
}
function srAttendance(rows){
  const known = (rows || []).filter(d => srNum(d.board_meetings_attended) !== null && srNum(d.board_meetings_eligible));
  if (!known.length) return null;
  const att = known.reduce((a, d) => a + Number(d.board_meetings_attended), 0), elig = known.reduce((a, d) => a + Number(d.board_meetings_eligible), 0);
  return {pct: elig ? att / elig * 100 : null, directors: known.length};
}

function srBoardEffectivenessPanel(data){
  const s = data.survey, regs = data.survey_director_rows || [];
  const fyY = srFyYear(s && s.fiscal_year);
  const ten = regs.map(d => srTenureYears(d, fyY)).filter(t => t !== null);
  const indepLong = regs.filter(d => d.independent === true && (srTenureYears(d, fyY) || 0) > 9).length;
  const att = srAttendance(regs);
  const calc = [
    s && srNum(s.board_attendance_pct) === null && att && att.pct !== null ? ['Average attendance (from the register)', `${att.pct.toFixed(1)}% <span style="font-size:11px;color:var(--text-faint);">(${att.directors} directors)</span>`] : null,
    ten.length ? ['Average tenure (from appointment dates)', `${(ten.reduce((a, b) => a + b, 0) / ten.length).toFixed(1)} years`] : null,
    ten.length && s && srNum(s.independent_neds_over_9_years) === null ? ['Independent directors over 9 years (from the register)', indepLong ? `<span style="color:var(--amber);font-weight:700;">${indepLong}</span>` : '0'] : null,
  ];
  return `<div class="panel" style="margin-top:14px;">
    <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Board effectiveness</h2><span style="font-size:11px;color:var(--text-faint);">Independence beyond 9 years is a CMA Code flag</span></div>
    ${srExtTable(data, 'board-effectiveness', null, calc)}</div>`;
}

function srExecutivePayPanel(data){
  const s = data.survey;
  const kmp = srNum(s && s.kmp_total_compensation), n = srNum(s && s.kmp_count);
  const pu = s ? surveyDirectorFiguresUnit(s) : 'units';
  const calc = [kmp !== null && n ? ['Average per key manager', `${escapeHtml(s.currency || 'KES')} ${srWhole(kmp * unitMultiplier(pu) / n)}`] : null];
  return `<div class="panel" style="margin-top:14px;">
    <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Executive team (key management)</h2><span style="font-size:11px;color:var(--text-faint);">From the related-party note (IAS 24) and the directors' pay note</span></div>
    ${srExtTable(data, 'executive-pay', null, calc)}</div>`;
}

function srWorkforcePanel(data){
  const s = data.survey, cpe = srCostPerEmployee(s), ratio = srCeoPayRatio(s);
  const calc = [cpe !== null ? ['Average cost per employee', `${escapeHtml(s.currency || 'KES')} ${srWhole(cpe)}`] : null,
                ratio !== null ? ['CEO pay ratio (CEO cost : average employee)', `<b>${ratio.toFixed(0)} : 1</b>`] : null];
  return `<div class="panel" style="margin-top:14px;">
    <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">10. Workforce</h2></div>
    ${srExtTable(data, 'workforce', null, calc)}</div>`;
}

function srReturnsPanel(data){
  const s = data.survey, eps = srNum(s && s.earnings_per_share), dps = srNum(s && s.dividend_per_share);
  const calc = [eps && dps !== null ? ['Dividend payout ratio', `${(dps / eps * 100).toFixed(1)}%`] : null];
  return `<div class="panel" style="margin-top:14px;">
    <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">11. Shareholder returns</h2><span class="ov-panel-link" onclick="switchSRTab('audit-ownership')">Ownership &rarr;</span></div>
    ${srExtTable(data, 'shareholders', ['earnings_per_share', 'dividend_per_share'], calc)}</div>`;
}

function srAuditOwnershipTab(data){
  const s = data.survey;
  if (!s) return `<div class="panel"><div class="empty">${naSpan('No survey data on file for this company yet')}</div></div>`;
  const fee = srNum(s.audit_fee), non = srNum(s.non_audit_fees), turn = srNum(s.turnover);
  const calcAudit = [
    fee && non !== null ? ['Non-audit fees as a share of the audit fee', `${(non / fee * 100).toFixed(1)}%`] : null,
    fee !== null && turn ? ['Audit fee as a share of turnover', `${(fee / turn * 100).toFixed(3)}%`] : null,   // both in the headline unit
  ];
  const tenure = srNum(s.auditor_tenure_years);
  const regs = (data.survey_director_rows || []).filter(d => srNum(d.shares_held) !== null);
  return `
    <div class="row row-2" style="grid-template-columns:1fr 1fr;">
      <div class="panel">
        <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Audit</h2>${tenure !== null && tenure >= 10 ? `<span class="ov-status-pill pending" title="Long auditor tenure: check the rotation requirements">${tenure} years in office</span>` : ''}</div>
        ${srExtTable(data, 'audit', null, calcAudit)}
      </div>
      <div class="panel">
        <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Ownership</h2></div>
        ${srExtTable(data, 'shareholders', ['shareholders_count', 'top10_shareholding_pct', 'free_float_pct', 'directors_shareholding_pct'])}
        ${regs.length ? `<div style="font-size:11px;font-weight:700;color:var(--text-faint);text-transform:uppercase;letter-spacing:.4px;margin:16px 0 8px;">Directors' shareholdings</div>
          <table><thead><tr><th>Director</th><th style="text-align:right;">Shares held</th></tr></thead><tbody>
          ${regs.sort((a, b) => Number(b.shares_held) - Number(a.shares_held)).map(d => `<tr><td>${escapeHtml(d.director_name)}</td><td style="text-align:right;font-weight:600;">${Number(d.shares_held).toLocaleString('en-US')}</td></tr>`).join('')}
          </tbody></table>` : ''}
      </div>
    </div>`;
}

function srKpi(icon, value, label){
  return `<div class="sr-kpi"><div class="sr-kpi-icon">${icon}</div><div><div class="sr-kpi-value">${value}</div><div class="sr-kpi-label">${escapeHtml(label)}</div></div></div>`;
}
function srSwitchYear(fiscalYear){
  srFiscalYear = fiscalYear;
  srSelectedDirectorIdx = 0;
  renderSurveyReportPage();
}
function srSwitchCompany(companyId, fiscalYear){
  srCompanyId = Number(companyId);
  // Reset to null (not carried over from the previous company) so the new
  // company opens on its OWN latest year, rather than possibly requesting
  // a fiscal year it doesn't have data for. A caller that knows the year
  // (Settings > Companies > a file) passes it.
  srFiscalYear = fiscalYear || null;
  srSelectedDirectorIdx = 0;
  srEditableCommittees = null;
  srCommitteesEditMode = false;
  srBenefitsSubtab = 'executive';
  srMappingStatusFilter = 'all';
  srMappingSectionFilter = 'all';
  srMappingSearch = '';
  srDQIssueFilter = 'all';
  srDQSearch = '';
  srEvidenceSubtab = 'executive';
  renderSurveyReportPage();
}
function switchSRTab(tabId){
  srTab = tabId;
  rpHeaderSelect('section','Section',SR_TABS,tabId,switchSRTab);
  renderSRTabBody();
}
function renderSRTabBody(){
  const body = document.getElementById('srTabBody');
  if (!body) return;
  const data = srDataCache;
  if (srTab === 'multi-year') return rpCompare(body,'company',data.available_survey_years,srCompanyId);
  if (srTab === 'company-overview') body.innerHTML = srCompanyOverviewTab(data);
  else if (srTab === 'board-composition') {
    body.innerHTML = srBoardCompositionTab(data);
    if (!srSurveyAvgCache) {
      fetch('/api/survey/overview').then(r => r.json()).then(overview => {
        srSurveyAvgCache = overview;
        if (srTab === 'board-composition') body.innerHTML = srBoardCompositionTab(data);
      }).catch(() => {});
    }
  }
  else if (srTab === 'directors-register') body.innerHTML = srDirectorsRegisterTab(data);
  else if (srTab === 'remuneration') body.innerHTML = srRemunerationTab(data);
  else if (srTab === 'committees') body.innerHTML = srCommitteesTab(data);
  else if (srTab === 'benefits') body.innerHTML = srBenefitsTab(data);
  else if (srTab === 'audit-ownership') body.innerHTML = srAuditOwnershipTab(data);
  else if (srTab === 'evidence') body.innerHTML = srEvidenceTab(data);
  else if (srTab === 'survey-mapping') body.innerHTML = srSurveyMappingTab(data);
  else if (srTab === 'data-quality') { body.innerHTML = srDataQualityTab(data); srDrawDataQualityTrend(data); }
  const emptyBanner = srEmptyBanner(srTab, data);
  if (emptyBanner) body.innerHTML = emptyBanner + body.innerHTML;
  if (srTab === 'committees') attachSRCommitteeHandlers();
}

// An empty tab says WHY it is empty. "Not available" alone hides whether the report does not
// disclose the data, the rule-based readers missed it, or the AI extraction just has not been run.
const SR_TAB_TASK = {'board-composition':'board', 'directors-register':'board', 'remuneration':'pay', 'benefits':'pay', 'committees':'committees'};
function srTabIsEmpty(tabId, data){
  const s = data.survey || {};
  if (tabId === 'board-composition') {
    const keys = ['board_size','board_meetings_per_year','committees_per_board','directors_female','directors_male','executive_directors_count','non_executive_directors_count','independent_neds_count'];
    return !keys.some(k => s[k] !== null && s[k] !== undefined);
  }
  if (tabId === 'directors-register') return !(data.survey_director_rows || []).length;
  if (tabId === 'remuneration') return !(data.director_rows || []).length;
  if (tabId === 'committees') return !(data.committees || []).length;
  if (tabId === 'benefits') {
    // benefits also come from benefit-like columns of the filed pay rows (Retirement benefits, Other employee benefits, ...)
    const pat = /housing|vehicle|car|medical|health|travel|pension|benefit|allowance|insurance|mortgage|fuel/i;
    const inPay = (data.director_rows || []).some(r => { let c = r.components; if (typeof c === 'string') { try { c = JSON.parse(c); } catch (e) { c = {}; } } return Object.keys(c || {}).some(k => pat.test(k) && !/^total/i.test(k)); });
    return !inPay && !(s.ned_benefits && Object.keys(s.ned_benefits).length) && !(data.survey_director_benefits || []).length && !(data.benefit_categories || []).length;
  }
  return false;
}
function srEmptyBanner(tabId, data){
  if (!SR_TAB_TASK[tabId] || !srTabIsEmpty(tabId, data)) return '';
  const task = SR_TAB_TASK[tabId];
  const st = (data.ai_items || {})[task] || {};
  let why;
  if (st.done) why = `AI results for this tab are <b>ready to review</b> (${st.done}). Open <a href="#" onclick="openReview('ai-results');return false;">Review › AI results</a> and apply the verified items.`;
  else if (st.pending || st.failed) why = `The rule-based readers found nothing here. The AI can read this report's pages - <b>${(st.pending || 0) + (st.failed || 0)} item(s) are waiting</b> in <a href="#" onclick="openReview('ai-results');return false;">Report Reviews</a> (run them from the AI Backfilling page - the cost is shown before anything is sent). You can also <a href="#" onclick="openReview('manual');return false;">type the values in</a>.`;
  else if (st.submitted) why = 'The AI extraction for this tab has been sent and is still processing. Check it on the AI page.';
  else if (st.applied) why = 'The AI extraction ran for this tab but none of its items could be verified against the page text, so nothing was written. Open Review › AI results to see why.';
  else why = 'The rule-based readers found nothing here and no page in this report is relevant enough to send to the AI, so the report most likely does not disclose it (or it was uploaded before AI extraction existed - re-upload to check).';
  return `<div class="status-banner warn" style="margin-bottom:12px">No data on this tab yet. ${why}</div>`;
}

// Field-level confidence badge, reading SurveyCompanyData.field_confidence
// (0-1 float) for the given column name - real per-field confidence
// where an extractor produced it, absent entirely for hand-typed data
// (see field_confidence's docstring in models_survey.py).
function srConfBadge(survey, fieldName){
  if (!survey || !survey.field_confidence || !(fieldName in survey.field_confidence)) return '';
  const c = survey.field_confidence[fieldName];
  const pct = Math.round(c * 100);
  const cls = c >= 0.75 ? 'sr-conf-high' : c >= 0.45 ? 'sr-conf-med' : 'sr-conf-low';
  return `<span class="sr-conf-badge ${cls}">${pct}%</span>`;
}

// ---- Tab 1: Company Overview ----
function srCompanyOverviewTab(data){
  const c = data.company, s = data.survey;
  if (!s && !data.has_director_data) {
    return `<div class="panel"><div class="empty">No survey or filed director data on record for ${escapeHtml(c.name)} yet.</div></div>`;
  }
  // Same register fallback as srBoardCompositionTab: a filing that only
  // gives a named director register (survey_director_rows) rather than
  // its own separate "Board Composition" summary figures still lets
  // these counts be shown, counted live from that register instead of
  // left "Not available" - each marked with a (derived) note below
  // rather than presented as if it were itself a filed figure.
  const regRows = data.survey_director_rows || [];
  const roleKnownRows = regRows.filter(d => d.role === 'executive' || d.role === 'non_executive');
  const genderKnownRows = regRows.filter(d => d.gender);
  const indepKnownRows = regRows.filter(d => d.independent === true || d.independent === false);
  const derive = (statedVal, knownRows, counter) => {
    if (statedVal !== null && statedVal !== undefined) return [statedVal, false];
    if (!knownRows.length) return [statedVal, false];
    return [counter(), true];
  };
  const [execVal, execDerived] = derive(s && s.executive_directors_count, roleKnownRows, () => regRows.filter(d => d.role === 'executive').length);
  const [nonExecVal, nonExecDerived] = derive(s && s.non_executive_directors_count, roleKnownRows, () => regRows.filter(d => d.role === 'non_executive').length);
  const [indepVal, indepDerived] = derive(s && s.independent_neds_count, indepKnownRows, () => regRows.filter(d => d.independent === true).length);
  const [femaleVal, femaleDerived] = derive(s && s.directors_female, genderKnownRows, () => regRows.filter(d => (d.gender || '').toLowerCase() === 'female').length);

  const boardRows = [
    ['Board Size', s && s.board_size, 'board_size', false],
    ['Executive Directors', execVal, 'executive_directors_count', execDerived],
    ['Non-Executive Directors', nonExecVal, 'non_executive_directors_count', nonExecDerived],
    ['Independent Directors', indepVal, 'independent_neds_count', indepDerived],
    ['Female Directors', femaleVal, 'directors_female', femaleDerived],
    ['Board Meetings Held', s && s.board_meetings_per_year, 'board_meetings_per_year', false],
  ];
  return `
    <div class="row row-2" style="grid-template-columns:1.6fr 1fr;">
      <div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="sa-panel-title">1. Company Profile</div>
          <table><tbody>
            <tr><td>Company Name</td><td style="font-weight:700;">${escapeHtml(c.name)}</td></tr>
            <tr><td>Sector</td><td>${escapeHtml(c.sector || '-')}</td></tr>
            <tr><td>Ticker</td><td>${escapeHtml(c.ticker || '-')}</td></tr>
            <tr><td>Exchange</td><td>${escapeHtml(c.exchange || '-')}</td></tr>
            <tr><td>Financial Year</td><td>${s ? escapeHtml(s.fiscal_year) : naSpan('No survey data on file')}</td></tr>
            <tr><td>Currency</td><td>${s ? escapeHtml(s.currency) : '-'}</td></tr>
          </tbody></table>
        </div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">2. Board Composition</h2><span class="ov-panel-link" onclick="switchSRTab('board-composition')">View full board register &rarr;</span></div>
          <table><thead><tr><th>Item</th><th>Value</th><th>Confidence</th></tr></thead><tbody>
            ${boardRows.map(([label, val, field, derived]) => `
              <tr><td>${escapeHtml(label)}</td><td>${val !== null && val !== undefined ? val : naSpan('Not filed in survey data')}</td><td>${derived ? `<span style="font-size:10px;color:var(--text-faint);" title="Not itself stated in the filing - counted from the named director register">from register</span>` : srConfBadge(s, field)}</td></tr>`).join('')}
          </tbody></table>
        </div>
        <div class="panel">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">4. Director Register</h2><span class="ov-panel-link" onclick="switchSRTab('directors-register')">View all directors &rarr;</span></div>
          ${data.has_director_data ? `
          <table><thead><tr><th>Name</th><th>Role</th><th>Total</th></tr></thead><tbody>
            ${data.director_rows.filter(r => !r.is_grand_total && !r.is_total_row).slice(0,5).map(r => `
              <tr><td>${escapeHtml(r.director_name)}</td><td>${escapeHtml(r.role || '-')}</td><td>${r.total !== null ? fmtFiled(r.total) : '-'}</td></tr>`).join('')}
          </tbody></table>` : `<div class="empty">${naSpan('No named-director remuneration filed for this company yet')}</div>`}
        </div>
        ${s ? srWorkforcePanel(data) + srReturnsPanel(data) : ''}
      </div>
      <div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="sa-panel-title">3. Key Information</div>
          <div class="empty">${naSpan('Narrative key-information summaries are not generated by this app \u2014 the figures above are shown as filed, without an auto-written interpretation')}</div>
        </div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">5. Non-Executive Director Remuneration</h2><span class="ov-panel-link" onclick="switchSRTab('remuneration')">View full details &rarr;</span></div>
          ${srCompanyOverviewRemunerationTable(s, [
            ['Chairperson Annual Retainer','chairperson_annual_retainer'],
            ['Other NED Annual Retainer','other_ned_annual_retainer'],
            ['Chairperson Meeting Allowance','chairperson_meeting_allowance'],
            ['Other NED Meeting Allowance','other_ned_meeting_allowance'],
          ])}
        </div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">6. Executive Director Remuneration</h2><span class="ov-panel-link" onclick="switchSRTab('remuneration')">View full details &rarr;</span></div>
          ${srCompanyOverviewRemunerationTable(s, [
            ['Executive Director Annual Retainer','executive_director_annual_retainer'],
            ['Executive Director Meeting Allowance','executive_director_meeting_allowance'],
            ['CEO Monthly Salary','ceo_monthly_salary'],
            ['CEO Total Cost of Employment','ceo_monthly_cost_of_employment'],
          ])}
        </div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">7. Committees</h2><span class="ov-panel-link" onclick="switchSRTab('committees')">View all committees &rarr;</span></div>
          ${data.has_committee_data ? `<table><thead><tr><th>Committee</th><th>Chair</th><th>Members</th></tr></thead><tbody>
            ${data.committees.slice(0,5).map(cm => `<tr><td>${escapeHtml(cm.name)}</td><td>${escapeHtml(cm.chairperson_name || '-')}</td><td>${cm.member_count !== null && cm.member_count !== undefined ? cm.member_count : cm.members.length}</td></tr>`).join('')}
          </tbody></table>` : `<div class="empty">${naSpan('No committee data added for this company yet')}</div>`}
        </div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">8. Disclosure Evidence</h2><span class="ov-panel-link" onclick="switchSRTab('evidence')">View all sources &rarr;</span></div>
          ${srDisclosureEvidenceTable(s)}
        </div>
        ${window.currentUser.role === 'admin' ? `<div class="panel">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">9. Missing Disclosures</h2><span class="ov-panel-link" onclick="switchSRTab('data-quality')">View all &rarr;</span></div>
          ${srMissingDisclosuresList(s)}
        </div>` : ''}
      </div>
    </div>`;
}
// Small reusable helper for panels 5/6 on this tab - a short subset of
// the same fields the full Remuneration tab shows, each with the same
// confidence badge so a reader doesn't need to leave this page to
// sanity-check the summary numbers.
function srCompanyOverviewRemunerationTable(s, fieldPairs){
  if (!s) return `<div class="empty">${naSpan('No survey data on file for this company yet')}</div>`;
  // Pay figures are on the scale of this company's own pay table (director_figures_unit), which
  // can differ from its headline unit - label anything that isn't plain raw currency.
  const pu = surveyDirectorFiguresUnit(s);
  const puSuffix = pu && pu.toLowerCase() !== 'units' ? ` (${escapeHtml(pu)})` : '';
  return `<table><tbody>
    ${fieldPairs.map(([label, f]) => `<tr><td>${escapeHtml(label)}</td><td>${s[f] !== null && s[f] !== undefined ? escapeHtml(s.currency || '') + ' ' + fmtFull(s[f], pu) : naSpan('Not filed')}</td><td>${srConfBadge(s, f)}</td></tr>`).join('')}
  </tbody></table>`;
}
// Panel 8 in the design: which SOURCE DOCUMENT/PAGE backs a handful of
// the survey's most load-bearing figures, at a glance - a smaller,
// curated version of what the full Evidence & Sources tab shows for
// every field, using the same field_sources/field_confidence data.
const SR_DISCLOSURE_EVIDENCE_FIELDS = [
  ['board_size', 'Board Size'],
  ['independent_neds_count', 'Independent Directors'],
  ['chairperson_annual_retainer', 'Chairperson Annual Retainer'],
  ['executive_director_annual_retainer', 'Executive Director Retainer'],
];
function srDisclosureEvidenceTable(s){
  if (!s) return `<div class="empty">${naSpan('No survey data on file for this company yet')}</div>`;
  const rows = SR_DISCLOSURE_EVIDENCE_FIELDS.map(([f, label]) => ({
    label, value: s[f], source: (s.field_sources || {})[f], confidence: (s.field_confidence || {})[f],
  }));
  if (rows.every(r => r.value === null || r.value === undefined)) {
    return `<div class="empty">${naSpan('None of these fields are filed for this company yet')}</div>`;
  }
  return `<table><thead><tr><th>Field</th><th>Value</th><th>Source</th></tr></thead><tbody>
    ${rows.map(r => `<tr><td>${escapeHtml(r.label)}</td><td>${r.value !== null && r.value !== undefined ? escapeHtml(String(r.value)) : naSpan('Missing')}</td><td style="font-size:11px;">${r.source ? escapeHtml(r.source) : naSpan('\u2014')}</td></tr>`).join('')}
  </tbody></table>`;
}
// Fields the design's "Missing Disclosures" panels care about most -
// walks the real SurveyCompanyData row (when present) and lists which
// of these are actually null, rather than a fixed mock list.
const SR_KEY_DISCLOSURE_FIELDS = [
  ['chairperson_annual_retainer', 'Chairperson Annual Retainer'],
  ['other_ned_annual_retainer', 'NED Annual Retainer'],
  ['executive_director_annual_retainer', 'Executive Director Retainer'],
  ['committee_chair_annual_retainer', 'Committee Chair Fees'],
  ['ceo_monthly_cost_of_employment', 'CEO Total Cost of Employment'],
  ['directors_female', 'Female Directors'],
];
function srMissingDisclosuresList(s){
  if (!s) return `<div class="empty">${naSpan('No survey data on file to check for missing disclosures')}</div>`;
  const missing = SR_KEY_DISCLOSURE_FIELDS.filter(([f]) => s[f] === null || s[f] === undefined);
  if (!missing.length) return `<div class="empty" style="color:var(--green);">All key disclosure fields tracked by this survey are filled in.</div>`;
  return `<table><thead><tr><th>Field</th><th>Status</th></tr></thead><tbody>
    ${missing.map(([f, label]) => `<tr><td>${escapeHtml(label)}</td><td><span class="ov-status-pill pending">Missing</span></td></tr>`).join('')}
  </tbody></table>`;
}

// ---- Tab 2: Board Composition ----
// Portfolio comparison figures (the "vs market average" panel) come
// from /api/survey/overview's board_overview block, cached lazily in
// srSurveyAvgCache. That block gives PORTFOLIO TOTALS (e.g.
// total_independent_neds, total_directors_female), not a pre-computed
// average of each company's own percentage - so ratios here are
// computed as (portfolio total / portfolio total board size), a
// genuine portfolio-wide rate, and labelled "portfolio rate" rather
// than "average %" so it's not confused with an average-of-averages.
const SR_BOARD_FIELD_ROWS = [
  ['Board Size', 'board_size'],
  ['Executive Directors', 'executive_directors_count'],
  ['Non-Executive Directors', 'non_executive_directors_count'],
  ['Independent Directors', 'independent_neds_count'],
  ['Non-Independent NEDs', 'non_independent_neds_count'],
  ['NEDs \u2014 Kenyan', 'neds_kenyan_count'],
  ['NEDs \u2014 Non-Kenyan', 'neds_non_kenyan_count'],
  ['Female Directors', 'directors_female'],
  ['Male Directors', 'directors_male'],
  ['Committees / Board', 'committees_per_board'],
  ['Committee Meetings / Year', 'committee_meetings_per_year'],
  ['Average Age \u2014 Executive Directors', 'avg_age_executive_directors'],
  ['Average Age \u2014 Non-Executive Directors', 'avg_age_non_executive_directors'],
  ['Average Age \u2014 Independent NEDs', 'avg_age_independent_neds'],
  ['Average Age \u2014 Non-Independent NEDs', 'avg_age_non_independent_neds'],
  ['Board Meetings Held', 'board_meetings_per_year'],
];
function srBoardCompositionTab(data){
  return srBoardCompositionTabCore(data) + (data.survey ? srBoardEffectivenessPanel(data) : '');
}
function srBoardCompositionTabCore(data){
  const s = data.survey;
  if (!s) return `<div class="panel"><div class="empty">${naSpan('No survey data on file for this company yet')}</div></div>`;

  // The survey extraction fills executive_directors_count etc. only when
  // the filing states them as their own labeled figure (e.g. a "Board
  // Composition" summary table) - a filing that instead only gives a
  // named director-by-director register (survey_director_rows, from the
  // same document's board-composition pages, each row carrying its own
  // extracted role/gender/independence) leaves those survey fields null
  // even though the same counts are sitting right there in the register.
  // Fall back to counting the register itself in that case, rather than
  // showing "Not available" for something this company's own filing did
  // provide - each count only fires once at least one director in the
  // register actually has that attribute stated (never assumes the rest).
  const regRows = data.survey_director_rows || [];
  const roleKnownRows = regRows.filter(d => d.role === 'executive' || d.role === 'non_executive');
  const genderKnownRows = regRows.filter(d => d.gender);
  const indepKnownRows = regRows.filter(d => d.independent === true || d.independent === false);

  let exec = s.executive_directors_count, execDerived = false;
  if ((exec === null || exec === undefined) && roleKnownRows.length) {
    exec = regRows.filter(d => d.role === 'executive').length; execDerived = true;
  }
  let nonExec = s.non_executive_directors_count, nonExecDerived = false;
  if ((nonExec === null || nonExec === undefined) && roleKnownRows.length) {
    nonExec = regRows.filter(d => d.role === 'non_executive').length; nonExecDerived = true;
  }
  let independentCount = s.independent_neds_count, independentDerived = false;
  if ((independentCount === null || independentCount === undefined) && indepKnownRows.length) {
    independentCount = regRows.filter(d => d.independent === true).length; independentDerived = true;
  }
  let female = s.directors_female, femaleDerived = false;
  if ((female === null || female === undefined) && genderKnownRows.length) {
    female = regRows.filter(d => (d.gender || '').toLowerCase() === 'female').length; femaleDerived = true;
  }
  let male = s.directors_male;
  if ((male === null || male === undefined) && genderKnownRows.length) {
    male = regRows.filter(d => (d.gender || '').toLowerCase() === 'male').length;
  }
  // If the register doesn't cover every board seat (e.g. 11 of 13 have a
  // stated role), the derived exec+nonExec total can legitimately be
  // less than board_size - not a bug, just an incomplete register; flag
  // it rather than implying full coverage.
  const registerIncomplete = (execDerived || nonExecDerived) && s.board_size
    && (exec + nonExec) !== s.board_size;

  return `
    <div style="margin-bottom:14px;">
      <div class="sa-panel-title" style="margin-bottom:10px;">Board Composition</div>
      ${registerIncomplete ? `<div class="status-banner warn" style="margin-bottom:10px;">Executive/Non-Executive counts below are derived from the ${regRows.length}-person director register on file, which covers ${exec + nonExec} of the ${s.board_size} board seats stated elsewhere in this filing - the remaining seat(s) have no stated role.</div>` : ''}
      <div class="sr-stat-grid">
        ${srStat('👥', s.board_size, 'Board Size', s.board_size, 'board_size', false, 'blue')}
        ${srStat('👤', exec, 'Executive Directors', s.board_size, 'executive_directors_count', execDerived, 'green')}
        ${srStat('👥', nonExec, 'Non-Executive Directors', s.board_size, 'non_executive_directors_count', nonExecDerived, 'purple')}
        ${srStat('🛡️', independentCount, 'Independent Directors', s.board_size, 'independent_neds_count', independentDerived, 'teal')}
        ${srStat('♀️', female, 'Female Directors', s.board_size, 'directors_female', femaleDerived, 'pink')}
        ${srStat('📅', s.avg_age_executive_directors !== null ? Math.round(s.avg_age_executive_directors) : null, 'Average Age (Executive)', null, 'avg_age_executive_directors', false, 'amber')}
        ${srStat('📅', s.board_meetings_per_year, 'Board Meetings (FY)', null, 'board_meetings_per_year', false, 'red')}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Board Composition by Category</div>
        ${exec !== null && nonExec !== null && (exec+nonExec) > 0
          ? saDonut2([['Executive Directors', Math.round(exec/(exec+nonExec)*100), 'var(--blue)'], ['Non-Executive Directors', Math.round(nonExec/(exec+nonExec)*100), 'var(--amber)']], `${exec+nonExec}`)
          : `<div class="empty">${naSpan('Not filed in survey data')}</div>`}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Gender Representation</div>
        ${female !== null && male !== null && (female+male) > 0
          ? saDonut2([['Female', Math.round(female/(female+male)*100), 'var(--purple)'], ['Male', Math.round(male/(female+male)*100), 'var(--blue)']], `${female+male}`)
          : `<div class="empty">${naSpan('Not filed in survey data')}</div>`}
      </div>
    </div>
    <div class="row row-2" style="grid-template-columns:1.6fr 1fr;">
      <div class="panel">
        <div class="sa-panel-title">Board Composition Details</div>
        <table><thead><tr><th>Item</th><th>Value</th><th>Source Page</th><th>Confidence</th><th>Status</th></tr></thead><tbody>
          ${SR_BOARD_FIELD_ROWS.map(([label, f]) => {
            const val = s[f];
            const src = s.field_sources && s.field_sources[f];
            const conf = s.field_confidence && s.field_confidence[f];
            const hasVal = val !== null && val !== undefined;
            return `<tr>
              <td>${escapeHtml(label)}</td>
              <td>${hasVal ? val : naSpan('Not filed')}</td>
              <td>${src ? escapeHtml(src) : naSpan('\u2014')}</td>
              <td>${conf !== undefined ? Math.round(conf*100) + '%' : naSpan('\u2014')}</td>
              <td>${hasVal ? '<span class="ov-status-pill completed">Extracted</span>' : '<span class="ov-status-pill failed">Missing</span>'}</td>
            </tr>`;
          }).join('')}
        </tbody></table>
      </div>
      <div>
        ${srBoardKeyInsightsPanel(s, exec, nonExec, female, male)}
        ${srBoardComparisonPanel(s)}
      </div>
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Board Members</h2><span class="ov-panel-link" onclick="switchSRTab('directors-register')">Full register &rarr;</span></div>
      ${data.has_director_data ? `<table><thead><tr><th>#</th><th>Name</th><th>Role</th></tr></thead><tbody>
        ${data.director_rows.filter(r => !r.is_grand_total && !r.is_total_row).map((r,i) => `<tr><td>${i+1}</td><td>${escapeHtml(r.director_name)}</td><td>${escapeHtml(r.role || '-')}</td></tr>`).join('')}
      </tbody></table>` : `<div class="empty">${naSpan('No named-director data filed for this company yet')}</div>`}
    </div>
    <div class="panel">
      <div class="sa-panel-title">Source Documents</div>
      ${(data.source_documents || []).length ? `<table><thead><tr><th>Document</th><th>Financial Year</th><th>Pages</th>${canEdit() ? '<th>Extraction Score</th>' : ''}</tr></thead><tbody>
        ${data.source_documents.map(d => `<tr><td>${escapeHtml(d.filename || d.url || 'Untitled document')}</td><td>${d.period_label ? escapeHtml(d.period_label) : naSpan('\u2014')}</td><td>${d.page_count !== null && d.page_count !== undefined ? d.page_count : naSpan('\u2014')}</td>${canEdit() ? `<td>${extractionScoreBadge(d)}</td>` : ''}</tr>`).join('')}
      </tbody></table>` : `<div class="empty">${naSpan('No source documents on file for this company yet')}</div>`}
    </div>`;
}
// Small admin-only badge for a source document's extraction-quality
// score - "not available" (not a fake 0) when the doc has no
// confidence-bearing rows yet, otherwise the real 0-100 average with a
// low-confidence flag below the shared threshold. The score/flag are
// only ever present in the payload for an admin (see include_score in
// app.py) - this only reads what's already there, it doesn't gate
// visibility itself.
function extractionScoreBadge(d){
  if (d.extraction_score === null || d.extraction_score === undefined) return naSpan('not scored yet');
  const low = d.extraction_score_low;
  const color = low ? 'var(--red,#c0392b)' : 'var(--green,#1a7f37)';
  return `<span style="color:${color};font-weight:600;">${d.extraction_score}/100</span>${low ? ' <span title="Below the extraction-quality threshold - consider re-uploading after a parser fix" style="cursor:help;">⚠️</span>' : ''}`;
}
// Deterministic, non-fabricated observations - only fires a line when
// the underlying figures are actually on file, never a generic filler.
function srBoardKeyInsightsPanel(s, exec, nonExec, female, male){
  const insights = [];
  if (s.independent_neds_count !== null && s.board_size) {
    const pct = Math.round(s.independent_neds_count / s.board_size * 100);
    insights.push(`Independent directors make up ${pct}% of the board (${s.independent_neds_count} of ${s.board_size}).`);
  }
  if (female !== null && male !== null && (female + male) > 0) {
    const pct = Math.round(female / (female + male) * 100);
    insights.push(`Female representation stands at ${pct}% (${female} of ${female + male} directors).`);
  }
  if (s.board_meetings_per_year !== null) {
    insights.push(`The board met ${s.board_meetings_per_year} time${s.board_meetings_per_year === 1 ? '' : 's'} during the fiscal year.`);
  }
  return `
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Key Insights</div>
      ${insights.length ? `<ul style="margin:0;padding-left:18px;font-size:12.5px;line-height:1.7;">${insights.map(i => `<li>${i}</li>`).join('')}</ul>`
        : `<div class="empty">${naSpan('Not enough board composition data on file to generate insights')}</div>`}
    </div>`;
}
// See SR_BOARD_FIELD_ROWS comment above - these are portfolio-wide
// rates (sum/sum), not an average of each company's own percentage.
function srBoardComparisonPanel(s){
  if (!srSurveyAvgCache) return `<div class="panel"><div class="sa-panel-title">Comparison to Market</div><div class="empty">Loading portfolio averages\u2026</div></div>`;
  if (!srSurveyAvgCache.has_data) return `<div class="panel"><div class="sa-panel-title">Comparison to Market</div><div class="empty">${naSpan('Not enough companies with survey data to compute a portfolio comparison')}</div></div>`;
  const bo = srSurveyAvgCache.board_overview;
  const rows = [];
  if (s.board_size !== null && bo.avg_board_size && bo.avg_board_size.average !== null) {
    rows.push(['Board Size', s.board_size, Math.round(bo.avg_board_size.average * 10) / 10, s.board_size >= bo.avg_board_size.average]);
  }
  const totalBoardSeats = (bo.total_executive_directors || 0) + (bo.total_non_executive_directors || 0);
  if (s.independent_neds_count !== null && s.board_size && bo.total_independent_neds !== null && totalBoardSeats) {
    const companyPct = Math.round(s.independent_neds_count / s.board_size * 100);
    const portfolioPct = Math.round(bo.total_independent_neds / totalBoardSeats * 100);
    rows.push(['Independent Directors', companyPct + '%', portfolioPct + '% (portfolio rate)', companyPct >= portfolioPct]);
  }
  if (s.directors_female !== null && s.board_size && bo.total_directors_female !== null && (bo.total_directors_female + (bo.total_directors_male||0)) > 0) {
    const companyPct = Math.round(s.directors_female / s.board_size * 100);
    const portfolioPct = Math.round(bo.total_directors_female / (bo.total_directors_female + bo.total_directors_male) * 100);
    rows.push(['Female Directors', companyPct + '%', portfolioPct + '% (portfolio rate)', companyPct >= portfolioPct]);
  }
  if (s.board_meetings_per_year !== null && bo.avg_board_meetings_per_year && bo.avg_board_meetings_per_year.average !== null) {
    rows.push(['Board Meetings', s.board_meetings_per_year, Math.round(bo.avg_board_meetings_per_year.average * 10) / 10, s.board_meetings_per_year >= bo.avg_board_meetings_per_year.average]);
  }
  return `
    <div class="panel">
      <div class="sa-panel-title">Comparison to Market</div>
      ${rows.length ? `<table><tbody>
        ${rows.map(([label, val, avg, above]) => `<tr>
          <td>${escapeHtml(label)}</td><td style="font-weight:700;">${val}</td>
          <td style="color:var(--text-faint);font-size:11px;">vs ${avg} (portfolio)</td>
          <td>${above ? '<span style="color:var(--green);">\u2191 Above average</span>' : '<span style="color:var(--amber);">\u2193 Below average</span>'}</td>
        </tr>`).join('')}
      </tbody></table>` : `<div class="empty">${naSpan('Not enough matching data to compare')}</div>`}
    </div>`;
}
function srStat(icon, value, label, total, field, derived, tone){
  const s = srDataCache.survey;
  // 'derived' means this value wasn't itself a field the filing's survey
  // extraction stated - it's counted live from the named directors'
  // register (data.survey_director_rows) because the survey field itself
  // came back null. Real, not fabricated (every director counted was
  // actually extracted with a stated role) - but it isn't "filed" in the
  // sense the confidence badge means, so show a distinct note instead of
  // srConfBadge, which would otherwise look up a confidence score that
  // was never computed for this figure.
  const badge = derived
    ? `<span style="font-size:10px;color:var(--text-faint);" title="Not itself stated in the filing - counted from the named director register below">from register</span>`
    : srConfBadge(s, field);
  return `<div class="sr-stat-card" style="${toneVars(tone || 'blue')}">
    <div class="sr-stat-top"><div class="sr-stat-icon" style="${statTone(tone || 'blue')}">${icon}</div><div class="sr-stat-label">${escapeHtml(label)}</div></div>
    <div class="sr-stat-value">${value !== null && value !== undefined ? value : naSpan('Not filed in survey data')} ${badge}</div>
  </div>`;
}

// ---- Tab 3: Directors' Register ----
// Two independent sources, never merged (see SurveyDirector's own
// docstring): survey_director_rows (models_survey.py) holds PROFILE
// facts - position/gender/nationality/independence/appointed date/
// committees, from a filing's board-composition pages; director_rows
// (DirectorRemunerationRow, models.py) holds each person's own filed
// PAY breakdown, from the filing's remuneration tables. A real company
// usually has both for the same person, but this tab never assumes a
// name in one table is the same person in the other - it looks up a
// name-matched pay row only to display alongside the profile, and
// says so when no matching pay row exists rather than showing "-".
const SR_DIRECTOR_DETAIL_TABS = [
  {id: 'profile', label: 'Profile'},
  {id: 'committees', label: 'Committee Memberships'},
];
let srDirectorDetailTab = 'profile';
function srDirectorsRegisterTab(data){
  if (!data.has_survey_director_data) {
    return `<div class="panel"><div class="empty">${naSpan('No named-director register has been filed for this company yet \u2014 this needs a filing\u2019s board-composition/directors\u2019-register pages to be extracted or hand-entered; a Directors\u2019 Remuneration table alone (see the Remuneration tab) does not populate this')}</div></div>`;
  }
  const rows = data.survey_director_rows;
  const selected = rows[srSelectedDirectorIdx] || rows[0];
  const payByName = {};
  (data.director_rows || []).filter(r => !r.is_grand_total && !r.is_total_row).forEach(r => { payByName[r.director_name] = r; });

  const total = rows.length;
  const execCount = rows.filter(d => d.role === 'executive').length;
  const nonExecCount = rows.filter(d => d.role === 'non_executive').length;
  const independentCount = rows.filter(d => d.independent === true).length;
  const roleKnown = rows.filter(d => d.role === 'executive' || d.role === 'non_executive').length;
  const independentKnown = rows.filter(d => d.independent === true || d.independent === false).length;
  const genderKnown = rows.filter(d => d.gender).length;
  const femaleCount = rows.filter(d => (d.gender || '').toLowerCase() === 'female').length;
  const avgAgeNote = null; // SurveyDirector has no date-of-birth/age field - never fabricated here

  return `
    <div class="sr-stat-grid" style="margin-bottom:14px;">
      <div class="sr-stat-card" style="${toneVars('blue')}"><div class="sr-stat-top"><div class="sr-stat-icon" style="${statTone('blue')}">\ud83d\udc65</div><div class="sr-stat-label">Total Directors</div></div><div class="sr-stat-value">${total}</div></div>
      <div class="sr-stat-card" style="${toneVars('green')}"><div class="sr-stat-top"><div class="sr-stat-icon" style="${statTone('green')}">\ud83d\udc64</div><div class="sr-stat-label">Executive Directors</div></div><div class="sr-stat-value">${roleKnown ? execCount : naSpan('Role not stated for any director')}</div></div>
      <div class="sr-stat-card" style="${toneVars('purple')}"><div class="sr-stat-top"><div class="sr-stat-icon" style="${statTone('purple')}">\ud83d\udc65</div><div class="sr-stat-label">Non-Executive Directors</div></div><div class="sr-stat-value">${roleKnown ? nonExecCount : naSpan('Role not stated for any director')}</div></div>
      <div class="sr-stat-card" style="${toneVars('teal')}"><div class="sr-stat-top"><div class="sr-stat-icon" style="${statTone('teal')}">\ud83d\udee1\ufe0f</div><div class="sr-stat-label">Independent Directors</div></div><div class="sr-stat-value">${!independentKnown ? naSpan('Independence not stated for any director') : `${independentCount}`}${independentKnown && total ? ` <span style="font-size:11px;color:var(--text-faint);">(${Math.round(independentCount/total*100)}%)</span>` : ''}</div></div>
      <div class="sr-stat-card" style="${toneVars('pink')}"><div class="sr-stat-top"><div class="sr-stat-icon" style="${statTone('pink')}">\u2640\ufe0f</div><div class="sr-stat-label">Female Directors</div></div><div class="sr-stat-value">${genderKnown ? `${femaleCount} <span style="font-size:11px;color:var(--text-faint);">(${Math.round(femaleCount/genderKnown*100)}%)</span>` : naSpan('Gender not stated for any director')}</div></div>
    </div>
    <div class="row row-2" style="grid-template-columns:minmax(0,1.7fr) minmax(0,1fr);">
      <div class="panel" style="min-width:0;">
        <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Directors' Register</h2></div>
        <div style="overflow-x:auto;"><table><thead><tr><th>#</th><th>Name</th><th>Position</th><th>Gender</th><th>Nationality</th><th>Independence</th><th>Appointed</th><th title="Years on the board at this year end, from the appointment date">Tenure</th><th>Attendance</th><th title="Other directorships">Other boards</th><th style="text-align:right;">Shares held</th><th>Committees</th><th>Status</th></tr></thead><tbody>
          ${rows.map((d,i) => {
            const indepLabel = d.independent === true ? `<span style="color:var(--green);font-weight:600;">Independent</span>`
              : d.independent === false ? `<span style="color:var(--text-faint);">Not Independent</span>`
              : naSpan('Not stated');
            const committeeCount = d.committees && d.committees.length ? d.committees.length : null;
            return `
            <tr class="clickable ${srSelectedDirectorIdx === i ? 'active' : ''}" onclick="srSelectedDirectorIdx=${i};renderSRTabBody();">
              <td>${i+1}</td><td>${escapeHtml(d.director_name)}</td><td>${d.position ? escapeHtml(d.position) : naSpan('\u2014')}</td>
              <td>${d.gender ? escapeHtml(d.gender) : naSpan('\u2014')}</td><td>${d.nationality ? escapeHtml(d.nationality) : naSpan('\u2014')}</td>
              <td>${indepLabel}</td><td>${d.appointed_date ? escapeHtml(d.appointed_date) : naSpan('\u2014')}</td>
              <td>${(() => { const t = srTenureYears(d, srFyYear(data.survey && data.survey.fiscal_year)); return t === null ? naSpan('\u2014') : `<span style="${t > 9 && d.independent === true ? 'color:var(--amber);font-weight:700;' : ''}">${t} yrs</span>`; })()}</td>
              <td>${srNum(d.board_meetings_attended) !== null && srNum(d.board_meetings_eligible) ? `${d.board_meetings_attended}/${d.board_meetings_eligible} <span style="font-size:10.5px;color:var(--text-faint);">${Math.round(d.board_meetings_attended / d.board_meetings_eligible * 100)}%</span>` : naSpan('\u2014')}</td>
              <td style="text-align:center;">${srNum(d.other_directorships) !== null ? d.other_directorships : naSpan('\u2014')}</td>
              <td style="text-align:right;">${srNum(d.shares_held) !== null ? Number(d.shares_held).toLocaleString('en-US') : naSpan('\u2014')}</td>
              <td style="text-align:center;">${committeeCount !== null ? committeeCount : naSpan('\u2014')}</td>
              <td><span class="ov-status-pill completed">Verified</span></td>
            </tr>`;
          }).join('')}
        </tbody></table></div>
      </div>
      <div class="panel">
        ${selected ? srDirectorDetailPanel(selected, payByName[selected.director_name]) : `<div class="empty">Select a director from the register.</div>`}
      </div>
    </div>`;
}
function srDirectorDetailPanel(d, pay){
  const roleLabel = d.role === 'executive' ? 'Executive Director' : d.role === 'non_executive' ? 'Non-Executive Director (NED)' : null;
  const tabBar = `
    <div style="display:flex;gap:4px;border-bottom:1px solid var(--border);margin-bottom:12px;">
      ${SR_DIRECTOR_DETAIL_TABS.map(t => `
        <button onclick="srDirectorDetailTab='${t.id}';renderSRTabBody();"
          style="background:none;border:none;padding:8px 10px;font-size:12px;cursor:pointer;font-weight:${srDirectorDetailTab===t.id?'700':'500'};color:${srDirectorDetailTab===t.id?'var(--text)':'var(--text-faint)'};border-bottom:2px solid ${srDirectorDetailTab===t.id?'var(--blue)':'transparent'};">
          ${t.label}
        </button>`).join('')}
    </div>`;
  let body;
  if (srDirectorDetailTab === 'committees') {
    const committees = d.committees || [];
    body = committees.length
      ? `<ul style="margin:0;padding-left:18px;font-size:12.5px;">${committees.map(c => `<li style="margin-bottom:4px;">${escapeHtml(c)}</li>`).join('')}</ul>`
      : `<div class="empty">${naSpan('No committee memberships stated for this director in the filing')}</div>`;
  } else {
    body = `
      <div class="ir-kv-list">
        ${surveyDetailRow('Position (as filed)', d.position)}
        ${surveyDetailRow('Independence', d.independent === true ? 'Independent' : d.independent === false ? 'Not Independent' : null)}
        ${surveyDetailRow('Gender', d.gender)}
        ${surveyDetailRow('Nationality', d.nationality)}
        ${surveyDetailRow('Appointed', d.appointed_date)}
        ${surveyDetailRow('End of Term', d.end_of_term)}
        ${surveyDetailRow('Board attendance', srNum(d.board_meetings_attended) !== null && srNum(d.board_meetings_eligible) ? `${d.board_meetings_attended} of ${d.board_meetings_eligible} meetings` : null)}
        ${surveyDetailRow('Other directorships', srNum(d.other_directorships) !== null ? String(d.other_directorships) : null)}
        ${surveyDetailRow('Shares held', srNum(d.shares_held) !== null ? Number(d.shares_held).toLocaleString('en-US') : null)}
        ${surveyDetailRow('Source Page', d.page ? `p.${d.page}` : null)}
        ${d.confidence !== null && d.confidence !== undefined
          ? surveyDetailRow('Extraction Confidence', Math.round(d.confidence * 100), {suffix: '%'})
          : `<div class="ir-kv-row"><span class="k">Extraction Confidence</span><span style="color:var(--text-faint);font-size:11.5px;">Not scored (hand-entered, not a graded extraction)</span></div>`}
      </div>
      <div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border);">
        <div style="font-size:11px;font-weight:700;color:var(--text-faint);text-transform:uppercase;letter-spacing:.4px;margin-bottom:8px;">Filed Remuneration</div>
        ${pay ? `
          <table><tbody>
            ${pay.components ? Object.entries(pay.components).map(([k,v]) => `<tr><td>${escapeHtml(k)}</td><td style="font-weight:700;">${fmtFiled(v)}</td></tr>`).join('') : ''}
            <tr><td style="font-weight:700;">Total</td><td style="font-weight:700;">${pay.total !== null ? fmtFiled(pay.total) : '-'}</td></tr>
          </tbody></table>
          ${pay.page ? `<div style="margin-top:8px;font-size:10.5px;color:var(--text-faint);">Source: page ${pay.page}${pay.confidence !== null ? ' \u00b7 ' + Math.round(pay.confidence*100) + '% confidence' : ''}</div>` : ''}
        ` : `<div class="empty" style="padding:10px 0;">${naSpan('No remuneration row filed under this exact name \u2014 see the Remuneration tab for all named-director pay on file')}</div>`}
      </div>`;
  }
  return `
    <div class="sa-panel-title">${escapeHtml(d.director_name)}</div>
    <div style="font-size:11.5px;color:var(--text-dim);margin-bottom:10px;">${roleLabel ? escapeHtml(roleLabel) : naSpan('Role not specified')}</div>
    
    ${body}`;
}

// ---- Tab 4: Remuneration (Directors) ----
function srRemunerationTab(data){
  return srRemunerationTabCore(data) + (data.survey ? srExecutivePayPanel(data) : '');
}
function srRemunerationTabCore(data){
  const s = data.survey;
  if (!s && !data.has_director_data) return `<div class="panel"><div class="empty">${naSpan('No survey or filed director data on record for this company yet')}</div></div>`;
  const directorRows = (data.director_rows || []).filter(r => !r.is_grand_total && !r.is_total_row);
  const execRows = directorRows.filter(r => r.role === 'executive');
  const nonExecRows = directorRows.filter(r => r.role === 'non_executive');
  const profileByName = {};
  (data.survey_director_rows || []).forEach(d => { profileByName[d.director_name] = d; });

  return `
    <div class="row row-2" style="grid-template-columns:1.6fr 1fr;">
      <div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Executive Directors Remuneration</h2></div>
          ${srPerDirectorRemunerationTable(execRows, profileByName)}
        </div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Non-Executive Directors Remuneration</h2></div>
          ${srPerDirectorRemunerationTable(nonExecRows, profileByName)}
        </div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="sa-panel-title">Company-Level Remuneration (Survey Data)</div>
          ${s ? `<table><thead><tr><th>Field</th><th>Value</th><th>Confidence</th></tr></thead><tbody>
            ${[
              ['Chairperson Annual Retainer','chairperson_annual_retainer'],
              ['Other NED Annual Retainer','other_ned_annual_retainer'],
              ['Chairperson Meeting Allowance','chairperson_meeting_allowance'],
              ['Other NED Meeting Allowance','other_ned_meeting_allowance'],
              ['Executive Director Annual Retainer','executive_director_annual_retainer'],
              ['Executive Director Meeting Allowance','executive_director_meeting_allowance'],
              ['Committee Chair Annual Retainer','committee_chair_annual_retainer'],
              ['Committee Member Annual Retainer','committee_member_annual_retainer'],
              ['Committee Chair Meeting Allowance','committee_chair_meeting_allowance'],
              ['Committee Member Meeting Allowance','committee_member_meeting_allowance'],
            ].map(([label,f]) => `<tr><td>${label}</td><td>${s[f] !== null && s[f] !== undefined ? escapeHtml(s.currency) + ' ' + fmtFull(s[f], surveyDirectorFiguresUnit(s)) : naSpan('Not filed in survey data')}</td><td>${srConfBadge(s,f)}</td></tr>`).join('')}
          </tbody></table>` : `<div class="empty">${naSpan('No survey data on file for this company yet')}</div>`}
        </div>
        ${srCeoRemunerationPanel(s)}
        <div class="panel">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Named Directors' Filed Remuneration \u2014 All Rows</h2></div>
          ${data.has_director_data ? `<table><thead><tr><th>Director Name</th><th>Position</th><th>Total</th><th>Page</th><th>Confidence</th></tr></thead><tbody>
            ${data.director_rows.map(r => `<tr><td>${escapeHtml(r.director_name)}${r.is_grand_total ? ' <b>(Grand Total)</b>' : r.is_total_row ? ' <i>(subtotal)</i>' : ''}</td><td>${escapeHtml(r.role || '-')}</td><td>${r.total !== null ? fmtFiled(r.total) : '-'}</td><td>${r.page || '-'}</td><td>${r.confidence !== null ? Math.round(r.confidence*100) + '%' : '-'}</td></tr>`).join('')}
          </tbody></table>` : `<div class="empty">${naSpan('No named-director remuneration filed for this company yet')}</div>`}
        </div>
      </div>
      <div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="sa-panel-title">Source Document Evidence</div>
          ${srRemunerationSourceEvidenceList(s)}
        </div>
        <div class="panel">
          <div class="sa-panel-title">Missing Disclosures</div>
          ${srMissingDisclosuresList(s)}
        </div>
      </div>
    </div>`;
}
// Per-director table with EACH FILED PAY COMPONENT as its own column
// (Salary/Bonus/Benefits/LTIP/Pension, or whatever the filing itself
// labelled its columns - see DirectorRemunerationRow.components'
// own docstring in models.py: no fixed schema is assumed). Gender/
// Independence come from a SEPARATE source (SurveyDirector, matched
// by name, same convention as srDirectorDetailPanel) since
// DirectorRemunerationRow itself has no such fields - shown as
// "\u2014" rather than guessed when no SurveyDirector row shares that
// exact name.
function srPerDirectorRemunerationTable(rows, profileByName){
  if (!rows.length) return `<div class="empty">${naSpan('No named directors of this type filed for this company yet')}</div>`;
  const allKeys = new Set();
  rows.forEach(r => { if (r.components) Object.keys(r.components).forEach(k => allKeys.add(k)); });
  const keys = Array.from(allKeys);
  return `<table><thead><tr><th>#</th><th>Director Name</th><th>Position</th><th>Gender</th>${keys.map(k => `<th>${escapeHtml(k)}</th>`).join('')}<th>Total</th><th>Page</th></tr></thead><tbody>
    ${rows.map((r,i) => {
      const profile = profileByName[r.director_name];
      return `<tr>
        <td>${i+1}</td><td>${escapeHtml(r.director_name)}</td><td>${escapeHtml(r.role === 'executive' ? 'Executive Director' : 'Non-Executive Director')}</td>
        <td>${profile && profile.gender ? escapeHtml(profile.gender) : naSpan('\u2014')}</td>
        ${keys.map(k => `<td>${r.components && r.components[k] !== undefined ? fmtFiled(r.components[k]) : naSpan('\u2014')}</td>`).join('')}
        <td style="font-weight:700;">${r.total !== null ? fmtFiled(r.total) : '-'}</td>
        <td>${r.page || naSpan('\u2014')}</td>
      </tr>`;
    }).join('')}
  </tbody></table>`;
}
// A curated few high-value fields with their exact filed wording, if
// the extractor captured a quote - most fields only have field_sources
// (a page reference string), not a stored quote, so this only shows a
// quote where one genuinely exists rather than fabricating one.
const SR_REMUNERATION_EVIDENCE_FIELDS = [
  'chairperson_annual_retainer', 'executive_director_annual_retainer', 'ceo_monthly_salary',
];
function srRemunerationSourceEvidenceList(s){
  if (!s) return `<div class="empty">${naSpan('No survey data on file for this company yet')}</div>`;
  const rows = SR_REMUNERATION_EVIDENCE_FIELDS
    .map(f => ({field: f, source: (s.field_sources || {})[f]}))
    .filter(r => r.source);
  if (!rows.length) return `<div class="empty">${naSpan('No sourced remuneration fields on file for this company yet')}</div>`;
  return rows.map(r => `<div style="margin-bottom:10px;padding-bottom:10px;border-bottom:1px solid var(--border);">
    <div style="font-size:11.5px;font-weight:700;">${escapeHtml(r.field.replace(/_/g,' '))}</div>
    <div style="font-size:11px;color:var(--text-faint);">${escapeHtml(r.source)}</div>
  </div>`).join('');
}
// Merged in from the (now-removed) Survey Companies page's CEO/MD
// Remuneration tab - these are company-level MONTHLY figures (a
// different unit than the annual retainer/allowance fields above),
// so kept as its own panel rather than folded into the annual table.
function srCeoRemunerationPanel(s){
  if (!s) return '';
  const ceoFields = ['ceo_monthly_salary','ceo_monthly_allowances','ceo_monthly_incentive_bonus',
    'ceo_monthly_deferred_incentive','ceo_monthly_non_cash_benefits','ceo_monthly_pension',
    'ceo_monthly_gratuity','ceo_monthly_share_value','ceo_monthly_cost_of_employment',
    'ceo_annual_salary_as_stated'];
  const anyCeoData = ceoFields.some(f => s[f] !== null && s[f] !== undefined);
  if (!anyCeoData) return '';
  // The pay figures below are on whatever scale this company's OWN director pay table
  // used (SurveyCompanyData.director_figures_unit - see app.py's to_pay_unit), which can
  // differ from the company's headline Unit (confirmed real: KCB Group Plc states
  // turnover in billions but director pay in thousands). Label it whenever it isn't
  // plain raw currency, rather than showing a bare number that looks like whole
  // currency when it may not be.
  const payUnit = surveyDirectorFiguresUnit(s);
  const payUnitSuffix = payUnit && payUnit.toLowerCase() !== 'units' ? `, ${escapeHtml(payUnit)}` : '';
  return `
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">CEO/MD Remuneration \u2014 Monthly (${escapeHtml(s.currency || 'KES')})</div>
      <table><thead><tr><th>Field</th><th>Value</th><th>Confidence</th></tr></thead><tbody>
        ${[
          ['Salary','ceo_monthly_salary'], ['Allowances','ceo_monthly_allowances'],
          ['Incentive / Bonus','ceo_monthly_incentive_bonus'], ['Deferred Incentive','ceo_monthly_deferred_incentive'],
          ['Non-Cash Benefits','ceo_monthly_non_cash_benefits'], ['Pension','ceo_monthly_pension'],
          ['Gratuity','ceo_monthly_gratuity'], ['Share Value','ceo_monthly_share_value'],
          ['Total Cost of Employment','ceo_monthly_cost_of_employment'],
        ].map(([label,f]) => `<tr><td>${label}</td><td>${s[f] !== null && s[f] !== undefined ? escapeHtml(s.currency || 'KES') + ' ' + fmtFull(s[f], payUnit) : naSpan('Not filed')}</td><td>${srConfBadge(s,f)}</td></tr>`).join('')}
        <tr><td>Annual Salary (as stated in filing)</td><td>${s.ceo_annual_salary_as_stated !== null && s.ceo_annual_salary_as_stated !== undefined ? escapeHtml(s.currency || 'KES') + ' ' + fmtFull(s.ceo_annual_salary_as_stated, payUnit) : naSpan('Not filed')}</td><td>${srConfBadge(s,'ceo_annual_salary_as_stated')}</td></tr>
        <tr><td>Monthly Conversion Basis</td><td>${s.ceo_monthly_conversion_basis ? escapeHtml(s.ceo_monthly_conversion_basis) : naSpan('Not filed')}</td><td>${srConfBadge(s,'ceo_monthly_conversion_basis')}</td></tr>
      </tbody></table>
    </div>`;
}

// ---- Tab 5: Committees ----
// Read-only data display by default (matches the design mockup: stat
// cards, a Committee Structure table with real page/confidence
// evidence, a Committee Members table). Editing (the original
// hand-entry form this tab used to open directly into) is now behind
// an explicit "Edit Committees" toggle instead of being the default
// view, since most visits are to review filed data, not add it.
let srEditableCommittees = null;
let srCommitteesEditMode = false;
function srCommitteesTab(data){
  const committees = data.committees || [];
  if (!srCommitteesEditMode) return srCommitteesReadView(committees);
  if (!srEditableCommittees) srEditableCommittees = JSON.parse(JSON.stringify(committees));
  return `
    <div class="panel" style="margin-bottom:14px;">
      <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Edit Board Committees</h2>
        <span>
          <button class="secondary" data-perm="admin" onclick="srAddCommitteeRow()">+ Add Committee</button>
          <button class="secondary" onclick="srCommitteesEditMode=false;renderSRTabBody();">Done Editing</button>
        </span>
      </div>
      ${!committees.length && !srEditableCommittees.length ? `<div class="empty">${naSpan('No committee data has been added for this company yet \u2014 use "+ Add Committee" to start recording committee structure')}</div>` : ''}
      <div id="srCommitteeList">${srRenderCommitteeRows()}</div>
      ${srEditableCommittees.length ? `<button class="btn-primary-cta" data-perm="admin" style="margin-top:12px;" onclick="srSaveCommittees()">Save Committees</button>` : ''}
    </div>`;
}
function srCommitteesReadView(committees){
  if (!committees.length) {
    return `<div class="panel"><div class="empty">${naSpan('No committee data has been added for this company yet')}</div>
      <button class="secondary" data-perm="admin" style="margin-top:10px;" onclick="srCommitteesEditMode=true;renderSRTabBody();">+ Add Committee</button></div>`;
  }
  const totalCommittees = committees.length;
  const totalMembers = committees.reduce((sum, c) => sum + (c.members ? c.members.length : (c.member_count || 0)), 0);
  const totalMeetings = committees.reduce((sum, c) => sum + (c.meetings_held || 0), 0);
  const withAttendance = committees.filter(c => c.attendance_rate !== null && c.attendance_rate !== undefined);
  const avgAttendance = withAttendance.length ? Math.round(withAttendance.reduce((s,c) => s + c.attendance_rate, 0) / withAttendance.length) : null;

  const allMembers = [];
  committees.forEach(c => (c.members || []).forEach(m => allMembers.push({...m, committee_name: c.name})));

  return `
    <div class="sa-stat-grid" style="margin-bottom:14px;">
      ${saStatCard('\ud83d\udc65', totalCommittees, 'Total Committees')}
      ${saStatCard('\ud83d\udc64', totalMembers, 'Total Members (across all committees)')}
      ${saStatCard('\ud83d\udcc5', totalMeetings || naSpan('Not filed'), 'Total Meetings Held')}
      ${saStatCard('\ud83d\udcca', avgAttendance !== null ? avgAttendance + '%' : naSpan('Not filed'), 'Average Meeting Attendance')}
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Committee Structure</h2>
        <button class="secondary" data-perm="admin" onclick="srCommitteesEditMode=true;renderSRTabBody();">Edit Committees</button>
      </div>
      <table><thead><tr><th>Committee</th><th>Chairperson</th><th>Members</th><th>Meetings Held</th><th>Attendance Rate</th><th>Source Page</th><th>Confidence</th></tr></thead><tbody>
        ${committees.map(c => `
          <tr>
            <td>${escapeHtml(c.name)}</td>
            <td>${c.chairperson_name ? escapeHtml(c.chairperson_name) : naSpan('Not stated')}</td>
            <td>${c.member_count !== null && c.member_count !== undefined ? c.member_count : (c.members ? c.members.length : naSpan('\u2014'))}</td>
            <td>${c.meetings_held !== null && c.meetings_held !== undefined ? c.meetings_held : naSpan('\u2014')}</td>
            <td>${c.attendance_rate !== null && c.attendance_rate !== undefined ? Math.round(c.attendance_rate) + '%' : naSpan('\u2014')}</td>
            <td>${c.page ? 'p.' + c.page : naSpan('\u2014')}</td>
            <td>${c.confidence !== null && c.confidence !== undefined ? Math.round(c.confidence*100) + '%' : naSpan('\u2014')}</td>
          </tr>`).join('')}
      </tbody></table>
    </div>
    <div class="panel">
      <div class="sa-panel-title">Committee Members</div>
      ${allMembers.length ? `<table><thead><tr><th>Name</th><th>Committee</th><th>Role</th></tr></thead><tbody>
        ${allMembers.map(m => `<tr><td>${escapeHtml(m.director_name)}</td><td>${escapeHtml(m.committee_name)}</td><td>${m.role_on_committee === 'chair' ? '<b>Chair</b>' : 'Member'}</td></tr>`).join('')}
      </tbody></table>` : `<div class="empty">${naSpan('No individual committee members recorded \u2014 only committee-level counts are on file')}</div>`}
    </div>`;
}
function srRenderCommitteeRows(){
  return srEditableCommittees.map((cm, i) => `
    <div class="panel" style="margin-bottom:10px;background:var(--bg-panel-2);">
      <div class="row row-2" style="margin-bottom:8px;">
        <input placeholder="Committee name (e.g. Audit Committee)" value="${escapeHtml(cm.name || '')}" oninput="srEditableCommittees[${i}].name=this.value">
        <input placeholder="Chairperson name" value="${escapeHtml(cm.chairperson_name || '')}" oninput="srEditableCommittees[${i}].chairperson_name=this.value">
      </div>
      <div class="row row-3" style="margin-bottom:8px;">
        <input type="number" placeholder="Member count" value="${cm.member_count ?? ''}" oninput="srEditableCommittees[${i}].member_count=this.value?Number(this.value):null">
        <input type="number" placeholder="Meetings held" value="${cm.meetings_held ?? ''}" oninput="srEditableCommittees[${i}].meetings_held=this.value?Number(this.value):null">
        <input type="number" placeholder="Attendance rate %" value="${cm.attendance_rate ?? ''}" oninput="srEditableCommittees[${i}].attendance_rate=this.value?Number(this.value):null">
      </div>
      <div style="font-size:10.5px;color:var(--text-faint);margin-bottom:6px;">Members</div>
      ${(cm.members || []).map((m, mi) => `
        <div class="row row-2" style="margin-bottom:6px;">
          <input placeholder="Director name" value="${escapeHtml(m.director_name || '')}" oninput="srEditableCommittees[${i}].members[${mi}].director_name=this.value">
          <select onchange="srEditableCommittees[${i}].members[${mi}].role_on_committee=this.value">
            <option value="member" ${m.role_on_committee === 'member' ? 'selected' : ''}>Member</option>
            <option value="chair" ${m.role_on_committee === 'chair' ? 'selected' : ''}>Chair</option>
          </select>
        </div>`).join('')}
      <button class="secondary" data-perm="admin" onclick="srEditableCommittees[${i}].members=srEditableCommittees[${i}].members||[];srEditableCommittees[${i}].members.push({director_name:'',role_on_committee:'member'});renderSRTabBody();">+ Add Member</button>
      <button class="secondary" data-perm="admin" style="margin-left:8px;color:var(--red);" onclick="srEditableCommittees.splice(${i},1);renderSRTabBody();">Remove Committee</button>
    </div>`).join('');
}
function srAddCommitteeRow(){
  srEditableCommittees.push({name:'', chairperson_name:'', member_count:null, meetings_held:null, attendance_rate:null, members:[]});
  renderSRTabBody();
}
function attachSRCommitteeHandlers(){ /* inputs use inline oninput/onchange - nothing to attach separately */ }
async function srSaveCommittees(){
  const res = await fetch(`/api/companies/${srCompanyId}/committees`, {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({committees: srEditableCommittees}),
  });
  if (res.ok) {
    srEditableCommittees = null;
    srCommitteesEditMode = false;
    await renderSurveyReportPage();
    switchSRTab('committees');
  }
}

// ---- Tab 6: Benefits & Allowances ----
// ---- Tab 6: Benefits & Allowances ----
// Two real, independent data sources: SurveyCompanyData.ned_benefits
// (a filed benefit-name -> {provided, detail} map, boolean only, no
// amounts) and DirectorRemunerationRow.components (a filing's own
// remuneration-table columns, keyed exactly as printed - see that
// column's own docstring in pdf_parse.py). Some filings' components
// genuinely include a benefits-shaped column (e.g. "Benefits (KES)"),
// but there's no fixed schema, so this tab scans for component keys
// that look benefit/allowance-related rather than assuming a fixed
// Housing/Vehicle/Medical/Travel/Pension category list - showing
// whichever columns a given filing actually has, never inventing
// categories the filing didn't print.
const SR_BENEFITS_SUBTABS = [
  {id: 'executive', label: 'Executive Directors'},
  {id: 'non_executive', label: 'Non-Executive Directors'},
  {id: 'per_director', label: 'Per Director Breakdown'},
];
let srBenefitsSubtab = 'executive';
const BENEFIT_KEY_PATTERN = /housing|vehicle|car|medical|health|travel|pension|benefit|allowance|insurance|mortgage|fuel/i;

function srBenefitsTab(data){
  const s = data.survey;
  const benefits = (s && s.ned_benefits) || null;
  const directorRows = (data.director_rows || []).filter(r => !r.is_grand_total && !r.is_total_row);
  const surveyBenefits = data.survey_director_benefits || [];
  const categories = data.benefit_categories || [];

  return `
    <div style="display:flex;gap:4px;border-bottom:1px solid var(--border);margin-bottom:14px;">
      ${SR_BENEFITS_SUBTABS.map(t => `
        <button onclick="srBenefitsSubtab='${t.id}';renderSRTabBody();"
          style="background:none;border:none;padding:9px 12px;font-size:12.5px;cursor:pointer;font-weight:${srBenefitsSubtab===t.id?'700':'500'};color:${srBenefitsSubtab===t.id?'var(--text)':'var(--text-faint)'};border-bottom:2px solid ${srBenefitsSubtab===t.id?'var(--blue)':'transparent'};">
          ${t.label}
        </button>`).join('')}
    </div>
    ${srBenefitsSubtab === 'per_director' ? srBenefitsPerDirectorView(directorRows, surveyBenefits, categories) : srBenefitsRoleView(srBenefitsSubtab, benefits, directorRows)}`;
}

function srBenefitsRoleView(role, benefits, directorRows){
  const roleRows = directorRows.filter(r => r.role === role);
  const amounts = [];
  roleRows.forEach(r => {
    if (!r.components) return;
    Object.entries(r.components).forEach(([k, v]) => {
      if (BENEFIT_KEY_PATTERN.test(k) && typeof v === 'number') amounts.push(v);
    });
  });
  const total = amounts.length ? amounts.reduce((a,b) => a+b, 0) : null;
  const avg = amounts.length ? total / roleRows.length : null;

  // NED-specific boolean benefits list only makes sense for non-executive
  const showNedBenefitsTable = role === 'non_executive' && benefits && Object.keys(benefits).length > 0;

  return `
    <div class="sa-stat-grid" style="margin-bottom:14px;">
      ${saStatCard('\ud83d\udcb0', total !== null ? fmtFiled(total) : naSpan('Not filed'), 'Total Benefits (filed components)')}
      ${saStatCard('\ud83d\udc64', avg !== null ? fmtFiled(avg) : naSpan('\u2014'), 'Avg. per Director')}
      ${saStatCard('\ud83d\udcca', roleRows.length, role === 'executive' ? 'Executive Directors Covered' : 'Non-Executive Directors Covered')}
    </div>
    ${showNedBenefitsTable ? `
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Benefits Provided (as filed)</div>
      <table><thead><tr><th>Benefit</th><th>Provided</th><th>Detail</th></tr></thead><tbody>
        ${Object.entries(benefits).map(([key, v]) => `
          <tr><td>${escapeHtml(key)}</td><td><span class="ov-status-pill ${v.provided ? 'completed' : 'pending'}">${v.provided ? 'Provided' : 'Not Provided'}</span></td><td>${v.detail ? escapeHtml(v.detail) : naSpan('\u2014')}</td></tr>`).join('')}
      </tbody></table>
    </div>` : ''}
    <div class="panel">
      <div class="sa-panel-title">Benefit Components in Filed Remuneration</div>
      ${roleRows.length ? `<table><thead><tr><th>Director</th>${srBenefitColumnHeaders(roleRows)}</tr></thead><tbody>
        ${roleRows.map(r => `<tr><td>${escapeHtml(r.director_name)}</td>${srBenefitColumnCells(roleRows, r)}</tr>`).join('')}
      </tbody></table>` : `<div class="empty">${naSpan(`No named ${role === 'executive' ? 'executive' : 'non-executive'} directors filed for this company yet`)}</div>`}
    </div>`;
}
function srBenefitColumnKeys(rows){
  const keys = new Set();
  rows.forEach(r => { if (r.components) Object.keys(r.components).forEach(k => { if (BENEFIT_KEY_PATTERN.test(k)) keys.add(k); }); });
  return Array.from(keys);
}
function srBenefitColumnHeaders(rows){
  const keys = srBenefitColumnKeys(rows);
  return keys.length ? keys.map(k => `<th>${escapeHtml(k)}</th>`).join('') : '<th>Benefit Components</th>';
}
function srBenefitColumnCells(allRoleRows, r){
  const keys = srBenefitColumnKeys(allRoleRows);
  if (!keys.length) return `<td>${naSpan('No benefit-related column in this filing\u2019s table')}</td>`;
  return keys.map(k => `<td>${r.components && r.components[k] !== undefined ? fmtFiled(r.components[k]) : naSpan('\u2014')}</td>`).join('');
}
// Real per-director non-cash-benefit TOTALS (SurveyDirectorBenefit,
// models_survey.py) - a separate, independently-run extractor from
// the components-scan above (which only reverse-engineers a benefit
// figure from whatever columns a director's own remuneration table
// row happened to have). Shown as its own section since the two
// sources aren't guaranteed to agree or even both exist for the same
// director - see SurveyDirectorBenefit's own docstring for why they're
// matched by name, not merged into one row at write time.
function srBenefitsPerDirectorView(directorRows, surveyBenefits, categories){
  const withComponents = directorRows.filter(r => r.components && Object.keys(r.components).some(k => BENEFIT_KEY_PATTERN.test(k)));
  return `
    ${srBenefitCategoriesPanel(categories || [])}
    ${srSurveyDirectorBenefitsPanel(surveyBenefits)}
    <div class="panel">
      <div class="sa-panel-title">Benefit Components in Filed Director Remuneration Tables</div>
      ${withComponents.length ? (() => {
        const allKeys = srBenefitColumnKeys(withComponents);
        return `<table><thead><tr><th>Director</th><th>Position</th>${allKeys.map(k => `<th>${escapeHtml(k)}</th>`).join('')}<th>Total</th></tr></thead><tbody>
          ${withComponents.map(r => `<tr>
            <td>${escapeHtml(r.director_name)}</td><td>${escapeHtml(r.role || '-')}</td>
            ${allKeys.map(k => `<td>${r.components[k] !== undefined ? fmtFiled(r.components[k]) : naSpan('\u2014')}</td>`).join('')}
            <td style="font-weight:700;">${r.total !== null ? fmtFiled(r.total) : '-'}</td>
          </tr>`).join('')}
        </tbody></table>`;
      })() : `<div class="empty">${naSpan('No director\u2019s filed remuneration table includes a benefits-related column for this company')}</div>`}
    </div>`;
}
// SurveyBenefitCategory rows: an ITEMIZED breakdown (Housing, Vehicle,
// Medical, Travel, Pension, Other, ...) - see that model's docstring for
// why this is hand-entered rather than auto-extracted (real filings almost
// always describe these in prose, not a clean amount-per-category table).
// Split into company-level rows (director_name is null) and per-director
// rows, since a filing can state either shape.
let srAddingBenefitCategory = false;
function srBenefitCategoriesPanel(categories){
  const companyLevel = categories.filter(c => !c.director_name);
  const perDirector = categories.filter(c => c.director_name);
  const row = (c) => `<tr>
      <td>${c.director_name ? escapeHtml(c.director_name) : '<span style="color:var(--text-faint);">Company-wide</span>'}</td>
      <td>${escapeHtml(c.category)}</td>
      <td style="font-weight:700;">${fmtFiled(c.amount)}</td>
      <td style="font-size:11.5px;">${c.description ? escapeHtml(c.description) : naSpan('\u2014')}</td>
      ${canEdit() ? `<td><button class="secondary" style="color:var(--red);padding:2px 8px;font-size:11px;" onclick="srDeleteBenefitCategory(${c.id})">Delete</button></td>` : ''}
    </tr>`;
  return `
    <div class="panel" style="margin-bottom:14px;">
      <div class="ov-panel-head"><div class="sa-panel-title" style="margin:0;">Itemized Benefits Breakdown (as filed)</div>
        ${canEdit() ? `<button class="btn" onclick="srAddingBenefitCategory = !srAddingBenefitCategory; renderSRTabBody();">${srAddingBenefitCategory ? 'Cancel' : '+ Add Category'}</button>` : ''}
      </div>
      ${srAddingBenefitCategory ? srBenefitCategoryForm() : ''}
      ${categories.length ? `<table><thead><tr><th>Director</th><th>Category</th><th>Amount</th><th>Detail</th>${canEdit() ? '<th></th>' : ''}</tr></thead><tbody>
        ${companyLevel.map(row).join('')}${perDirector.map(row).join('')}
      </tbody></table>` : `<div class="empty">${naSpan('No itemized benefits breakdown filed for this company/year yet \u2014 most filings only give a single lump total (see the sections below); add one by hand here if the filing itself breaks it out by category (Housing, Vehicle, Medical, Travel, Pension, etc.)')}</div>`}
    </div>`;
}
function srBenefitCategoryForm(){
  return `
    <div class="panel" style="margin-bottom:14px;background:var(--bg-subtle,rgba(0,0,0,0.02));">
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;">
        <label style="font-size:11px;">Director (optional)<br><input id="bcDirectorName" type="text" placeholder="leave blank for company-wide" style="width:180px;"></label>
        <label style="font-size:11px;">Category<br><input id="bcCategory" type="text" placeholder="e.g. Housing Allowance" style="width:160px;"></label>
        <label style="font-size:11px;">Amount<br><input id="bcAmount" type="number" step="any" style="width:120px;"></label>
        <label style="font-size:11px;">Detail (optional)<br><input id="bcDescription" type="text" placeholder="e.g. mortgage support" style="width:200px;"></label>
        <button class="btn primary" onclick="srSaveBenefitCategory()">Save</button>
      </div>
      <div id="bcFormError" style="color:var(--red);font-size:11px;margin-top:6px;"></div>
    </div>`;
}
async function srSaveBenefitCategory(){
  const fiscalYear = srDataCache && srDataCache.survey ? srDataCache.survey.fiscal_year : srFiscalYear;
  const errEl = document.getElementById('bcFormError');
  if (!fiscalYear) { errEl.textContent = 'This company has no survey fiscal year on file yet - upload survey data first.'; return; }
  const body = {
    fiscal_year: fiscalYear,
    director_name: document.getElementById('bcDirectorName').value.trim() || null,
    category: document.getElementById('bcCategory').value.trim(),
    amount: document.getElementById('bcAmount').value,
    description: document.getElementById('bcDescription').value.trim() || null,
  };
  if (!body.category) { errEl.textContent = 'Category is required.'; return; }
  if (body.amount === '' || isNaN(Number(body.amount))) { errEl.textContent = 'Amount must be a number.'; return; }
  const res = await fetch(`/api/companies/${srCompanyId}/benefit-categories`, {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body),
  });
  const d = await res.json();
  if (!res.ok) { errEl.textContent = d.error || 'Could not save.'; return; }
  srAddingBenefitCategory = false;
  await renderSurveyReportPage();
}
async function srDeleteBenefitCategory(id){
  if (!confirm('Remove this benefit category row?')) return;
  await fetch(`/api/benefit-categories/${id}`, {method: 'DELETE'});
  await renderSurveyReportPage();
}
// SurveyDirectorBenefit rows: a real, separately-run extractor that
// reads a filing's own "non-cash benefits" column directly, rather
// than reverse-engineering one from whichever columns a remuneration
// table happens to have (see srBenefitColumnKeys above). Matched to a
// director by name only - see SurveyDirectorBenefit's own docstring
// for why this is never merged into one row with the components-scan
// table above.
function srSurveyDirectorBenefitsPanel(surveyBenefits){
  if (!surveyBenefits || !surveyBenefits.length) {
    return `<div class="panel" style="margin-bottom:14px;"><div class="sa-panel-title">Non-Cash Benefits (as filed)</div><div class="empty">${naSpan('No non-cash benefit figures extracted for named directors at this company yet')}</div></div>`;
  }
  const total = surveyBenefits.reduce((sum, b) => sum + (b.total_amount || 0), 0);
  return `
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Non-Cash Benefits (as filed)</div>
      <table><thead><tr><th>Director</th><th>Position</th><th>Total Benefit</th><th>Detail</th><th>Source Page</th><th>Confidence</th></tr></thead><tbody>
        ${surveyBenefits.map(b => `<tr>
          <td>${escapeHtml(b.director_name)}</td>
          <td>${b.position ? escapeHtml(b.position) : naSpan('\u2014')}</td>
          <td style="font-weight:700;">${b.total_amount !== null && b.total_amount !== undefined ? fmtFiled(b.total_amount) : naSpan('\u2014')}</td>
          <td style="font-size:11.5px;">${b.detail ? escapeHtml(b.detail) : naSpan('\u2014')}</td>
          <td>${b.page ? 'p.' + b.page : naSpan('\u2014')}</td>
          <td>${b.confidence !== null && b.confidence !== undefined ? Math.round(b.confidence*100) + '%' : naSpan('\u2014')}</td>
        </tr>`).join('')}
        <tr><td style="font-weight:700;">Total</td><td></td><td style="font-weight:700;">${fmtFiled(total)}</td><td></td><td></td><td></td></tr>
      </tbody></table>
    </div>`;
}

// ---- Tab 7: Evidence & Sources ----
// ---- Tab 7: Evidence & Sources ----
const SR_EVIDENCE_SUBTABS = [
  {id: 'executive', label: 'Executive Directors'},
  {id: 'non_executive', label: 'Non-Executive Directors'},
];
let srEvidenceSubtab = 'executive';
function srEvidenceTab(data){
  const docs = data.source_documents || [];
  const s = data.survey;
  const directorRows = (data.director_rows || []).filter(r => !r.is_grand_total && !r.is_total_row);
  const profileByName = {};
  (data.survey_director_rows || []).forEach(d => { profileByName[d.director_name] = d; });

  return `
    <div class="row row-2" style="grid-template-columns:1.6fr 1fr;">
      <div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Source Documents</h2></div>
          ${docs.length ? `<table><thead><tr><th>Document</th><th>Financial Year</th><th>Pages</th>${canEdit() ? '<th>Extraction Score</th>' : ''}</tr></thead><tbody>
            ${docs.map(d => `<tr><td>${escapeHtml(d.filename || d.url || 'Untitled document')}</td><td>${d.period_label ? escapeHtml(d.period_label) : naSpan('\u2014')}</td><td>${d.page_count !== null && d.page_count !== undefined ? d.page_count : naSpan('\u2014')}</td>${canEdit() ? `<td>${extractionScoreBadge(d)}</td>` : ''}${d.url ? `<td><a href="${escapeHtml(d.url)}" target="_blank" rel="noopener">View</a></td>` : '<td></td>'}</tr>`).join('')}
          </tbody></table>` : `<div class="empty">${naSpan('No source documents on file for this company yet')}</div>`}
        </div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="ov-panel-head"><h2 class="sa-panel-title" style="margin:0;">Extracted Remuneration Data</h2></div>
          <div style="display:flex;gap:4px;border-bottom:1px solid var(--border);margin-bottom:12px;">
            ${SR_EVIDENCE_SUBTABS.map(t => `
              <button onclick="srEvidenceSubtab='${t.id}';renderSRTabBody();"
                style="background:none;border:none;padding:8px 10px;font-size:12px;cursor:pointer;font-weight:${srEvidenceSubtab===t.id?'700':'500'};border-bottom:2px solid ${srEvidenceSubtab===t.id?'var(--blue)':'transparent'};">
                ${t.label}
              </button>`).join('')}
          </div>
          ${srPerDirectorRemunerationTable(directorRows.filter(r => r.role === srEvidenceSubtab), profileByName)}
        </div>
        <div class="panel">
          <div class="sa-panel-title">Per-Field Source References (Survey Data)</div>
          ${s && s.field_sources && Object.keys(s.field_sources).length ? `
          <table><thead><tr><th>Field</th><th>Source</th></tr></thead><tbody>
            ${Object.entries(s.field_sources).map(([f, ref]) => `<tr><td>${escapeHtml(f)}</td><td>${escapeHtml(ref)}</td></tr>`).join('')}
          </tbody></table>` : `<div class="empty">${naSpan('No per-field source references recorded for this company\u2019s survey data')}</div>`}
        </div>
      </div>
      <div>
        ${srDocumentInsightsPanel(docs, s)}
        <div class="panel">
          <div class="sa-panel-title">Named-Director Filed Rows (Evidence Trail)</div>
          ${data.has_director_data ? `<table><thead><tr><th>Director</th><th>Page</th><th>Confidence</th></tr></thead><tbody>
            ${data.director_rows.map(r => `<tr><td>${escapeHtml(r.director_name)}</td><td>${r.page || '-'}</td><td>${r.confidence !== null ? Math.round(r.confidence*100) + '%' : '-'}</td></tr>`).join('')}
          </tbody></table>` : `<div class="empty">${naSpan('No named-director remuneration filed for this company yet')}</div>`}
        </div>
      </div>
    </div>`;
}
// A real, computed summary - NOT the mockup's literal per-document
// "312 pages / 118 of 124 fields extracted / Processed" status, since
// SourceDocument has no per-document extracted-field-count or status
// column (see its own definition in models.py) and no doc-level
// extraction status is tracked anywhere in this app. What IS real and
// shown instead: how many documents are on file, their total page
// count, and how many of this company's survey fields have SOME
// source reference at all (a genuine, if coarser, completeness signal).
function srDocumentInsightsPanel(docs, s){
  const totalPages = docs.reduce((sum, d) => sum + (d.page_count || 0), 0);
  const sourcedFieldCount = s && s.field_sources ? Object.keys(s.field_sources).length : 0;
  return `
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Document Insights</div>
      <ul style="margin:0;padding-left:18px;font-size:12.5px;line-height:1.7;">
        <li>${docs.length} source document${docs.length === 1 ? '' : 's'} on file for this company.</li>
        ${totalPages ? `<li>${totalPages} total page${totalPages === 1 ? '' : 's'} across those documents.</li>` : ''}
        ${s ? `<li>${sourcedFieldCount} survey field${sourcedFieldCount === 1 ? '' : 's'} have a recorded source reference.</li>` : `<li>${naSpan('No survey data on file to check field-level sourcing')}</li>`}
      </ul>
    </div>`;
}

// ---- Tab 8: Survey Mapping ----
// "Mapped" here means: this SurveyCompanyData column has a non-null
// value AND the app has some field-level evidence for it (confidence
// score or a source reference) - "Partially Mapped" means it has a
// value but no evidence attached - "Unmapped" means the column itself
// is null. This is a genuinely different (simpler) meaning than the
// design mockup's "extracted-value-mapped-to-survey-field" workflow,
// which would need a real field-mapping/review model this app doesn't
// have - flagged in the panel caption below rather than faked.
let srMappingStatusFilter = 'all';
let srMappingSectionFilter = 'all';
let srMappingSearch = '';
function srSurveyMappingTab(data){
  const s = data.survey;
  if (!s) return `<div class="panel"><div class="empty">${naSpan('No survey data on file for this company yet')}</div></div>`;
  // Uses MAPPING_FIELDS and renderMappingTab, shared with the Data
  // Quality tab below (see renderMappingTab's own comment).
  return renderMappingTab(s, {
    statusFilter: srMappingStatusFilter, sectionFilter: srMappingSectionFilter, search: srMappingSearch,
    onSetStatusFilter: 'srSetMappingStatusFilter', onSetSectionFilter: 'srSetMappingSectionFilter',
    onSetSearch: 'srSetMappingSearch', onApprove: 'srApproveField', onCorrect: 'srPromptCorrectField',
  });
}
function srSetMappingStatusFilter(v){ srMappingStatusFilter = v; renderSRTabBody(); }
function srSetMappingSectionFilter(v){ srMappingSectionFilter = v; renderSRTabBody(); }
function srSetMappingSearch(v){ srMappingSearch = v; renderSRTabBody(); }
async function srApproveField(field){ await srReviewField(field, 'approve'); }
function srPromptCorrectField(field, currentValue){
  const next = prompt('Corrected value:', currentValue);
  if (next === null || next.trim() === '') return;
  const numeric = Number(next);
  srReviewField(field, 'correct', Number.isNaN(numeric) ? next : numeric);
}
async function srReviewField(field, action, correctedValue){
  const body = {field, action};
  if (action === 'correct') body.corrected_value = correctedValue;
  const fiscalYear = srDataCache && srDataCache.survey ? srDataCache.survey.fiscal_year : null;
  if (!fiscalYear) return;
  const result = await safeJson(await fetch(`/api/survey-data/${srCompanyId}/${encodeURIComponent(fiscalYear)}/review`, {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body),
  }), null);
  if (result && result.ok) {
    srDataCache.survey = {...srDataCache.survey, ...result.survey_data};
    renderSRTabBody();
  }
}

// ---- Tab 9: Data Quality ----
// ---- Tab 9: Data Quality ----
// "Manual Overrides" = fields with a field_review_corrections entry
// (a person actually typed a replacement value - see review_survey_
// field's docstring in app.py). "Validation Errors" = open
// EvidenceConflict rows (two different chunks of the same filing
// disagreed on a field's value and neither was auto-picked - see
// EvidenceConflict's own docstring in models_survey.py). Both are
// real, queryable concepts, not estimates - unlike the mockup's literal
// "Manual Overrides (7)" / "Validation Errors (3)" cards, this shows
// whatever the real counts are for this company, which may be zero.
let srDQIssueFilter = 'all';
let srDQSearch = '';
let srDataQualityChart = null;
function srDataQualityTab(data){
  const s = data.survey;
  if (!s) return `<div class="panel"><div class="empty">${naSpan('No survey data on file for this company yet')}</div></div>`;
  const rows = MAPPING_FIELDS.map(m => ({
    ...m,
    val: s[m.field],
    conf: s.field_confidence && s.field_confidence[m.field],
    source: s.field_sources && s.field_sources[m.field],
    overridden: !!(s.field_review_corrections && s.field_review_corrections[m.field]),
  }));
  const complete = rows.filter(r => r.val !== null && r.val !== undefined && (r.conf === undefined || r.conf >= 0.75)).length;
  const needsReview = rows.filter(r => r.val !== null && r.val !== undefined && r.conf !== undefined && r.conf < 0.75).length;
  const missing = rows.filter(r => r.val === null || r.val === undefined).length;
  const manualOverrides = rows.filter(r => r.overridden).length;
  const openConflicts = (data.evidence_conflicts || []).filter(ec => ec.is_open);
  const score = rows.length ? Math.round(complete / rows.length * 100) : 0;

  const issueRows = rows.filter(r => r.val === null || r.val === undefined || r.overridden || (r.conf !== undefined && r.conf < 0.75))
    .map(r => {
      let issueType, issueDetail;
      if (r.val === null || r.val === undefined) { issueType = 'missing'; issueDetail = 'Missing'; }
      else if (r.overridden) { issueType = 'override'; issueDetail = 'Manual Override'; }
      else { issueType = 'low_confidence'; issueDetail = 'Low Confidence'; }
      return {...r, issueType, issueDetail};
    });
  // EvidenceConflicts are field-level too, but live in a separate table
  // (see EvidenceConflict's own docstring) - surfaced as their own
  // "validation_error" issue rows rather than folded into issueRows above,
  // since a conflict isn't tied to a single candidate value the way a
  // missing/low-confidence/overridden SurveyCompanyData field is.
  const conflictRows = openConflicts.map(ec => ({
    field: ec.field_name, label: ec.field_name, section: 'Evidence Conflict',
    issueType: 'validation_error', issueDetail: 'Validation Error',
    val: null, conf: undefined, source: null,
  }));
  const allIssues = [...issueRows, ...conflictRows];

  let filteredIssues = allIssues;
  if (srDQIssueFilter !== 'all') filteredIssues = filteredIssues.filter(r => r.issueType === srDQIssueFilter);
  if (srDQSearch.trim()) {
    const q = srDQSearch.trim().toLowerCase();
    filteredIssues = filteredIssues.filter(r => r.label.toLowerCase().includes(q) || (r.source || '').toLowerCase().includes(q));
  }

  const issueTabs = [
    ['all', `All Issues (${allIssues.length})`],
    ['missing', `Missing Fields (${missing})`],
    ['low_confidence', `Low Confidence (${needsReview})`],
    ['override', `Manual Overrides (${manualOverrides})`],
    ['validation_error', `Validation Errors (${openConflicts.length})`],
  ];

  return `
    <div class="row row-2" style="grid-template-columns:1fr 1.6fr;">
      <div class="panel">
        <div class="sa-panel-title">Overall Data Quality Score</div>
        ${saDonut2([['Complete', Math.round(complete/rows.length*100), 'var(--green)'], ['Needs Review', Math.round(needsReview/rows.length*100), 'var(--amber)'], ['Missing', Math.round(missing/rows.length*100), 'var(--red)']], `${score}%`)}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Data Issues Summary</div>
        <div class="sa-stat-grid" style="grid-template-columns:repeat(4,1fr);">
          ${saStatCard('❗', missing, 'Missing Fields')}
          ${saStatCard('⚠️', needsReview, 'Low Confidence')}
          ${saStatCard('✏️', manualOverrides, 'Manual Overrides')}
          ${saStatCard('🚫', openConflicts.length, 'Validation Errors')}
        </div>
      </div>
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Quality Trend</div>
      ${(data.quality_by_year || []).length > 1
        ? `<div style="height:220px;"><canvas id="srDQTrendChart"></canvas></div>`
        : `<div class="empty">${naSpan('Only one fiscal year on file for this company \u2014 a trend needs at least two')}</div>`}
    </div>
    <div class="row row-2" style="grid-template-columns:1.6fr 1fr;">
      <div class="panel">
        <div class="ov-panel-head" style="margin-bottom:10px;">
          <h2 class="sa-panel-title" style="margin:0;">Data Quality Issues</h2>
          <input type="text" placeholder="Search issues..." value="${escapeHtml(srDQSearch)}" oninput="srDQSearch=this.value;renderSRTabBody();" style="padding:6px 10px;font-size:12.5px;width:220px;">
        </div>
        <div style="display:flex;gap:4px;border-bottom:1px solid var(--border);margin-bottom:12px;flex-wrap:wrap;">
          ${issueTabs.map(([id, label]) => `
            <button onclick="srDQIssueFilter='${id}';renderSRTabBody();" style="background:none;border:none;padding:8px 10px;font-size:11.5px;cursor:pointer;font-weight:${srDQIssueFilter===id?'700':'500'};border-bottom:2px solid ${srDQIssueFilter===id?'var(--blue)':'transparent'};">${label}</button>`).join('')}
        </div>
        <table><thead><tr><th>Field</th><th>Section</th><th>Issue Type</th><th>Value</th><th>Source</th><th>Confidence</th></tr></thead><tbody>
          ${filteredIssues.length ? filteredIssues.map(r => `<tr>
              <td>${escapeHtml(r.label)}</td>
              <td style="color:var(--text-faint);font-size:11px;">${escapeHtml(r.section)}</td>
              <td>${srDQIssueBadge(r.issueType, r.issueDetail)}</td>
              <td>${r.val !== null && r.val !== undefined ? escapeHtml(String(r.val)) : naSpan('\u2014')}</td>
              <td style="font-size:11px;">${r.source ? escapeHtml(r.source) : naSpan('\u2014')}</td>
              <td>${r.conf !== undefined ? Math.round(r.conf*100) + '%' : naSpan('\u2014')}</td>
            </tr>`).join('') : `<tr><td colspan="6"><div class="empty">No issues match this filter.</div></td></tr>`}
        </tbody></table>
      </div>
      <div>
        ${srDQKeyInsightsPanel(rows, missing, needsReview, manualOverrides, openConflicts, score)}
        ${srDQRecommendedActionsPanel(missing, needsReview, openConflicts)}
      </div>
    </div>`;
}
function srDQIssueBadge(type, label){
  const color = type === 'missing' ? 'var(--red)' : type === 'validation_error' ? 'var(--red)' : type === 'override' ? 'var(--blue)' : 'var(--amber)';
  return `<span style="color:${color};font-weight:700;font-size:11px;">${escapeHtml(label)}</span>`;
}
function srDQKeyInsightsPanel(rows, missing, needsReview, manualOverrides, openConflicts, score){
  const insights = [];
  if (missing) insights.push(`${missing} field${missing === 1 ? ' is' : 's are'} missing from the filing on record.`);
  if (needsReview) insights.push(`${needsReview} field${needsReview === 1 ? ' has' : 's have'} a confidence score below 75% and may need verification.`);
  if (manualOverrides) insights.push(`${manualOverrides} field${manualOverrides === 1 ? ' was' : 's were'} manually corrected during review.`);
  if (openConflicts.length) insights.push(`${openConflicts.length} field${openConflicts.length === 1 ? '' : 's'} ${openConflicts.length === 1 ? 'has' : 'have'} two conflicting extracted values still unresolved.`);
  insights.push(`Overall data quality score is ${score}% (${score >= 75 ? 'Good' : score >= 50 ? 'Fair' : 'Needs Attention'}).`);
  return `
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Key Insights</div>
      <ul style="margin:0;padding-left:18px;font-size:12.5px;line-height:1.7;">${insights.map(i => `<li>${i}</li>`).join('')}</ul>
    </div>`;
}
function srDQRecommendedActionsPanel(missing, needsReview, openConflicts){
  const actions = [];
  if (missing) actions.push('Collect and file the missing fields from the company\u2019s source documents.');
  if (needsReview) actions.push('Review and confirm the low-confidence extracted values.');
  if (openConflicts.length) actions.push('Resolve the open evidence conflicts by choosing the correct candidate value for each.');
  return `
    <div class="panel">
      <div class="sa-panel-title">Recommended Actions</div>
      ${actions.length ? `<ol style="margin:0;padding-left:18px;font-size:12.5px;line-height:1.8;">${actions.map(a => `<li>${a}</li>`).join('')}</ol>`
        : `<div class="empty">${naSpan('No outstanding data quality issues for this company')}</div>`}
    </div>`;
}
function srDrawDataQualityTrend(data){
  const canvas = document.getElementById('srDQTrendChart');
  if (!canvas || typeof Chart === 'undefined') return;
  const years = data.quality_by_year || [];
  if (years.length < 2) return;
  if (srDataQualityChart) srDataQualityChart.destroy();
  const labels = years.map(y => y.fiscal_year);
  const scores = years.map(y => {
    const confMap = y.field_confidence || {};
    const scored = Object.values(confMap);
    if (!scored.length) return null;
    const complete = scored.filter(c => c >= 0.75).length;
    return Math.round(complete / scored.length * 100);
  });
  srDataQualityChart = new Chart(canvas, {
    type: 'line',
    data: {labels, datasets: [{label: 'Data Quality Score', data: scores, borderColor: '#48cfa0', backgroundColor: 'rgba(72,207,160,.15)', tension: .3}]},
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {legend: {labels: {color: '#aaccbb'}}},
      scales: {
        x: {ticks: {color: themeChartColors().tick}, grid: {color: themeChartColors().grid}},
        y: {ticks: {color: themeChartColors().tick}, grid: {color: themeChartColors().grid}, min: 0, max: 100},
      },
    },
  });
}

// ---------- Intelligence Layer (interactive, 6 tabs) ----------
// Sits on top of Survey Analytics' aggregate data, but lets the user
// pick a company/sector/year/comparison-group rather than reading one
// fixed report - fundamentally different interaction model, so this is
// its own page, not a tab inside Survey Analytics & Reporting. Backed
// by two new endpoints (added 2026-09-13): /api/intelligence-layer/
// companies (per-company rows + an illustrative governance score - see
// GOVERNANCE_SCORE_METHODOLOGY in survey_aggregate.py, always shown
// alongside any score in this UI) and /api/intelligence-layer/
// historical-trends (one build_survey_overview() per fiscal year that
// has data, so trend lines are real multi-year series, never
// interpolated for a year with nothing on file).
const IL_TABS = [
  {id:'multi-year', label:'Comparative Intelligence'},
  {id:'benchmarking', label:'Benchmarking'},
  {id:'survey-insights', label:'Survey Insights'},
  {id:'historical-trends', label:'Historical Trends'},
  {id:'company-profiles', label:'Company Profiles'},
  {id:'company-rankings', label:'Company Rankings'},
  {id:'governance-compliance', label:'Governance & Compliance'},
];
let ilTab = 'benchmarking';
let ilFiscalYear = null;
let ilCompaniesCache = null;
let ilTrendsCache = null;
let ilBenchmarkCompanyId = null;
let ilBenchmarkSector = 'all';
let ilProfileCompanyId = null;
let ilRankingsSubtab = 'top-pay';

async function renderIntelligenceLayerPage(){
  const app = document.getElementById('app');
  document.getElementById('pageTitle').textContent = 'Intelligence Report';
  document.getElementById('pageSub').textContent = 'Compare, benchmark and explore trends across every surveyed company';
  setPageActions(null);

  const companiesData = await safeJson(
    await fetch('/api/intelligence-layer/companies' + (ilFiscalYear ? `?fiscal_year=${encodeURIComponent(ilFiscalYear)}` : '')),
    {has_data: false, rows: []}
  );
  ilCompaniesCache = companiesData;
  ilFiscalYear = companiesData.fiscal_year || ilFiscalYear;

  if (!companiesData.has_data) {
    const years = fullYears(companiesData.available_fiscal_years);
    app.innerHTML = `<div class="panel"><div class="empty">
      ${years.length
        ? `No companies on file for this fiscal year. Available: ${years.map(y => `<a href="#" onclick="ilFiscalYear='${escapeHtml(y)}';renderIntelligenceLayerPage();return false;">${escapeHtml(y)}</a>`).join(', ')}`
        : 'No survey data uploaded yet. Add company survey data from the Survey Companies page first.'}
    </div></div>`;
    return;
  }

  if (!ilBenchmarkCompanyId) ilBenchmarkCompanyId = companiesData.rows[0].company_id;
  if (!ilProfileCompanyId) ilProfileCompanyId = companiesData.rows[0].company_id;

  // Company count + NSE + year selector live in the top bar (beside the user badge), not in the page body.
  setPageActions([
    {label: 'Documents & Reports', icon: '🗂️', perm: 'user', onClick: `docOpenFor('${ilFiscalYear || ''}')`},
  ], `<span><b>${companiesData.rows.length}</b> companies in survey</span><span>NSE listed</span>
    <select title="Fiscal year" onchange="ilFiscalYear=this.value;ilProfileCompanyId=null;ilBenchmarkCompanyId=null;renderIntelligenceLayerPage();">
      ${fullYears(companiesData.available_fiscal_years || [ilFiscalYear]).map(y => `<option value="${escapeHtml(y)}" ${y === ilFiscalYear ? 'selected' : ''}>${escapeHtml(y)}</option>`).join('')}
    </select>`);

  rpHeaderSelect('section','Section',IL_TABS,ilTab,switchILTab);

  app.innerHTML = `
    
    <div id="ilTabBody"></div>
  `;
  renderILTabBody();
}
function switchILTab(tabId){
  ilTab = tabId;
  rpRemoveSelect('ranking');
  rpHeaderSelect('section','Section',IL_TABS,tabId,switchILTab);
  renderILTabBody();
}
async function renderILTabBody(){
  const body = document.getElementById('ilTabBody');
  if (!body) return;
  body.innerHTML = `<div class="empty">Loading\u2026</div>`;
  if (ilTab === 'multi-year') return rpCompare(body,'intelligence',ilCompaniesCache.available_fiscal_years,null,ilCompaniesCache.rows);
  if (ilTab === 'benchmarking') body.innerHTML = ilBenchmarkingTab();
  else if (ilTab === 'survey-insights') body.innerHTML = ilSurveyInsightsTab();
  else if (ilTab === 'historical-trends') body.innerHTML = await ilHistoricalTrendsTab();
  else if (ilTab === 'company-profiles') body.innerHTML = ilCompanyProfilesTab();
  else if (ilTab === 'company-rankings') body.innerHTML = ilCompanyRankingsTab();
  else if (ilTab === 'governance-compliance') body.innerHTML = ilGovernanceComplianceTab();
}

function ilSectorList(){
  const sectors = [...new Set(ilCompaniesCache.rows.map(r => r.sector).filter(Boolean))].sort();
  return sectors;
}
function ilSectorRows(sector){
  return ilCompaniesCache.rows.filter(r => sector === 'all' || r.sector === sector);
}

// ---- Tab 1: Benchmarking ----
// ---- Tab 1: Benchmarking ----
const IL_BENCHMARK_METRICS = [
  {field: 'total_director_remuneration', label: 'Total Director Remuneration'},
  {field: 'chairperson_annual_retainer', label: 'Chairperson Annual Retainer'},
  {field: 'executive_director_annual_retainer', label: 'Executive Director Annual Retainer'},
  {field: 'other_ned_annual_retainer', label: 'Non-Executive Director Annual Retainer'},
  {field: 'total_directors_fees', label: "Total Non-Executive Directors' Fees"},
  {field: 'kmp_total', label: 'Key Management Pay (total)'},
  {field: 'audit_fee', label: 'Audit Fee'},
  {field: 'audit_fee_pct_of_turnover', label: 'Audit Fee as % of Turnover', kind: 'pct'},
  {field: 'board_attendance_pct', label: 'Board Meeting Attendance', kind: 'pct'},
  {field: 'employees_count', label: 'Employees', kind: 'count'},
  {field: 'staff_costs', label: 'Staff Costs'},
  {field: 'staff_cost_per_employee', label: 'Staff Cost per Employee'},
  {field: 'women_in_workforce_pct', label: 'Women in the Workforce', kind: 'pct'},
  {field: 'women_in_senior_management_pct', label: 'Women in Senior Management', kind: 'pct'},
  {field: 'earnings_per_share', label: 'Earnings per Share', kind: 'pershare'},
  {field: 'dividend_per_share', label: 'Dividend per Share', kind: 'pershare'},
  {field: 'top10_shareholding_pct', label: 'Top 10 Shareholders - Combined Holding', kind: 'pct'},
];
// How a benchmark metric is written: money in full, percentages with %, counts whole, per-share to 2 decimals.
function ilMetricFmt(field){
  const m = IL_BENCHMARK_METRICS.find(x => x.field === field) || {};
  if (m.kind === 'pct') return v => `${fmt(v, 1)}%`;
  if (m.kind === 'count') return v => fmtAmount(Math.round(v));
  if (m.kind === 'pershare') return v => fmt(v, 2);
  return v => fmtAmount(Math.round(v));
}
let ilBenchFmtFn = fmtAmount;
let ilBenchmarkMetric = 'total_director_remuneration';
function ilBenchmarkingTab(){
  const rows = ilCompaniesCache.rows;
  const company = rows.find(r => r.company_id === ilBenchmarkCompanyId) || rows[0];
  const metricField = ilBenchmarkMetric;
  const metricLabel = (IL_BENCHMARK_METRICS.find(m => m.field === metricField) || {}).label || metricField;
  ilBenchFmtFn = ilMetricFmt(metricField);
  const sectorRows = ilSectorRows(company.sector || 'all').filter(r => r[metricField] !== null);
  const sectorAvg = sectorRows.length ? sectorRows.reduce((a,r) => a + r[metricField], 0) / sectorRows.length : null;
  const withMetric = rows.filter(r => r[metricField] !== null);
  const top = withMetric.length ? withMetric.reduce((a,b) => a[metricField] > b[metricField] ? a : b) : null;
  const lowest = withMetric.length ? withMetric.reduce((a,b) => a[metricField] < b[metricField] ? a : b) : null;

  return `
    <div class="il-filter-bar">
      <div class="il-filter-field"><label>Company</label>
        <select onchange="ilBenchmarkCompanyId=Number(this.value);renderILTabBody();">
          ${rows.map(r => `<option value="${r.company_id}" ${r.company_id === company.company_id ? 'selected' : ''}>${escapeHtml(r.name)}</option>`).join('')}
        </select>
      </div>
      <div class="il-filter-field"><label>Comparison Group</label>
        <select disabled title="Sector of the selected company">
          <option>${escapeHtml(company.sector || 'Unclassified')} Sector</option>
        </select>
      </div>
      <div class="il-filter-field"><label>Metric</label>
        <select onchange="ilBenchmarkMetric=this.value;renderILTabBody();">
          ${IL_BENCHMARK_METRICS.map(m => `<option value="${m.field}" ${m.field === metricField ? 'selected' : ''}>${escapeHtml(m.label)}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="sa-stat-grid">
      ${saStatCard('👤', company[metricField] !== null ? ilBenchFmtFn(company[metricField]) : naSpan('Not filed'), escapeHtml(company.name), metricLabel)}
      ${saStatCard('🏦', sectorAvg !== null ? ilBenchFmtFn(sectorAvg) : naSpan('Not enough sector data'), escapeHtml(company.sector || 'Sector') + ' Average', metricLabel)}
      ${saStatCard('🏆', top ? ilBenchFmtFn(top[metricField]) : naSpan('Not enough data'), 'Top Performer (Sector)', top ? escapeHtml(top.name) : '')}
      ${saStatCard('📉', lowest ? ilBenchFmtFn(lowest[metricField]) : naSpan('Not enough data'), 'Lowest Performer (Sector)', lowest ? escapeHtml(lowest.name) : '')}
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">${escapeHtml(metricLabel)} \u2014 Company vs Sector</div>
        ${company[metricField] !== null || sectorAvg !== null ? `
        <div class="sa-bar-list">
          ${company[metricField] !== null ? saBar(company.name, ilBenchFmtFn(company[metricField]), Math.max(company[metricField], sectorAvg||0, top ? top[metricField] : 0)) : ''}
          ${sectorAvg !== null ? saBar('Sector Average', ilBenchFmtFn(sectorAvg), Math.max(company[metricField]||0, sectorAvg, top ? top[metricField] : 0), 'var(--green)') : ''}
          ${top ? saBar('Top Performer', ilBenchFmtFn(top[metricField]), Math.max(company[metricField]||0, sectorAvg||0, top[metricField]), 'var(--purple)') : ''}
        </div>` : `<div class="empty">${naSpan('Not enough data')}</div>`}
      </div>
      <div class="panel">
        <div class="sa-panel-title">${escapeHtml(metricLabel)} by Sector</div>
        ${ilSectorAvgBarList(metricField)}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Board Size Comparison</div>
        ${ilBoardSizeComparisonPanel(company, sectorRows, top, lowest)}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Key Governance Metrics</div>
        ${ilKeyGovernanceMetricsPanel(company)}
      </div>
    </div>
    <div class="panel">
      <div class="sa-panel-title">Top 5 Companies by ${escapeHtml(metricLabel)}</div>
      ${ilTopCompaniesTable(withMetric, metricField, 5, metricLabel, ilBenchFmtFn)}
    </div>`;
}
function ilBoardSizeComparisonPanel(company, sectorRows, top, lowest){
  const sectorWithSize = sectorRows.filter(r => r.board_size !== null);
  const sectorAvgSize = sectorWithSize.length ? Math.round(sectorWithSize.reduce((a,r) => a + r.board_size, 0) / sectorWithSize.length) : null;
  const bars = [];
  if (company.board_size !== null) bars.push(['Company', company.board_size]);
  if (sectorAvgSize !== null) bars.push(['Sector Avg', sectorAvgSize]);
  if (top && top.board_size !== null && top.board_size !== undefined) bars.push(['Top Performer', top.board_size]);
  if (lowest && lowest.board_size !== null && lowest.board_size !== undefined) bars.push(['Lowest Performer', lowest.board_size]);
  if (!bars.length) return `<div class="empty">${naSpan('Board size not filed for this company or its sector peers')}</div>`;
  const max = Math.max(...bars.map(b => b[1]));
  return `<div class="sa-bar-list">${bars.map(([label, val]) => saBar(label, val, max)).join('')}</div>`;
}
// Uses the same _governance_score()/'governance' block build_company_rows
// already computes per company (survey_aggregate.py) - see that
// function's docstring for the exact CMA-threshold methodology. No
// CMA Compliance Rate or Committee Meetings donut here: neither is
// computed anywhere in the backend for a single company (Committee
// Meetings exists only as committee_meetings_per_year, a company-wide
// count with no compliance threshold attached), so those two mockup
// cards are left out rather than approximated from an unrelated number.
function ilKeyGovernanceMetricsPanel(company){
  const gov = company.governance || {};
  const items = [
    ['Board Independence', gov.independence_pct, gov.independence_compliant],
    ['Gender Diversity (Board)', gov.gender_pct, gov.gender_compliant],
  ];
  return `
    <div class="row row-2">
      ${items.map(([label, pct, compliant]) => pct !== null && pct !== undefined ? `
        <div style="text-align:center;">
          ${saDonut2([[label, Math.round(pct), compliant ? 'var(--green)' : 'var(--amber)'], ['Remaining', Math.round(100-pct), 'var(--bg-hover)']], Math.round(pct)+'%')}
          <div style="font-size:11px;color:var(--text-faint);margin-top:4px;">${escapeHtml(label)}</div>
        </div>` : `<div class="empty" style="align-self:center;">${naSpan(label + ' not enough data')}</div>`).join('')}
    </div>
    <div style="font-size:10px;color:var(--text-faint);margin-top:10px;">${escapeHtml(ilCompaniesCache.governance_methodology || '')}</div>`;
}
function ilSectorAvgBarList(field){
  const sectors = ilSectorList();
  const rows = sectors.map(sec => {
    const secRows = ilSectorRows(sec).filter(r => r[field] !== null);
    if (!secRows.length) return null;
    return {name: sec, val: secRows.reduce((a,r) => a + r[field], 0) / secRows.length};
  }).filter(Boolean);
  if (!rows.length) return `<div class="empty">${naSpan('Not enough data')}</div>`;
  rows.sort((a,b) => b.val - a.val);
  const max = Math.max(...rows.map(r => r.val));
  return `<div class="sa-bar-list">${rows.map(r => saBar(r.name, ilBenchFmtFn(r.val), max)).join('')}</div>`;
}
function ilTopCompaniesTable(rows, field, limit, label, fmtFn){
  fmtFn = fmtFn || fmtAmount;
  const sorted = [...rows].filter(r => r[field] !== null).sort((a,b) => b[field] - a[field]).slice(0, limit);
  if (!sorted.length) return `<div class="empty">${naSpan('Not enough data')}</div>`;
  return `<table><thead><tr><th>#</th><th>Company</th><th>Sector</th><th>${escapeHtml(label || 'Total Director Remuneration')}</th></tr></thead><tbody>
    ${sorted.map((r,i) => `<tr class="clickable" onclick="goToCompanySurveyData(${r.company_id})"><td>${i+1}</td><td>${escapeHtml(r.name)}</td><td>${escapeHtml(r.sector || '-')}</td><td>${fmtFn(r[field])}</td></tr>`).join('')}
  </tbody></table>`;
}

// ---- Tab 2: Survey Insights ----
// Reuses build_survey_overview() via /api/survey/overview (same data as
// Survey Analytics' Executive Summary tab) - this tab is the same real
// numbers, framed as an insights readout rather than a report page.
let ilInsightsOverviewCache = null;
function ilSurveyInsightsTab(){
  fetch('/api/survey/overview' + (ilFiscalYear ? `?fiscal_year=${encodeURIComponent(ilFiscalYear)}` : ''))
    .then(r => r.json()).then(ov => {
      ilInsightsOverviewCache = ov;
      const body = document.getElementById('ilTabBody');
      if (body && ilTab === 'survey-insights') body.innerHTML = ilSurveyInsightsBody(ov);
    });
  if (!ilTrendsCache) {
    fetch('/api/intelligence-layer/historical-trends').then(r => r.json()).then(t => {
      ilTrendsCache = t;
      const body = document.getElementById('ilTabBody');
      if (body && ilTab === 'survey-insights' && ilInsightsOverviewCache) body.innerHTML = ilSurveyInsightsBody(ilInsightsOverviewCache);
    }).catch(() => { ilTrendsCache = {has_data: false}; });
  }
  return `<div class="empty">Loading\u2026</div>`;
}
function ilSurveyInsightsBody(ov){
  if (!ov.has_data) return `<div class="panel"><div class="empty">${naSpan('No survey data on file for this fiscal year')}</div></div>`;
  const es = ov.executive_summary, bo = ov.board_overview, cr = ov.committee_remuneration;
  const femPct = (bo.total_directors_female !== null && bo.total_directors_male !== null && (bo.total_directors_female+bo.total_directors_male) > 0)
    ? Math.round(bo.total_directors_female/(bo.total_directors_female+bo.total_directors_male)*100) : null;
  return `
    <div class="sa-stat-grid">
      ${saStatCard('💰', saMetricAvg(es.avg_turnover) !== null ? fmtMillions(es.avg_turnover.average) : naSpan('Not enough data'), 'Avg. Turnover')}
      ${saStatCard('👤', saMetricAvg(ov.directors_remuneration.executive_director_annual_retainer) !== null ? fmtAmount(ov.directors_remuneration.executive_director_annual_retainer.average) : naSpan('Not enough data'), 'Avg. Executive Director Pay')}
      ${saStatCard('👥', saMetricAvg(ov.directors_remuneration.other_ned_annual_retainer) !== null ? fmtAmount(ov.directors_remuneration.other_ned_annual_retainer.average) : naSpan('Not enough data'), 'Avg. NED Pay')}
      ${saStatCard('📋', cr && saMetricAvg(cr.committee_member_annual_retainer) !== null ? fmtAmount(cr.committee_member_annual_retainer.average) : naSpan('Not enough data'), 'Avg. Committee Member Retainer')}
      ${saStatCard('🏛️', bo.avg_board_size && bo.avg_board_size.average !== null ? Math.round(bo.avg_board_size.average * 10) / 10 : naSpan('Not enough data'), 'Avg. Board Size')}
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Key Insights</div>
        <div class="sr-insight-panel">
          ${saMetricAvg(ov.directors_remuneration.executive_director_annual_retainer) !== null ? `<div class="sa-insight-row"><div class="sa-numbered-icon">1</div><div class="sa-insight-text-body">Executive directors average ${escapeHtml(ov.currency)} ${fmtAmount(ov.directors_remuneration.executive_director_annual_retainer.average)} in annual retainer.</div></div>` : ''}
          ${femPct !== null ? `<div class="sa-insight-row"><div class="sa-numbered-icon">2</div><div class="sa-insight-text-body">Female board representation is ${femPct}%.</div></div>` : ''}
          ${ov.directors_remuneration.chairperson_vs_other_ned_annual_retainer_ratio !== null ? `<div class="sa-insight-row"><div class="sa-numbered-icon">3</div><div class="sa-insight-text-body">Board chairs earn ${ov.directors_remuneration.chairperson_vs_other_ned_annual_retainer_ratio}x the retainer of other NEDs.</div></div>` : ''}
          ${[saMetricAvg(ov.directors_remuneration.executive_director_annual_retainer), femPct].every(v => v === null) ? `<div class="empty">${naSpan('Not enough data yet for key insights')}</div>` : ''}
        </div>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Top 5 Companies by Total Board Remuneration</div>
        ${ilTopCompaniesTable(ilCompaniesCache.rows, 'total_director_remuneration', 5)}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Total Board Remuneration by Sector</div>
        ${saSectorBarList(ov.sector_comparison, 'avg_other_ned_annual_retainer')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Gender Diversity</div>
        ${ilGenderDiversityDonuts(bo)}
      </div>
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Pay Trends</div>
      ${ilPayTrendsChart(ov)}
    </div>
    <div class="panel">
      <div class="sa-panel-title">What the Data Tells Us</div>
      ${ilWhatTheDataTellsUs(ov, femPct)}
    </div>`;
}
function ilGenderDiversityDonuts(bo){
  const total = (bo.total_directors_female || 0) + (bo.total_directors_male || 0);
  if (!total) return `<div class="empty">${naSpan('Not enough data')}</div>`;
  const femPct = Math.round(bo.total_directors_female / total * 100);
  return saDonut2([['Female', femPct, 'var(--purple)'], ['Male', 100 - femPct, 'var(--blue)']], femPct + '%');
}
// Uses the SAME multi-year series as the Historical Trends tab
// (ilTrendsCache, from /api/intelligence-layer/historical-trends) -
// a real portfolio-wide average per year, not interpolated.
function ilPayTrendsChart(ov){
  if (!ilTrendsCache) return `<div class="empty">Loading\u2026</div>`;
  if (!ilTrendsCache.has_data || ilTrendsCache.series.length < 2) {
    return `<div class="empty">${naSpan('At least two fiscal years of survey data are needed to chart a trend')}</div>`;
  }
  const years = ilTrendsCache.series.map(s => s.fiscal_year);
  const execSeries = ilTrendsCache.series.map(s => {
    const m = s.directors_remuneration && s.directors_remuneration.executive_director_annual_retainer;
    return m && m.average !== null ? m.average : null;
  });
  const nedSeries = ilTrendsCache.series.map(s => {
    const m = s.directors_remuneration && s.directors_remuneration.other_ned_annual_retainer;
    return m && m.average !== null ? m.average : null;
  });
  if (execSeries.every(v => v === null) && nedSeries.every(v => v === null)) {
    return `<div class="empty">${naSpan('Not enough data across years to chart pay trends')}</div>`;
  }
  const max = Math.max(1, ...execSeries.filter(v => v !== null), ...nedSeries.filter(v => v !== null));
  return `
    <div class="sa-bar-list">
      ${years.map((y,i) => execSeries[i] !== null ? saBar(y + ' \u2014 Executive', fmtAmount(execSeries[i]), max) : '').join('')}
    </div>
    <div class="sa-bar-list" style="margin-top:8px;">
      ${years.map((y,i) => nedSeries[i] !== null ? saBar(y + ' \u2014 NED', fmtAmount(nedSeries[i]), max, 'var(--green)') : '').join('')}
    </div>`;
}
function ilWhatTheDataTellsUs(ov, femPct){
  const items = [];
  if (saMetricAvg(ov.directors_remuneration.executive_director_annual_retainer) !== null) {
    items.push(['📈', 'Remuneration', `Executive director pay averages ${escapeHtml(ov.currency)} ${fmtAmount(ov.directors_remuneration.executive_director_annual_retainer.average)} across surveyed companies.`]);
  }
  if (femPct !== null) {
    items.push(['♀️', 'Gender Balance', `Female board representation stands at ${femPct}% across the surveyed portfolio.`]);
  }
  if (ov.sector_comparison && ov.sector_comparison.length) {
    items.push(['🏢', 'Sector Concentration', `Data spans ${ov.sector_comparison.length} sector${ov.sector_comparison.length === 1 ? '' : 's'}.`]);
  }
  if (ov.board_overview.avg_board_meetings_per_year && ov.board_overview.avg_board_meetings_per_year.average !== null) {
    items.push(['📅', 'Board Activity', `Boards meet an average of ${Math.round(ov.board_overview.avg_board_meetings_per_year.average * 10) / 10} times per year.`]);
  }
  if (!items.length) return `<div class="empty">${naSpan('Not enough data on file yet to generate portfolio-wide observations')}</div>`;
  return `<div class="row row-2">${items.map(([icon, title, text]) => `
    <div style="display:flex;gap:10px;">
      <div style="font-size:20px;">${icon}</div>
      <div><div style="font-weight:700;font-size:12.5px;">${escapeHtml(title)}</div><div style="font-size:11.5px;color:var(--text-dim);">${text}</div></div>
    </div>`).join('')}</div>`;
}

// ---- Tab 3: Historical Trends ----
async function ilHistoricalTrendsTab(){
  if (!ilTrendsCache) ilTrendsCache = await safeJson(await fetch('/api/intelligence-layer/historical-trends'), {has_data: false});
  const t = ilTrendsCache;
  if (!t.has_data || t.series.length < 2) {
    return `<div class="panel"><div class="empty">${naSpan('At least two fiscal years of survey data are needed to chart a trend \u2014 ' + (t.series ? t.series.length : 0) + ' currently on file')}</div></div>`;
  }
  const years = t.series.map(s => s.fiscal_year);
  const nedSeries = t.series.map(s => saMetricAvg(s.directors_remuneration.other_ned_annual_retainer, {raw:true}));
  const execSeries = t.series.map(s => saMetricAvg(s.directors_remuneration.executive_director_annual_retainer, {raw:true}));
  const chairSeries = t.series.map(s => saMetricAvg(s.directors_remuneration.chairperson_annual_retainer, {raw:true}));
  const latest = t.series[t.series.length - 1];
  const first = t.series[0];

  return `
    <div class="sa-stat-grid" style="margin-bottom:14px;">
      ${saStatCard('💰', saMetricAvg(latest.directors_remuneration.executive_director_annual_retainer) !== null ? fmtAmount(latest.directors_remuneration.executive_director_annual_retainer.average) : naSpan('Not enough data'), `Avg. Executive Director Pay (${escapeHtml(latest.fiscal_year)})`)}
      ${saStatCard('👥', saMetricAvg(latest.directors_remuneration.other_ned_annual_retainer) !== null ? fmtAmount(latest.directors_remuneration.other_ned_annual_retainer.average) : naSpan('Not enough data'), `Avg. NED Pay (${escapeHtml(latest.fiscal_year)})`)}
      ${saStatCard('📋', latest.committee_remuneration && saMetricAvg(latest.committee_remuneration.committee_member_annual_retainer) !== null ? fmtAmount(latest.committee_remuneration.committee_member_annual_retainer.average) : naSpan('Not enough data'), `Avg. Committee Member Retainer (${escapeHtml(latest.fiscal_year)})`)}
      ${saStatCard('♀️', ilFemalePctForYear(latest) !== null ? ilFemalePctForYear(latest) + '%' : naSpan('Not enough data'), `Female Representation (${escapeHtml(latest.fiscal_year)})`)}
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Director Remuneration Trends (${escapeHtml(t.series[0].currency)})</div>
      <table><thead><tr><th>Fiscal Year</th><th>Avg. NED Retainer</th><th>Avg. Executive Director Retainer</th><th>Avg. Chairperson Retainer</th></tr></thead><tbody>
        ${years.map((y,i) => `<tr><td>${escapeHtml(y)}</td>
          <td>${nedSeries[i] !== null ? fmtAmount(nedSeries[i]) : naSpan('Not enough data')}</td>
          <td>${execSeries[i] !== null ? fmtAmount(execSeries[i]) : naSpan('Not enough data')}</td>
          <td>${chairSeries[i] !== null ? fmtAmount(chairSeries[i]) : naSpan('Not enough data')}</td></tr>`).join('')}
      </tbody></table>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Board Size Trend</div>
        ${ilTrendBarList(t.series, s => saMetricAvg(s.board_overview.avg_board_size))}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Companies Surveyed per Year</div>
        ${ilTrendBarList(t.series, s => s.companies_surveyed)}
      </div>
    </div>
    <div class="row row-2" style="margin-top:14px;">
      <div class="panel">
        <div class="sa-panel-title">Committee Fee Trends</div>
        ${t.series.every(s => !s.committee_remuneration)
          ? `<div class="empty">${naSpan('No committee remuneration data across the years on file')}</div>`
          : `<div class="sa-bar-list">${ilTrendBarList(t.series, s => s.committee_remuneration ? saMetricAvg(s.committee_remuneration.committee_chair_annual_retainer, {raw:true}) : null)}</div>
             <div style="font-size:10px;color:var(--text-faint);margin-top:6px;">Average committee chair annual retainer per year.</div>`}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Gender Diversity Trend</div>
        ${ilTrendBarList(t.series, s => ilFemalePctForYear(s))}
        <div style="font-size:10px;color:var(--text-faint);margin-top:6px;">Portfolio-wide female representation (%) per year.</div>
      </div>
    </div>
    <div class="panel" style="margin-top:14px;">
      <div class="sa-panel-title">Key Insights</div>
      ${ilHistoricalTrendsInsights(first, latest, years)}
    </div>`;
}
function ilFemalePctForYear(s){
  const bo = s.board_overview;
  const total = (bo.total_directors_female || 0) + (bo.total_directors_male || 0);
  return total ? Math.round(bo.total_directors_female / total * 100) : null;
}
// Deliberately does NOT attempt a CEO/CFO-specific pay-trend split or
// a Pay Growth by Sector percentage panel - no per-role (CEO vs CFO
// vs other EDs) breakdown exists anywhere in the aggregate data this
// app computes (ceo_monthly_* fields are company-level only, never
// portfolio-averaged), and a real year-over-year growth % per sector
// would need each sector's own prior-year average, which
// sector_comparison gives per-year but this app doesn't diff across
// years anywhere - so neither is shown rather than approximated.
function ilHistoricalTrendsInsights(first, latest, years){
  const insights = [];
  const firstExec = saMetricAvg(first.directors_remuneration.executive_director_annual_retainer, {raw:true});
  const latestExec = saMetricAvg(latest.directors_remuneration.executive_director_annual_retainer, {raw:true});
  if (firstExec !== null && latestExec !== null && firstExec > 0) {
    const pctChange = Math.round((latestExec - firstExec) / firstExec * 100);
    insights.push(`Average executive director pay ${pctChange >= 0 ? 'grew' : 'fell'} ${Math.abs(pctChange)}% from ${escapeHtml(first.fiscal_year)} to ${escapeHtml(latest.fiscal_year)}.`);
  }
  const firstFem = ilFemalePctForYear(first), latestFem = ilFemalePctForYear(latest);
  if (firstFem !== null && latestFem !== null) {
    insights.push(`Female board representation moved from ${firstFem}% (${escapeHtml(first.fiscal_year)}) to ${latestFem}% (${escapeHtml(latest.fiscal_year)}).`);
  }
  insights.push(`Data spans ${years.length} fiscal years: ${escapeHtml(first.fiscal_year)} to ${escapeHtml(latest.fiscal_year)}.`);
  return `<ul style="margin:0;padding-left:18px;font-size:12.5px;line-height:1.7;">${insights.map(i => `<li>${i}</li>`).join('')}</ul>`;
}
function ilTrendBarList(series, getVal){
  const rows = series.map(s => ({name: s.fiscal_year, val: getVal(s)})).filter(r => r.val !== null && r.val !== undefined);
  if (!rows.length) return `<div class="empty">${naSpan('Not enough data')}</div>`;
  const max = Math.max(...rows.map(r => r.val));
  return `<div class="sa-bar-list">${rows.map(r => saBar(r.name, r.val, max)).join('')}</div>`;
}

// ---- Tab 4: Company Profiles ----
let ilProfileSector = 'all';
let ilProfileSearch = '';
// Company Profiles: one compact picker (sector filter + search + a single drop-down grouped by sector +
// previous/next) instead of a chip for every company. The profile below only redraws itself.
function ilProfileList(){
  const q = ilProfileSearch.trim().toLowerCase();
  return ilCompaniesCache.rows
    .filter(r => ilProfileSector === 'all' || (r.sector || 'Other') === ilProfileSector)
    .filter(r => !q || (r.name || '').toLowerCase().includes(q) || (r.ticker || '').toLowerCase().includes(q))
    .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
}
function ilProfilePickerInner(){
  const list = ilProfileList();
  const idx = list.findIndex(r => r.company_id === ilProfileCompanyId);
  const bySector = {};
  list.forEach(r => { (bySector[r.sector || 'Other'] = bySector[r.sector || 'Other'] || []).push(r); });
  const opt = r => `<option value="${r.company_id}" ${r.company_id === ilProfileCompanyId ? 'selected' : ''}>${escapeHtml(r.name)}</option>`;
  const options = list.length
    ? Object.keys(bySector).sort().map(sec => `<optgroup label="${escapeHtml(sec)}">${bySector[sec].map(opt).join('')}</optgroup>`).join('')
    : '<option value="">No company matches</option>';
  return {options, count: list.length ? `${idx >= 0 ? idx + 1 : '–'} of ${list.length}` : '0 of 0', hasPrev: idx > 0, hasNext: idx >= 0 && idx < list.length - 1};
}
function ilProfileRefreshPicker(){
  const p = ilProfilePickerInner();
  document.getElementById('ilProfSel').innerHTML = p.options;
  document.getElementById('ilProfCount').textContent = p.count;
  document.getElementById('ilProfPrev').disabled = !p.hasPrev;
  document.getElementById('ilProfNext').disabled = !p.hasNext;
}
function ilProfilePick(id){ ilProfileCompanyId = id; ilProfileRefreshPicker(); document.getElementById('ilProfDetail').innerHTML = ilProfileDetail(); }
function ilProfileStep(d){
  const list = ilProfileList(); const i = list.findIndex(r => r.company_id === ilProfileCompanyId);
  const n = list[i + d]; if (n) ilProfilePick(n.company_id);
}
function ilProfileFilterChanged(){
  ilProfileSector = document.getElementById('ilProfSector').value;
  ilProfileSearch = document.getElementById('ilProfSearch').value;
  const list = ilProfileList();
  if (list.length && !list.some(r => r.company_id === ilProfileCompanyId)) ilProfilePick(list[0].company_id);
  else ilProfileRefreshPicker();
}
function ilCompanyProfilesTab(){
  const rows = ilCompaniesCache.rows;
  if (!rows.some(r => r.company_id === ilProfileCompanyId)) ilProfileCompanyId = rows[0].company_id;
  const sectors = {};
  rows.forEach(r => { const k = r.sector || 'Other'; sectors[k] = (sectors[k] || 0) + 1; });
  const p = ilProfilePickerInner();
  return `
    <div class="il-picker">
      <div class="il-filter-field"><label>Sector</label>
        <select id="ilProfSector" onchange="ilProfileFilterChanged()">
          <option value="all">All sectors (${rows.length})</option>
          ${Object.keys(sectors).sort().map(k => `<option value="${escapeHtml(k)}" ${k === ilProfileSector ? 'selected' : ''}>${escapeHtml(k)} (${sectors[k]})</option>`).join('')}
        </select></div>
      <div class="il-filter-field"><label>Search</label>
        <input id="ilProfSearch" type="search" placeholder="Name or ticker" value="${escapeHtml(ilProfileSearch)}" oninput="ilProfileFilterChanged()"></div>
      <div class="il-filter-field il-pick-main"><label>Company</label>
        <select id="ilProfSel" onchange="ilProfilePick(+this.value)">${p.options}</select></div>
      <div class="il-pick-nav">
        <button class="secondary" id="ilProfPrev" onclick="ilProfileStep(-1)" ${p.hasPrev ? '' : 'disabled'} title="Previous company">&larr;</button>
        <span class="il-pick-count" id="ilProfCount">${p.count}</span>
        <button class="secondary" id="ilProfNext" onclick="ilProfileStep(1)" ${p.hasNext ? '' : 'disabled'} title="Next company">&rarr;</button>
      </div>
    </div>
    <div id="ilProfDetail">${ilProfileDetail()}</div>`;
}
function ilProfileDetail(){
  const rows = ilCompaniesCache.rows;
  const company = rows.find(r => r.company_id === ilProfileCompanyId) || rows[0];
  const gov = company.governance;
  return `
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">${escapeHtml(company.name)}</div>
        <table><tbody>
          <tr><td>Sector</td><td>${escapeHtml(company.sector || '-')}</td></tr>
          <tr><td>Ticker</td><td>${escapeHtml(company.ticker || '-')}</td></tr>
          <tr><td>Fiscal Year</td><td>${escapeHtml(company.fiscal_year)}</td></tr>
          <tr><td>Board Size</td><td>${company.board_size !== null ? company.board_size : naSpan('Not filed')}</td></tr>
          <tr><td>Board Meetings / Year</td><td>${company.board_meetings_per_year !== null ? company.board_meetings_per_year : naSpan('Not filed')}</td></tr>
          <tr><td>Total Director Remuneration</td><td>${company.total_director_remuneration !== null ? fmtAmount(company.total_director_remuneration) : naSpan('Not filed')}</td></tr>
        </tbody></table>
        <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap;">
          <button class="secondary" onclick="goToCompanySurveyData(${company.company_id})">View Intelligence Report (financials) &rarr;</button>
          <button class="secondary" onclick="goToCompanySurveyData(${company.company_id})">View Survey Data (board, committees, evidence) &rarr;</button>
        </div>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Board Composition</div>
        ${company.independent_neds_count !== null && company.non_independent_neds_count !== null && (company.independent_neds_count+company.non_independent_neds_count) > 0
          ? saDonut2([['Independent NEDs', Math.round(company.independent_neds_count/(company.independent_neds_count+company.non_independent_neds_count)*100), 'var(--blue)'], ['Non-Independent NEDs', Math.round(company.non_independent_neds_count/(company.independent_neds_count+company.non_independent_neds_count)*100), 'var(--green)']], `${company.independent_neds_count+company.non_independent_neds_count}`)
          : `<div class="empty">${naSpan('Not filed in survey data')}</div>`}
      </div>
    </div>
    <div class="panel">
      <div class="sa-panel-title">Illustrative Governance Score</div>
      ${ilGovScoreBlock(gov)}
    </div>
    ${ilExtendedProfilePanel(company)}
    <div class="panel" style="margin-top:14px;font-size:11px;color:var(--text-faint);">
      This tab compares companies on their survey data (board, pay, audit, workforce and shareholder figures as stated in each annual report). For the full report figures and document-level detail (committees, benefits, source evidence), use the links above.
    </div>`;
}
function ilExtendedProfilePanel(c){
  const cur = escapeHtml((ilCompaniesCache.rows[0] || {}).currency || 'KES');
  const v = (x, f) => (x === null || x === undefined || x === '') ? naSpan('Not stated in the report') : f(x);
  const money = x => `${cur} ${fmtAmount(Math.round(x))}`, pct = x => `${fmt(x, 1)}%`, num = x => fmtAmount(Math.round(x)), ps = x => `${cur} ${fmt(x, 2)}`, txt = x => escapeHtml(String(x));
  const rows = (items) => `<table><tbody>${items.map(([l, x, f]) => `<tr><td>${escapeHtml(l)}</td><td>${v(x, f)}</td></tr>`).join('')}</tbody></table>`;
  return `<div class="row row-3" style="margin-top:14px;">
    <div class="panel"><div class="sa-panel-title">Audit & Governance</div>${rows([
      ['External auditor', c.auditor_name, txt], ['Audit opinion', c.audit_opinion, txt], ['Going-concern warning', c.going_concern_uncertainty, txt],
      ['Audit fee', c.audit_fee, money], ['Board attendance', c.board_attendance_pct, pct], ['Chair and CEO separate', c.chair_ceo_separate, txt],
      ['Independent chair', c.chair_independent, txt], ['Governance audit', c.governance_audit_done, txt]])}</div>
    <div class="panel"><div class="sa-panel-title">Pay & Workforce</div>${rows([
      ['Key management pay (total)', c.kmp_total, money], ["Non-executive directors' fees", c.total_directors_fees, money],
      ['Employees', c.employees_count, num], ['Staff costs', c.staff_costs, money], ['Staff cost per employee', c.staff_cost_per_employee, money],
      ['Women in the workforce', c.women_in_workforce_pct, pct], ['Women in senior management', c.women_in_senior_management_pct, pct]])}</div>
    <div class="panel"><div class="sa-panel-title">Shareholders & Returns</div>${rows([
      ['Earnings per share', c.earnings_per_share, ps], ['Dividend per share', c.dividend_per_share, ps], ['Dividend payout', c.payout_ratio_pct, pct],
      ['Shareholders', c.shareholders_count, num], ['Top 10 holders - combined', c.top10_shareholding_pct, pct]])}</div>
  </div>`;
}
function ilGovScoreBlock(gov){
  if (!gov || gov.score === null) return `<div class="empty">${naSpan('Not enough board-composition data filed to compute this')}</div>`;
  return `
    <div class="il-gov-bar-wrap" style="margin-bottom:10px;">
      <div style="font-size:26px;font-weight:700;">${gov.score}</div>
      <div class="il-gov-bar-track"><div class="il-gov-bar-fill" style="width:${gov.score}%;background:${gov.score >= 75 ? 'var(--green)' : gov.score >= 50 ? 'var(--amber)' : 'var(--red)'};"></div></div>
    </div>
    <div style="font-size:11.5px;color:var(--text-dim);margin-bottom:6px;">
      ${gov.independence_pct !== null ? `Board independence: <b>${gov.independence_pct}%</b> ${gov.independence_compliant ? '✔️ meets 1/3 threshold' : '\u2014 below 1/3 threshold'}<br>` : ''}
      ${gov.gender_pct !== null ? `Gender diversity: <b>${gov.gender_pct}%</b> ${gov.gender_compliant ? '✔️ meets 1/3 threshold' : '\u2014 below 1/3 threshold'}` : ''}
    </div>
    <div class="il-methodology-note">${escapeHtml(ilCompaniesCache.governance_methodology)}</div>`;
}

// ---- Tab 5: Company Rankings ----
let ilAwSort = 'employees_count';
function ilRankingsAuditWorkforce(rows){
  const cols = [['auditor_name','Auditor','txt'],['audit_opinion','Opinion','txt'],['audit_fee','Audit fee','money'],['board_attendance_pct','Attendance','pct'],
    ['employees_count','Employees','num'],['staff_cost_per_employee','Staff cost / employee','money'],['women_in_workforce_pct','Women staff','pct'],
    ['earnings_per_share','EPS','ps'],['dividend_per_share','DPS','ps']];
  const f = {txt: x => escapeHtml(String(x)), money: x => fmtAmount(Math.round(x)), pct: x => `${fmt(x,1)}%`, num: x => fmtAmount(Math.round(x)), ps: x => fmt(x,2)};
  const sorted = [...rows].sort((a,b) => {
    const x = a[ilAwSort], y = b[ilAwSort];
    if (x === null || x === undefined) return 1; if (y === null || y === undefined) return -1;
    return typeof x === 'number' ? y - x : String(x).localeCompare(String(y));
  });
  return `<div class="panel"><div class="sa-panel-title">Audit, Workforce & Returns (click a heading to sort)</div>
    <div style="overflow-x:auto;"><table><thead><tr><th>Company</th>${cols.map(([k,l]) => `<th style="cursor:pointer;white-space:nowrap;" onclick="ilAwSort='${k}';renderILTabBody();">${escapeHtml(l)}${ilAwSort === k ? ' ▾' : ''}</th>`).join('')}</tr></thead><tbody>
    ${sorted.map(r => `<tr class="clickable" onclick="goToCompanySurveyData(${r.company_id})"><td style="white-space:nowrap;">${escapeHtml(r.name)}</td>${cols.map(([k,,t]) => `<td style="${k === 'auditor_name' ? 'min-width:150px;max-width:190px;font-size:11.5px;' : 'white-space:nowrap;'}">${(r[k] === null || r[k] === undefined || r[k] === '') ? '<span style="color:var(--text-faint);">—</span>' : f[t](r[k])}</td>`).join('')}</tr>`).join('')}
    </tbody></table></div></div>`;
}
const IL_RANKING_SUBTABS = [
  {id:'top-pay', label:'Top by Pay'},
  {id:'board-composition', label:'Board Composition'},
  {id:'governance', label:'Governance'},
  {id:'sector-rankings', label:'Sector Rankings'},
  {id:'audit-workforce', label:'Audit, Workforce & Returns'},
];
let ilRankingsSectorFilter = 'all';
function ilCompanyRankingsTab(){
  const allRows = ilCompaniesCache.rows;
  const rows = ilRankingsSectorFilter === 'all' ? allRows : allRows.filter(r => r.sector === ilRankingsSectorFilter);
  rpHeaderSelect('ranking','Ranking section',IL_RANKING_SUBTABS,ilRankingsSubtab,v=>{ilRankingsSubtab=v;renderILTabBody();});

  const withPay = rows.filter(r => r.total_director_remuneration !== null);
  const highest = withPay.length ? withPay.reduce((a,b) => a.total_director_remuneration > b.total_director_remuneration ? a : b) : null;
  const avgPay = withPay.length ? withPay.reduce((s,r) => s + r.total_director_remuneration, 0) / withPay.length : null;

  const header = `
    <div class="sa-stat-grid" style="margin-bottom:14px;">
      ${saStatCard('🏆', highest ? fmtAmount(highest.total_director_remuneration) : naSpan('Not enough data'), 'Highest Board Remuneration', highest ? escapeHtml(highest.name) : '')}
      ${saStatCard('📊', avgPay !== null ? fmtAmount(avgPay) : naSpan('Not enough data'), 'Average Board Remuneration', `${withPay.length} compan${withPay.length === 1 ? 'y' : 'ies'}`)}
      ${saStatCard('🏢', rows.length, 'Companies Ranked', ilRankingsSectorFilter === 'all' ? 'All sectors' : escapeHtml(ilRankingsSectorFilter))}
    </div>`;

  let content;
  if (ilRankingsSubtab === 'top-pay') content = ilRankingsTopPay(rows);
  else if (ilRankingsSubtab === 'board-composition') content = ilRankingsBoardComposition(rows);
  else if (ilRankingsSubtab === 'governance') content = ilRankingsGovernance(rows);
  else if (ilRankingsSubtab === 'audit-workforce') content = ilRankingsAuditWorkforce(rows);
  else content = ilRankingsSectorRankings();

  return `
    <div class="row row-2" style="grid-template-columns:1.7fr 1fr;">
      <div style="min-width:0;">${header}${content}</div>
      <div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="sa-panel-title">Filters</div>
          <label style="font-size:11.5px;color:var(--text-faint);">Sector</label>
          <select onchange="ilRankingsSectorFilter=this.value;renderILTabBody();" style="width:100%;margin-top:4px;">
            <option value="all" ${ilRankingsSectorFilter === 'all' ? 'selected' : ''}>All Sectors</option>
            ${ilSectorList().map(s => `<option value="${escapeHtml(s)}" ${ilRankingsSectorFilter === s ? 'selected' : ''}>${escapeHtml(s)}</option>`).join('')}
          </select>
          ${ilRankingsSectorFilter !== 'all' ? `<button class="secondary" style="margin-top:8px;width:100%;" onclick="ilRankingsSectorFilter='all';renderILTabBody();">Reset</button>` : ''}
        </div>
        <div class="panel" style="margin-bottom:14px;">
          <div class="sa-panel-title">Board Diversity</div>
          ${ilRankingsBoardDiversityDonuts(rows)}
        </div>
        <div class="panel">
          <div class="sa-panel-title">Key Takeaways</div>
          ${ilRankingsKeyTakeaways(rows, highest, avgPay)}
        </div>
      </div>
    </div>`;
}
function ilRankingsBoardDiversityDonuts(rows){
  const withGender = rows.filter(r => r.governance.gender_pct !== null);
  const genderCompliant = withGender.filter(r => r.governance.gender_compliant).length;
  if (!withGender.length) return `<div class="empty">${naSpan('Not enough data')}</div>`;
  const avgGenderPct = Math.round(withGender.reduce((s,r) => s + r.governance.gender_pct, 0) / withGender.length);
  return `
    ${saDonut2([['Female Directors (avg)', avgGenderPct, 'var(--purple)'], ['Male Directors (avg)', 100 - avgGenderPct, 'var(--blue)']], avgGenderPct + '%')}
    <div style="font-size:11px;color:var(--text-faint);margin-top:6px;">${genderCompliant} of ${withGender.length} companies meet the CMA's \u2265 33% threshold.</div>`;
}
function ilRankingsKeyTakeaways(rows, highest, avgPay){
  const items = [];
  const withIndep = rows.filter(r => r.governance.independence_pct !== null);
  if (withIndep.length) {
    const bySector = {};
    withIndep.forEach(r => { bySector[r.sector || 'Unclassified'] = (bySector[r.sector || 'Unclassified'] || 0) + 1; });
    const topSector = Object.entries(bySector).sort((a,b) => b[1]-a[1])[0];
    if (topSector) items.push(`${escapeHtml(topSector[0])} has the most companies (${topSector[1]}) with board independence data on file.`);
  }
  if (highest && avgPay !== null) {
    const multiple = (highest.total_director_remuneration / avgPay).toFixed(1);
    items.push(`${escapeHtml(highest.name)}'s board remuneration is ${multiple}x the ranked average.`);
  }
  const scored = rows.filter(r => r.governance.score !== null);
  if (scored.length && scored.length < rows.length) {
    items.push(`${rows.length - scored.length} of ${rows.length} companies lack enough data to compute a governance score.`);
  }
  if (!items.length) return `<div class="empty">${naSpan('Not enough data on file yet for takeaways')}</div>`;
  return `<ul style="margin:0;padding-left:18px;font-size:12.5px;line-height:1.7;">${items.map(i => `<li>${i}</li>`).join('')}</ul>`;
}
function ilRankingsTopPay(rows){
  return `<div class="panel"><div class="sa-panel-title">Top Companies by Total Director Remuneration</div>${ilTopCompaniesTable(rows, 'total_director_remuneration', 20)}</div>`;
}
function ilRankingsBoardComposition(rows){
  const sorted = [...rows].filter(r => r.board_size !== null).sort((a,b) => b.board_size - a.board_size);
  if (!sorted.length) return `<div class="panel"><div class="empty">${naSpan('Not enough data')}</div></div>`;
  return `<div class="panel"><div class="sa-panel-title">Ranked by Board Size</div>
    <table><thead><tr><th>#</th><th>Company</th><th>Sector</th><th>Board Size</th><th>Independent NEDs</th></tr></thead><tbody>
    ${sorted.map((r,i) => `<tr><td>${i+1}</td><td>${escapeHtml(r.name)}</td><td>${escapeHtml(r.sector || '-')}</td><td>${r.board_size}</td><td>${r.independent_neds_count !== null ? r.independent_neds_count : naSpan('Not filed')}</td></tr>`).join('')}
    </tbody></table></div>`;
}
function ilRankingsGovernance(rows){
  const sorted = [...rows].filter(r => r.governance.score !== null).sort((a,b) => b.governance.score - a.governance.score);
  if (!sorted.length) return `<div class="panel"><div class="empty">${naSpan('Not enough board-composition data filed to compute governance scores')}</div></div>`;
  return `<div class="panel">
    <div class="sa-panel-title">Ranked by Illustrative Governance Score</div>
    <table><thead><tr><th>#</th><th>Company</th><th>Sector</th><th>Score</th></tr></thead><tbody>
      ${sorted.map((r,i) => `<tr><td>${i+1}</td><td>${escapeHtml(r.name)}</td><td>${escapeHtml(r.sector || '-')}</td>
        <td><div class="il-gov-bar-wrap"><span>${r.governance.score}</span><div class="il-gov-bar-track" style="width:80px;"><div class="il-gov-bar-fill" style="width:${r.governance.score}%;background:${r.governance.score >= 75 ? 'var(--green)' : r.governance.score >= 50 ? 'var(--amber)' : 'var(--red)'};"></div></div></div></td></tr>`).join('')}
    </tbody></table>
    <div class="il-methodology-note">${escapeHtml(ilCompaniesCache.governance_methodology)}</div>
  </div>`;
}
function ilRankingsSectorRankings(){
  const sectors = ilSectorList();
  const rows = sectors.map(sec => {
    const secRows = ilSectorRows(sec).filter(r => r.total_director_remuneration !== null);
    if (!secRows.length) return null;
    return {sector: sec, count: ilSectorRows(sec).length, avg: secRows.reduce((a,r) => a + r.total_director_remuneration, 0) / secRows.length};
  }).filter(Boolean).sort((a,b) => b.avg - a.avg);
  if (!rows.length) return `<div class="panel"><div class="empty">${naSpan('Not enough data')}</div></div>`;
  return `<div class="panel"><div class="sa-panel-title">Sectors Ranked by Avg. Total Director Remuneration</div>
    <table><thead><tr><th>#</th><th>Sector</th><th>Companies</th><th>Avg. Total Director Remuneration</th></tr></thead><tbody>
      ${rows.map((r,i) => `<tr><td>${i+1}</td><td>${escapeHtml(r.sector)}</td><td>${r.count}</td><td>${fmtAmount(r.avg)}</td></tr>`).join('')}
    </tbody></table></div>`;
}

// ---- Tab 6: Governance & Compliance ----
// Only 2 stat cards/panels correspond to real, computable backend
// concepts: Board Independence and Gender Diversity (both driven by
// _governance_score(), survey_aggregate.py). The mockup's other 3
// stat cards - CMA Compliance Rate, Companies with Audit Committee,
// Average Director Tenure - have no backing data anywhere in this
// app (no CMA-principle-by-principle model, no portfolio-wide
// "has an Audit Committee" flag, no tenure/appointment-date-derived
// calculation), so they're left out rather than approximated. The
// existing GOVERNANCE_SCORE_METHODOLOGY string already says as much:
// this app measures 2 of a real CMA assessment's several criteria.
let ilGCTrendsCache = null;
function ilGovernanceComplianceTab(){
  const rows = ilCompaniesCache.rows;
  const scored = rows.filter(r => r.governance.score !== null);
  const withIndep = rows.filter(r => r.governance.independence_pct !== null);
  const withGender = rows.filter(r => r.governance.gender_pct !== null);
  const indepCompliant = withIndep.filter(r => r.governance.independence_compliant).length;
  const genderCompliant = withGender.filter(r => r.governance.gender_compliant).length;
  const avgScore = scored.length ? Math.round(scored.reduce((a,r) => a + r.governance.score, 0) / scored.length) : null;
  const sorted = [...scored].sort((a,b) => b.governance.score - a.governance.score);
  const topPerformer = sorted[0];
  const lowestPerformer = sorted[sorted.length - 1];

  if (!ilGCTrendsCache) {
    fetch('/api/intelligence-layer/historical-trends').then(r => r.json()).then(t => {
      ilGCTrendsCache = t;
      const body = document.getElementById('ilTabBody');
      if (body && ilTab === 'governance-compliance') body.innerHTML = ilGovernanceComplianceTab();
    }).catch(() => { ilGCTrendsCache = {has_data: false}; });
  }

  return `
    <div class="sa-stat-grid">
      ${saStatCard('👥', withIndep.length ? Math.round(indepCompliant/withIndep.length*100) + '%' : naSpan('Not enough data'), 'Board Independence Compliance', `${indepCompliant} / ${withIndep.length} companies meet \u2265 1/3`)}
      ${saStatCard('♀️', withGender.length ? Math.round(genderCompliant/withGender.length*100) + '%' : naSpan('Not enough data'), 'Gender Diversity Compliance', `${genderCompliant} / ${withGender.length} companies meet \u2265 1/3`)}
      ${saStatCard('🏆', avgScore !== null ? avgScore : naSpan('Not enough data'), 'Average Governance Score', 'Illustrative only')}
      ${saStatCard('🏢', scored.length, 'Companies Scored', `of ${rows.length} surveyed`)}
    </div>
    <div class="il-methodology-note" style="margin-bottom:14px;">${escapeHtml(ilCompaniesCache.governance_methodology)}</div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Board Independence Trend</div>
        ${ilGovernanceTrendPanel('independence')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Gender Diversity Trend</div>
        ${ilGovernanceTrendPanel('gender')}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Board Independence by Company</div>
        ${withIndep.length ? `<div class="sa-bar-list">${[...withIndep].sort((a,b) => b.governance.independence_pct - a.governance.independence_pct).slice(0,10).map(r => saBar(r.name, r.governance.independence_pct + '%', 100, r.governance.independence_compliant ? 'var(--green)' : 'var(--amber)')).join('')}</div>` : `<div class="empty">${naSpan('Not enough data')}</div>`}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Gender Diversity by Company</div>
        ${withGender.length ? `<div class="sa-bar-list">${[...withGender].sort((a,b) => b.governance.gender_pct - a.governance.gender_pct).slice(0,10).map(r => saBar(r.name, r.governance.gender_pct + '%', 100, r.governance.gender_compliant ? 'var(--green)' : 'var(--purple)')).join('')}</div>` : `<div class="empty">${naSpan('Not enough data')}</div>`}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Overall Governance Score</div>
        ${avgScore !== null ? `
          ${saDonut2([['Average Score', avgScore, 'var(--green)'], ['Remaining', 100-avgScore, 'var(--bg-hover)']], avgScore + '%')}
          ${topPerformer ? `<div style="font-size:11.5px;margin-top:8px;"><b>Top Performer:</b> ${escapeHtml(topPerformer.name)} (${topPerformer.governance.score})</div>` : ''}
          ${lowestPerformer && lowestPerformer !== topPerformer ? `<div style="font-size:11.5px;"><b>Lowest Performer:</b> ${escapeHtml(lowestPerformer.name)} (${lowestPerformer.governance.score})</div>` : ''}
        ` : `<div class="empty">${naSpan('Not enough data to compute an overall score')}</div>`}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Board Composition</div>
        ${ilGovernanceBoardCompositionTable(rows)}
      </div>
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Companies Ranked by Governance Score</div>
      ${sorted.length ? `<table><thead><tr><th>#</th><th>Company</th><th>Sector</th><th>Independence</th><th>Gender Diversity</th><th>Score</th></tr></thead><tbody>
        ${sorted.map((r,i) => `<tr><td>${i+1}</td><td>${escapeHtml(r.name)}</td><td>${escapeHtml(r.sector || '-')}</td>
          <td>${r.governance.independence_pct !== null ? r.governance.independence_pct + '%' : '-'}</td>
          <td>${r.governance.gender_pct !== null ? r.governance.gender_pct + '%' : '-'}</td>
          <td><b>${r.governance.score}</b></td></tr>`).join('')}
      </tbody></table>` : `<div class="empty">${naSpan('Not enough board-composition data filed to compute governance scores')}</div>`}
    </div>
    <div class="panel">
      <div class="sa-panel-title">Key Insights & Observations</div>
      ${ilGovernanceKeyInsights(withIndep, withGender, indepCompliant, genderCompliant, scored.length, rows.length)}
    </div>`;
}
function ilGovernanceTrendPanel(kind){
  if (!ilGCTrendsCache) return `<div class="empty">Loading\u2026</div>`;
  if (!ilGCTrendsCache.has_data || ilGCTrendsCache.series.length < 2) {
    return `<div class="empty">${naSpan('At least two fiscal years of survey data are needed to chart a trend')}</div>`;
  }
  const years = ilGCTrendsCache.series.map(s => s.fiscal_year);
  const rates = ilGCTrendsCache.series.map(s => {
    const bo = s.board_overview || {};
    if (kind === 'independence') {
      const totalSeats = (bo.total_independent_neds||0) + (bo.total_non_independent_neds||0);
      return totalSeats ? Math.round(bo.total_independent_neds / totalSeats * 100) : null;
    }
    const totalGender = (bo.total_directors_female||0) + (bo.total_directors_male||0);
    return totalGender ? Math.round(bo.total_directors_female / totalGender * 100) : null;
  });
  if (rates.every(r => r === null)) return `<div class="empty">${naSpan('Not enough data across years to chart this trend')}</div>`;
  const max = Math.max(33, ...rates.filter(r => r !== null));
  return `<div class="sa-bar-list">${years.map((y,i) => rates[i] !== null ? saBar(y, rates[i] + '%', max) : '').join('')}</div>
    <div style="font-size:10px;color:var(--text-faint);margin-top:8px;">Portfolio-wide rate per year (sum of all companies' seats), not an average of each company's own %. CMA target: \u2265 33%.</div>`;
}
function ilGovernanceBoardCompositionTable(rows){
  const withSize = rows.filter(r => r.board_size !== null);
  if (!withSize.length) return `<div class="empty">${naSpan('Board size not filed for any surveyed company')}</div>`;
  const sumIndep = rows.reduce((a,r) => a + (r.independent_neds_count || 0), 0);
  const sumNonIndep = rows.reduce((a,r) => a + (r.non_independent_neds_count || 0), 0);
  const sumFemale = rows.reduce((a,r) => a + (r.directors_female || 0), 0);
  const sumMale = rows.reduce((a,r) => a + (r.directors_male || 0), 0);
  const totalSeats = sumIndep + sumNonIndep;
  return `<table><tbody>
    <tr><td>Independent NEDs</td><td style="font-weight:700;">${sumIndep}</td><td style="color:var(--text-faint);">${totalSeats ? Math.round(sumIndep/totalSeats*100) + '%' : '-'}</td></tr>
    <tr><td>Non-Independent NEDs</td><td style="font-weight:700;">${sumNonIndep}</td><td style="color:var(--text-faint);">${totalSeats ? Math.round(sumNonIndep/totalSeats*100) + '%' : '-'}</td></tr>
    <tr><td>Female Directors</td><td style="font-weight:700;">${sumFemale}</td><td style="color:var(--text-faint);">${(sumFemale+sumMale) ? Math.round(sumFemale/(sumFemale+sumMale)*100) + '%' : '-'}</td></tr>
    <tr><td>Male Directors</td><td style="font-weight:700;">${sumMale}</td><td style="color:var(--text-faint);">${(sumFemale+sumMale) ? Math.round(sumMale/(sumFemale+sumMale)*100) + '%' : '-'}</td></tr>
  </tbody></table>
  <div style="font-size:10px;color:var(--text-faint);margin-top:8px;">Portfolio totals across all ${withSize.length} companies with board size on file.</div>`;
}
function ilGovernanceKeyInsights(withIndep, withGender, indepCompliant, genderCompliant, scoredCount, totalCount){
  const insights = [];
  if (withIndep.length) insights.push(`${indepCompliant} of ${withIndep.length} companies with independence data meet the CMA's \u2265 1/3 board independence threshold.`);
  if (withGender.length) insights.push(`${genderCompliant} of ${withGender.length} companies with gender data meet the CMA's \u2265 1/3 gender diversity threshold.`);
  if (scoredCount < totalCount) insights.push(`${totalCount - scoredCount} of ${totalCount} surveyed companies lack enough board composition data to compute a governance score.`);
  return insights.length
    ? `<ul style="margin:0;padding-left:18px;font-size:12.5px;line-height:1.7;">${insights.map(i => `<li>${i}</li>`).join('')}</ul>`
    : `<div class="empty">${naSpan('Not enough data on file to generate portfolio-wide governance insights')}</div>`;
}

// ---------- Reports (import job audit trail) ----------

// ---------- Survey Analytics & Reporting ----------
// A fixed-edition aggregate report across every company with
// SurveyCompanyData for one fiscal year (see survey_aggregate.py /
// build_survey_overview) - 9 in-page tabs matching the user's design
// images exactly, top to bottom. Unlike the interactive Intelligence
// Layer (company/year pickers, comparisons), this page presents ONE
// computed dataset per fiscal year, styled after the original NSE-style
// PDF "Board Remuneration Survey" report. All numbers here are REAL,
// computed live from build_survey_overview() - nothing on this page is
// mocked. Fields the backend legitimately has no data for (NSE market
// capitalisation history, a fixed list of "sources of data" companies
// beyond the ones actually on file) are shown as "Not available" rather
// than the design mockup's illustrative numbers.
const SA_TABS = [
  {id:'multi-year', label:'Multi-Year Survey Comparison'},
  {id:'executive-summary', label:'Executive Summary'},
  {id:'board-overview', label:'Board Overview'},
  {id:'directors-remuneration', label:"Directors' Remuneration"},
  {id:'executive-directors', label:'Executive Directors'},
  {id:'non-executive-directors', label:'Non-Executive Directors'},
  {id:'committee-remuneration', label:'Committee Remuneration'},
  {id:'audit-governance', label:'Audit & Governance'},
  {id:'workforce-returns', label:'Pay, Workforce & Returns'},
  {id:'comparative-analysis', label:'Comparative Analysis'},
  {id:'appendix', label:'Appendix'},
];
let saTab = 'executive-summary';
let saFiscalYear = null;
let saOverviewCache = null;
let saDirRemSectorMetric = 'ned'; // 'ned' | 'chair' - which sector bar list the Directors' Remuneration tab shows

async function renderSurveyAnalyticsPage(){
  const app = document.getElementById('app');
  const overview = await safeJson(
    await fetch('/api/survey/overview' + (saFiscalYear ? `?fiscal_year=${encodeURIComponent(saFiscalYear)}` : '')),
    null
  );
  saOverviewCache = overview;
  saFiscalYear = overview && overview.fiscal_year;

  document.getElementById('pageTitle').textContent = 'Survey Analytics & Reporting';
  document.getElementById('pageSub').textContent = 'Executive and Non-Executive Directors\u2019 Remuneration Survey';
  const saYears = fullYears(overview && overview.available_fiscal_years);
  const saYearPicker = saYears.length ? `<select title="Fiscal year - the survey is aggregated per fiscal year" onchange="saFiscalYear=this.value;renderSurveyAnalyticsPage();">
      ${saYears.map(y => `<option value="${escapeHtml(y)}" ${y === saFiscalYear ? 'selected' : ''}>${escapeHtml(y)}</option>`).join('')}
    </select>` : '';
  setPageActions(overview && overview.has_data ? [
    {label: 'Documents & Reports', icon: '🗂️', perm: 'user', onClick: `docOpenFor('${saFiscalYear || ''}')`},
  ] : null, saYearPicker);

  if (!overview || !overview.has_data) {
    const years = fullYears(overview && overview.available_fiscal_years);
    app.innerHTML = `<div class="panel"><div class="empty">
      ${years.length
        ? `No companies on file for this fiscal year. Available: ${years.map(y => `<a href="#" onclick="saFiscalYear='${escapeHtml(y)}';renderSurveyAnalyticsPage();return false;">${escapeHtml(y)}</a>`).join(', ')}`
        : 'No survey data uploaded yet. Add company survey data from the Survey Companies page first.'}
    </div></div>`;
    return;
  }

  rpHeaderSelect('section','Section',SA_TABS,saTab,switchSATab);

  app.innerHTML = `<div class="sa-shell"><div id="saTabBody"></div></div>`;
  renderSATabBody();
}

function switchSATab(tabId){
  saTab = tabId;
  rpHeaderSelect('section','Section',SA_TABS,tabId,switchSATab);
  renderSATabBody();
}

// Shared header block every SA tab starts with: title/subtitle on the
// left, the 3-item "N companies | NSE listed | FY" info strip on the
// right - matches every one of the 9 design images exactly.
function saHeader(title, subtitle){
  const ov = saOverviewCache;
  return `
    <div class="sa-header-row">
      <div>
        <div class="sa-title">${escapeHtml(title)}</div>
        <div class="sa-subtitle">${escapeHtml(subtitle)}</div>
      </div>
      <div class="sa-info-strip">
        <div class="sa-info-item"><div class="sa-info-icon">🏢</div><div><div class="sa-info-value">${ov.companies_surveyed} companies</div><div class="sa-info-label">in survey</div></div></div>
        <div class="sa-info-item"><div class="sa-info-icon">📈</div><div><div class="sa-info-value">NSE listed</div><div class="sa-info-label">100% coverage</div></div></div>
        <div class="sa-info-item"><div class="sa-info-icon">📅</div><div><div class="sa-info-value">${escapeHtml(ov.fiscal_year)}</div><div class="sa-info-label">Reporting year</div></div></div>
      </div>
    </div>`;
}

function saStatCard(icon, value, label, sub, trend){
  return `
    <div class="sa-stat-card">
      <div class="sa-stat-top"><div class="sa-stat-icon">${icon}</div><div class="sa-stat-label">${escapeHtml(label)}</div></div>
      <div class="sa-stat-value">${value}</div>
      ${sub ? `<div class="sa-stat-sub">${sub}</div>` : ''}
      ${trend ? `<div class="sa-stat-trend ${trend.dir}">${trend.dir === 'up' ? '\u2191' : '\u2193'} ${escapeHtml(trend.text)}</div>` : ''}
    </div>`;
}

// A metric() object from survey_aggregate.py is {average, p25, p50, p75, company_count}.
// Renders "Not enough data" (not a fake number) when average is null.
function saMetricAvg(metric, opts){
  opts = opts || {};
  if (!metric || metric.average === null || metric.average === undefined) return null;
  const decimals = opts.decimals !== undefined ? opts.decimals : 1;
  return opts.raw ? metric.average : Number(metric.average).toFixed(decimals);
}
function saBar(label, value, max, colorVar){
  // value is usually a display string (fmtAmount output, or "N%") -
  // parse the leading numeric portion back out for the width calc
  // rather than assuming callers pass a raw number. Fixes a real bug:
  // passing a formatted string here silently produced width:NaN% (a
  // zero-width bar) at several existing call sites before this fix.
  const numeric = typeof value === 'number' ? value : parseFloat(String(value).replace(/,/g, ''));
  const pct = (max > 0 && !isNaN(numeric)) ? Math.max(2, Math.round(numeric / max * 100)) : 0;
  return `
    <div class="sa-bar-row">
      <div class="lbl">${escapeHtml(label)}</div>
      <div class="sa-bar-track"><div class="sa-bar-fill" style="width:${pct}%;background:${colorVar || 'var(--blue)'};"></div></div>
      <div class="sa-bar-val">${value}</div>
    </div>`;
}

function renderSATabBody(){
  const body = document.getElementById('saTabBody');
  if (!body) return;
  const ov = saOverviewCache;
  if (saTab === 'multi-year') return rpCompare(body,'survey',ov.available_fiscal_years);
  if (saTab === 'executive-summary') body.innerHTML = saExecutiveSummaryTab(ov);
  else if (saTab === 'board-overview') body.innerHTML = saBoardOverviewTab(ov);
  else if (saTab === 'directors-remuneration') body.innerHTML = saDirectorsRemunerationTab(ov);
  else if (saTab === 'executive-directors') body.innerHTML = saExecutiveDirectorsTab(ov);
  else if (saTab === 'non-executive-directors') body.innerHTML = saNonExecutiveDirectorsTab(ov);
  else if (saTab === 'committee-remuneration') body.innerHTML = saCommitteeRemunerationTab(ov);
  else if (saTab === 'audit-governance') body.innerHTML = saAuditGovernanceTab(ov);
  else if (saTab === 'workforce-returns') body.innerHTML = saWorkforceReturnsTab(ov);
  else if (saTab === 'comparative-analysis') body.innerHTML = saComparativeAnalysisTab(ov);
  else if (saTab === 'appendix') body.innerHTML = saAppendixTab(ov);
}

// ---- Data Quality tab: AVERAGE completeness across every surveyed company ----
// Numbers come from /api/survey/data-quality-average (data_quality.py) - the same scoring rules as each company's
// own Data Quality tab (Complete = has a value with confidence >= 75%, over all 40 survey fields), averaged per
// company so a company with many fields cannot outweigh one with few.

// ====================== Documents & Reports ======================
// One place for every download. Each card says what the file contains and which year/company it
// covers. The per-page Actions menus only keep a shortcut here (plus the company report on Survey
// Report, which people expect next to the company they are looking at). Download URLs are the same
// endpoints the old Actions items used - nothing about the files themselves changed.
let docFiscalYear = null;
let docCompanyId = null;
let docPeriodLabel = null;
// Per-card year choice for the Company documents (null = use that card's default).
let docYear = {report: null, word: null, snap: null, raw: null, ext: null, extzip: null};
let docCache = null;      // {years:[...], companies:[{id,name,ticker, fiscal_years:[...]}], periods:{companyId:[labels]}}

function docOpenFor(fiscalYear, companyId){
  if (fiscalYear) docFiscalYear = fiscalYear;
  if (companyId) docCompanyId = companyId;
  goTo('documents');
}
// Download through fetch() so a refusal (daily download limit, sign-in needed, too many requests)
// shows a clear message here instead of navigating the browser to a raw JSON error page.
async function docDownload(url){
  if (/[?&]fiscal_year=all\b|\/periods\/all\//.test(url)) showToast('Preparing every year - this can take a little while...');
  try {
    const res = await fetch(url, {credentials: 'same-origin'});
    if (!res.ok) {
      let msg = 'Could not download this file.';
      try { const j = await res.json(); if (j && j.error) msg = j.error; } catch (e) {}
      showToast(msg);
      return;
    }
    const blob = await res.blob();
    const cd = res.headers.get('Content-Disposition') || '';
    const m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(cd);
    const name = m ? decodeURIComponent(m[1]) : (url.split('?')[0].split('/').pop() || 'download');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  } catch (e) {
    showToast('Could not download this file - please try again.');
  }
}
function docFyQuery(){ return docFiscalYear ? '?fiscal_year=' + encodeURIComponent(docFiscalYear) : ''; }
// 'all' = the person picked "All years". Single-year reports then download as a zip with one file per year.
const DOC_ALL = 'all';
function docYearOnly(v){ return (v && v !== DOC_ALL) ? v : null; }
function docYearLabel(v, none){ return v === DOC_ALL ? 'All years' : (v || none); }
let docLoadRetried = false;

async function docLoadPeriods(companyId){
  docCache.periods = docCache.periods || {};
  if (docCache.periods[companyId]) return docCache.periods[companyId];
  const res = await safeJson(await fetch(`/api/companies/${companyId}/periods`), []);
  docCache.periods[companyId] = (res || []).map(p => p.period_label).filter(isFullYear);
  return docCache.periods[companyId];
}

async function renderDocumentsPage(){
  const app = document.getElementById('app');
  document.getElementById('pageTitle').textContent = 'Documents & Reports';
  document.getElementById('pageSub').textContent = 'Every report and export in one place - pick a year or company, then download';

  // A failed request (server busy with a large upload, a brief restart, the rate limit) used to look exactly
  // like "no data", which greyed out every year picker. Failures are now told apart from empty results.
  const getJson = async url => { try { return await safeJson(await fetch(url), null); } catch (e) { return null; } };
  const ovFy = docYearOnly(docFiscalYear);
  const [surveyCos, allCos, years] = await Promise.all([
    getJson('/api/survey/companies'),
    getJson('/api/companies'),
    getJson('/api/survey/overview' + (ovFy ? `?fiscal_year=${encodeURIComponent(ovFy)}` : '')),
  ]);
  const loadFailed = surveyCos === null || allCos === null || years === null;
  if (loadFailed && !docLoadRetried) {          // one quiet retry before showing anything
    docLoadRetried = true;
    await new Promise(r => setTimeout(r, 2500));
    if (currentPage === 'documents') return renderDocumentsPage();
    return;
  }
  docLoadRetried = false;
  const surveyList = Array.isArray(surveyCos) ? surveyCos : ((surveyCos && surveyCos.companies) || []);
  const fyList = fullYears(years && years.available_fiscal_years);
  if (docFiscalYear !== DOC_ALL && (!docFiscalYear || (fyList.length && !fyList.includes(docFiscalYear)))) docFiscalYear = (years && years.fiscal_year) || fyList[0] || null;
  const companies = (Array.isArray(allCos) ? allCos : ((allCos && allCos.companies) || [])).slice().sort((a, b) => (a.name || '').localeCompare(b.name || ''));
  const surveyById = {};
  surveyList.forEach(c => { surveyById[c.company_id] = c; });
  docCache = {years: fyList, companies, surveyById, periods: (docCache && docCache.periods) || {}};
  if (!docCompanyId || !companies.some(c => c.id === docCompanyId)) docCompanyId = companies.length ? companies[0].id : null;

  const yearPicker = `<select title="Fiscal year" onchange="docFiscalYear=this.value||null;renderDocumentsPage();">
      <option value="${DOC_ALL}" ${docFiscalYear === DOC_ALL ? 'selected' : ''}>All years</option>
      ${fyList.map(y => `<option value="${escapeHtml(y)}" ${y === docFiscalYear ? 'selected' : ''}>${escapeHtml(y)}</option>`).join('')}
    </select>`;
  setPageActions(null, yearPicker);
  // setPageActions(null, extra) renders only the extra block (the year picker), which is what we want here.

  const hasYear = !!docFiscalYear;
  const co = companies.find(c => c.id === docCompanyId);
  const coSurvey = surveyById[docCompanyId];
  const coHasYear = !!(coSurvey && (coSurvey.fiscal_years || []).includes(docFiscalYear));
  const failBanner = loadFailed ? `<div class="panel" style="margin-bottom:14px;"><div class="empty">Some of this page could not be loaded (the server may be busy with an upload). The lists below may be incomplete. <a href="#" onclick="renderDocumentsPage();return false;">Retry</a></div></div>` : '';
  const coPicker = `<select onchange="docCompanyId=parseInt(this.value,10);docPeriodLabel=null;docYear={report:null,word:null,snap:null,raw:null,ext:null,extzip:docYear.extzip};renderDocumentsPage();" style="max-width:100%;">
      ${companies.map(c => `<option value="${c.id}" ${c.id === docCompanyId ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('')}
    </select>`;

  const card = (icon, title, badge, desc, contents, controlsHtml, btnLabel, onClick, disabledReason) => `
    <div class="panel doc-card">
      <div class="doc-card-head">
        <div class="doc-icon">${icon}</div>
        <div style="min-width:0;flex:1;">
          <div class="doc-title">${escapeHtml(title)}</div>
          <div class="doc-badges">${badge.map(b => `<span class="doc-badge">${escapeHtml(b)}</span>`).join('')}</div>
        </div>
      </div>
      <div class="doc-desc">${desc}</div>
      <ul class="doc-list">${contents.map(x => `<li>${escapeHtml(x)}</li>`).join('')}</ul>
      ${controlsHtml ? `<div class="doc-controls">${controlsHtml}</div>` : ''}
      <div class="doc-foot">
        <button class="btn-primary-cta doc-btn" ${disabledReason ? 'disabled' : ''} onclick="${disabledReason ? '' : onClick}">&#10515; ${escapeHtml(btnLabel)}</button>
        ${disabledReason ? `<span class="muted" style="font-size:11px;">${escapeHtml(disabledReason)}</span>` : ''}
      </div>
    </div>`;

  const noYear = (hasYear && (docFiscalYear !== DOC_ALL || fyList.length)) ? '' : (loadFailed ? 'Could not load - retry above' : 'No survey data on file yet');
  const surveyYearBadge = docYearLabel(docFiscalYear, 'No year');
  const surveyCards = [
    card('📘', 'Board Remuneration & Governance Report', ['PDF', surveyYearBadge],
      'The full report for the selected year, joining the survey findings with the cross-company analysis.',
      ['Key findings and the year at a glance', 'Board, director, committee and CEO pay with market percentiles', 'Audit, board attendance, workforce and shareholder returns', 'Company-by-company tables, rankings and governance scores', 'Sector comparison, trends, data completeness, appendix'],
      '', 'Download full report', `docDownload('/api/export/combined-report.pdf${docFyQuery()}')`, noYear),
    card('📊', 'Survey Data Tables', ['PDF', surveyYearBadge],
      'The compact tables-only version of the survey, laid out like the Survey Analytics page.',
      ['Executive summary and board overview', "Directors' and committee remuneration", 'CEO/MD pay, NED benefits', 'Audit & governance, pay, workforce & returns', 'Sector comparison and list of companies'],
      '', 'Download data tables', `docDownload('/api/survey/export/report.pdf${docFyQuery()}')`, noYear),
    ...(!canEdit() ? [] : [card('🧾', 'Portfolio Export', ['Excel', 'All companies'],
      'One row per company with its latest year\'s figures, all in full and in KES, for your own sorting and filtering.',
      ['Company, ticker, sector, reporting currency', 'Turnover, net profit, margin, market cap', 'ROE, debt/equity, EPS, dividend, employees'],
      '', 'Download portfolio (.xlsx)', `docDownload('/api/export/portfolio')`, '')]),
    ...(!canEdit() ? [] : [card('🔀', 'Company Comparison Export', ['Excel', 'All companies'],
      'A summary ranking sheet plus one sheet per company with every year on file.',
      ['Summary ranked by net margin', 'One sheet per company, year by year, in KES', 'Turnover, profit, ratios, EPS, dividend, staff'],
      '', 'Download comparison (.xlsx)', `docDownload('/api/export/comparison')`, '')]),
  ].join('');

  const periods = docCompanyId ? await docLoadPeriods(docCompanyId) : [];
  const surveyYears = fullYears((coSurvey && coSurvey.fiscal_years)).slice().sort().reverse();
  // Each card has its own year picker. Survey-based report: years with a survey. Word report: financial periods.
  // Snapshot and raw CSV: any financial period, or all of them.
  // Every year picker is always usable and always offers "All years". Its year list is the years that
  // card has data for; when that is empty (or failed to load) it falls back to every year known on the page.
  const knownYears = [...new Set([...fyList, ...surveyYears, ...periods])].sort().reverse();
  const orKnown = list => (list.length ? list : knownYears);
  const keep = (v, list) => v === DOC_ALL || (v && list.includes(v));
  if (!keep(docYear.report, orKnown(surveyYears))) docYear.report = surveyYears.includes(docFiscalYear) ? docFiscalYear : (surveyYears[0] || null);
  if (!keep(docYear.word, orKnown(periods))) docYear.word = periods[0] || null;
  docPeriodLabel = docYear.word;
  if (docYear.ext && !keep(docYear.ext, orKnown(surveyYears))) docYear.ext = null;
  if (docYear.extzip && !keep(docYear.extzip, orKnown(fyList))) docYear.extzip = null;
  if (docYear.snap && !keep(docYear.snap, orKnown(periods))) docYear.snap = null;
  if (docYear.raw && !keep(docYear.raw, orKnown(periods))) docYear.raw = null;
  const yearSel = (key, opts) => {
    const list = orKnown(opts);
    const cur = docYear[key];
    return `<select onchange="docYear['${key}']=this.value||null;renderDocumentsPage();" style="max-width:100%;">
      <option value="${DOC_ALL}" ${(cur === DOC_ALL || !cur) ? 'selected' : ''}>All years</option>
      ${list.map(l => `<option value="${escapeHtml(l)}" ${l === cur ? 'selected' : ''}>${escapeHtml(l)}</option>`).join('')}</select>`;
  };
  const qy = v => docYearOnly(v) ? '?period=' + encodeURIComponent(v) : '';
  const fyq = v => docYearOnly(v) ? '?fiscal_year=' + encodeURIComponent(v) : '';
  const coName = co ? co.name : 'a company';
  const companyCards = [
    card('🏢', 'Company Remuneration & Governance Report', ['PDF', docYearLabel(docYear.report, 'All years'), coName],
      "One company's board, pay and governance for the selected year, set against the survey.",
      ['Key figures against the survey median and average', 'Director register, pay and pay components', 'Committees, CEO/MD package, benefits', 'Peer ranking and data notes'],
      `<label class="doc-label">Company</label>${coPicker}<label class="doc-label">Year</label>${yearSel('report', surveyYears)}`, 'Download company report', `docDownload('/api/companies/${docCompanyId}/export/report.pdf?fiscal_year=' + encodeURIComponent(docYear.report || DOC_ALL))`,
      !co ? (loadFailed ? 'Could not load - retry above' : 'No companies yet') : (!surveyYears.length ? `${coName} has no survey data yet` : '')),
    card('📝', 'Annual Report Summary (Word)', ['Word', docYearLabel(docYear.word, 'All years'), coName],
      "A Word report built from the company's verified financial statements for one period.",
      ['Executive summary and key findings', 'Financial statements and calculated ratios'],
      `<label class="doc-label">Company</label>${coPicker}<label class="doc-label">Year</label>${yearSel('word', periods)}`,
      'Download Word report', `docDownload('/api/companies/${docCompanyId}/periods/' + encodeURIComponent(docPeriodLabel || DOC_ALL) + '/report.docx')`,
      !co ? (loadFailed ? 'Could not load - retry above' : 'No companies yet') : (!periods.length ? `No financial periods on file for ${coName}` : '')),
    card('📄', 'Company Snapshot', ['Excel', docYearLabel(docYear.snap, 'All years'), coName],
      "A single-sheet summary of one company: its details, every period on file and the key ratios.",
      ['Company details', 'All periods with revenue, profit, assets and equity', 'Key ratios'],
      `<label class="doc-label">Company</label>${coPicker}<label class="doc-label">Year</label>${yearSel('snap', periods)}`, 'Download snapshot (.xlsx)', `docDownload('/api/companies/${docCompanyId}/export/snapshot${qy(docYear.snap)}')`,
      !co ? (loadFailed ? 'Could not load - retry above' : 'No companies yet') : ''),
    card('🧮', 'Raw Financials', ['CSV', docYearLabel(docYear.raw, 'All years'), coName],
      "The underlying financial rows for one company, for modelling in your own tools.",
      ['Revenue, net income, assets, liabilities, equity', 'Period, currency and source for each row'],
      `<label class="doc-label">Company</label>${coPicker}<label class="doc-label">Year</label>${yearSel('raw', periods)}`, 'Download CSV', `docDownload('/api/companies/${docCompanyId}/export/raw.csv${qy(docYear.raw)}')`,
      !co ? (loadFailed ? 'Could not load - retry above' : 'No companies yet') : ''),
    card('🔎', 'Text Extraction Report', ['PDF', docYearLabel(docYear.ext, 'All years'), coName],
      "What the text readers pulled from this company's annual report, and why each missing field was not found.",
      ['Filled, low-confidence and missing survey fields with the cause', 'Directors register, committee and pay-row gaps', 'Source page and reader for every filled value', 'PDF facts: pages, text layer, two-page spreads'],
      `<label class="doc-label">Company</label>${coPicker}<label class="doc-label">Year</label>${yearSel('ext', surveyYears)}`,
      'Download extraction report', `docDownload('/api/extraction-report/company/${docCompanyId}.pdf${fyq(docYear.ext)}')`,
      !co ? (loadFailed ? 'Could not load - retry above' : 'No companies yet') : (!surveyYears.length ? `${coName} has no survey data yet` : '')),
  ].join('');

  const extractionCards = [
    card('🗜️', 'Text Extraction Reports - All Companies', ['ZIP', docYearLabel(docYear.extzip, 'All years')],
      'One extraction report PDF per company, ranked by most missing fields, with a coverage summary (PDF and CSV).',
      ['Summary: score, filled, low confidence, missing per file', 'Whether each file agrees with the Manual Entry form', 'One PDF per company for the chosen year or every year'],
      `<label class="doc-label">Year</label>${yearSel('extzip', fyList)}`,
      'Download all (.zip)', `docDownload('/api/extraction-report/zip${fyq(docYear.extzip)}')`,
      fyList.length ? '' : (loadFailed ? 'Could not load - retry above' : 'No survey data on file yet')),
    card('🧪', 'Diagnose Already-Uploaded Reports', ['Tool', 'Changes no data'],
      'Adds the real reasons for missing fields to files uploaded before extraction reports existed, from the original annual-report PDFs.',
      ['Select all PDFs (or a zip) at once', 'Company and year read from file names like ke-kcb-2025-ar-00.pdf', 'Reports and the zip then show real causes'],
      '', 'Open diagnose tool', `window.open('/extraction-report','_blank')`, ''),
  ].join('');

  app.innerHTML = `${failBanner}
    <div class="doc-group-title">Survey reports <span class="muted">&middot; follow the year selector above</span></div>
    <div class="doc-grid">${surveyCards}</div>
    <div class="doc-group-title" style="margin-top:22px;">Company documents <span class="muted">&middot; pick a company and year in each card</span></div>
    <div class="doc-grid">${companyCards}</div>
    <div class="doc-group-title" style="margin-top:22px;">Text extraction <span class="muted">&middot; every company in one zip (the single-company report is under Company documents)</span></div>
    <div class="doc-grid">${extractionCards}</div>`;
}

// Data Quality is its own page (below Survey Analytics in the sidebar). The Overview's "Data Quality
// Overview" card links here. It shares saFiscalYear with Survey Analytics, so the year picked on one
// carries over to the other.
async function renderDataQualityPage(){
  const app = document.getElementById('app');
  const overview = await safeJson(
    await fetch('/api/survey/overview' + (saFiscalYear ? `?fiscal_year=${encodeURIComponent(saFiscalYear)}` : '')), null);
  saOverviewCache = overview;
  saFiscalYear = overview && overview.fiscal_year;
  document.getElementById('pageTitle').textContent = 'Data Quality';
  document.getElementById('pageSub').textContent = 'How complete the survey data is, averaged across all companies';
  const years = fullYears(overview && overview.available_fiscal_years);
  const yearPicker = years.length ? `<select title="Fiscal year" onchange="saFiscalYear=this.value;renderDataQualityPage();">
      ${years.map(y => `<option value="${escapeHtml(y)}" ${y === saFiscalYear ? 'selected' : ''}>${escapeHtml(y)}</option>`).join('')}
    </select>` : '';
  // The "N companies | NSE listed | FY" tally lives in the top bar, just left of the year selector,
  // so the page body can start straight with the KPI cards.
  const tally = (overview && overview.has_data) ? `<div class="sa-info-strip" style="padding:0;gap:14px;flex-wrap:nowrap;">
      <div class="sa-info-item"><div class="sa-info-icon">🏢</div><div><div class="sa-info-value">${overview.companies_surveyed} companies</div><div class="sa-info-label">in survey</div></div></div>
      <div class="sa-info-item"><div class="sa-info-icon">📈</div><div><div class="sa-info-value">NSE listed</div><div class="sa-info-label">100% coverage</div></div></div>
      <div class="sa-info-item"><div class="sa-info-icon">📅</div><div><div class="sa-info-value">${escapeHtml(overview.fiscal_year)}</div><div class="sa-info-label">Reporting year</div></div></div>
    </div>` : '';
  setPageActions([
    {label: 'Open Review queue', icon: '🔍', perm: 'admin', onClick: "goTo('review')"},
    {label: 'Report Manual Entry', icon: '📝', perm: 'admin', onClick: "goTo('manual-entry')"},
    {label: 'Survey Analytics', icon: '📈', onClick: "goTo('survey-analytics')"},
    {label: 'Extraction report (why fields failed)', icon: '🧾', onClick: "window.open('/extraction-report','_blank')"},
  ], tally + yearPicker);
  if (!overview || !overview.has_data) {
    app.innerHTML = `<div class="panel"><div class="empty">${years.length
      ? `No companies on file for this fiscal year. Available: ${years.map(y => `<a href="#" onclick="saFiscalYear='${escapeHtml(y)}';renderDataQualityPage();return false;">${escapeHtml(y)}</a>`).join(', ')}`
      : 'No survey data uploaded yet. Add company survey data first.'}</div></div>`;
    return;
  }
  app.innerHTML = `<div id="saDQBody"><div class="panel"><div class="empty">Loading data quality&hellip;</div></div></div>`;
  saLoadDataQuality();
}
function saDQColor(score){ return score >= 75 ? '#3ddc84' : score >= 50 ? '#f5a623' : '#ff6b6b'; }
async function saLoadDataQuality(){
  const el = document.getElementById('saDQBody');
  if (!el) return;
  const d = await safeJson(await fetch('/api/survey/data-quality-average' + (saFiscalYear ? `?fiscal_year=${encodeURIComponent(saFiscalYear)}` : '')), null);
  const box = document.getElementById('saDQBody');
  if (!box || currentPage !== 'data-quality') return;       // person moved to another page while this was loading
  if (!d || !d.has_data) {
    box.innerHTML = `<div class="panel"><div class="empty">${naSpan('No survey data on file for this fiscal year yet')}</div></div>`;
    return;
  }
  const card = (label, value, sub, color) => `<div class="panel" style="flex:1;min-width:170px;margin:0;">
      <div style="font-size:11px;color:var(--text-faint);text-transform:uppercase;letter-spacing:.04em;">${label}</div>
      <div style="font-size:26px;font-weight:800;color:${color || 'inherit'};margin:4px 0 2px;">${value}</div>
      <div style="font-size:11px;color:var(--text-faint);">${sub}</div></div>`;
  const bar = (score) => `<div style="display:flex;align-items:center;gap:8px;min-width:160px;">
      <div style="flex:1;height:8px;border-radius:4px;background:var(--bg-hover);overflow:hidden;"><div style="width:${score}%;height:100%;background:${saDQColor(score)};"></div></div>
      <span style="font-weight:700;width:38px;text-align:right;">${score}%</span></div>`;
  const t = d.totals;
  const companyRows = d.companies.map(c => `<tr>
      <td><b>${escapeHtml(c.name)}</b> <span class="muted">${escapeHtml(c.ticker || '')}</span></td>
      <td>${bar(c.score)}</td><td>${c.complete}</td><td>${c.needs_review}</td><td>${c.missing}</td>
      <td><span style="color:${saDQColor(c.score)};font-weight:600;">${escapeHtml(c.grade)}</span></td></tr>`).join('');
  const sectionRows = d.sections.map(x => `<tr><td>${escapeHtml(x.section)}</td><td>${bar(x.average_score)}</td>
      <td>${x.complete}/${x.total}</td></tr>`).join('');
  const years = fullYears(d.available_fiscal_years);
  box.innerHTML = `
    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:14px;">
      ${card('Average data quality', d.average_score + '%', escapeHtml(d.grade) + ' &middot; mean of ' + d.companies_counted + ' company scores', saDQColor(d.average_score))}
      ${card('Complete fields', t.complete, 'of ' + t.total + ' (' + d.pooled_score + '% pooled)', '')}
      ${card('Needs review', t.needs_review, 'confidence below 75%', t.needs_review ? '#f5a623' : '')}
      ${card('Missing', t.missing, 'no value on file', t.missing ? '#ff6b6b' : '')}
      ${card('Best / lowest', d.best.score + '% / ' + d.lowest.score + '%', escapeHtml(d.best.name) + ' / ' + escapeHtml(d.lowest.name), '')}
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Data quality by company &mdash; ${escapeHtml(d.fiscal_year)}</div>
      <table class="tbl"><thead><tr><th>Company</th><th>Score</th><th>Complete</th><th>Needs review</th><th>Missing</th><th>Rating</th></tr></thead>
        <tbody>${companyRows}</tbody></table>
      ${d.not_on_file.length ? `<div style="margin-top:8px;font-size:11px;color:var(--text-faint);">Not scored (no survey data for ${escapeHtml(d.fiscal_year)}): ${d.not_on_file.map(escapeHtml).join(', ')}</div>` : ''}
    </div>
    <div class="panel">
      <div class="sa-panel-title">Average score by section</div>
      <table class="tbl"><thead><tr><th>Section</th><th>Average score</th><th>Complete fields</th></tr></thead>
        <tbody>${sectionRows}</tbody></table>
      <div style="margin-top:8px;font-size:10.5px;color:var(--text-faint);">Score = complete fields &divide; all ${d.fields_per_company} survey fields, per company, then averaged. Complete means a value is on file with confidence of at least 75%. Same rules as each company's Data Quality tab.${years.length > 1 ? ' Fiscal year follows the selector on this page.' : ''}</div>
    </div>`;
}

// A real prior-year comparison, using the SAME multi-year series the
// Historical Trends tab (Intelligence Layer) is built from - fetched
// lazily since the Executive Summary doesn't otherwise need it.
// Wrapped in a div id="saPerformanceTrendSlot". Falls
// back to an honest "needs a second year" message rather than a
// fabricated comparison when fewer than 2 fiscal years are on file.
function saPerformanceTrendPanel(){
  if (!ilTrendsCache) {
    fetch('/api/intelligence-layer/historical-trends').then(r => r.json()).then(t => {
      ilTrendsCache = t;
      const slot = document.getElementById('saPerformanceTrendSlot');
      if (slot) slot.innerHTML = saPerformanceTrendPanel();
    }).catch(() => { ilTrendsCache = {has_data: false}; });
    return `<div class="empty">Loading\u2026</div>`;
  }
  if (!ilTrendsCache.has_data || ilTrendsCache.series.length < 2) {
    return `<div class="empty">${naSpan('A year-over-year performance comparison needs at least two fiscal years on file')}</div>`;
  }
  const series = ilTrendsCache.series;
  const prior = series[series.length - 2], latest = series[series.length - 1];
  const priorTurnover = saMetricAvg(prior.executive_summary && prior.executive_summary.avg_turnover, {raw:true});
  const latestTurnover = saMetricAvg(latest.executive_summary && latest.executive_summary.avg_turnover, {raw:true});
  const priorProfit = saMetricAvg(prior.executive_summary && prior.executive_summary.avg_net_profit, {raw:true});
  const latestProfit = saMetricAvg(latest.executive_summary && latest.executive_summary.avg_net_profit, {raw:true});
  if (priorTurnover === null && priorProfit === null) {
    return `<div class="empty">${naSpan('Prior fiscal year has no executive summary data to compare against')}</div>`;
  }
  const max = Math.max(priorTurnover||0, latestTurnover||0, priorProfit||0, latestProfit||0, 1);
  return `
    <div class="sa-bar-list">
      ${priorTurnover !== null ? saBar(prior.fiscal_year + ' \u2014 Avg. Turnover', fmtMillions(priorTurnover), max) : ''}
      ${latestTurnover !== null ? saBar(latest.fiscal_year + ' \u2014 Avg. Turnover', fmtMillions(latestTurnover), max) : ''}
      ${priorProfit !== null ? saBar(prior.fiscal_year + ' \u2014 Avg. Net Profit', fmtMillions(priorProfit), max, 'var(--green)') : ''}
      ${latestProfit !== null ? saBar(latest.fiscal_year + ' \u2014 Avg. Net Profit', fmtMillions(latestProfit), max, 'var(--green)') : ''}
    </div>`;
}

// ---- Tab 2: Executive Summary ----
// Figures that were left OUT of the averages because they are impossibly large for a KES survey
// (almost always a unit saved wrongly, e.g. whole shillings tagged "millions").
const SA_FIELD_LABELS = {turnover: 'Turnover', net_profit: 'Net profit', market_cap: 'Market capitalisation'};
let saWarnOpen = false;
function saImplausibleBanner(ov){
  const list = (ov && ov.implausible_values) || [];
  if (!list.length) return '';
  const rows = list.map(v => `<tr><td>${escapeHtml(v.company)}</td><td>${escapeHtml(SA_FIELD_LABELS[v.field] || v.field)}</td>
      <td style="text-align:right">${fmtFull(v.stated_value, 'units')} <span class="muted">(${escapeHtml(v.stated_unit || 'no unit')})</span></td>
      <td style="text-align:right">${fmtFull(v.full_value, 'units')}</td></tr>`).join('');
  // Collapsed by default so it never pushes the real content down; stays open/closed as the person left it.
  return `<details class="panel" style="margin-bottom:14px;border-color:#ff6b6b;padding:0;" ${saWarnOpen ? 'open' : ''} ontoggle="saWarnOpen = this.open; this.querySelector('.sa-warn-hint').textContent = this.open ? 'Click to hide' : 'Click to review and fix';">
    <summary style="cursor:pointer;list-style:none;padding:10px 14px;display:flex;align-items:center;gap:8px;">
      <span class="sa-panel-title" style="color:#ff6b6b;margin:0;">&#9888; ${list.length} figure${list.length === 1 ? '' : 's'} left out of the averages</span>
      <span class="muted sa-warn-hint" style="font-size:11px;margin-left:auto;">${saWarnOpen ? 'Click to hide' : 'Click to review and fix'}</span>
    </summary>
    <div style="padding:0 14px 14px;">
    <div style="font-size:12px;color:var(--text-dim);margin-bottom:8px;">These are larger than any listed company could be (above KES 2 trillion turnover, 1 trillion profit or 3 trillion market cap), so the unit saved with them is almost certainly wrong. They are excluded from every average and total until corrected on the company's Survey Report / Review page.</div>
    <table class="tbl"><thead><tr><th>Company</th><th>Figure</th><th style="text-align:right">As saved</th><th style="text-align:right">Reads as (KES)</th></tr></thead><tbody>${rows}</tbody></table>
    ${saUnitFixTable(ov)}
    </div>
  </details>`;
}

// One saved Unit covers a company's turnover, net profit and market cap together. The buttons only offer
// units under which ALL of that company's figures become believable; if none does, the figures use
// different scales and must be corrected one by one (Survey Companies -> Survey Mapping -> Edit).
const SA_UNIT_LABELS = {units: 'Whole shillings', thousands: 'Thousands', millions: 'Millions', billions: 'Billions'};
function saUnitFixTable(ov){
  const list = (ov && ov.implausible_companies) || [];
  if (!list.length) return '';
  const rows = list.map(c => {
    const buttons = (c.suggested_units || []).map(u => {
      const pv = (c.preview || {})[u] || {};
      const effect = ['turnover', 'net_profit', 'market_cap'].filter(f => pv[f] !== null && pv[f] !== undefined)
        .map(f => `${SA_FIELD_LABELS[f]} ${fmtFull(pv[f], 'units')}`).join(' · ');
      return `<div style="margin:3px 0;"><button class="btn" data-perm="admin" style="margin-right:8px;" onclick="saSetUnit(${c.company_id}, '${escapeHtml(c.fiscal_year)}', '${u}', this)">Read as ${SA_UNIT_LABELS[u].toLowerCase()}</button>
        <span class="muted" style="font-size:11px;">would read: ${effect}</span></div>`;
    }).join('');
    return `<tr><td>${escapeHtml(c.company)}</td><td>${escapeHtml(c.current_unit || 'no unit')}</td>
      <td>${buttons || '<span class="muted">Figures use different scales - correct each one on the company\u2019s Survey Mapping tab</span>'}</td></tr>`;
  }).join('');
  return `<div class="sa-panel-title" style="margin-top:14px;">Fix the unit</div>
    <div style="font-size:12px;color:var(--text-dim);margin-bottom:8px;">Changes only how the saved numbers are read; the numbers themselves are not touched. Pay tables keep their own unit.</div>
    <table class="tbl"><thead><tr><th>Company</th><th>Saved as</th><th>Correct it</th></tr></thead><tbody>${rows}</tbody></table>`;
}
async function saSetUnit(companyId, fiscalYear, unit, btn){
  if (btn) { btn.disabled = true; btn.textContent = 'Saving...'; }
  try {
    const res = await fetch(`/api/survey-data/${companyId}/${encodeURIComponent(fiscalYear)}/unit`, {
      method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({unit})});
    if (!res.ok) { const e = await safeJson(res, {}); alert((e && e.error) || 'Could not change the unit.'); }
  } catch (err) { alert('Could not change the unit: ' + err.message); }
  await renderSurveyAnalyticsPage();
}

function saExecutiveSummaryTab(ov){
  const es = ov.executive_summary;
  const bo = ov.board_overview;
  return `
    ${saHeader('Executive Summary', `Key findings and Insights from the ${escapeHtml(ov.fiscal_year)} Board Remuneration Survey`)}
    ${saImplausibleBanner(ov)}
    <div class="sa-stat-grid">
      ${saStatCard('💰', es.total_market_cap !== null ? fmtMillions(es.total_market_cap) : naSpan('Not enough companies reported market cap'), 'Total Market Capitalisation')}
      ${saStatCard('📈', saMetricAvg(es.avg_turnover) !== null ? fmtMillions(es.avg_turnover.average) : naSpan('Not enough data'), 'Average Turnover')}
      ${saStatCard('💵', saMetricAvg(es.avg_net_profit) !== null ? fmtMillions(es.avg_net_profit.average) : naSpan('Not enough data'), 'Average Net Profit')}
      ${saStatCard('%', saMetricAvg(es.avg_profit_margin) !== null ? fmt(es.avg_profit_margin.average) + '%' : naSpan('Not enough data'), 'Average Profit Margin')}
    </div>
    <div class="row row-3">
      <div class="panel"><div class="empty">${naSpan('NSE-wide market capitalisation history is not tracked by this app')}</div></div>
      <div class="panel" id="saPerformanceTrendSlot">${saPerformanceTrendPanel()}</div>
      <div class="panel">
        <div class="sa-panel-title">Board Composition</div>
        <div class="row row-2">
          ${saMiniStat(saMetricAvg(bo.avg_board_size), 'Average board size (directors)')}
          ${saMiniStat(saMetricAvg(bo.avg_board_meetings_per_year), 'Average board meetings per year')}
          ${saMiniStat(bo.total_directors_female !== null && bo.total_directors_male !== null ? fmt((bo.total_directors_female/(bo.total_directors_female+bo.total_directors_male || 1))*100, 0) + '%' : naSpan('Not enough data'), 'Female')}
          ${saMiniStat(bo.total_directors_female !== null && bo.total_directors_male !== null ? fmt((bo.total_directors_male/(bo.total_directors_female+bo.total_directors_male || 1))*100, 0) + '%' : naSpan('Not enough data'), 'Male')}
          ${saMiniStat(saMetricAvg(bo.avg_committees_per_board), 'Average committees (per board)')}
          ${saMiniStat(saMetricAvg(bo.avg_committee_meetings_per_year), 'Average committee meetings per year')}
        </div>
      </div>
    </div>
    <div class="row row-3">
      <div class="panel">
        <div class="sa-panel-title">Director Profile</div>
        <div class="row row-2">
          ${saMiniStat(saMetricAvg(bo.avg_age_executive_directors), 'Executive Directors (years)')}
          ${saMiniStat(saMetricAvg(bo.avg_age_non_executive_directors), 'Non-Executive Directors (years)')}
          ${saMiniStat(saMetricAvg(bo.avg_age_independent_neds), 'Ind. NEDs (years)')}
          ${saMiniStat(saMetricAvg(bo.avg_age_non_independent_neds), 'Non-Ind. NEDs (years)')}
        </div>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Domicile of Directors</div>
        <div class="row row-2">
          ${saMiniStat(bo.total_neds_kenyan !== null ? bo.total_neds_kenyan : naSpan('Not enough data'), 'Kenyans (NEDs)')}
          ${saMiniStat(bo.total_neds_non_kenyan !== null ? bo.total_neds_non_kenyan : naSpan('Not enough data'), 'Non-Kenyans (NEDs)')}
        </div>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Sector Highlights — Avg. NED Annual Retainer</div>
        ${saSectorBarList(ov.sector_comparison, 'avg_other_ned_annual_retainer')}
      </div>
    </div>
    <div class="panel">
      <div class="sa-panel-title">Key Takeaways</div>
      ${saExecutiveSummaryTakeaways(ov, es, bo)}
    </div>`;
}
// Deterministic, non-fabricated observations - only fires a line when
// the underlying figures are actually on file. Deliberately doesn't
// attempt the mockup's "Outlook"-style forward-looking narrative
// (e.g. "the survey highlights resilience... opportunities for
// improved governance") since that's editorial judgement, not
// something derivable from the data.
function saExecutiveSummaryTakeaways(ov, es, bo){
  const items = [];
  if (ilTrendsCache && ilTrendsCache.has_data && ilTrendsCache.series.length >= 2) {
    const series = ilTrendsCache.series;
    const prior = series[series.length - 2], latest = series[series.length - 1];
    const priorProfit = saMetricAvg(prior.executive_summary && prior.executive_summary.avg_net_profit, {raw:true});
    const latestProfit = saMetricAvg(latest.executive_summary && latest.executive_summary.avg_net_profit, {raw:true});
    if (priorProfit !== null && latestProfit !== null && priorProfit > 0) {
      const pctChange = Math.round((latestProfit - priorProfit) / priorProfit * 100);
      items.push(['📉', 'Performance', `Average net profit ${pctChange >= 0 ? 'grew' : 'declined'} ${Math.abs(pctChange)}% compared to ${escapeHtml(prior.fiscal_year)}.`]);
    }
  }
  const female = bo.total_directors_female, male = bo.total_directors_male;
  if (female !== null && male !== null && (female + male) > 0) {
    const pct = Math.round(female / (female + male) * 100);
    items.push(['♀️', 'Board Diversity', `Female representation stands at ${pct}%, with a mix of Kenyan and non-Kenyan directors.`]);
  }
  if (saMetricAvg(ov.directors_remuneration.other_ned_annual_retainer) !== null) {
    items.push(['💰', 'Remuneration', `Average NED annual retainer is ${escapeHtml(ov.currency)} ${fmtAmount(ov.directors_remuneration.other_ned_annual_retainer.average)}.`]);
  }
  if (!items.length) return `<div class="empty">${naSpan('Not enough data on file yet for key takeaways')}</div>`;
  return `<div class="row row-3">${items.map(([icon, title, text]) => `
    <div style="display:flex;gap:10px;">
      <div style="font-size:20px;">${icon}</div>
      <div><div style="font-weight:700;font-size:12.5px;">${escapeHtml(title)}</div><div style="font-size:11.5px;color:var(--text-dim);">${text}</div></div>
    </div>`).join('')}</div>`;
}
function saMiniStat(value, label){
  return `<div class="sa-mini-stat"><div class="n">${value !== null && value !== undefined ? value : naSpan('Not enough data')}</div><div class="l">${escapeHtml(label)}</div></div>`;
}
function saSectorBarList(sectorComparison, fieldName){
  const base = fieldName.replace(/^avg_/, '');
  const rows = (sectorComparison || []).map(s => {
    const one = (s[fieldName] === null || s[fieldName] === undefined) && s['avg_' + base + '_company_count'] === 1 ? s['single_' + base] : null;
    return {name: s.sector + (one !== null && one !== undefined ? ' (1 company)' : ''), val: (one !== null && one !== undefined) ? one : s[fieldName]};
  }).filter(r => r.val !== null && r.val !== undefined);
  if (!rows.length) return `<div class="empty">${naSpan('Not enough companies report this field by sector yet')}</div>`;
  rows.sort((a,b) => b.val - a.val);
  const max = Math.max(...rows.map(r => r.val));
  return `<div class="sa-bar-list">${rows.map(r => saBar(r.name, fmtAmount(r.val), max)).join('')}</div>`;
}

// ---- Tab 3: Board Overview ----
function saBoardOverviewTab(ov){
  const bo = ov.board_overview;
  const female = bo.total_directors_female, male = bo.total_directors_male;
  const femPct = (female !== null && male !== null && (female+male) > 0) ? Math.round(female/(female+male)*100) : null;
  const exec = bo.total_executive_directors, nonExec = bo.total_non_executive_directors;
  const execPct = (exec !== null && nonExec !== null && (exec+nonExec) > 0) ? Math.round(exec/(exec+nonExec)*100) : null;
  const indep = bo.total_independent_neds, nonIndep = bo.total_non_independent_neds;
  const kenyan = bo.total_neds_kenyan, nonKenyan = bo.total_neds_non_kenyan;
  return `
    ${saHeader('Board Overview', 'Board composition, governance structure and director profile')}
    <div class="sa-stat-grid">
      ${saStatCard('👥', saMetricAvg(bo.avg_board_size) !== null ? saMetricAvg(bo.avg_board_size) : naSpan('Not enough data'), 'Average Board Size', 'directors')}
      ${saStatCard('📅', saMetricAvg(bo.avg_board_meetings_per_year) !== null ? saMetricAvg(bo.avg_board_meetings_per_year) : naSpan('Not enough data'), 'Average Board Meetings', 'per year')}
      ${saStatCard('👥', saMetricAvg(bo.avg_committees_per_board) !== null ? saMetricAvg(bo.avg_committees_per_board) : naSpan('Not enough data'), 'Average Committees', 'per board')}
      ${saStatCard('📅', saMetricAvg(bo.avg_committee_meetings_per_year) !== null ? saMetricAvg(bo.avg_committee_meetings_per_year) : naSpan('Not enough data'), 'Average Committee Meetings', 'per year')}
    </div>
    <div class="row row-3">
      <div class="panel">
        <div class="sa-panel-title">Gender Representation</div>
        ${femPct !== null ? saDonut2([['Female', femPct, 'var(--purple)'], ['Male', 100-femPct, 'var(--blue)']], `${female} / ${female+male}`)
          : `<div class="empty">${naSpan('Not enough companies reported director gender counts')}</div>`}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Board Composition</div>
        ${execPct !== null ? `
        <div class="row row-2">
          <div>${saDonut2([['Executive', execPct, 'var(--blue)'], ['Non-Executive', 100-execPct, 'var(--amber)']], `${exec+nonExec}`)}</div>
          <div class="ir-kv-list" style="font-size:11.5px;align-self:center;">
            <div class="ir-kv-row"><span class="k">● Executive Directors</span><span style="font-weight:700;">${exec} (${execPct}%)</span></div>
            <div class="ir-kv-row"><span class="k">● Non-Executive Directors</span><span style="font-weight:700;">${nonExec} (${100-execPct}%)</span></div>
            ${indep !== null && nonIndep !== null ? `
            <div class="ir-kv-row"><span class="k">● Independent NEDs</span><span style="font-weight:700;">${indep} (${Math.round(indep/(indep+nonIndep)*100)}%)</span></div>
            <div class="ir-kv-row"><span class="k">● Non-Independent NEDs</span><span style="font-weight:700;">${nonIndep} (${Math.round(nonIndep/(indep+nonIndep)*100)}%)</span></div>` : ''}
          </div>
        </div>` : `<div class="empty">${naSpan('Not enough companies reported executive/non-executive counts')}</div>`}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Director Age Comparison</div>
        <div class="sa-bar-list">
          ${saMetricAvg(bo.avg_age_executive_directors) !== null ? saBar('Executive Directors', saMetricAvg(bo.avg_age_executive_directors), 80) : ''}
          ${saMetricAvg(bo.avg_age_non_executive_directors) !== null ? saBar('Non-Executive Directors', saMetricAvg(bo.avg_age_non_executive_directors), 80) : ''}
          ${saMetricAvg(bo.avg_age_independent_neds) !== null ? saBar('Independent NEDs', saMetricAvg(bo.avg_age_independent_neds), 80) : ''}
          ${saMetricAvg(bo.avg_age_non_independent_neds) !== null ? saBar('Non-Independent NEDs', saMetricAvg(bo.avg_age_non_independent_neds), 80) : ''}
          ${[bo.avg_age_executive_directors, bo.avg_age_non_executive_directors, bo.avg_age_independent_neds, bo.avg_age_non_independent_neds].every(m => saMetricAvg(m) === null) ? `<div class="empty">${naSpan('Not enough data')}</div>` : ''}
        </div>
      </div>
    </div>
    <div class="row row-3">
      <div class="panel">
        <div class="sa-panel-title">Domicile of Directors</div>
        ${kenyan !== null && nonKenyan !== null && (kenyan+nonKenyan) > 0 ? saDonut2([['Kenyan', Math.round(kenyan/(kenyan+nonKenyan)*100), 'var(--green)'], ['Non-Kenyan', Math.round(nonKenyan/(kenyan+nonKenyan)*100), 'var(--blue)']], `${kenyan+nonKenyan}`)
          : `<div class="empty">${naSpan('Not enough companies reported director domicile')}</div>`}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Key Governance Insights</div>
        <div class="ir-kv-list" style="font-size:11.5px;">
          ${saMetricAvg(bo.avg_board_size) !== null ? `<div>✔️ Boards had an average of ${saMetricAvg(bo.avg_board_size)} directors and met ${saMetricAvg(bo.avg_board_meetings_per_year) || '-'} times on average in ${escapeHtml(ov.fiscal_year)}.</div>` : ''}
          ${saMetricAvg(bo.avg_committees_per_board) !== null ? `<div>✔️ The board had ${saMetricAvg(bo.avg_committees_per_board)} committees on average, meeting ${saMetricAvg(bo.avg_committee_meetings_per_year) || '-'} times a year.</div>` : ''}
          ${femPct !== null ? `<div>✔️ ${femPct}% of directors are female (${100-femPct}% male).</div>` : ''}
          ${kenyan !== null ? `<div>✔️ ${kenyan} of ${kenyan+nonKenyan} NEDs are Kenyan.</div>` : ''}
          ${[bo.avg_board_size, femPct, kenyan].every(v => v === null || v === undefined) ? `<div class="empty">${naSpan('Not enough data yet for governance insights')}</div>` : ''}
        </div>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Regulatory Alignment</div>
        <p style="font-size:11.5px;color:var(--text-dim);line-height:1.5;">The survey compares board composition against the CMA Code of Corporate Governance, which recommends at least a third of board members be independent, and gender diversity of at least a third.</p>
        ${indep !== null && (indep+ (nonIndep||0)) > 0
          ? `<div style="background:var(--green-soft,rgba(34,197,94,.12));border-radius:10px;padding:12px;margin-top:8px;">
              <div style="font-size:11.5px;font-weight:700;color:var(--green);">${(indep/(indep+nonIndep)) >= 0.33 ? '✔️ Meets the \u2265 33% independence threshold' : '\u26a0\ufe0f Below the \u2265 33% independence threshold'}</div>
              <div style="font-size:11px;color:var(--text-dim);margin-top:4px;">At least 33% of board members should be independent \u2014 this portfolio averages ${(indep/(indep+nonIndep)*100).toFixed(0)}%.</div>
            </div>`
          : `<div>${naSpan('Not enough companies reported independence status')}</div>`}
      </div>
    </div>`;
}
function saDonut2(segments, centerLabel){
  // segments: [[label, pct, color], ...] summing to ~100
  let acc = 0;
  const stops = segments.map(([label, pct, color]) => {
    const start = acc; acc += pct;
    return `${color} ${start}% ${acc}%`;
  });
  return `
    <div class="ov-donut-wrap">
      <div class="ov-donut" style="background:conic-gradient(${stops.join(', ')});">
        <div class="ov-donut-hole"><div class="n">${centerLabel}</div></div>
      </div>
      <div class="ov-sector-legend">
        ${segments.map(([label, pct, color]) => `<div class="sa-donut-legend-row"><span class="dot" style="background:${color};"></span>${escapeHtml(label)} <b style="margin-left:auto;">${pct}%</b></div>`).join('')}
      </div>
    </div>`;
}

// ---- Tab 4: Directors' Remuneration ----
function saDirectorsRemunerationTab(ov){
  const dr = ov.directors_remuneration;
  const cr = ov.committee_remuneration;
  return `
    ${saHeader("Directors' Remuneration", `Fees, retainers and allowances for directors across ${ov.companies_surveyed} NSE-listed companies`)}
    <div class="sa-stat-grid">
      ${saStatCard('👤', saMetricAvg(dr.chairperson_annual_retainer, {raw:true}) !== null ? fmtAmount(dr.chairperson_annual_retainer.average) : naSpan('Not enough data'), 'Average Chairperson Annual Retainer', ov.fiscal_year)}
      ${saStatCard('👥', saMetricAvg(dr.other_ned_annual_retainer, {raw:true}) !== null ? fmtAmount(dr.other_ned_annual_retainer.average) : naSpan('Not enough data'), 'Average NED Annual Retainer', ov.fiscal_year)}
      ${saStatCard('📅', saMetricAvg(dr.chairperson_meeting_allowance, {raw:true}) !== null ? fmtAmount(dr.chairperson_meeting_allowance.average) : naSpan('Not enough data'), 'Average Board Meeting Allowance', 'per meeting')}
      ${saStatCard('👥', cr && saMetricAvg(cr.committee_chair_meeting_allowance, {raw:true}) !== null ? fmtAmount(cr.committee_chair_meeting_allowance.average) : naSpan('Not enough data'), 'Average Committee Meeting Allowance', 'per meeting')}
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Annual Retainer Fees — Chairperson vs Other NEDs</div>
        ${saPercentileChart(dr.chairperson_annual_retainer, dr.other_ned_annual_retainer, 'Chairperson', 'Other NEDs')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Chairperson Premium</div>
        ${dr.chairperson_vs_other_ned_annual_retainer_ratio !== null
          ? `<div style="text-align:center;padding:20px 0;"><div style="font-size:36px;font-weight:700;color:var(--blue);">${dr.chairperson_vs_other_ned_annual_retainer_ratio}x</div><div style="font-size:11.5px;color:var(--text-dim);margin-top:6px;">The average board chair earns approximately ${dr.chairperson_vs_other_ned_annual_retainer_ratio}x the annual retainer paid to other NEDs.</div></div>`
          : `<div class="empty">${naSpan('Not enough companies reported both figures')}</div>`}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Board Meeting Allowances — Chairperson vs Other NEDs</div>
        ${saPercentileChart(dr.chairperson_meeting_allowance, dr.other_ned_meeting_allowance, 'Chairperson', 'Other NEDs')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Committee Meeting Allowances — Chair vs Member</div>
        ${cr ? saPercentileChart(cr.committee_chair_meeting_allowance, cr.committee_member_meeting_allowance, 'Committee Chair', 'Committee Member')
          : `<div class="empty">${naSpan('No committee remuneration data on file')}</div>`}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Committee Premium</div>
        ${saCommitteePremiumCallout(cr)}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Average NED Annual Retainer by Sector</div>
        <div style="display:flex;gap:4px;margin-bottom:10px;">
          <button class="secondary ${saDirRemSectorMetric === 'ned' ? 'active' : ''}" onclick="saDirRemSectorMetric='ned';renderSATabBody();">NED Retainers</button>
          <button class="secondary ${saDirRemSectorMetric === 'chair' ? 'active' : ''}" onclick="saDirRemSectorMetric='chair';renderSATabBody();">Chairperson Retainers</button>
        </div>
        ${saSectorBarList(ov.sector_comparison, saDirRemSectorMetric === 'ned' ? 'avg_other_ned_annual_retainer' : 'avg_chairperson_annual_retainer')}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Typical NED Compensation Mix</div>
        ${saCompensationMixDonut(dr, cr)}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Key Takeaways</div>
        <div class="row row-2">
          ${saTakeaway('👤', 'Chairperson Retainer', saMetricAvg(dr.chairperson_annual_retainer, {raw:true}) !== null ? `Average annual retainer of ${escapeHtml(ov.currency)} ${fmtAmount(dr.chairperson_annual_retainer.average)}.` : 'Not enough data yet.')}
          ${saTakeaway('👥', 'NED Retainer', saMetricAvg(dr.other_ned_annual_retainer, {raw:true}) !== null ? `Average annual retainer of ${escapeHtml(ov.currency)} ${fmtAmount(dr.other_ned_annual_retainer.average)} for other non-executive directors.` : 'Not enough data yet.')}
          ${saTakeaway('📅', 'Meeting Fees', saMetricAvg(dr.chairperson_meeting_allowance, {raw:true}) !== null ? `Board attendance allowance averages ${escapeHtml(ov.currency)} ${fmtAmount(dr.chairperson_meeting_allowance.average)} for chairs.` : 'Not enough data yet.')}
          ${cr && saMetricAvg(cr.committee_chair_meeting_allowance, {raw:true}) !== null ? saTakeaway('👥', 'Committee Fees', `Committee chairpersons average ${escapeHtml(ov.currency)} ${fmtAmount(cr.committee_chair_meeting_allowance.average)} per meeting.`) : ''}
        </div>
      </div>
    </div>`;
}
// Uses the real chair_vs_member_annual_retainer_ratio field - the
// SAME field and computation the dedicated Committee Remuneration tab
// uses for its own "Key Insight" panel (see that tab's own code) -
// rather than recomputing a ratio from raw averages here.
function saCommitteePremiumCallout(cr){
  if (!cr || cr.chair_vs_member_annual_retainer_ratio === null || cr.chair_vs_member_annual_retainer_ratio === undefined) {
    return `<div class="empty">${naSpan('Not enough companies reported both committee chair and member retainers')}</div>`;
  }
  const pct = Math.round((cr.chair_vs_member_annual_retainer_ratio - 1) * 100);
  return `<div style="text-align:center;padding:20px 0;"><div style="font-size:36px;font-weight:700;color:var(--green);">${pct}%</div><div style="font-size:11.5px;color:var(--text-dim);margin-top:6px;">Committee chairpersons receive approximately ${pct}% higher annual retainer than committee members.</div></div>`;
}
function saCompensationMixDonut(dr, cr){
  const retainer = saMetricAvg(dr.other_ned_annual_retainer, {raw:true});
  const meetingFees = saMetricAvg(dr.chairperson_meeting_allowance, {raw:true});
  const committeeFees = cr ? saMetricAvg(cr.committee_chair_meeting_allowance, {raw:true}) : null;
  const parts = [retainer, meetingFees, committeeFees].filter(v => v !== null);
  if (parts.length < 2) return `<div class="empty">${naSpan('Not enough components on file to compute a compensation mix')}</div>`;
  const total = (retainer||0) + (meetingFees||0) + (committeeFees||0);
  if (total === 0) return `<div class="empty">${naSpan('Not enough data')}</div>`;
  const retainerPct = Math.round((retainer||0)/total*100);
  const meetingPct = Math.round((meetingFees||0)/total*100);
  const committeePct = 100 - retainerPct - meetingPct;
  return saDonut2([['Annual Retainer', retainerPct, 'var(--blue)'], ['Board Meeting Fees', meetingPct, 'var(--green)'], ['Committee Fees', committeePct, 'var(--purple)']], '100%');
}
function saPercentileChart(metricA, metricB, labelA, labelB){
  if ((!metricA || metricA.average === null) && (!metricB || metricB.average === null)) {
    return `<div class="empty">${naSpan('Not enough data')}</div>`;
  }
  const rows = [
    {k:'25th Percentile', a: metricA && metricA.p25, b: metricB && metricB.p25},
    {k:'Median (50th)', a: metricA && metricA.p50, b: metricB && metricB.p50},
    {k:'75th Percentile', a: metricA && metricA.p75, b: metricB && metricB.p75},
    {k:'Average', a: metricA && metricA.average, b: metricB && metricB.average},
  ];
  const max = Math.max(...rows.flatMap(r => [r.a||0, r.b||0]), 1);
  return `<div class="sa-bar-list">${rows.map(r => `
    <div>
      <div style="font-size:10.5px;color:var(--text-faint);margin-bottom:2px;">${r.k}</div>
      ${r.a !== null && r.a !== undefined ? saBar(labelA, fmtAmount(r.a), max, 'var(--blue)') : ''}
      ${r.b !== null && r.b !== undefined ? saBar(labelB, fmtAmount(r.b), max, 'var(--green)') : ''}
    </div>`).join('')}</div>`;
}
function saTakeaway(icon, title, body){
  return `<div class="sa-key-takeaway"><div class="sa-key-takeaway-icon">${icon}</div><div><div class="sa-insight-text-title">${escapeHtml(title)}</div><div class="sa-insight-text-body">${escapeHtml(body)}</div></div></div>`;
}

// ---- Tab 5: Executive Directors ----
function saExecutiveDirectorsTab(ov){
  const dr = ov.directors_remuneration;
  const bo = ov.board_overview;
  const execAvg = saMetricAvg(dr.executive_director_annual_retainer, {raw:true});
  const nedAvg = saMetricAvg(dr.other_ned_annual_retainer, {raw:true});
  const ratio = (execAvg !== null && nedAvg !== null && nedAvg > 0) ? (execAvg / nedAvg) : null;
  return `
    ${saHeader('Executive Directors', `Key insights and remuneration trends for Executive Directors across ${ov.companies_surveyed} surveyed companies`)}
    <div class="sa-stat-grid">
      ${saStatCard('👤', execAvg !== null ? fmtAmount(execAvg) : saNotApplicable('Executive directors are normally paid a salary, not a separate board retainer, so most filings do not state one'), 'Average Executive Director Annual Retainer', 'per year')}
      ${saStatCard('📅', saMetricAvg(dr.executive_director_meeting_allowance, {raw:true}) !== null ? fmtAmount(dr.executive_director_meeting_allowance.average) : saNotApplicable('Executive directors are normally not paid sitting allowances, so most filings do not state one'), 'Average Board Meeting Allowance', 'per meeting')}
      ${saStatCard('👤', saMetricAvg(bo.avg_age_executive_directors) !== null ? saMetricAvg(bo.avg_age_executive_directors) : naSpan('Not enough data'), 'Average Age of Executive Directors', 'years')}
      ${saStatCard('👥', bo.total_executive_directors !== null ? bo.total_executive_directors : naSpan('Not enough data'), 'Total Executive Directors', 'across survey')}
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Executive Director Remuneration</div>
        ${(dr.executive_director_annual_retainer && dr.executive_director_annual_retainer.average !== null && dr.executive_director_annual_retainer.average !== undefined)
          ? saPercentileChart(dr.executive_director_annual_retainer, dr.other_ned_annual_retainer, 'Executive Director', 'Other Directors')
          : `<div class="empty">${saNotApplicable('Executive directors are normally paid a salary, not a separate board retainer, so most filings do not state one')}</div>`}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Key Insight</div>
        ${ratio !== null
          ? `<div style="text-align:center;padding:20px 0;"><div style="font-size:36px;font-weight:700;color:var(--blue);">${ratio.toFixed(1)}x</div><div style="font-size:11.5px;color:var(--text-dim);margin-top:6px;">Executive directors earn approximately ${ratio.toFixed(1)}x the annual retainer paid to other directors.</div></div>`
          : `<div class="empty">${naSpan('Not enough companies reported both figures')}</div>`}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Executive Director Compensation by Sector</div>
        ${saSectorBarList(ov.sector_comparison, 'avg_executive_director_annual_retainer')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Executive Director Composition</div>
        ${bo.total_executive_directors !== null && bo.total_non_executive_directors !== null
          ? saDonut2([['Executive', Math.round(bo.total_executive_directors/(bo.total_executive_directors+bo.total_non_executive_directors)*100), 'var(--green)'], ['Non-Executive', Math.round(bo.total_non_executive_directors/(bo.total_executive_directors+bo.total_non_executive_directors)*100), 'var(--blue)']], `${bo.total_executive_directors+bo.total_non_executive_directors}`)
          : `<div class="empty">${naSpan('Not enough data')}</div>`}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Age Profile of Executive Directors</div>
        <div class="empty">${naSpan('Only a portfolio-wide average age is tracked \u2014 youngest/oldest/median needs individual director ages, which this survey does not aggregate across companies')}</div>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Director Gender Representation</div>
        <div class="empty">${naSpan('Gender is tracked board-wide (all director types combined), not broken out separately for executive directors only')}</div>
      </div>
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">CEO/MD Remuneration — Monthly (${escapeHtml(ov.currency)})</div>
      ${ov.ceo_remuneration ? `<div class="row row-2">
        <div>
          ${surveyMetricRow('Salary', ov.ceo_remuneration.ceo_monthly_salary, {amount:true})}
          ${surveyMetricRow('Allowances', ov.ceo_remuneration.ceo_monthly_allowances, {amount:true})}
          ${surveyMetricRow('Incentive / Bonus', ov.ceo_remuneration.ceo_monthly_incentive_bonus, {amount:true})}
          ${surveyMetricRow('Deferred Incentive', ov.ceo_remuneration.ceo_monthly_deferred_incentive, {amount:true})}
          ${surveyMetricRow('Pension', ov.ceo_remuneration.ceo_monthly_pension, {amount:true})}
        </div>
        <div>
          ${surveyMetricRow('Non-Cash Benefits', ov.ceo_remuneration.ceo_monthly_non_cash_benefits, {amount:true})}
          ${surveyMetricRow('Gratuity', ov.ceo_remuneration.ceo_monthly_gratuity, {amount:true})}
          ${surveyMetricRow('Share Value', ov.ceo_remuneration.ceo_monthly_share_value, {amount:true})}
          ${surveyMetricRow('Total Cost of Employment', ov.ceo_remuneration.ceo_monthly_cost_of_employment, {amount:true})}
        </div>
      </div>` : `<div class="empty">${naSpan('Not enough data on file yet')}</div>`}
    </div>
    <div class="panel">
      <div class="sa-panel-title">Key Takeaways</div>
      <div class="row row-3">
        ${saTakeaway('💰', 'Executive Retainers', execAvg !== null ? `Average annual retainer of ${escapeHtml(ov.currency)} ${fmtAmount(execAvg)}.` : 'Not enough data yet.')}
        ${saTakeaway('📅', 'Meeting Fees', saMetricAvg(dr.executive_director_meeting_allowance, {raw:true}) !== null ? `Board attendance allowance averages ${escapeHtml(ov.currency)} ${fmtAmount(dr.executive_director_meeting_allowance.average)} per meeting.` : 'Not enough data yet.')}
        ${saTakeaway('👤', 'Age Profile', saMetricAvg(bo.avg_age_executive_directors) !== null ? `Average age of executive directors is ${saMetricAvg(bo.avg_age_executive_directors)} years.` : 'Not enough data yet.')}
      </div>
    </div>`;
}

// ---- Tab 6: Non-Executive Directors ----
function saNonExecutiveDirectorsTab(ov){
  const dr = ov.directors_remuneration;
  const bo = ov.board_overview;
  const indep = bo.total_independent_neds, nonIndep = bo.total_non_independent_neds;
  return `
    ${saHeader('Non-Executive Directors', `Remuneration, composition and key insights for Non-Executive Directors across ${ov.companies_surveyed} surveyed companies`)}
    <div class="sa-stat-grid">
      ${saStatCard('👤', saMetricAvg(dr.other_ned_annual_retainer, {raw:true}) !== null ? fmtAmount(dr.other_ned_annual_retainer.average) : naSpan('Not enough data'), 'Average NED Annual Retainer', 'per year')}
      ${saStatCard('📅', saMetricAvg(dr.other_ned_meeting_allowance, {raw:true}) !== null ? fmtAmount(dr.other_ned_meeting_allowance.average) : naSpan('Not enough data'), 'Average Board Meeting Allowance', 'per meeting')}
      ${saStatCard('👥', ov.committee_remuneration && saMetricAvg(ov.committee_remuneration.committee_member_meeting_allowance, {raw:true}) !== null ? fmtAmount(ov.committee_remuneration.committee_member_meeting_allowance.average) : naSpan('Not enough data'), 'Average Committee Meeting Allowance', 'per meeting')}
      ${saStatCard('%', dr.chairperson_vs_other_ned_annual_retainer_ratio !== null ? dr.chairperson_vs_other_ned_annual_retainer_ratio + 'x' : naSpan('Not enough data'), 'Chairperson Premium', 'vs other NEDs')}
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">NED Annual Retainer Fees</div>
        ${saPercentileChart(dr.other_ned_annual_retainer, dr.chairperson_annual_retainer, 'NEDs', 'Chairpersons')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Key Insight</div>
        ${dr.chairperson_vs_other_ned_annual_retainer_ratio !== null
          ? `<div style="text-align:center;padding:20px 0;"><div style="font-size:36px;font-weight:700;color:var(--blue);">${dr.chairperson_vs_other_ned_annual_retainer_ratio}x</div><div style="font-size:11.5px;color:var(--text-dim);margin-top:6px;">The average board chair earns approximately ${dr.chairperson_vs_other_ned_annual_retainer_ratio}x the annual retainer paid to other NEDs.</div></div>`
          : `<div class="empty">${naSpan('Not enough companies reported both figures')}</div>`}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">NED Meeting Allowances</div>
        ${saPercentileChart(dr.other_ned_meeting_allowance, dr.chairperson_meeting_allowance, 'NEDs', 'Chairpersons')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">NED Composition</div>
        ${indep !== null && nonIndep !== null && (indep+nonIndep) > 0
          ? saDonut2([['Independent NEDs', Math.round(indep/(indep+nonIndep)*100), 'var(--blue)'], ['Non-Independent NEDs', Math.round(nonIndep/(indep+nonIndep)*100), 'var(--green)']], `${indep+nonIndep}`)
          : `<div class="empty">${naSpan('Not enough data')}</div>`}
      </div>
    </div>
    <div class="row row-3">
      <div class="panel">
        <div class="sa-panel-title">Average Age of NEDs</div>
        <div class="sa-bar-list">
          ${saMetricAvg(bo.avg_age_independent_neds) !== null ? saBar('Independent NEDs', saMetricAvg(bo.avg_age_independent_neds), 80) : ''}
          ${saMetricAvg(bo.avg_age_non_independent_neds) !== null ? saBar('Non-Independent NEDs', saMetricAvg(bo.avg_age_non_independent_neds), 80) : ''}
          ${[bo.avg_age_independent_neds, bo.avg_age_non_independent_neds].every(m => saMetricAvg(m) === null) ? `<div class="empty">${naSpan('Not enough data')}</div>` : ''}
        </div>
        <div style="font-size:10px;color:var(--text-faint);margin-top:8px;">${naSpan('Age broken down by gender is not tracked \u2014 only independent/non-independent')}</div>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Gender Representation</div>
        <div class="empty">${naSpan('Gender is tracked board-wide (all director types combined), not broken out separately for NEDs only')}</div>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Average NED Annual Retainer by Sector</div>
        ${saSectorBarList(ov.sector_comparison, 'avg_other_ned_annual_retainer')}
      </div>
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">NED Benefits Summary — % of Companies Providing Each Benefit</div>
      ${ov.ned_benefits_summary ? `<div class="sa-bar-list">
        ${[
          ['MedicalCover', 'Medical Cover'], ['IndemnityInsurance', 'Indemnity Insurance'],
          ['TravelAccommodation', 'Travel & Accommodation'], ['TelephoneAllowance', 'Telephone Allowance'],
          ['TransportAllowance', 'Transport Allowance'], ['MealAllowance', 'Meal Allowance'],
          ['ClubMembership', 'Club Membership'], ['DutyDayAllowance', 'Duty Day Allowance'],
          ['GroupPersonalAccident', 'Group Personal Accident'], ['ShareSchemeParticipation', 'Share Scheme Participation'],
        ].map(([key, label]) => {
          const b = ov.ned_benefits_summary[key];
          if (!b || b.percent_provided === null || b.percent_provided === undefined) {
            return `<div class="ir-kv-row"><span class="k">${escapeHtml(label)}</span>${naSpan('Not enough companies have addressed this benefit yet' + (b && b.companies_addressing ? ` (${b.companies_addressing} of 2+ needed)` : ''))}</div>`;
          }
          return saBar(label, b.percent_provided + '%', 100);
        }).join('')}
      </div>` : `<div class="empty">${naSpan('Not enough data on file yet')}</div>`}
    </div>
    <div class="panel">
      <div class="sa-panel-title">Key Takeaways</div>
      <div class="row row-3">
        ${saTakeaway('💰', 'NED Retainers', saMetricAvg(dr.other_ned_annual_retainer, {raw:true}) !== null ? `Average annual retainer of ${escapeHtml(ov.currency)} ${fmtAmount(dr.other_ned_annual_retainer.average)}.` : 'Not enough data yet.')}
        ${saTakeaway('📅', 'Meeting Fees', saMetricAvg(dr.other_ned_meeting_allowance, {raw:true}) !== null ? `Board attendance allowance averages ${escapeHtml(ov.currency)} ${fmtAmount(dr.other_ned_meeting_allowance.average)} per meeting.` : 'Not enough data yet.')}
        ${saTakeaway('👤', 'Chairperson Premium', dr.chairperson_vs_other_ned_annual_retainer_ratio !== null ? `Board chairs earn ${dr.chairperson_vs_other_ned_annual_retainer_ratio}x the retainer of other NEDs.` : 'Not enough data yet.')}
      </div>
    </div>`;
}

// ---- Tab 7: Committee Remuneration ----
function saCommitteeRemunerationTab(ov){
  const cr = ov.committee_remuneration;
  const bo = ov.board_overview;
  return `
    ${saHeader('Committee Remuneration', `Overview of committee chair and member remuneration across ${ov.companies_surveyed} surveyed companies`)}
    <div class="sa-stat-grid">
      ${saStatCard('👤', saMetricAvg(cr.committee_chair_annual_retainer, {raw:true}) !== null ? fmtAmount(cr.committee_chair_annual_retainer.average) : naSpan('Not enough data'), 'Average Committee Chair Annual Retainer', 'per year')}
      ${saStatCard('👥', saMetricAvg(cr.committee_member_annual_retainer, {raw:true}) !== null ? fmtAmount(cr.committee_member_annual_retainer.average) : naSpan('Not enough data'), 'Average Committee Member Annual Retainer', 'per year')}
      ${saStatCard('📅', saMetricAvg(cr.committee_chair_meeting_allowance, {raw:true}) !== null ? fmtAmount(cr.committee_chair_meeting_allowance.average) : naSpan('Not enough data'), 'Average Committee Meeting Allowance (Chair)', 'per meeting')}
      ${saStatCard('📅', saMetricAvg(cr.committee_member_meeting_allowance, {raw:true}) !== null ? fmtAmount(cr.committee_member_meeting_allowance.average) : naSpan('Not enough data'), 'Average Committee Meeting Allowance (Member)', 'per meeting')}
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Annual Retainer Fees</div>
        ${saPercentileChart(cr.committee_chair_annual_retainer, cr.committee_member_annual_retainer, 'Committee Chair', 'Committee Member')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Key Insight</div>
        ${cr.chair_vs_member_annual_retainer_ratio !== null
          ? `<div style="text-align:center;padding:20px 0;"><div style="font-size:36px;font-weight:700;color:var(--blue);">${Math.round((cr.chair_vs_member_annual_retainer_ratio-1)*100)}%</div><div style="font-size:11.5px;color:var(--text-dim);margin-top:6px;">Committee chairpersons receive a premium of approximately ${Math.round((cr.chair_vs_member_annual_retainer_ratio-1)*100)}% higher than committee members.</div></div>`
          : `<div class="empty">${naSpan('Not enough companies reported both figures')}</div>`}
      </div>
    </div>
    <div class="row row-3">
      <div class="panel">
        <div class="sa-panel-title">Committee Meeting Allowances</div>
        ${saPercentileChart(cr.committee_chair_meeting_allowance, cr.committee_member_meeting_allowance, 'Chair', 'Member')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Committee Composition</div>
        ${saMetricAvg(bo.avg_committees_per_board) !== null
          ? `<div class="ov-donut-wrap"><div class="ov-donut" style="background:var(--bg-panel-2);"><div class="ov-donut-hole"><div class="n">${saMetricAvg(bo.avg_committees_per_board)}</div><div class="l">avg. committees</div></div></div></div>`
          : `<div class="empty">${naSpan('Not enough data')}</div>`}
        <div style="font-size:10px;color:var(--text-faint);margin-top:8px;">${naSpan('A breakdown by committee type (Audit/Risk/Nomination, etc.) is not aggregated across the portfolio \u2014 only a per-board average count is tracked at this level')}</div>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Average Committee Meeting Allowance by Sector (Chair)</div>
        ${saSectorBarList(ov.sector_comparison, 'avg_committee_chair_meeting_allowance')}
      </div>
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Average Meetings per Committee</div>
      <div class="empty">${naSpan('Meetings-per-committee-type is not aggregated across the portfolio \u2014 only a per-board average meeting count is tracked at this level (see Committee Composition above)')}</div>
    </div>
    <div class="panel">
      <div class="sa-panel-title">Key Takeaways</div>
      <div class="row row-3">
        ${saTakeaway('💰', 'Chair Retainer', saMetricAvg(cr.committee_chair_annual_retainer, {raw:true}) !== null ? `Average ${escapeHtml(ov.currency)} ${fmtAmount(cr.committee_chair_annual_retainer.average)} annually.` : 'Not enough data yet.')}
        ${saTakeaway('👥', 'Member Retainer', saMetricAvg(cr.committee_member_annual_retainer, {raw:true}) !== null ? `Average ${escapeHtml(ov.currency)} ${fmtAmount(cr.committee_member_annual_retainer.average)} annually.` : 'Not enough data yet.')}
        ${saTakeaway('📅', 'Meeting Allowances', saMetricAvg(cr.committee_chair_meeting_allowance, {raw:true}) !== null ? `Chair: ${escapeHtml(ov.currency)} ${fmtAmount(cr.committee_chair_meeting_allowance.average)} · Member: ${saMetricAvg(cr.committee_member_meeting_allowance, {raw:true}) !== null ? fmtAmount(cr.committee_member_meeting_allowance.average) : '-'} (per meeting).` : 'Not enough data yet.')}
        ${saMetricAvg(bo.avg_committees_per_board) !== null ? saTakeaway('🗂️', 'Committee Composition', `Boards have ${saMetricAvg(bo.avg_committees_per_board)} committees on average.`) : ''}
      </div>
    </div>`;
}

// ---- Tab 8: Comparative Analysis ----
function saComparativeAnalysisTab(ov){
  const dr = ov.directors_remuneration;
  const cr = ov.committee_remuneration;
  const sectorRows = (ov.sector_comparison || []);
  const nedRows = sectorRows.filter(s => s.avg_other_ned_annual_retainer !== null);
  const highest = nedRows.length ? nedRows.reduce((a,b) => a.avg_other_ned_annual_retainer > b.avg_other_ned_annual_retainer ? a : b) : null;
  const lowest = nedRows.length ? nedRows.reduce((a,b) => a.avg_other_ned_annual_retainer < b.avg_other_ned_annual_retainer ? a : b) : null;
  return `
    ${saHeader('Comparative Analysis', 'How director remuneration compares across sectors, company sizes and key metrics')}
    <div class="sa-stat-grid">
      ${saStatCard('👥', highest ? fmtAmount(highest.avg_other_ned_annual_retainer) : naSpan('Not enough data'), 'Highest Paying Sector', highest ? escapeHtml(highest.sector) : '')}
      ${saStatCard('🏢', lowest ? fmtAmount(lowest.avg_other_ned_annual_retainer) : naSpan('Not enough data'), 'Lowest Paying Sector', lowest ? escapeHtml(lowest.sector) : '')}
      ${saStatCard('📈', naSpan('No market-cap-by-company data is tracked for the survey'), 'Largest Company (by market cap)', '')}
      ${saStatCard('🏢', naSpan('No market-cap-by-company data is tracked for the survey'), 'Smallest Company (by market cap)', '')}
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Director Remuneration by Sector — NED vs Chairperson Retainer</div>
        ${saTwoMetricSectorBarChart(sectorRows, 'avg_other_ned_annual_retainer', 'avg_chairperson_annual_retainer', 'NED Retainer', 'Chair Retainer')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Remuneration by Company Size</div>
        <div class="empty">${naSpan('Company-size (market cap band) data is not tracked by this app')}</div>
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Remuneration Structure Comparison</div>
        <div class="empty">${naSpan('A NED-vs-Executive-Director component mix needs a way to attribute committee fees to one director type or the other \u2014 committee chair/member fees are tracked by committee role only, with no link back to whether that person is also an executive or non-executive director, so this app cannot honestly build that split')}</div>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Key Insight</div>
        ${highest && lowest
          ? `<p style="font-size:12px;color:var(--text-dim);line-height:1.5;">The <b>${escapeHtml(highest.sector)}</b> sector pays the highest average NED retainer at <b>${escapeHtml(ov.currency)} ${fmtAmount(highest.avg_other_ned_annual_retainer)}</b>, while <b>${escapeHtml(lowest.sector)}</b> pays the lowest at <b>${escapeHtml(ov.currency)} ${fmtAmount(lowest.avg_other_ned_annual_retainer)}</b>.</p>`
          : `<div class="empty">${naSpan('Not enough sector data yet')}</div>`}
      </div>
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Chair vs Member/NED Premiums — Average Percentage Difference</div>
      ${saChairPremiumDonuts(dr, cr)}
    </div>
    <div class="panel" style="margin-bottom:14px;">
      <div class="sa-panel-title">Key Takeaways</div>
      ${saComparativeAnalysisTakeaways(ov, dr, cr, highest, lowest)}
    </div>
    <div class="panel">
      <div class="sa-panel-title">Sector Comparison — Average Pay Figures (${escapeHtml(ov.currency)})</div>
      <div style="overflow-x:auto;">
      <table>
        <thead><tr><th>Sector</th><th>Companies</th><th>Avg. NED Retainer</th><th>Avg. Chairperson Retainer</th><th>Avg. Exec. Director Retainer</th>
          <th>Avg. Chairperson Meeting Allow.</th><th>Avg. NED Meeting Allow.</th><th>Avg. Exec. Director Meeting Allow.</th>
          <th>Avg. Committee Chair Retainer</th><th>Avg. Committee Member Retainer</th>
          <th>Avg. Committee Chair Meeting Allow.</th><th>Avg. Committee Member Meeting Allow.</th>
          <th>Avg. CEO Monthly Salary</th><th>Avg. CEO Monthly Cost of Employment</th></tr></thead>
        <tbody>
          ${sectorRows.map(s => `
            <tr>
              <td>${escapeHtml(s.sector)}</td>
              <td>${s.company_count}</td>
              <td>${saSectorCell(s,'other_ned_annual_retainer')}</td>
              <td>${saSectorCell(s,'chairperson_annual_retainer')}</td>
              <td>${saSectorCell(s,'executive_director_annual_retainer')}</td>
              <td>${saSectorCell(s,'chairperson_meeting_allowance')}</td>
              <td>${saSectorCell(s,'other_ned_meeting_allowance')}</td>
              <td>${saSectorCell(s,'executive_director_meeting_allowance')}</td>
              <td>${saSectorCell(s,'committee_chair_annual_retainer')}</td>
              <td>${saSectorCell(s,'committee_member_annual_retainer')}</td>
              <td>${saSectorCell(s,'committee_chair_meeting_allowance')}</td>
              <td>${saSectorCell(s,'committee_member_meeting_allowance')}</td>
              <td>${saSectorCell(s,'ceo_monthly_salary')}</td>
              <td>${saSectorCell(s,'ceo_monthly_cost_of_employment')}</td>
            </tr>`).join('')}
        </tbody>
      </table>
      </div>
    </div>`;
}
// Two grouped-bar-friendly series over the same sector list - a
// lightweight variant of saSectorBarList for when two metrics need to
// be compared side-by-side per sector rather than one bar per sector.
function saTwoMetricSectorBarChart(sectorRows, fieldA, fieldB, labelA, labelB){
  const rows = sectorRows.filter(s => s[fieldA] !== null || s[fieldB] !== null);
  if (!rows.length) return `<div class="empty">${naSpan('Not enough data')}</div>`;
  const max = Math.max(...rows.map(s => Math.max(s[fieldA]||0, s[fieldB]||0)));
  return `<div class="sa-bar-list">${rows.map(s => `
    <div style="margin-bottom:10px;">
      <div style="font-size:11px;color:var(--text-faint);margin-bottom:2px;">${escapeHtml(s.sector)}</div>
      ${s[fieldA] !== null ? saBar(labelA, fmtAmount(s[fieldA]), max) : ''}
      ${s[fieldB] !== null ? saBar(labelB, fmtAmount(s[fieldB]), max, 'var(--green)') : ''}
    </div>`).join('')}</div>`;
}
// Premium comparisons: the retainer and committee ratios come from the backend
// (computed over companies that report BOTH figures); the board meeting allowance
// premium is computed live from the two averages. Only comparisons with data are drawn.
function saChairPremiumDonuts(dr, cr){
  const items = [];
  const boardChair = saMetricAvg(dr.chairperson_meeting_allowance, {raw:true});
  const boardNed = saMetricAvg(dr.other_ned_meeting_allowance, {raw:true});
  if (boardChair !== null && boardNed !== null && boardNed > 0) {
    items.push(['Board Meeting Allowances', Math.round((boardChair/boardNed - 1)*100), '(Chair vs NED)']);
  }
  if (cr && cr.chair_vs_member_meeting_allowance_ratio !== null && cr.chair_vs_member_meeting_allowance_ratio !== undefined) {
    items.push(['Committee Meeting Allowances', Math.round((cr.chair_vs_member_meeting_allowance_ratio - 1)*100), '(Chair vs Member)']);
  }
  if (cr && cr.chair_vs_member_annual_retainer_ratio !== null && cr.chair_vs_member_annual_retainer_ratio !== undefined) {
    items.push(['Committee Retainers', Math.round((cr.chair_vs_member_annual_retainer_ratio - 1)*100), '(Chair vs Member)']);
  }
  if (dr.chairperson_vs_other_ned_annual_retainer_ratio !== null && dr.chairperson_vs_other_ned_annual_retainer_ratio !== undefined) {
    items.push(['Annual Retainers', Math.round((dr.chairperson_vs_other_ned_annual_retainer_ratio - 1)*100), '(Chair vs NED)']);
  }
  // 'Total Remuneration' (annual retainer + per-meeting allowance, chair vs member) was removed: it added a per-meeting
  // figure to an annual one and, with meeting allowances missing (counted as 0), just repeated the retainer premium.
  if (!items.length) return `<div class="empty">${naSpan('Not enough data to compute chair/member premiums')}</div>`;
  return `<div class="row row-4">${items.map(([label, pct, sub]) => `
    <div style="text-align:center;">
      <div style="font-size:28px;font-weight:700;color:var(--blue);">${pct}%</div>
      <div style="font-size:11px;font-weight:600;margin-top:2px;">${escapeHtml(label)}</div>
      <div style="font-size:10px;color:var(--text-faint);">${escapeHtml(sub)}</div>
    </div>`).join('')}</div>`;
}
function saComparativeAnalysisTakeaways(ov, dr, cr, highest, lowest){
  const items = [];
  if (highest) items.push(`${escapeHtml(highest.sector)} has the highest average remuneration across most metrics.`);
  if (lowest) items.push(`${escapeHtml(lowest.sector)} remains the lowest-paying sector.`);
  if (dr.chairperson_vs_other_ned_annual_retainer_ratio !== null) {
    items.push(`Chairpersons earn a significant premium over other NEDs, particularly in annual retainers (${dr.chairperson_vs_other_ned_annual_retainer_ratio}x).`);
  }
  if (!items.length) return `<div class="empty">${naSpan('Not enough data on file yet for key takeaways')}</div>`;
  return `<ul style="margin:0;padding-left:18px;font-size:12.5px;line-height:1.7;">${items.map(i => `<li>${i}</li>`).join('')}</ul>`;
}

// ---- Tab 9: Appendix ----
// ---- Extended survey fields (audit, board effectiveness, executive pay, workforce, shareholders) ----
// Figures come from survey_extended.py via ov.extended: money already in whole survey-currency units,
// each metric {average,p25,p50,p75,min,max,company_count,top:[{name,value}]}, yes/no as {yes,no,answered,pct_yes}.
function saExtAvg(m){ return (m && m.average !== null && m.average !== undefined) ? m.average : null; }
function saExtCount(m){ return m && m.company_count ? `${m.company_count} ${m.company_count === 1 ? 'company' : 'companies'}` : 'no companies yet'; }
function saYesNoCard(icon, yn, label){
  if (!yn || !yn.answered) return saStatCard(icon, naSpan('No company has stated this yet'), label, 'not yet reported');
  return saStatCard(icon, `${Math.round(yn.pct_yes)}%`, label, `${yn.yes} of ${yn.answered} companies that state it`);
}
function saShareBars(list, color){
  if (!list || !list.length) return `<div class="empty">${naSpan('No company has stated this yet')}</div>`;
  const max = Math.max(...list.map(x => x.companies));
  return list.slice(0, 8).map(x => `<div title="${escapeHtml((x.company_names || []).join(', '))}">${saBar(x.label, `${x.companies} (${x.pct}%)`, max, color)}</div>`).join('');
}
function saTopList(metric, fmtFn, unitLabel){
  if (!metric || !metric.top || !metric.top.length) return `<div class="empty">${naSpan('No company has stated this yet')}</div>`;
  const max = Math.max(...metric.top.map(t => Math.abs(t.value)));
  return metric.top.map(t => saBar(t.name, fmtFn(t.value) + (unitLabel || ''), max)).join('');
}
const saPct = v => `${fmt(v, 1)}%`;
const saWhole = {fmtVal: v => fmtAmount(Math.round(v))};
const saCount = v => fmtAmount(Math.round(v));
function saAuditGovernanceTab(ov){
  const e = ov.extended || {}; const a = e.audit || {}; const b = e.board_effectiveness || {};
  const cur = escapeHtml(ov.currency);
  const ops = a.opinions || {};
  const modified = Object.entries(ops).filter(([k]) => k !== 'Unmodified');
  const gc = a.going_concern || {};
  const da = b.director_attendance || {};
  return `
    ${saHeader('Audit & Governance', `External audit, audit opinions and board effectiveness across ${ov.companies_surveyed} surveyed companies`)}
    <div class="sa-stat-grid">
      ${saStatCard('🧾', saExtAvg(a.audit_fee) !== null ? `${cur} ${saCount(a.audit_fee.average)}` : naSpan('Not enough companies yet'), 'Average Audit Fee', saExtCount(a.audit_fee))}
      ${saStatCard('✅', a.opinions_answered ? `${(ops.Unmodified || {}).companies || 0} of ${a.opinions_answered}` : naSpan('Not reported yet'), 'Clean (Unmodified) Audit Opinions', modified.length ? `${modified.map(([k,v]) => `${v.companies} ${k.toLowerCase()}`).join(', ')}` : 'no modified opinions')}
      ${saStatCard('⚠️', gc.answered ? `${gc.yes}` : naSpan('Not reported yet'), 'Going-Concern Warnings', gc.answered ? `${gc.yes} of ${gc.answered} companies` : '')}
      ${saStatCard('📅', saExtAvg(b.board_attendance_pct) !== null ? saPct(b.board_attendance_pct.average) : naSpan('Not enough companies yet'), 'Average Board Attendance', saExtCount(b.board_attendance_pct))}
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Who Audits the Market</div>
        ${saShareBars(a.auditor_share, 'var(--blue)')}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Audit Fees (${cur})</div>
        ${surveyMetricRow('Audit fee', a.audit_fee, saWhole)}
        ${surveyMetricRow('Audit fee as % of turnover', a.audit_fee_pct_of_turnover, {decimals:2, suffix:'%'})}
        ${surveyMetricRow('Non-audit fees paid to the auditor', a.non_audit_fees, saWhole)}
        ${surveyMetricRow('Key audit matters per report', a.key_audit_matters_count, {decimals:1})}
        ${surveyMetricRow('Years the auditor has been in office', a.auditor_tenure_years, {decimals:1})}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Highest Audit Fees (${cur})</div>
        ${saTopList(a.audit_fee, fmtAmount)}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Audit Opinions & Going Concern</div>
        ${a.opinions_answered ? Object.entries(ops).map(([k,v]) => `<div class="ir-kv-row"><span class="k">${escapeHtml(k)}</span><span title="${escapeHtml(v.company_names.join(', '))}"><b>${v.companies}</b> ${v.companies === 1 ? 'company' : 'companies'}${k !== 'Unmodified' ? ' — ' + escapeHtml(v.company_names.join(', ')) : ''}</span></div>`).join('') : `<div class="empty">${naSpan('Not reported yet')}</div>`}
        <div class="ir-kv-row"><span class="k">Material uncertainty on going concern</span><span>${gc.answered ? `<b>${gc.yes}</b> of ${gc.answered}${gc.yes ? ' — ' + escapeHtml(gc.yes_companies.join(', ')) : ''}` : naSpan('Not reported yet')}</span></div>
      </div>
    </div>
    <div class="sa-stat-grid">
      ${saYesNoCard('👥', b.chair_ceo_separate, 'Chair and CEO Roles Separate')}
      ${saYesNoCard('⚖️', b.chair_independent, 'Independent Chairperson')}
      ${saYesNoCard('🧭', b.lead_independent_director, 'Lead / Senior Independent Director')}
      ${saYesNoCard('🔍', b.governance_audit_done, 'Governance Audit Carried Out')}
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Board Attendance</div>
        ${surveyMetricRow('Average board meeting attendance', b.board_attendance_pct, {decimals:1, suffix:'%'})}
        <div class="ir-kv-row"><span class="k">Directors with attendance on file</span><span>${da.directors ? `<b>${da.directors}</b> across ${da.companies} ${da.companies === 1 ? 'company' : 'companies'}` : naSpan('Not reported yet')}</span></div>
        ${da.directors ? `<div class="ir-kv-row"><span class="k">Attended every meeting</span><span><b>${da.full_attendance}</b> of ${da.directors} directors</span></div>
        <div class="ir-kv-row"><span class="k">Attended fewer than 75% of meetings</span><span><b>${da.below_75}</b> of ${da.directors} directors</span></div>` : ''}
        ${surveyMetricRow('Independent NEDs serving more than 9 years', b.independent_neds_over_9_years, {decimals:1})}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Governance Auditors</div>
        ${saShareBars(b.governance_auditors, 'var(--green)')}
      </div>
    </div>`;
}
function saWorkforceReturnsTab(ov){
  const e = ov.extended || {}; const p = e.executive_pay || {}; const w = e.workforce || {}; const h = e.shareholders || {};
  const cur = escapeHtml(ov.currency);
  return `
    ${saHeader('Pay, Workforce & Returns', `Key-management pay, people and shareholder returns across ${ov.companies_surveyed} surveyed companies`)}
    <div class="sa-stat-grid">
      ${saStatCard('💼', saExtAvg(p.kmp_total) !== null ? `${cur} ${saCount(p.kmp_total.average)}` : naSpan('Not enough companies yet'), 'Key Management Pay (total, per company)', saExtCount(p.kmp_total))}
      ${saStatCard('👥', saExtAvg(w.employees_count) !== null ? saCount(w.employees_count.average) : naSpan('Not enough companies yet'), 'Average Employees', saExtCount(w.employees_count))}
      ${saStatCard('💵', saExtAvg(w.staff_cost_per_employee) !== null ? `${cur} ${fmtAmount(Math.round(w.staff_cost_per_employee.average))}` : naSpan('Not enough companies yet'), 'Staff Cost per Employee', 'per year, ' + saExtCount(w.staff_cost_per_employee))}
      ${saStatCard('📈', saExtAvg(h.earnings_per_share) !== null ? `${cur} ${fmt(h.earnings_per_share.average, 2)}` : naSpan('Not enough companies yet'), 'Average Earnings per Share', saExtCount(h.earnings_per_share))}
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Key Management & Board Pay (${cur}, per company per year)</div>
        ${surveyMetricRow('Key management: total', p.kmp_total, saWhole)}
        ${surveyMetricRow('Salaries and short-term benefits', p.kmp_short_term_benefits, saWhole)}
        ${surveyMetricRow('Pension / post-employment', p.kmp_post_employment_benefits, saWhole)}
        ${surveyMetricRow('Share-based payments', p.kmp_share_based_payments, saWhole)}
        ${surveyMetricRow('Termination benefits', p.kmp_termination_benefits, saWhole)}
        ${surveyMetricRow("Total non-executive directors' fees", p.total_directors_fees, saWhole)}
        ${surveyMetricRow("Total executive directors' emoluments", p.total_executive_directors_emoluments, saWhole)}
        ${surveyMetricRow('CFO / finance director total pay', p.cfo_annual_total_pay, saWhole)}
        ${surveyMetricRow('Loans to directors (year end)', p.loans_to_directors, saWhole)}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Highest Non-Executive Directors' Fees (${cur})</div>
        ${saTopList(p.total_directors_fees, fmtAmount)}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Workforce</div>
        ${surveyMetricRow('Employees', w.employees_count, saWhole)}
        ${surveyMetricRow(`Staff costs (${ov.currency})`, w.staff_costs, saWhole)}
        ${surveyMetricRow(`Staff cost per employee (${ov.currency})`, w.staff_cost_per_employee, {fmtVal: v => fmtAmount(Math.round(v))})}
        ${surveyMetricRow('Staff costs as % of turnover', w.staff_costs_pct_of_turnover, {decimals:1, suffix:'%'})}
        ${surveyMetricRow('Women in the workforce', w.women_in_workforce_pct, {decimals:1, suffix:'%'})}
        ${surveyMetricRow('Women in senior management', w.women_in_senior_management_pct, {decimals:1, suffix:'%'})}
        ${surveyMetricRow('Staff turnover', w.staff_turnover_pct, {decimals:1, suffix:'%'})}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Largest Employers</div>
        ${saTopList(w.employees_count, saCount, ' staff')}
      </div>
    </div>
    <div class="row row-2">
      <div class="panel">
        <div class="sa-panel-title">Shareholders & Returns</div>
        ${surveyMetricRow(`Earnings per share (${ov.currency})`, h.earnings_per_share, {decimals:2})}
        ${surveyMetricRow(`Dividend per share (${ov.currency})`, h.dividend_per_share, {decimals:2})}
        ${surveyMetricRow('Dividend payout (dividend / earnings)', h.payout_ratio_pct, {decimals:1, suffix:'%'})}
        ${surveyMetricRow('Shareholders', h.shareholders_count, saWhole)}
        ${surveyMetricRow('Top 10 shareholders - combined holding', h.top10_shareholding_pct, {decimals:1, suffix:'%'})}
        ${surveyMetricRow('Free float', h.free_float_pct, {decimals:1, suffix:'%'})}
        ${surveyMetricRow('Directors - combined holding', h.directors_shareholding_pct, {decimals:1, suffix:'%'})}
      </div>
      <div class="panel">
        <div class="sa-panel-title">Most Concentrated Ownership (top 10 holders)</div>
        ${saTopList(h.top10_shareholding_pct, v => fmt(v, 1), '%')}
      </div>
    </div>`;
}

function saAppendixTab(ov){
  const defs = [
    ['NED', 'Non-Executive Director'],
    ['ED', 'Executive Director'],
    ['Chairperson', 'Chairman of the Board'],
    ['Retainer', 'Annual fee paid to directors for their service on the board.'],
    ['Board Meeting Allowance', 'Fee paid for attendance at board meetings.'],
    ['Committee Meeting Allowance', 'Fee paid for attendance at committee meetings.'],
    ['FY', 'Financial Year'],
    ['NSE', 'Nairobi Securities Exchange'],
    [escapeHtml(ov.currency), ov.currency === 'KES' ? 'Kenya Shillings' : 'Survey reporting currency'],
  ];
  const sectorRows = (ov.sector_comparison || []);
  return `
    ${saHeader('Appendix', 'Additional information, key definitions and the list of companies surveyed in this report.')}
    <div class="row row-3">
      <div class="panel">
        <div class="sa-panel-title">Key Definitions</div>
        <table class="sa-def-table"><tbody>
          ${defs.map(([k,v]) => `<tr><td>${escapeHtml(k)}</td><td>${escapeHtml(v)}</td></tr>`).join('')}
        </tbody></table>
      </div>
      <div class="panel">
        <div class="sa-panel-title">Sectors Covered in the Survey</div>
        <table><thead><tr><th>Sector / Industry</th><th>No. of Companies</th></tr></thead>
          <tbody>${sectorRows.map(s => `<tr><td>${escapeHtml(s.sector)}</td><td>${s.company_count}</td></tr>`).join('')}</tbody>
        </table>
      </div>
      <div class="panel">
        <div class="sa-panel-title">List of Companies Surveyed</div>
        <div style="max-height:280px;overflow-y:auto;">
          <table style="font-size:11.5px;"><thead><tr><th>Organisation</th><th>Sector</th></tr></thead>
            <tbody>${ov.companies.map(c => `<tr><td>${escapeHtml(c.name)}</td><td style="color:var(--text-faint);">${escapeHtml(c.sector || '-')}</td></tr>`).join('')}</tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="panel">
      <div class="sa-panel-title">Methodology</div>
      <div class="sa-methodology-strip">
        ${[
          ['1','Data Collection', `Extracted from company filings and annual reports for the ${escapeHtml(ov.fiscal_year)} reporting period.`],
          ['2','Data Analysis', 'Reviewed and analysed for remuneration trends and benchmarks.'],
          ['3','Currency', `All figures are in ${escapeHtml(ov.currency)}.`],
          ['4','Period Covered', escapeHtml(ov.fiscal_year)],
          ['5','Reporting', 'Findings computed live from every company on file for this fiscal year.'],
        ].map(([n,t,d]) => `<div class="sa-method-step"><div class="sa-method-num">${n}</div><div class="sa-method-title">${t}</div><div class="sa-method-desc">${d}</div></div>`).join('')}
      </div>
    </div>
    <div class="panel">
      <div class="sa-panel-title">Key Survey Highlights</div>
      <div class="row row-3">
        ${saMiniStat(ov.companies_surveyed, 'Companies surveyed (NSE listed)')}
        ${saMiniStat(saMetricAvg(ov.board_overview.avg_board_size), 'Average board size (Directors)')}
        ${saMiniStat(saMetricAvg(ov.board_overview.avg_board_meetings_per_year), 'Average board meetings (per year)')}
        ${saMiniStat(saAppendixFemalePct(ov.board_overview), 'Female representation (Board level)')}
        ${saMiniStat(ov.directors_remuneration.chairperson_vs_other_ned_annual_retainer_ratio !== null ? ov.directors_remuneration.chairperson_vs_other_ned_annual_retainer_ratio + 'x' : null, 'Chairperson vs other NED retainer premium')}
        ${saMiniStat(saAppendixHighestPayingSector(sectorRows), 'Highest paying sector (Avg. NED retainer)')}
      </div>
    </div>`;
}
function saAppendixFemalePct(bo){
  const f = bo.total_directors_female, m = bo.total_directors_male;
  if (f === null || m === null || (f + m) === 0) return null;
  return Math.round(f / (f + m) * 100) + '%';
}
function saAppendixHighestPayingSector(sectorRows){
  const withRetainer = sectorRows.filter(s => s.avg_other_ned_annual_retainer !== null);
  if (!withRetainer.length) return null;
  const top = withRetainer.reduce((a,b) => a.avg_other_ned_annual_retainer > b.avg_other_ned_annual_retainer ? a : b);
  return fmtAmount(top.avg_other_ned_annual_retainer) + ' (' + escapeHtml(top.sector) + ')';
}

// ---------- Shared survey helpers (kept from the removed old flat Survey page) ----------
// surveyMetricRow: one avg + 25th/50th/75th percentile row, used by the Survey Analytics
// Executive Directors tab's CEO/MD panel. surveyDetailRow/fmtSurveyAmount: label/value rows
// used by the Directors' Register detail panel. surveyDirectorFiguresUnit: the unit label
// for director/committee/CEO pay figures on the Survey Report Remuneration tab.

function surveyMetricRow(label, metric, opts){
  opts = opts || {};
  if (opts.amount) { const _a = fmtAmount; opts = Object.assign({}, opts, {fmtVal: v => _a(v)}); }
  const decimals = opts.decimals !== undefined ? opts.decimals : 1;
  const suffix = opts.suffix || '';
  const prefix = opts.prefix || '';
  if (!metric || metric.average === null || metric.average === undefined) {
    const countNote = metric && metric.company_count ? ` (${metric.company_count} of 2+ needed)` : '';
    return `<div class="ir-kv-row"><span class="k">${escapeHtml(label)}</span>${naSpan('Not enough companies have supplied this figure yet' + countNote)}</div>`;
  }
  const hasPercentiles = metric.p25 !== undefined && metric.p25 !== null;
  const percentileNote = hasPercentiles
    ? `<div style="font-size:11px;color:var(--text-dim);margin-top:1px;">25th: ${prefix}${(opts.fmtVal || (v => fmt(v, decimals)))(metric.p25)}${suffix} &nbsp;·&nbsp; 50th: ${prefix}${(opts.fmtVal || (v => fmt(v, decimals)))(metric.p50)}${suffix} &nbsp;·&nbsp; 75th: ${prefix}${(opts.fmtVal || (v => fmt(v, decimals)))(metric.p75)}${suffix}</div>`
    : '';
  return `<div class="ir-kv-row" style="flex-direction:column;align-items:flex-start;">
    <div style="display:flex;justify-content:space-between;width:100%;">
      <span class="k">${escapeHtml(label)}</span>
      <span style="font-weight:700;">${prefix}${(opts.fmtVal || (v => fmt(v, decimals)))(metric.average)}${suffix}</span>
    </div>
    ${percentileNote}
  </div>`;
}

function surveyDetailRow(label, value, opts){
  opts = opts || {};
  if (value === null || value === undefined) {
    return `<div class="ir-kv-row"><span class="k">${escapeHtml(label)}</span>${naSpan('Not captured in this company\'s submitted data')}</div>`;
  }
  const formatted = opts.isAmount ? fmtSurveyAmount(value, opts.amountDecimals) : (typeof value === 'number' ? fmt(value, opts.decimals !== undefined ? opts.decimals : 0) : escapeHtml(String(value)));
  const prefix = opts.prefix || '';
  const suffix = opts.suffix || '';
  return `<div class="ir-kv-row"><span class="k">${escapeHtml(label)}</span><span style="font-weight:700;">${prefix}${formatted}${suffix}</span></div>`;
}

// Same rounding/thousands-separator behaviour as fmtAmount(), but lets
// callers ask for decimal places - fmtAmount() itself
// always rounds to 0 decimals, which is correct for the KES thousands/
// millions figures used everywhere else in the app but silently drops
// real precision on a billions-scale figure (e.g. KCB's turnover of
// 211.8 rendering as "212"). Only callers that pass isAmount to surveyDetailRow use this; every other
// fmtAmount() call site is untouched.
function fmtSurveyAmount(val, decimals){
  return fmtFull(val, 'units');
}

// Director/committee/CEO pay and benefit figures can genuinely be at
// a DIFFERENT scale than the company's headline turnover/profit unit
// (confirmed on a real filing: KCB Group Plc states turnover in
// billions but its director remuneration tables in thousands - see
// SurveyCompanyData.director_figures_unit in models_survey.py). Every
// tab showing that kind of figure (Directors' Remuneration, Committee
// Remuneration, CEO/MD Remuneration, Benefits) should call this
// instead of reading sd.unit directly; the Company Overview tab's
// turnover/net profit/market cap keep reading sd.unit as before,
// since those are the headline figures director_figures_unit is
// explicitly NOT for.
function surveyDirectorFiguresUnit(sd){
  // A missing director_figures_unit means the pay figures were stored as raw currency
  // (app.py's to_pay_unit defaults to 1.0 the same way) - NOT that they share the
  // headline unit, so never fall back to sd.unit here.
  return sd.director_figures_unit || 'units';
}

// ---------- Survey Mapping tab (shared by Company Survey Data's
// Survey Mapping and Data Quality tabs, via renderMappingTab below) ----------
// A meta-view of the EXTRACTION itself, not company data: for each
// field this app tracks on SurveyCompanyData, shows what value (if
// any) is on file, which source document/page it came from, how
// confident the extractor was, and whether a person has reviewed it -
// then lets that person approve/reject/correct it, using the real
// review workflow already built into /api/survey-data/<id>/<fy>/review
// (see that route's own docstring in app.py). This is intentionally
// NOT a fabricated document-processing-status view - every number
// shown here (mapped/unmapped/partial counts, confidence bands) is
// computed live from field_confidence/field_review_status/the field's
// own current value, never a separate invented tracking table.

// Every SurveyCompanyData field this view covers, with a human label
// and which drill-down tab it "belongs" to (the mockup's Section
// column). This is the single source of truth for "which fields
// count" on both the Survey Mapping and Data Quality tabs (both call
// renderMappingTab, which reads this list) - there is no equivalent
// Python-side list to keep in sync with; adding a new SurveyCompanyData
// column means adding it here too, or it silently never appears on
// either tab (this is exactly how ceo_annual_salary_as_stated and
// ceo_monthly_conversion_basis went missing until the 2026-09-26 fix
// below added them).
const MAPPING_FIELDS = [
  {field: 'turnover', label: 'Turnover', section: 'Company Overview'},
  {field: 'net_profit', label: 'Net Profit', section: 'Company Overview'},
  {field: 'market_cap', label: 'Market Cap', section: 'Company Overview'},
  {field: 'board_size', label: 'Board Size', section: 'Board Composition'},
  {field: 'board_meetings_per_year', label: 'Board Meetings / Year', section: 'Board Composition'},
  {field: 'committees_per_board', label: 'Committees / Board', section: 'Board Composition'},
  {field: 'committee_meetings_per_year', label: 'Committee Meetings / Year', section: 'Board Composition'},
  {field: 'directors_female', label: 'Female Directors', section: 'Board Composition'},
  {field: 'directors_male', label: 'Male Directors', section: 'Board Composition'},
  {field: 'executive_directors_count', label: 'Executive Directors', section: 'Board Composition'},
  {field: 'non_executive_directors_count', label: 'Non-Executive Directors', section: 'Board Composition'},
  {field: 'independent_neds_count', label: 'Independent NEDs', section: 'Board Composition'},
  {field: 'non_independent_neds_count', label: 'Non-Independent NEDs', section: 'Board Composition'},
  {field: 'neds_kenyan_count', label: 'NEDs — Kenyan', section: 'Board Composition'},
  {field: 'neds_non_kenyan_count', label: 'NEDs — Non-Kenyan', section: 'Board Composition'},
  {field: 'avg_age_executive_directors', label: 'Avg. Age — Executive Directors', section: 'Board Composition'},
  {field: 'avg_age_non_executive_directors', label: 'Avg. Age — Non-Executive Directors', section: 'Board Composition'},
  {field: 'avg_age_independent_neds', label: 'Avg. Age — Independent NEDs', section: 'Board Composition'},
  {field: 'avg_age_non_independent_neds', label: 'Avg. Age — Non-Independent NEDs', section: 'Board Composition'},
  {field: 'chairperson_annual_retainer', label: 'Chairperson Annual Retainer', section: "Directors' Remuneration"},
  {field: 'other_ned_annual_retainer', label: 'Other NED Annual Retainer', section: "Directors' Remuneration"},
  {field: 'chairperson_meeting_allowance', label: 'Chairperson Meeting Allowance', section: "Directors' Remuneration"},
  {field: 'other_ned_meeting_allowance', label: 'Other NED Meeting Allowance', section: "Directors' Remuneration"},
  {field: 'executive_director_annual_retainer', label: 'Executive Director Annual Retainer', section: "Directors' Remuneration"},
  {field: 'executive_director_meeting_allowance', label: 'Executive Director Meeting Allowance', section: "Directors' Remuneration"},
  {field: 'committee_chair_annual_retainer', label: 'Committee Chair Annual Retainer', section: 'Committee Remuneration'},
  {field: 'committee_member_annual_retainer', label: 'Committee Member Annual Retainer', section: 'Committee Remuneration'},
  {field: 'committee_chair_meeting_allowance', label: 'Committee Chair Meeting Allowance', section: 'Committee Remuneration'},
  {field: 'committee_member_meeting_allowance', label: 'Committee Member Meeting Allowance', section: 'Committee Remuneration'},
  {field: 'ceo_monthly_salary', label: 'CEO Monthly Salary', section: 'CEO/MD Remuneration'},
  {field: 'ceo_monthly_allowances', label: 'CEO Monthly Allowances', section: 'CEO/MD Remuneration'},
  {field: 'ceo_monthly_incentive_bonus', label: 'CEO Monthly Incentive/Bonus', section: 'CEO/MD Remuneration'},
  {field: 'ceo_monthly_deferred_incentive', label: 'CEO Monthly Deferred Incentive', section: 'CEO/MD Remuneration'},
  {field: 'ceo_monthly_non_cash_benefits', label: 'CEO Monthly Non-Cash Benefits', section: 'CEO/MD Remuneration'},
  {field: 'ceo_monthly_pension', label: 'CEO Monthly Pension', section: 'CEO/MD Remuneration'},
  {field: 'ceo_monthly_gratuity', label: 'CEO Monthly Gratuity', section: 'CEO/MD Remuneration'},
  {field: 'ceo_monthly_share_value', label: 'CEO Monthly Share Value', section: 'CEO/MD Remuneration'},
  {field: 'ceo_monthly_cost_of_employment', label: 'CEO Total Cost of Employment', section: 'CEO/MD Remuneration'},
  {field: 'ceo_annual_salary_as_stated', label: 'CEO Annual Salary (as stated)', section: 'CEO/MD Remuneration'},
  {field: 'ceo_monthly_conversion_basis', label: 'CEO Monthly Conversion Basis', section: 'CEO/MD Remuneration'},
];

const MAPPING_HIGH_CONFIDENCE_THRESHOLD = 0.75;

// Money fields are stored in a scaled unit (e.g. 211.8 billions); the Mapping/Data Quality
// value column writes them out in full. Headline figures use the company's own unit, pay
// figures use its pay-table unit. Counts, ages and text are shown untouched.
const MAPPING_HEADLINE_AMOUNT_FIELDS = new Set(['turnover', 'net_profit', 'market_cap']);
function mappingIsPayAmountField(field){
  return /(retainer|allowance)/.test(field) || (/^ceo_monthly_/.test(field) && field !== 'ceo_monthly_conversion_basis') || field === 'ceo_annual_salary_as_stated';
}
function mappingDisplayValue(sd, field){
  const v = sd[field];
  if (v === null || v === undefined || typeof v !== 'number') return v;
  if (MAPPING_HEADLINE_AMOUNT_FIELDS.has(field)) return fmtFull(v, sd.unit);
  if (mappingIsPayAmountField(field)) return fmtFull(v, surveyDirectorFiguresUnit(sd));
  return v;
}

function mappingFieldStatus(sd, field){
  const value = sd[field];
  const conf = (sd.field_confidence || {})[field];
  const reviewStatus = (sd.field_review_status || {})[field];
  if (value === null || value === undefined) return 'unmapped';
  if (reviewStatus === 'approved') return 'mapped';   // explicitly reviewed and approved/corrected - trust it regardless of the original confidence band
  if (typeof conf === 'number' && conf < MAPPING_HIGH_CONFIDENCE_THRESHOLD) return 'partial';
  return 'mapped';   // has a value, and either no confidence score at all (hand-typed - typing WAS the review) or high confidence
}

// Shared mapping-tab renderer, used by Company Survey Data's Survey
// Mapping tab (srSurveyMappingTab). Was originally duplicated between
// two pages (Survey Companies and Company Survey Data) with the
// Company Survey Data version much thinner; factored into one shared
// implementation (2026-09-14), and the Survey Companies page itself
// was later removed as a full duplicate of Company Survey Data
// (2026-09-14) - this function's the one surviving piece of it.
function renderMappingTab(sd, opts){
  const {statusFilter, sectionFilter, search, onSetStatusFilter, onSetSectionFilter, onSetSearch, onApprove, onCorrect} = opts;
  const rows = MAPPING_FIELDS.map(m => ({
    ...m,
    value: sd[m.field],
    display: mappingDisplayValue(sd, m.field),
    confidence: (sd.field_confidence || {})[m.field],
    source: (sd.field_sources || {})[m.field],
    status: mappingFieldStatus(sd, m.field),
  }));

  const mappedCount = rows.filter(r => r.status === 'mapped').length;
  const partialCount = rows.filter(r => r.status === 'partial').length;
  const unmappedCount = rows.filter(r => r.status === 'unmapped').length;
  const total = rows.length;

  const highConf = rows.filter(r => typeof r.confidence === 'number' && r.confidence >= MAPPING_HIGH_CONFIDENCE_THRESHOLD).length;
  const medConf = rows.filter(r => typeof r.confidence === 'number' && r.confidence >= 0.45 && r.confidence < MAPPING_HIGH_CONFIDENCE_THRESHOLD).length;
  const lowConf = rows.filter(r => typeof r.confidence === 'number' && r.confidence < 0.45).length;
  const scoredCount = highConf + medConf + lowConf;
  const avgConf = scoredCount ? rows.filter(r => typeof r.confidence === 'number').reduce((s, r) => s + r.confidence, 0) / scoredCount : null;

  const sections = [...new Set(MAPPING_FIELDS.map(m => m.section))];

  let filtered = rows;
  if (statusFilter !== 'all') filtered = filtered.filter(r => r.status === statusFilter);
  if (sectionFilter !== 'all') filtered = filtered.filter(r => r.section === sectionFilter);
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    filtered = filtered.filter(r => r.label.toLowerCase().includes(q) || (r.source || '').toLowerCase().includes(q) || String(r.value ?? '').toLowerCase().includes(q));
  }

  const statusBadge = (status) => status === 'mapped'
    ? `<span style="color:var(--green);font-weight:700;">Mapped</span>`
    : status === 'partial'
    ? `<span style="color:var(--amber,#b45309);font-weight:700;">Partially Mapped</span>`
    : `<span style="color:var(--red,#dc2626);font-weight:700;">Unmapped</span>`;

  const tableRows = filtered.map(r => {
    const confBadge = typeof r.confidence === 'number' ? `${Math.round(r.confidence * 100)}%` : naSpan('—');
    const hasConfidence = typeof r.confidence === 'number';
    return `
      <tr>
        <td>${escapeHtml(r.label)}</td>
        <td style="color:var(--text-faint);font-size:11.5px;">${escapeHtml(r.section)}</td>
        <td>${r.value !== null && r.value !== undefined ? escapeHtml(String(r.display)) : naSpan('—')}</td>
        <td style="font-size:11.5px;">${r.source ? escapeHtml(r.source) : naSpan('—')}</td>
        <td>${confBadge}</td>
        <td>${statusBadge(r.status)}</td>
        <td>
          ${hasConfidence && r.status !== 'mapped' ? `<button data-perm="admin" onclick="${onApprove}('${r.field}')" style="font-size:11px;padding:3px 8px;margin-right:4px;">Approve</button>` : ''}
          ${hasConfidence ? `<button data-perm="admin" onclick="${onCorrect}('${r.field}', ${JSON.stringify(String(r.value ?? '')).replace(/"/g, '&quot;')})" style="font-size:11px;padding:3px 8px;">Edit</button>` : ''}
        </td>
      </tr>`;
  }).join('');

  return `
    <div class="row row-2">
      <div>
        <div class="panel" style="margin-bottom:16px;">
          <div style="display:flex;gap:8px;align-items:center;margin-bottom:12px;flex-wrap:wrap;">
            <input type="text" placeholder="Search fields, values, or source..." value="${escapeHtml(search)}"
              oninput="${onSetSearch}(this.value)" style="flex:1;min-width:200px;padding:6px 10px;font-size:12.5px;">
            <select onchange="${onSetSectionFilter}(this.value)">
              <option value="all">All Sections</option>
              ${sections.map(s => `<option value="${escapeHtml(s)}" ${sectionFilter===s?'selected':''}>${escapeHtml(s)}</option>`).join('')}
            </select>
          </div>
          <div style="display:flex;gap:4px;border-bottom:1px solid var(--border);margin-bottom:12px;">
            <button onclick="${onSetStatusFilter}('all')" style="background:none;border:none;padding:8px 10px;font-size:12px;cursor:pointer;font-weight:${statusFilter==='all'?'700':'500'};border-bottom:2px solid ${statusFilter==='all'?'var(--accent,#047857)':'transparent'};">Mapped Fields (${mappedCount})</button>
            <button onclick="${onSetStatusFilter}('unmapped')" style="background:none;border:none;padding:8px 10px;font-size:12px;cursor:pointer;font-weight:${statusFilter==='unmapped'?'700':'500'};border-bottom:2px solid ${statusFilter==='unmapped'?'var(--accent,#047857)':'transparent'};">Unmapped Fields (${unmappedCount})</button>
            <button onclick="${onSetStatusFilter}('partial')" style="background:none;border:none;padding:8px 10px;font-size:12px;cursor:pointer;font-weight:${statusFilter==='partial'?'700':'500'};border-bottom:2px solid ${statusFilter==='partial'?'var(--accent,#047857)':'transparent'};">Partially Mapped (${partialCount})</button>
          </div>
          <table>
            <thead><tr><th>Survey Field</th><th>Section</th><th>Value</th><th>Source</th><th>Confidence</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>${tableRows.length ? tableRows : `<tr><td colspan="7"><div class="empty">No fields match this filter.</div></td></tr>`}</tbody>
          </table>
        </div>
      </div>
      <div>
        <div class="panel" style="margin-bottom:16px;text-align:center;">
          <div class="ir-panel-title" style="text-align:left;">Mapping Summary</div>
          <div style="font-size:32px;font-weight:800;margin:8px 0 4px;">${total}</div>
          <div style="font-size:11.5px;color:var(--text-faint);margin-bottom:12px;">Total Fields</div>
          <div style="text-align:left;font-size:12px;">
            <div style="display:flex;justify-content:space-between;padding:4px 0;"><span style="color:var(--green);">● Mapped</span><span>${mappedCount} (${total ? Math.round(mappedCount/total*100) : 0}%)</span></div>
            <div style="display:flex;justify-content:space-between;padding:4px 0;"><span style="color:var(--amber,#b45309);">● Partially Mapped</span><span>${partialCount} (${total ? Math.round(partialCount/total*100) : 0}%)</span></div>
            <div style="display:flex;justify-content:space-between;padding:4px 0;"><span style="color:var(--red,#dc2626);">● Unmapped</span><span>${unmappedCount} (${total ? Math.round(unmappedCount/total*100) : 0}%)</span></div>
          </div>
        </div>
        <div class="panel" style="margin-bottom:16px;">
          <div class="ir-panel-title">Confidence Level</div>
          ${scoredCount ? `
            <div style="font-size:11.5px;margin:8px 0 4px;">High (≥75%) — ${highConf} (${Math.round(highConf/scoredCount*100)}%)</div>
            <div style="background:var(--panel-alt,#f1f9f5);border-radius:6px;height:6px;margin-bottom:8px;"><div style="background:var(--green);width:${Math.round(highConf/scoredCount*100)}%;height:6px;border-radius:6px;"></div></div>
            <div style="font-size:11.5px;margin:8px 0 4px;">Medium (45–74%) — ${medConf} (${Math.round(medConf/scoredCount*100)}%)</div>
            <div style="background:var(--panel-alt,#f1f9f5);border-radius:6px;height:6px;margin-bottom:8px;"><div style="background:var(--amber,#b45309);width:${Math.round(medConf/scoredCount*100)}%;height:6px;border-radius:6px;"></div></div>
            <div style="font-size:11.5px;margin:8px 0 4px;">Low (&lt;45%) — ${lowConf} (${Math.round(lowConf/scoredCount*100)}%)</div>
            <div style="background:var(--panel-alt,#f1f9f5);border-radius:6px;height:6px;">${lowConf ? `<div style="background:var(--red,#dc2626);width:${Math.round(lowConf/scoredCount*100)}%;height:6px;border-radius:6px;"></div>` : ''}</div>
          ` : `<div class="empty">No fields on this company have an extraction confidence score - either every value was hand-typed, or none have been extracted yet.</div>`}
        </div>
        <div class="panel">
          <div class="ir-panel-title">Key Insights</div>
          <ul style="margin:0;padding-left:18px;font-size:12.5px;line-height:1.7;">
            <li>${total ? Math.round(mappedCount/total*100) : 0}% of survey fields are mapped for this company.</li>
            ${partialCount ? `<li>${partialCount} field(s) are partially mapped and need review.</li>` : ''}
            ${unmappedCount ? `<li>${unmappedCount} field(s) have no value on file - either not disclosed in the filing, or not yet extracted/entered.</li>` : ''}
            ${avgConf !== null ? `<li>Average confidence across scored fields is ${Math.round(avgConf * 100)}%.</li>` : ''}
          </ul>
        </div>
      </div>
    </div>`;
}

// ---------- Settings ----------


// ---------------------------------------------------------------------------
// Settings > AI  and  Settings > Review (Uploads | AI results | Conflicts | Manual entry | Issues)
// The AI is the last resort and is never called until "Run" is clicked; nothing from an upload reaches the
// Survey Report until it is approved; anything neither the rules nor the AI could read can be typed in.
// ---------------------------------------------------------------------------
const aiPill = i => ({pending:'⏳ waiting for AI', submitted:'📤 sent', done:'✅ ready to review', applied:'✔ applied', failed:'❌ failed', discarded:'🗑 discarded', skipped:'⏭ rules filled it - not sent'}[i.status] || i.status);
function openReview(sub){
  // "manual" used to be a Review sub-tab - it is now its own top-level
  // Manual Entry page, so route there instead of into Review's own tabbar.
  if (sub === 'manual') { currentPage = 'manual-entry'; renderNav(); render(); return; }
  currentPage = 'review'; reviewSub = sub || 'uploads'; renderNav(); render();
}

async function dhSchemaCheck(){
  const out = document.getElementById('dataHealthOut'); out.innerHTML = '<span class="bl-faint">Checking the live database…</span>';
  const d = await fetch('/api/system/schema-check').then(r => r.json());
  if (d.ok) { out.innerHTML = `<span class="bl-ok">${blIcon('check')}</span> <b>Schema complete</b> <span class="bl-faint">(${escapeHtml(d.engine)})</span> - every column the app uses exists.`; return; }
  out.innerHTML = `<div class="bl-warn"><b>${d.gaps.length} missing column(s) or table(s) in the live database:</b></div>
    <ul>${d.gaps.map(g => `<li><code>${escapeHtml(g.table)}${g.column ? '.' + escapeHtml(g.column) : ''}</code> ${g.missing_table ? '(table missing)' : escapeHtml(g.type || '')}</li>`).join('')}</ul>
    <button onclick="dhSchemaFix()">Add the missing columns (additive only)</button>`;
}
async function dhSchemaFix(){
  const d = await fetch('/api/system/schema-fix', {method:'POST'}).then(r => r.json());
  document.getElementById('dataHealthOut').innerHTML = `<span class="${d.failed.length ? 'bl-warn' : 'bl-ok'}"><b>Added ${d.fixed.length} column(s).</b></span>${d.failed.length ? ' Failed: ' + escapeHtml(JSON.stringify(d.failed)) : ''} Now re-upload or press "Rebuild tabs".`;
}
async function dhReconcileAll(){
  const out = document.getElementById('dataHealthOut'); out.innerHTML = '<span class="bl-faint">Rebuilding tabs for every company…</span>';
  const d = await fetch('/api/tabs/reconcile-all', {method:'POST'}).then(r => r.json());
  out.innerHTML = `<span class="bl-ok">${blIcon('check')}</span> <b>Checked ${stNum(d.companies)} company-year(s).</b> Added ${stNum(d.register_added)} director(s) to registers, enriched ${stNum(d.register_enriched)}, filled ${stNum(d.fields)} board-composition field(s).`;
}

function aiJobPill(st){
  const tone = {ended:'green', completed:'green', done:'green', failed:'red', errored:'red', canceled:'faint', cancelled:'faint'}[st] || 'amber';
  const label = {ended:'Finished', in_progress:'In progress', submitted:'Sent', canceling:'Cancelling'}[st] || String(st || 'unknown').replace(/_/g, ' ').replace(/^./, ch => ch.toUpperCase());
  return `<span class="bl-pill bl-${tone}">${escapeHtml(label)}</span>`;
}
async function renderAITab(body){
  body.innerHTML = `<div class="st-console"><div class="bl-loading"><span></span><span></span><span></span></div></div>`;
  const [st, items] = await Promise.all([fetch('/api/ai/status').then(r => r.json()), fetch('/api/ai/items').then(r => r.json())]);
  const c = st.items || {};
  const pending = items.filter(i => i.status === 'pending' || i.status === 'failed');
  const failed = items.filter(i => i.status === 'failed').length;
  const jobsList = st.jobs || [];
  const cost = j => (j.actual_cost_usd != null ? j.actual_cost_usd : (j.est_cost_usd || 0));
  const spent = jobsList.reduce((a, j) => a + (j.actual_cost_usd || 0), 0);
  const canRun = st.configured && pending.length;
  const setup = st.configured
    ? `<div class="bl-banner bl-banner-blue" style="background:var(--green-soft);"><span><span class="bl-ok">${blIcon('check')}</span> <b>API key configured</b> <span class="bl-faint">· model ${escapeHtml(st.model || '')}</span></span></div>`
    : `<div class="panel bl-setup-card"><div class="ai-setup">
        <span class="bl-stat-icon bl-amber" style="width:40px;height:40px;">${blIcon('key')}</span>
        <div style="flex:1;min-width:240px;">
          <div class="bl-card-title">Connect your Anthropic API key</div>
          <div class="st-sub" style="color:var(--text-dim);">Add <code>ANTHROPIC_API_KEY</code> to the project secrets (Replit › Tools › Secrets), then restart the app. Until then nothing is sent, but you can still press Estimate to see what would be.</div>
        </div></div></div>`;
  const jobs = jobsList.map(j => `<tr>
      <td><span class="bl-strong bl-mono">#${j.id}</span><span class="bl-tag">${escapeHtml(j.mode === 'batch' ? 'Batch' : j.mode === 'direct' ? 'Direct' : (j.mode || ''))}</span></td>
      <td class="bl-faint">${escapeHtml(j.model || '-')}</td>
      <td class="num bl-mono">${stNum(j.n_items)}</td>
      <td>${aiJobPill(j.status)}</td>
      <td class="num bl-mono">$${cost(j).toFixed(3)}${j.actual_cost_usd != null ? '' : ' <span class="bl-faint">est.</span>'}</td>
      <td class="bl-actions">${j.mode === 'batch' && j.status !== 'ended' ? `<button class="secondary sm" onclick="aiCollect(${j.id})">${blIcon('refresh')} Check / collect</button>` : ''}</td></tr>`).join('');
  body.innerHTML = `<div class="st-console">
    <div class="st-intro"><div class="st-sub"><b style="color:var(--text);">The AI is the last resort.</b> Rule-based readers run first at upload and tabs are filled from each other; only fields that are still empty are sent to the AI.</div>
      <button class="secondary" style="display:inline-flex;align-items:center;gap:6px;margin:0;" onclick="openReview('ai-results')">${blIcon('inbox')}Review AI results${c.done ? ` <span class="bl-pill bl-amber">${c.done}</span>` : ''}</button></div>
    ${setup}
    <div class="bl-stats">
      ${stStat('clock', 'amber', 'Waiting to send', stNum(pending.length), failed ? `${failed} failed earlier, will be retried` : 'Empty fields queued for the AI')}
      ${stStat('inbox', 'blue', 'Ready to review', stNum(c.done || 0), 'Answers awaiting your check')}
      ${stStat('check', 'green', 'Applied', stNum(c.applied || 0), 'Written into the survey tables')}
      ${stStat('wallet', 'red', 'Spent so far', '$' + spent.toFixed(2), `${jobsList.length} run${jobsList.length === 1 ? '' : 's'} in total`)}
    </div>
    <div class="panel">
      <div class="bl-card-head"><div><div class="bl-card-title">Run AI extraction</div><div class="st-sub">Estimate first - nothing is sent until you press Run.</div></div></div>
      <div class="ai-run">
        <div class="ai-modes">
          <div class="ai-mode"><span class="bl-stat-icon bl-green">${blIcon('clock')}</span><div><b>Batch <span class="bl-pill bl-green" style="margin-left:4px;">Half price</span></b><span class="bl-faint">Sends every waiting item. Results come back within about an hour - press "Check / collect" on the job below.</span></div></div>
          <div class="ai-mode"><span class="bl-stat-icon bl-blue">${blIcon('spark')}</span><div><b>Direct</b><span class="bl-faint">Runs the first 6 items straight away at full price. Useful for a quick test.</span></div></div>
          <ol class="ai-steps" style="margin-top:4px;">
            <li><span>1</span><span>Press <b>Estimate</b> to see the tokens and cost.</span></li>
            <li><span>2</span><span>Set a <b>spend cap</b>; a run that would cost more is refused.</span></li>
            <li><span>3</span><span>Check the answers in <a href="#" onclick="openReview('ai-results');return false;">Review › AI results</a> before they are applied.</span></li>
          </ol>
        </div>
        <div>
          <div class="bl-faint" style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.03em;margin-bottom:6px;">Cost estimate</div>
          <div id="aiEstimate" class="ai-est">${pending.length ? `${stNum(pending.length)} item(s) waiting. Press Estimate to see the cost before anything is sent.` : 'Nothing is waiting - every field the rules could not read has already been sent or filled.'}</div>
          <div class="ai-controls">
            <button class="secondary" onclick="aiEstimate()">${blIcon('search')}Estimate</button>
            <label class="ai-cap">Spend cap <span style="display:flex;align-items:center;gap:4px;">$<input id="aiCap" class="bl-input" type="number" step="0.5" min="0" value="5"></span></label>
          </div>
          <div class="ai-controls">
            <button onclick="aiRun('batch')" ${canRun ? '' : 'disabled'}>${blIcon('clock')}Run batch</button>
            <button class="secondary" onclick="aiRun('direct')" ${canRun ? '' : 'disabled'}>${blIcon('spark')}Run now (6 max)</button>
          </div>
          ${!canRun ? `<div class="ai-note">${!st.configured ? 'Running is switched off until the API key is added.' : 'Running is switched off because nothing is waiting.'}</div>` : ''}
        </div>
      </div>
    </div>
    <div class="panel bl-flush">
      <div class="bl-card-head padded"><div class="bl-card-title">Jobs and cost</div><span class="bl-faint">${jobsList.length} run${jobsList.length === 1 ? '' : 's'}</span></div>
      ${jobs ? `<div class="bl-table-wrap"><table class="bl-table"><thead><tr><th>Job</th><th>Model</th><th class="num">Items</th><th>Status</th><th class="num">Cost (USD)</th><th></th></tr></thead><tbody>${jobs}</tbody></table></div>`
        : blEmpty('spark', 'No AI runs yet', 'When you run an extraction, each batch or direct run is listed here with its cost.')}
    </div></div>`;
}

let reviewSub = 'uploads';
// "Manual entry" moved out to its own top-level nav page (see PAGES /
// renderManualEntryPage above) and is no longer one of Review's own tabs.
const REVIEW_SUBS = [{id:'approvals', label:'Approvals', k:'ap'}, {id:'uploads', label:'Uploads', k:'up'}, {id:'ai-results', label:'AI results', k:'ai'}, {id:'conflicts', label:'Conflicts', k:'cf'},
                     {id:'issues', label:'Issues', k:'is'}];
async function renderReviewTab(body){
  clearTimeout(reviewPollTimer);
  const [sum, approvals] = await Promise.all([fetch('/api/review/summary').then(r=>r.json()).catch(()=>({})),fetch('/api/approvals/count').then(r=>r.json()).catch(()=>({}))]);
  const apCount = approvals.pending || 0;
  const count = {ap: apCount, up: (sum.uploads_ready || 0) + (sum.uploads_processing || 0), ai: sum.ai_ready || 0, cf: sum.conflicts_open || 0, is: sum.issues_open || 0};
  if (currentPage !== 'review') return;
  rpHeaderSelect('section','Review section',REVIEW_SUBS.map(t=>({id:t.id,label:t.label+(count[t.k]?' ('+count[t.k]+')':'')})),reviewSub,v=>{reviewSub=v;renderReviewTab(body);});
  body.innerHTML = `
    <div id="reviewBody" style="margin-top:12px"></div>`;
  const box = document.getElementById('reviewBody');
  if (reviewSub === 'approvals') await renderReviewApprovals(box);
  else if (reviewSub === 'uploads') await renderReviewUploads(box);
  else if (reviewSub === 'ai-results') await renderReviewAIResults(box);
  else if (reviewSub === 'conflicts') await renderReviewConflicts(box);
  else await renderReviewIssues(box);
}
// Re-renders whichever of the three pages (AI / Review / Manual Entry) is
// currently on screen - callers like aiRun()/aiApplyItem() run from the AI
// page as often as from Review, so this can't just always jump to Review.
async function reviewRefresh(){
  if (currentPage === 'ai') await renderAIPage();
  else if (currentPage === 'manual-entry') await renderManualEntryPage();
  else await renderReviewPage();
}

// ---- Approvals: uploads / manual entries from non-super admins wait here for a super admin
async function renderReviewApprovals(box){
  const d = await fetch('/api/approvals').then(r => r.json()).catch(() => ({items: []}));
  const sup = !!d.is_super_admin, items = d.items || [];
  const pill = i => ({pending:'Waiting for approval', approved:'Approved', rejected:'Rejected', failed:'Failed when applied'}[i.status] || i.status);
  const rows = items.map(i => `<tr>
      <td>${escapeHtml(i.summary || '-')}${i.file_count ? `<div class="muted">${i.file_count} file(s)</div>` : ''}</td>
      <td>${escapeHtml(i.submitted_by || '-')}<div class="muted">${escapeHtml(i.submitted_by_email || '')}</div></td>
      <td>${i.created_at ? new Date(i.created_at).toLocaleString() : '-'}</td>
      <td>${pill(i)}${i.decided_by ? `<div class="muted">by ${escapeHtml(i.decided_by)}</div>` : ''}${i.status === 'failed' && i.result ? `<div class="muted">${escapeHtml(i.result.slice(0, 160))}</div>` : ''}</td>
      <td>${sup && (i.status === 'pending' || i.status === 'failed') ? `${i.status === 'pending' ? `<button class="btn primary" onclick="approvalDecide(${i.id}, 'approve', this)">Approve</button> ` : ''}<button class="btn danger" onclick="approvalDecide(${i.id}, 'reject', this)">Reject</button>` : ''}</td></tr>`).join('');
  box.innerHTML = `<div class="panel">
    <p class="muted">${sup ? 'You are a super admin. Reports and manual entries sent by other admins wait here - nothing is saved until you approve it.' : 'Only a super admin can add reports directly. What you upload or type in is listed here and is saved once a super admin approves it.'}</p>
    <table class="tbl" style="margin-top:10px"><thead><tr><th>Request</th><th>Sent by</th><th>Sent</th><th>Status</th><th></th></tr></thead>
    <tbody>${rows || '<tr><td colspan="5" class="muted">Nothing waiting for approval.</td></tr>'}</tbody></table></div>`;
}
async function approvalDecide(id, action, btn){
  if (action === 'reject' && !confirm('Reject this request? What was submitted will be discarded.')) return;
  if (btn) btn.disabled = true;
  const r = await fetch(`/api/approvals/${id}/${action}`, {method:'POST'});
  const d = await r.json().catch(() => ({}));
  if (!r.ok) alert(d.error || (d.item && d.item.result) || 'Could not apply this request (status ' + r.status + ').');
  else showToast(action === 'approve' ? 'Approved - it has been saved.' : 'Rejected.');
  srDataCache = null;
  renderReviewTab(document.getElementById('app'));
}

// ---- Uploads awaiting approval (the review gate)
let reviewPollTimer = null, reviewDraftPage = 1;
document.addEventListener('visibilitychange',()=>{ if(!document.hidden && currentPage==='review' && reviewSub==='uploads' && !document.getElementById('reviewDraftDetail')?.textContent.trim()) renderReviewTab(document.getElementById('app')); });
function reviewDraftMove(page){ reviewDraftPage=page; renderReviewTab(document.getElementById('app')); }
async function renderReviewUploads(box){
  const response = await fetch('/api/review/drafts?page='+reviewDraftPage+'&limit=25');
  if (!response.ok) { box.textContent = 'Unable to load drafts. Please retry.'; return; }
  const result = await response.json();
  if (!box.isConnected || currentPage !== 'review' || reviewSub !== 'uploads') return;
  const drafts = result.items;
  const pill = d => ({processing:'⏳ reading…', ready:'🟢 imported', approved:'✅ approved', failed:'❌ failed'}[d.status] || d.status);
  const co = d => { const c = d.company || {}; return c.matched ? escapeHtml(c.matched.name) : c.will_create ? `<b>NEW:</b> ${escapeHtml(c.new_name || c.detected || '')}` : escapeHtml(c.detected || '-'); };
  const rows = drafts.map(d => `<tr>
      <td>${escapeHtml(d.filename)}<div class="muted">${(d.size / 1048576).toFixed(1)} MB</div></td>
      <td>${d.status === 'processing' ? '-' : co(d)}</td><td>${escapeHtml(d.period || '-')}</td>
      <td>${pill(d)}${d.error ? `<div class="muted">${escapeHtml(d.error)}</div>` : ''}</td>
      <td>${d.status === 'processing' ? '' : (d.checks_failed ? `<span style="color:var(--red,#c0392b)">⚠ ${d.checks_failed} check(s) failed</span>` : '✓ checks pass') + (d.warnings ? ` · ${d.warnings} note(s)` : '')}</td>
      <td>${d.status !== 'processing' ? `<button class="btn" onclick="reviewViewDraft(${d.id})">View</button> ${d.status !== 'approved' && d.status !== 'failed' ? `<button class="btn primary" id="apprBtn${d.id}" onclick="reviewApprove(${d.id})">Approve</button> ` : ''}${d.source_document_id ? `<button class="btn danger" onclick="reviewReject(${d.id})">Reject</button>` : `<button class="btn" onclick="reviewDiscard(${d.id})">Discard</button>`}` : ''}</td></tr>`).join('');
  const ready = result.ready;
  box.innerHTML = `<div class="panel">
      <p class="muted">Every uploaded PDF is parsed and saved to the Survey Report immediately. This list is for confirming that afterward: <b>Approve</b> marks a report as checked, <b>Reject</b> deletes everything it saved (removing it from the Survey Report page). Typed survey files are already human-made and are never listed here.</p>
      ${ready > 1 ? `<button class="btn primary" onclick="reviewApproveAll()">Approve all ${ready}</button>` : ''}
      <table class="tbl" style="margin-top:10px"><thead><tr><th>File</th><th>Company</th><th>Period</th><th>Status</th><th>Checks</th><th></th></tr></thead>
      <tbody>${rows || '<tr><td colspan="6" class="muted">No uploads yet. Upload reports from the Overview page; they will appear here once saved.</td></tr>'}</tbody></table></div>
    <div class="panel"><button class="btn" ${reviewDraftPage<=1?'disabled':''} onclick="reviewDraftMove(${reviewDraftPage-1})">Previous</button> Page ${reviewDraftPage} · ${result.total} drafts <button class="btn" ${result.has_more?'':'disabled'} onclick="reviewDraftMove(${reviewDraftPage+1})">Next</button></div><div id="reviewDraftDetail"></div>`;
  clearTimeout(reviewPollTimer);
  if (result.processing) {
    const poll = () => {
      if (currentPage !== 'review' || reviewSub !== 'uploads') return;
      if (document.hidden || document.getElementById('reviewDraftDetail')?.textContent.trim()) {
        reviewPollTimer = setTimeout(poll, 15000); return;
      }
      renderReviewTab(document.getElementById('app'));
    };
    reviewPollTimer = setTimeout(poll, 15000);
  }
}
async function reviewViewDraft(id){
  const d = await fetch(`/api/review/drafts/${id}`).then(r => r.json());
  const pv = d.preview || {}, kf = pv.key_figures || {}, b = pv.board || {}, c = pv.company || {};
  const fmt = (v, u) => v === undefined || v === null ? '<span class="muted">-</span>' : fmtFull(v, u);
  const checks = (pv.checks || []).map(x => `<li>${x.ok ? '✅' : '⚠'} ${escapeHtml(x.check)} <span class="muted">(${escapeHtml(x.detail || '')})</span></li>`).join('');
  const warns = (pv.warnings || []).map(w => `<li>⚠ ${escapeHtml(w)}</li>`).join('');
  const stm = Object.entries(pv.statements || {}).map(([k, v]) => `${escapeHtml(k)}: ${v.items} lines (avg confidence ${v.avg_confidence ?? '-'})`).join(' · ');
  const people = (b.sample || []).map(p => `${escapeHtml(p.name)}${p.role && p.role !== 'unknown' ? ` <span class="muted">(${escapeHtml(p.role.replace('_', '-'))})</span>` : ''}`).join(', ');
  document.getElementById('reviewDraftDetail').innerHTML = `<div class="panel">
    <h3>${escapeHtml(d.filename)}</h3>
    <p>Will be saved to: <b>${c.matched ? escapeHtml(c.matched.name) : c.will_create ? 'a NEW company "' + escapeHtml(c.new_name || c.detected || '') + '"' : '?'}</b>
      · period <b>${escapeHtml(pv.period || '-')}</b>${pv.prior_period ? ` (+ comparative ${escapeHtml(pv.prior_period)})` : ''} · unit ${escapeHtml(pv.unit || 'not stated')} · ${pv.pages || '?'} pages${pv.survey_only ? ' · <b>survey-only (no statements)</b>' : ''}</p>
    ${warns ? `<ul>${warns}</ul>` : ''}
    <h4>Financial statements</h4><div class="muted">${stm || 'none found'}</div>
    <table class="tbl" style="max-width:520px"><tbody>${['revenue','profit_before_tax','tax_expense','net_income','total_assets','total_liabilities','total_equity'].map(k => `<tr><td>${k.replace(/_/g, ' ')}</td><td style="text-align:right">${fmt(kf[k], pv.unit)}</td></tr>`).join('')}</tbody></table>
    ${checks ? `<h4>Checks</h4><ul>${checks}</ul>` : ''}
    <h4>Board and pay</h4>
    <div>Directors: <b>${b.directors || 0}</b> (${b.roles_known || 0} with a stated role) · read from: ${escapeHtml(b.register_kind || 'nothing found')}</div>
    <div class="muted">${people}</div>
    <div>Committees from attendance table: ${(b.attendance_committees || []).length} · from sentences: ${(pv.prose_committees || []).length}</div>
    <div>Director pay rows: <b>${(pv.pay || {}).rows || 0}</b>${((pv.pay || {}).grand_totals || []).length ? ' · printed total ' + fmt(pv.pay.grand_totals[0], (pv.pay || {}).unit) : ''}</div>
    <div>CEO pay block: ${pv.ceo ? escapeHtml(pv.ceo.name) : 'not found'} · NED fee fields: ${(pv.policy_fields || []).length} · NED benefits found: ${Object.keys(pv.benefits || {}).length}</div>
    <p class="muted" style="margin-top:10px">Anything still missing after approval can be typed in under Report Manual Entry, or sent to the AI (the AI Backfilling page) if a page in the report can answer it.</p></div>`;
  document.getElementById('reviewDraftDetail').scrollIntoView({behavior: 'smooth'});
}
async function reviewApprove(id){
  const btn = document.getElementById('apprBtn' + id); if (btn) { btn.disabled = true; btn.textContent = 'Approving…'; }
  const r = await fetch(`/api/review/drafts/${id}/approve`, {method:'POST'});
  const d = await r.json();
  if (!r.ok) alert(d.error || (d.result && d.result.error) || 'Approve failed');
  await reviewRefresh();
}
async function reviewApproveAll(){
  const drafts = (await fetch('/api/review/drafts').then(r => r.json())).filter(d => d.status === 'ready');
  if (!drafts.length) return;
  for (const d of drafts) {
    const btn = document.getElementById('apprBtn' + d.id); if (btn) { btn.disabled = true; btn.textContent = 'Approving…'; }
    await fetch(`/api/review/drafts/${d.id}/approve`, {method:'POST'});
  }
  await reviewRefresh();
}
async function reviewReject(id){
  if (!confirm('Reject this report? Everything it saved will be deleted from the Survey Report page - this cannot be undone.')) return;
  await fetch(`/api/review/drafts/${id}/reject`, {method:'POST'});
  await reviewRefresh();
}
async function reviewDiscard(id){
  if (!confirm('Discard this upload? The file is deleted and nothing is saved.')) return;
  await fetch(`/api/review/drafts/${id}/discard`, {method:'POST'});
  await reviewRefresh();
}

// ---- AI results
async function renderReviewAIResults(box){
  const items = await fetch('/api/ai/items').then(r => r.json());
  const sum = i => i.summary ? `${i.summary.verified}/${i.summary.items} verified` + (i.summary.checks_failed ? ` · ⚠ ${i.summary.checks_failed} check(s) failed` : '') : '-';
  const rows = items.map(i => `<tr>
      <td>${escapeHtml(i.company || '')}<div class="muted">${escapeHtml(i.fiscal_year)}</div></td>
      <td>${escapeHtml(i.task)}<div class="muted">pages ${escapeHtml((i.pages || []).join(', '))}</div>${(i.gaps || []).length ? `<div class="muted">rules left empty: ${escapeHtml(i.gaps.join(', '))}</div>` : ''}</td>
      <td>${aiPill(i)}${i.error ? `<div class="muted">${escapeHtml(i.error)}</div>` : ''}</td>
      <td>${escapeHtml(sum(i))}</td>
      <td>${i.status === 'done' || i.status === 'applied' ? `<button class="btn" onclick="aiViewItem(${i.id})">View</button> <button class="btn primary" onclick="aiApplyItem(${i.id})">${i.status === 'applied' ? 'Re-apply' : 'Apply verified'}</button>` : ''}</td></tr>`).join('');
  box.innerHTML = `<div class="panel"><p class="muted">Apply only fills fields the rule-based readers left empty; a value the AI disagrees with goes to Conflicts and is never overwritten. Run items from the AI tab.</p>
    <table class="tbl"><thead><tr><th>Report</th><th>Task</th><th>Status</th><th>Verification</th><th></th></tr></thead>
    <tbody>${rows || '<tr><td colspan="5" class="muted">No AI items. Reports the rules read completely queue nothing.</td></tr>'}</tbody></table></div><div id="aiDetail"></div>`;
}

// ---- Conflicts
async function renderReviewConflicts(box){
  const list = await fetch('/api/review/conflicts').then(r => r.json());
  const rows = list.map(c => `<tr style="${c.resolution ? 'opacity:.55' : ''}">
      <td>${escapeHtml(c.company || '')}<div class="muted">${escapeHtml(c.fiscal_year)}</div></td><td>${escapeHtml(c.field_name)}</td>
      <td>${c.candidate_a_value ?? '-'}<div class="muted">${escapeHtml((c.candidate_a_source_text || '').slice(0, 110))}</div></td>
      <td>${c.candidate_b_value ?? '-'}${c.candidate_b_page ? ` <span class="muted">p.${c.candidate_b_page}</span>` : ''}<div class="muted">${escapeHtml((c.candidate_b_source_text || '').slice(0, 110))}</div></td>
      <td>${c.resolution ? escapeHtml(c.resolution.replace('candidate_a', 'kept stored').replace('candidate_b', 'used other value')) :
        `<button class="btn" onclick="reviewResolve(${c.id},'candidate_a')">Keep stored</button> <button class="btn" onclick="reviewResolve(${c.id},'candidate_b')">Use AI value</button> <button class="btn" onclick="reviewResolve(${c.id},'neither')">Neither</button>`}</td></tr>`).join('');
  box.innerHTML = `<div class="panel"><p class="muted">Two sources gave different values for one field. Nothing changes until you choose.</p>
    <table class="tbl"><thead><tr><th>Report</th><th>Field</th><th>Stored value</th><th>Other value</th><th>Decision</th></tr></thead>
    <tbody>${rows || '<tr><td colspan="5" class="muted">No conflicts.</td></tr>'}</tbody></table></div>`;
}
async function reviewResolve(id, resolution){
  await fetch(`/api/review/conflicts/${id}/resolve`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({resolution})});
  await reviewRefresh();
}

// ---- Issues (extraction steps that raised)
async function renderReviewIssues(box){
  const list = await fetch('/api/review/issues').then(r => r.json());
  const rows = list.map(i => `<tr style="${i.resolved ? 'opacity:.5' : ''}"><td>${escapeHtml(i.company || '-')}<div class="muted">${escapeHtml(i.fiscal_year || '')} · ${escapeHtml(i.filename || '')}</div></td>
      <td>${escapeHtml(i.step)}</td><td><code style="white-space:pre-wrap">${escapeHtml(i.error || '')}</code></td>
      <td>${i.resolved ? 'resolved' : `<button class="btn" onclick="reviewIssueResolve(${i.id})">Mark resolved</button>`}</td></tr>`).join('');
  box.innerHTML = `<div class="panel"><p class="muted">A step that raised during import used to disappear ("non-fatal") and leave a tab empty. They are listed here with the error. A "column … does not exist" error means the live database schema is behind the code - run <b>Settings › Overview › Data health › Schema check</b>.</p>
    <table class="tbl"><thead><tr><th>Report</th><th>Step</th><th>Error</th><th></th></tr></thead>
    <tbody>${rows || '<tr><td colspan="4" class="muted">No extraction problems recorded.</td></tr>'}</tbody></table></div>`;
}
async function reviewIssueResolve(id){ await fetch(`/api/review/issues/${id}/resolve`, {method:'POST'}); await reviewRefresh(); }

// ---- Manual entry: for data that is in the report but that no reader could extract
let manualCtx = {companyId: null, fy: null};
async function renderReviewManual(box){
  manualCtx.companies = await fetch('/api/companies').then(r => r.json());
  box.innerHTML = `<div class="panel">
    <p class="muted">Type in what the report contains but the app could not read. Values entered here are marked <b>entered manually</b> and are never overwritten by a re-upload or by the AI.</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
      <select id="manFy" title="Fiscal year" onchange="manualYearChanged()"></select>
      <input id="manFyNew" placeholder="or new year, e.g. FY2026" style="width:170px" oninput="manualFillCompanies()">
      <select id="manCo" title="Only companies that have the selected year" onchange="manualCtx.companyId=+this.value"></select>
      <button class="btn primary" onclick="manualLoad()">Open</button>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px">
      <button class="btn" onclick="manualDownloadForm()" title="PDF form for the company and year selected above: every survey field, the directors' register, every committee, every director pay row and the NED benefits - with what is on file, to check against the annual report">⭳ Download form (this company)</button>
      <button class="btn" onclick="manualDownloadAllForms()" title="One PDF per company for the selected year, zipped, with a summary of the problems found for each company and how to fix them">⭳ Download forms (all companies, .zip)</button>
      <button class="btn primary" onclick="document.getElementById('manFormFiles').click()" title="Upload filled forms: one PDF, several PDFs, or a .zip of PDFs">⭱ Upload filled form(s) (.pdf / .zip)</button>
      <input type="file" id="manFormFiles" accept=".pdf,.zip,application/pdf,application/zip,application/x-zip-compressed" multiple style="display:none" onchange="manualUploadForms(this)">
      <label title="Each uploaded form becomes the whole truth for its company and year: every survey field and the directors' register are set to exactly what the form says (a box left empty is cleared). Financial statements and the stored report text are kept." style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer"><input type="checkbox" id="manReplace"> Replace the year with the form</label>
      <label title="For forms whose company is not in the app - for example when restoring a forms zip into a new installation. The company is added (name, ticker and sector from the form) when you approve. Without this, such forms are skipped." style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer"><input type="checkbox" id="manAddMissing"> Add companies that are not in the app</label>
    </div>
    <p class="muted" style="margin-top:6px">Fill the downloaded PDF on screen (it has typing boxes), save it, and upload it here. You see what would change and approve it before anything is stored.</p>
    <p class="muted" style="margin-top:4px"><b>Restoring into a new installation:</b> upload the forms zip with both boxes ticked. Each form carries every field and every table row (register, committees, director pay, NED benefits), is matched to its company by name and ticker (never by number alone), and companies that are missing are added. Download a fresh zip per year to keep as a backup.</p>
    </div><div id="manualUploadPanel"></div><div id="manualBody"></div>`;
  await manualLoadYears();
}
// Year drives the company list: only companies that have data for the selected year
// are offered. Typing a brand-new year in the box shows every company (nobody has it yet).
function manualFillCompanies(){
  const co = document.getElementById('manCo'); if (!co) return;
  const typed = (document.getElementById('manFyNew').value || '').trim();
  const fy = document.getElementById('manFy').value;
  const all = manualCtx.companies || [];
  const ids = typed ? null : new Set(((manualCtx.byYear || {})[fy]) || []);
  const list = ids ? all.filter(c => ids.has(c.id)) : all;
  if (!list.some(c => c.id === manualCtx.companyId)) manualCtx.companyId = list.length ? list[0].id : null;
  co.innerHTML = list.map(c => `<option value="${c.id}" ${c.id === manualCtx.companyId ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('')
    || '<option value="">(no company has this year)</option>';
}
function manualYearChanged(){
  manualCtx.fy = document.getElementById('manFy').value;
  document.getElementById('manFyNew').value = '';
  manualFillCompanies();
}
// Year to act on: the typed "new year" if any, else the dropdown. Half-year / quarterly labels are refused.
function manualPickedFy(){
  const typed = (document.getElementById('manFyNew').value || '').trim();
  if (typed && !isFullYear(typed)) { alert('Only full financial years are supported - type it like FY2026.'); return ''; }
  return typed || document.getElementById('manFy').value;
}
function manualDownloadForm(){
  const fy = manualPickedFy();
  if (!manualCtx.companyId) { alert('Choose a company first.'); return; }
  if (!fy) { alert('Choose or type a fiscal year first.'); return; }
  window.location.href = `/api/manual/${manualCtx.companyId}/${encodeURIComponent(fy)}/form.pdf`;
}
function manualDownloadAllForms(){
  const fy = manualPickedFy();
  // Only companies that have the selected year are included; the summary lists the rest.
  window.location.href = '/api/manual/forms.zip' + (fy ? '?fiscal_year=' + encodeURIComponent(fy) : '');
}
// ---- upload of filled forms: preview -> approve -> apply ----
let manualUpload = {changes: [], busy: false};
async function manualUploadForms(input){
  const files = [...input.files];
  input.value = '';
  if (!files.length) return;
  const box = document.getElementById('manualUploadPanel');
  box.innerHTML = `<div class="panel"><p class="muted">Reading ${files.length} file${files.length === 1 ? '' : 's'}...</p></div>`;
  const fd = new FormData(); files.forEach(f => fd.append('files', f));
  const rep = document.getElementById('manReplace');
  if (rep && rep.checked) fd.append('mode', 'replace');
  const addm = document.getElementById('manAddMissing');
  if (addm && addm.checked) fd.append('add_missing', '1');
  let d;
  try {
    const r = await fetch('/api/manual/upload-forms', {method:'POST', body: fd});
    d = await r.json().catch(() => ({}));
    if (!r.ok) { box.innerHTML = `<div class="panel"><b>Upload failed.</b> ${escapeHtml(d.error || 'status ' + r.status)}</div>`; return; }
  } catch (e) { box.innerHTML = `<div class="panel"><b>Upload failed.</b> Check the connection and try again.</div>`; return; }
  manualUpload.changes = (d.changes || []).map(c => ({...c, checked: !!c.checked && !c.broken}));
  manualUpload.files = d.files || []; manualUpload.notes = d.notes || []; manualUpload.problems = d.problems || [];
  manualUpload.newCompanies = d.new_companies || [];
  manualUploadRender();
}
function manualUploadRender(result){
  const box = document.getElementById('manualUploadPanel');
  const U = manualUpload, ch = U.changes;
  const list = (arr, cls) => arr && arr.length ? `<ul class="${cls || ''}" style="margin:6px 0 6px 18px">${arr.map(x => `<li>${escapeHtml(x)}</li>`).join('')}</ul>` : '';
  const groups = {};
  ch.forEach((c, i) => { const k = c.company_id + '|' + c.fiscal_year; (groups[k] = groups[k] || {name: c.company, fy: c.fiscal_year, isNew: !!c.new_company, items: []}).items.push([c, i]); });
  const nSel = ch.filter(c => c.checked).length;
  const resMap = {}; (result && result.results || []).forEach(r => { resMap[r.id] = r; });
  const body = Object.entries(groups).map(([k, g]) => `
    <details open style="margin-top:10px"><summary><b>${escapeHtml(g.name)}</b>${g.isNew && !result ? ' <span class="bl-pill" style="background:#e3fcf0;color:#1e8a54;padding:1px 8px;border-radius:999px;font-size:11px;font-weight:600">new company - added on approval</span>' : ''} <span class="muted">${escapeHtml(g.fy)} · ${g.items.length} change${g.items.length === 1 ? '' : 's'}</span>
      ${result ? '' : `<label style="margin-left:10px;font-weight:normal"><input type="checkbox" ${g.items.every(([c]) => c.checked) ? 'checked' : ''} onchange="manualUploadToggleGroup('${k}', this.checked)"> select all</label>`}</summary>
      <table class="tbl"><thead><tr>${result ? '' : '<th></th>'}<th>Field</th><th>Stored now</th><th>From the form</th><th>${result ? 'Result' : 'Note'}</th></tr></thead><tbody>
      ${g.items.map(([c, i]) => { const r = resMap[c.id];
        return `<tr><td${result ? ' style="display:none"' : ''}>${result ? '' : `<input type="checkbox" ${c.checked ? 'checked' : ''} ${c.broken ? 'disabled' : ''} onchange="manualUpload.changes[${i}].checked=this.checked;manualUploadRender()">`}</td>
          <td>${escapeHtml(c.label)}</td><td class="muted">${escapeHtml(c.current || '')}</td><td>${escapeHtml(c.new || '')}</td>
          <td>${result ? (r ? (r.ok ? '<span style="color:var(--green)">saved</span>' : `<span style="color:var(--red)">${escapeHtml(r.message)}</span>`) : '<span class="muted">not approved</span>')
                        : `<span class="muted">${escapeHtml(c.warning || '')}</span>`}</td></tr>`
          + (c.details || []).map(x => `<tr class="muted" style="font-size:12px"><td${result ? ' style="display:none"' : ''}></td><td style="padding-left:18px">${escapeHtml(x.label)}</td><td>${escapeHtml(x.current || '')}</td><td style="color:var(--text)">${escapeHtml(x.new || '')}</td><td></td></tr>`).join(''); }).join('')}
      </tbody></table></details>`).join('');
  const filesLine = (U.files || []).map(f => `${f.company} ${f.fiscal_year} (${f.proposed})`).join(' · ');
  box.innerHTML = `<div class="panel">
    <h3>${result ? 'Upload applied' : 'Review the uploaded forms'}</h3>
    ${filesLine ? `<p class="muted">Forms read: ${escapeHtml(filesLine)}</p>` : ''}
    ${!result && (U.newCompanies || []).length ? `<p><b>${U.newCompanies.length} compan${U.newCompanies.length === 1 ? 'y is' : 'ies are'} not in the app and will be added</b> when you approve: ${escapeHtml(U.newCompanies.map(n => n.name + (n.ticker ? ' (' + n.ticker + ')' : '')).join(', '))}.</p>` : ''}
    ${result && (result.companies_added || []).length ? `<p><b>Companies added:</b> ${escapeHtml(result.companies_added.map(n => n.name).join(', '))}.</p>` : ''}
    ${list(U.notes, 'muted')}${list(U.problems, 'muted')}
    ${!ch.length && !result ? '<p><b>Nothing to change.</b> The forms had no filled-in boxes that differ from what is stored.</p>' : ''}
    ${body}
    ${result ? `<p style="margin-top:10px"><b>${result.results.filter(r => r.ok).length}</b> saved${result.results.some(r => !r.ok) ? `, <b>${result.results.filter(r => !r.ok).length}</b> failed` : ''}. The Survey Report tabs now show the saved values.</p>
        <button class="btn" onclick="manualUploadClose()">Close</button>`
      : `<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        ${ch.length ? `<button class="btn primary" ${nSel && !U.busy ? '' : 'disabled'} onclick="manualUploadApply()">Approve &amp; save ${nSel} selected</button>
        <button class="btn" onclick="manualUploadSelectAll(true)">Select all</button><button class="btn" onclick="manualUploadSelectAll(false)">Select none</button>` : ''}
        <button class="btn" onclick="manualUploadClose()">Discard</button></div>`}
  </div>`;
}
function manualUploadToggleGroup(k, on){ manualUpload.changes.forEach(c => { if ((c.company_id + '|' + c.fiscal_year) === k && !c.broken) c.checked = on; }); manualUploadRender(); }
function manualUploadSelectAll(on){ manualUpload.changes.forEach(c => { if (!c.broken) c.checked = on; }); manualUploadRender(); }
function manualUploadClose(){ manualUpload = {changes: [], busy: false}; document.getElementById('manualUploadPanel').innerHTML = ''; }
async function manualUploadApply(){
  const sel = manualUpload.changes.filter(c => c.checked);
  if (!sel.length || manualUpload.busy) return;
  manualUpload.busy = true; manualUploadRender();
  try {
    const r = await fetch('/api/manual/apply-forms', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({changes: sel})});
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { alert(d.error || 'Could not save (status ' + r.status + ').'); manualUpload.busy = false; manualUploadRender(); return; }
    manualUpload.busy = false;
    manualUpload.changes = sel;              // the result table lists what was approved
    manualUploadRender(d);
    if ((d.companies_added || []).length) { manualCtx.companies = await fetch('/api/companies').then(r => r.json()).catch(() => manualCtx.companies); await manualLoadYears(); }
    if (manualCtx.companyId && manualCtx.fy && sel.some(c => c.company_id === manualCtx.companyId)) { await manualLoadYears(); await manualLoad(); }
    srDataCache = null;                      // Survey Report re-reads on next visit
  } catch (e) { alert('Could not save - check the connection and try again.'); manualUpload.busy = false; manualUploadRender(); }
}

async function manualLoadYears(){
  const d = await fetch('/api/manual/years-index').then(r => r.json());
  manualCtx.byYear = d.by_year || {};
  const years = fullYears(d.years);
  const sel = document.getElementById('manFy');
  sel.innerHTML = years.map(y => `<option>${escapeHtml(y)}</option>`).join('') || '<option value="">(no year yet)</option>';
  if (manualCtx.fy && years.includes(manualCtx.fy)) sel.value = manualCtx.fy;
  manualFillCompanies();
}
async function manualLoad(){
  const fy = manualPickedFy();
  if (!fy) { alert('Choose or type a fiscal year first.'); return; }
  if (!manualCtx.companyId) { alert('Choose a company first.'); return; }
  manualCtx.fy = fy;
  const d = await fetch(`/api/manual/${manualCtx.companyId}/${encodeURIComponent(fy)}`).then(r => r.json());
  const chips = Object.values(d.status).map(t => `<span class="sr-conf-badge ${t.filled >= t.total ? 'sr-conf-high' : 'sr-conf-med'}" title="missing: ${escapeHtml(t.missing.join(', '))}">${escapeHtml(t.label)} ${t.filled}/${t.total}</span>`).join(' ');
  const metricRow = m => `<tr><td>${escapeHtml(m.label)}</td><td><input class="manMetric" data-key="${m.key}" value="${m.value ?? ''}" style="width:130px"></td><td class="muted">${escapeHtml((m.source || '').slice(0, 90))}</td></tr>`;
  const groups = d.groups.map(g => `<details ${g.metrics.some(m => m.value === null) ? 'open' : ''}><summary><b>${escapeHtml(g.label)}</b> <span class="muted">(${g.metrics.filter(m => m.value !== null).length}/${g.metrics.length} filled)</span></summary>
      <table class="tbl"><tbody>${g.metrics.map(metricRow).join('')}</tbody></table></details>`).join('');
  const dirRows = d.directors.map(x => manualDirRow(x)).join('') + manualDirRow({});
  const comRows = d.committees.map(x => manualComRow(x)).join('') + manualComRow({});
  const payRows = d.pay_rows.map(x => manualPayRow(x)).join('') + manualPayRow({});
  const ben = d.benefit_keys.map(k => { const v = d.ned_benefits[k]; const st = v ? (v.provided ? 'yes' : 'no') : '';
    return `<tr><td>${k}</td><td><select class="manBen" data-key="${k}"><option value="" ${st === '' ? 'selected' : ''}>not stated</option><option value="yes" ${st === 'yes' ? 'selected' : ''}>provided</option><option value="no" ${st === 'no' ? 'selected' : ''}>not provided</option></select></td><td><input class="manBenD" data-key="${k}" value="${escapeHtml((v && v.detail) || '')}" placeholder="detail / page" style="width:240px"></td></tr>`; }).join('');
  document.getElementById('manualBody').innerHTML = `
    <div class="panel"><div>${chips}</div>
      <p style="margin-top:8px"><button class="btn" onclick="manualReconcile()">Rebuild tabs from what is stored</button> <span class="muted">(fills the Register from the pay tables and Board Composition from the Register)</span></p></div>
    <div class="panel"><h3>Metrics</h3>${groups}
      <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <label>Unit of pay figures <select id="manUnit"><option value="">(unchanged${d.unit ? ': ' + d.unit : ''})</option><option value="units">units (Shs)</option><option value="thousands">thousands</option><option value="millions">millions</option></select></label>
        <input id="manNote" placeholder="source note, e.g. p.88" style="width:200px"><button class="btn primary" onclick="manualSaveMetrics()">Save metrics</button></div></div>
    <div class="panel"><h3>Directors' register</h3><table class="tbl"><thead><tr><th>Name</th><th>Role</th><th>Independent</th><th>Gender</th><th>Nationality</th><th>Appointed</th><th></th></tr></thead><tbody>${dirRows}</tbody></table></div>
    <div class="panel"><h3>Committees</h3><table class="tbl"><thead><tr><th>Name</th><th>Chair</th><th>Meetings</th><th>Members (comma separated)</th><th></th></tr></thead><tbody>${comRows}</tbody></table></div>
    <div class="panel"><h3>Director pay rows</h3><p class="muted">Amounts as printed, in the unit chosen above. Components as <code>Fees=5000, Allowances=1200</code>. Tick "total row" for the table's printed grand total.</p>
      <table class="tbl"><thead><tr><th>Name</th><th>Role</th><th>Total</th><th>Components</th><th>Total row</th><th></th></tr></thead><tbody>${payRows}</tbody></table></div>
    <div class="panel"><h3>NED benefits</h3><table class="tbl"><tbody>${ben}</tbody></table><button class="btn primary" style="margin-top:8px" onclick="manualSaveBenefits()">Save benefits</button></div>`;
}
const _sel = (opts, cur, cls, extra='') => `<select class="${cls}" ${extra}>${opts.map(([v, l]) => `<option value="${v}" ${String(cur ?? '') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
function manualDirRow(x){
  const id = x.id || '';
  return `<tr data-id="${id}" class="manDir"><td><input class="dn" value="${escapeHtml(x.director_name || '')}" style="width:170px"></td>
    <td>${_sel([['unknown','?'],['executive','executive'],['non_executive','non-executive']], x.role, 'dr')}</td>
    <td>${_sel([['','?'],['true','yes'],['false','no']], x.independent === true ? 'true' : x.independent === false ? 'false' : '', 'di')}</td>
    <td>${_sel([['','?'],['Male','Male'],['Female','Female']], x.gender, 'dg')}</td>
    <td><input class="dnat" value="${escapeHtml(x.nationality || '')}" style="width:100px"></td><td><input class="dap" value="${escapeHtml(x.appointed_date || '')}" style="width:100px"></td>
    <td><button class="btn" onclick="manualSaveDir(this)">${id ? 'Save' : 'Add'}</button>${id ? ` <button class="btn" onclick="manualDel('directors',${id})">✕</button>` : ''}</td></tr>`;
}
function manualComRow(x){
  const id = x.id || '';
  return `<tr data-id="${id}" class="manCom"><td><input class="cn" value="${escapeHtml(x.name || '')}" style="width:190px"></td><td><input class="cc" value="${escapeHtml(x.chairperson_name || '')}" style="width:140px"></td>
    <td><input class="cm" value="${x.meetings_held ?? ''}" style="width:60px"></td><td><input class="cmem" value="${escapeHtml((x.members || []).join(', '))}" style="width:300px"></td>
    <td><button class="btn" onclick="manualSaveCom(this)">${id ? 'Save' : 'Add'}</button>${id ? ` <button class="btn" onclick="manualDel('committees',${id})">✕</button>` : ''}</td></tr>`;
}
function manualPayRow(x){
  const id = x.id || '';
  let comps = x.components; if (typeof comps === 'string') { try { comps = JSON.parse(comps); } catch (e) { comps = {}; } }
  const cs = Object.entries(comps || {}).map(([k, v]) => `${k}=${v}`).join(', ');
  return `<tr data-id="${id}" class="manPay"><td><input class="pn" value="${escapeHtml(x.director_name || '')}" style="width:170px"></td>
    <td>${_sel([['unknown','?'],['executive','executive'],['non_executive','non-executive']], x.role, 'pr')}</td>
    <td><input class="pt" value="${x.total ?? ''}" style="width:110px"></td><td><input class="pc" value="${escapeHtml(cs)}" style="width:260px"></td>
    <td><input type="checkbox" class="pg" ${x.is_grand_total ? 'checked' : ''}></td>
    <td><button class="btn" onclick="manualSavePay(this)">${id ? 'Save' : 'Add'}</button>${id ? ` <button class="btn" onclick="manualDel('pay-rows',${id})">✕</button>` : ''}</td></tr>`;
}
async function _manualPost(kind, body){
  const r = await fetch(`/api/manual/${manualCtx.companyId}/${encodeURIComponent(manualCtx.fy)}/${kind}`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
  const d = await r.json(); if (!r.ok) { alert(d.error || 'Could not save'); return false; } await manualLoad(); return true;
}
async function manualSaveDir(btn){
  const tr = btn.closest('tr'), q = c => tr.querySelector(c).value;
  await _manualPost('directors', {id: +tr.dataset.id || undefined, director_name: q('.dn'), role: q('.dr'), independent: q('.di') === '' ? null : q('.di') === 'true', gender: q('.dg') || null, nationality: q('.dnat'), appointed_date: q('.dap')});
}
async function manualSaveCom(btn){
  const tr = btn.closest('tr'), q = c => tr.querySelector(c).value;
  await _manualPost('committees', {id: +tr.dataset.id || undefined, name: q('.cn'), chairperson_name: q('.cc'), meetings_held: q('.cm'), members: q('.cmem')});
}
async function manualSavePay(btn){
  const tr = btn.closest('tr'), q = c => tr.querySelector(c);
  const comps = {}; q('.pc').value.split(',').forEach(p => { const [k, v] = p.split('='); if (k && v !== undefined) comps[k.trim()] = v.trim(); });
  await _manualPost('pay-rows', {id: +tr.dataset.id || undefined, director_name: q('.pn').value, role: q('.pr').value, total: q('.pt').value, components: comps, is_grand_total: q('.pg').checked});
}
async function manualDel(kind, id){
  if (!confirm('Delete this row?')) return;
  await fetch(`/api/manual/${kind}/${id}`, {method:'DELETE'}); await manualLoad();
}
async function manualSaveMetrics(){
  const fields = {}; document.querySelectorAll('.manMetric').forEach(i => { fields[i.dataset.key] = i.value.trim() === '' ? null : i.value; });
  const r = await fetch(`/api/manual/${manualCtx.companyId}/${encodeURIComponent(manualCtx.fy)}/metrics`, {method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({fields, note: document.getElementById('manNote').value, unit: document.getElementById('manUnit').value || undefined})});
  const d = await r.json(); if (!r.ok) { alert(d.error || 'Could not save'); return; } await manualLoad();
}
async function manualSaveBenefits(){
  const b = {}; document.querySelectorAll('.manBen').forEach(s => { if (s.value) b[s.dataset.key] = {provided: s.value === 'yes', detail: document.querySelector(`.manBenD[data-key="${s.dataset.key}"]`).value || null}; });
  await fetch(`/api/manual/${manualCtx.companyId}/${encodeURIComponent(manualCtx.fy)}/benefits`, {method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ned_benefits: b})});
  await manualLoad();
}
async function manualReconcile(){
  await fetch(`/api/tabs/${manualCtx.companyId}/${encodeURIComponent(manualCtx.fy)}/reconcile`, {method:'POST'}); await manualLoad();
}

async function aiEstimate(){
  const r = await fetch('/api/ai/estimate', {method:'POST', headers:{'Content-Type':'application/json'}, body:'{}'});
  const e = await r.json();
  document.getElementById('aiEstimate').innerHTML = e.items
    ? `<b>${e.items} item(s) from ${e.files} report(s)</b> · ~${e.batch.input_tokens.toLocaleString()} tokens in / ${e.batch.output_tokens.toLocaleString()} out · <b>batch $${e.batch.usd.toFixed(2)}</b> · direct $${e.direct.usd.toFixed(2)} (${escapeHtml(e.batch.model)})`
    : 'Nothing pending.';
}
async function aiRun(mode){
  const cap = parseFloat(document.getElementById('aiCap').value);
  const r = await fetch('/api/ai/run', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({mode, max_cost_usd: isNaN(cap) ? null : cap})});
  const d = await r.json();
  if (!r.ok) { alert(d.error || 'Could not start'); return; }
  await reviewRefresh();
}
async function aiCollect(id){
  const r = await fetch(`/api/ai/jobs/${id}/collect`, {method:'POST'});
  const d = await r.json();
  if (d.status && d.status !== 'ended') alert('Still processing (' + d.status + '). Try again in a few minutes.');
  await reviewRefresh();
}
async function aiApplyItem(id){
  if (!confirm('Write the VERIFIED values from this item into the survey tables? Only fields the rules left empty are filled; unverified items are never written.')) return;
  const r = await fetch(`/api/ai/items/${id}/apply`, {method:'POST'});
  const d = await r.json();
  if (!r.ok) { alert(d.error || 'Could not apply'); return; }
  const a = d.applied || {};
  alert(`Applied: ${(a.fields || []).length} field(s), ${a.directors || 0} director(s), ${a.committees || 0} committee(s), ${a.pay_rows || 0} pay row(s), ${a.benefits || 0} benefit(s).` +
        ((a.conflicts || []).length ? `\n${a.conflicts.length} value(s) disagreed with what was stored - see Review › Conflicts.` : '') +
        ((a.skipped || []).length ? `\nSkipped: ${a.skipped.join('; ')}` : ''));
  await reviewRefresh();
}
async function aiViewItem(id){
  const it = await fetch(`/api/ai/items/${id}`).then(r => r.json());
  const res = it.result || {};
  const flag = x => x.verified ? '✅' : '❌';
  const problems = x => (x.problems || []).length ? `<div class="muted">${escapeHtml(x.problems.join('; '))}</div>` : '';
  let body = '';
  (res.directors || []).forEach(d => body += `<tr><td>${flag(d)}</td><td>${escapeHtml(d.name)}${problems(d)}</td><td>${escapeHtml(d.role || '')}${d.independent ? ' · independent' : ''}</td><td>${escapeHtml(d.gender || '')} ${escapeHtml(d.nationality || '')} ${escapeHtml(d.appointed || '')}</td><td>p.${d.page}</td></tr>`);
  (res.facts || []).forEach(f => body += `<tr><td>${flag(f)}</td><td>${escapeHtml(f.field)}${problems(f)}</td><td>${f.value}</td><td>${escapeHtml(f.evidence || '')}</td><td>p.${f.page}</td></tr>`);
  (res.committees || []).forEach(c => body += `<tr><td>${flag(c)}</td><td>${escapeHtml(c.name)}${problems(c)}</td><td>${c.meetings_held ?? ''} meetings · ${(c.members || []).length} members</td><td>chair ${escapeHtml(c.chair || '-')}</td><td>p.${c.page}</td></tr>`);
  (res.tables || []).forEach(t => { (t.rows || []).forEach(r => body += `<tr><td>${flag(r)}</td><td>${escapeHtml(r.name)}${problems(r)}</td><td>${r.total === null || r.total === undefined ? '' : fmtFull(r.total, t.unit)}</td><td>${escapeHtml(t.title || '')}${t.is_current_year === false ? ' (prior year - not applied)' : ''}</td><td>p.${r.page}</td></tr>`); });
  (res.policy || []).forEach(p => body += `<tr><td>${flag(p)}</td><td>${escapeHtml(p.field)}${problems(p)}</td><td>${(typeof p.value === 'number' && unitMultiplier(p.unit) !== 1) ? fmtFull(p.value, p.unit) : p.value + ' ' + escapeHtml(p.unit || '')}</td><td>${escapeHtml(p.evidence || '')}</td><td>p.${p.page}</td></tr>`);
  (res.ned_benefits || []).forEach(b => body += `<tr><td>${flag(b)}</td><td>${escapeHtml(b.key)}${problems(b)}</td><td>${b.provided ? 'provided' : 'not provided'}</td><td>${escapeHtml(b.detail || b.evidence || '')}</td><td>p.${b.page}</td></tr>`);
  const checks = (it.checks || []).map(c => `<li>${c.ok ? '✅' : '⚠'} ${escapeHtml(c.check)} - ${escapeHtml(c.detail || '')}</li>`).join('');
  document.getElementById('aiDetail').innerHTML = `<div class="panel"><h3>${escapeHtml(it.task)} · ${escapeHtml(it.fiscal_year)}</h3>
    ${checks ? `<ul>${checks}</ul>` : ''}
    <table class="tbl"><thead><tr><th></th><th>Item</th><th>Value</th><th>Detail / evidence</th><th>Page</th></tr></thead><tbody>${body}</tbody></table></div>`;
  document.getElementById('aiDetail').scrollIntoView({behavior:'smooth'});
}

// Settings used to stack Database/Companies/Users/Import Activity as four
// panels on one long scroll - reworked into tabs (same ir-tabbar/ir-tab-btn
// styling the Survey Report and Intelligence Report pages already use) so
// each data category gets its own screen. "Overview" (the database/health
// numbers - what you'd check first) is the default/first tab.
// AI, Review and Manual Entry used to be tabs here too - promoted to their
// own top-level nav items (see PAGES above), so they are no longer listed.
const SETTINGS_TABS = [
  {id:'overview', label:'Overview'},
  {id:'companies', label:'Companies'},
  {id:'users', label:'Users'},
  {id:'activity', label:'Import Activity'},
  {id:'enquiries', label:'Enquiries'},
  {id:'emails', label:'Emails'},
];
const SETTINGS_SUPER_ONLY = new Set(['users', 'enquiries', 'emails']);
// The Users tab (create / delete accounts, change roles, reset passwords) is for super admins only.
function settingsTabs(){
  return SETTINGS_TABS.filter(t => !SETTINGS_SUPER_ONLY.has(t.id) || window.currentUser.is_super_admin);
}
let settingsTab = 'overview';
let settingsStatusCache = null;

function switchSettingsTab(tabId){
  settingsTab = tabId;
  renderSettingsTabBody();
}

async function renderSettingsPage(){
  const app = document.getElementById('app');
  if (SETTINGS_SUPER_ONLY.has(settingsTab) && !window.currentUser.is_super_admin) settingsTab = 'overview';
  if (window.currentUser.role !== 'admin') {
    app.innerHTML = `<div class="panel"><h2>Account settings</h2><p class="bl-faint">Manage your subscription, invoices and payment details.</p><button onclick="goTo('billing')">Open Billing &amp; Plan</button></div>`;
    return;
  }
  app.innerHTML = `<div class="st-console"><div class="bl-loading"><span></span><span></span><span></span></div></div>`;
  const res = await fetch('/api/system/status');
  settingsStatusCache = await res.json();
  if (currentPage !== 'settings') return;

  app.innerHTML = `<div class="st-console">
    <div id="settingsTabBody" class="st-tab-body"></div></div>`;
  renderSettingsTabBody();
}

function stStat(icon, tone, label, value, sub){
  return `<div class="bl-stat"><div class="bl-stat-top"><span class="bl-stat-icon bl-${tone}">${blIcon(icon)}</span><span>${label}</span></div>
    <div class="bl-stat-value">${value}</div>${sub ? `<div class="bl-faint">${sub}</div>` : ''}</div>`;
}
function stNum(v){ return v == null ? '0' : Number(v).toLocaleString('en-US'); }

function renderSettingsTabBody(){
  const body = document.getElementById('settingsTabBody');
  if (!body) return;
  rpHeaderSelect('section','General settings section',settingsTabs(),settingsTab,switchSettingsTab);
  const status = settingsStatusCache || {counts: {}};
  const c = status.counts || {};
  const engine = ({postgresql: 'PostgreSQL', sqlite: 'SQLite', mysql: 'MySQL'})[status.database_engine] || status.database_engine || 'Unknown';

  // The shell is drawn once by renderSettingsPage - switching tabs only re-renders the body, so the active tab is updated here.
  document.querySelectorAll('.st-subnav button').forEach((btn, i) => {
    btn.classList.toggle('active', settingsTabs()[i].id === settingsTab);
  });

  if (settingsTab === 'overview') {
    body.innerHTML = `
      <div class="panel"><div class="st-db">
        <span class="st-db-icon bl-${status.persistent ? 'green' : 'amber'}">${blIcon('database')}</span>
        <div class="st-db-main">
          <div class="st-db-title">${escapeHtml(engine)} database <span class="bl-pill bl-${status.persistent ? 'green' : 'amber'}">${status.persistent ? 'Connected · persistent' : 'Not persistent'}</span></div>
          <div class="st-sub">${status.persistent
            ? 'Saved data survives restarts and redeploys.'
            : escapeHtml(status.warning || '')}</div>
        </div></div></div>
      <div class="bl-stats">
        ${stStat('building', 'blue', 'Companies', stNum(c.companies), 'Listed companies on file')}
        ${stStat('calendar', 'amber', 'Financial periods', stNum(c.periods), 'Company-years with statements')}
        ${stStat('doc', 'green', 'Source documents', stNum(c.source_documents), 'Annual reports uploaded')}
        ${stStat('upload', 'red', 'Import jobs', stNum(c.import_jobs), 'Uploads and manual entries')}
      </div>
      <div class="panel" id="dataHealthPanel">
        <div class="bl-card-head"><div><div class="bl-card-title">Data health</div>
          <div class="st-sub">Two checks for when the data is on file but a tab still shows empty.</div></div></div>
        <div class="st-actions">
          <div class="st-action">
            <div class="st-action-top"><span class="bl-stat-icon bl-blue">${blIcon('shield')}</span>Schema check</div>
            <p>Finds columns the app expects that the live database does not have. A missing column makes every save that touches it fail, and the only sign is an empty tab.</p>
            <button class="secondary" onclick="dhSchemaCheck()">${blIcon('search')}Run schema check</button>
          </div>
          <div class="st-action">
            <div class="st-action-top"><span class="bl-stat-icon bl-green">${blIcon('refresh')}</span>Rebuild tabs</div>
            <p>Fills a tab from what other tabs already hold (for example the Directors' Register from the pay tables), for every company and year.</p>
            <button class="secondary" onclick="dhReconcileAll()">${blIcon('refresh')}Rebuild tabs for all companies</button>
          </div>
        </div>
        <div id="dataHealthOut" class="st-out" style="margin-top:12px"></div>
      </div>`;
  } else if (settingsTab === 'companies') {
    body.innerHTML = `
      <div class="panel bl-flush" id="settingsCompaniesPanel">
        <div class="bl-card-head padded" style="flex-wrap:wrap;margin-bottom:12px;">
          <div><div class="bl-card-title">Companies</div><div class="st-sub" id="settingsCoSub">Every company with its report files, by year.</div></div>
          <div class="bl-head-act" id="settingsCompaniesActions"></div>
        </div>
        <div id="settingsCompaniesToolbar" class="st-toolbar" style="border-top:1px solid var(--border);"></div>
        <div id="settingsCompaniesBody"><div class="bl-loading"><span></span><span></span><span></span></div></div>
        <div id="settingsCompaniesFoot"></div>
      </div>`;
    renderSettingsCompaniesPanel();
  } else if (settingsTab === 'users') {
    body.innerHTML = `<div id="userManagementBody"><div class="bl-loading"><span></span><span></span><span></span></div></div>`;
    renderUserManagementPanel();
  } else if (settingsTab === 'enquiries') {
    body.innerHTML = `<div id="settingsEnquiriesBody"><div class="bl-loading"><span></span><span></span><span></span></div></div>`;
    renderEnquiriesPanel();
  } else if (settingsTab === 'emails') {
    body.innerHTML = `<div id="settingsEmailsBody"><div class="bl-loading"><span></span><span></span><span></span></div></div>`;
    renderEmailsPanel();
  } else if (settingsTab === 'activity') {
    body.innerHTML = `<div id="settingsActivityBody"><div class="bl-loading"><span></span><span></span><span></span></div></div>`;
    renderSettingsActivityPanel();
  }
}

// ---------------------------------------------------------------------------
// AI / Review / Manual Entry - promoted from Settings tabs to their own
// top-level nav pages (2026-09-25). Each is a thin wrapper around the same
// render function Settings used to call directly into its own tab body -
// the underlying renderAITab/renderReviewTab/renderReviewManual functions
// are unchanged and just get the page's own <div id="app"> instead of
// Settings' #settingsTabBody.
// ---------------------------------------------------------------------------
async function renderAIPage(){
  const app = document.getElementById('app');
  if (window.currentUser.role !== 'admin') {
    app.innerHTML = `<div class="panel"><div class="empty">AI extraction is only available to admin accounts.</div></div>`;
    return;
  }
  app.innerHTML = '';
  await renderAITab(app);
}

async function renderReviewPage(){
  const app = document.getElementById('app');
  if (window.currentUser.role !== 'admin') {
    app.innerHTML = `<div class="panel"><div class="empty">Report Reviews is only available to admin accounts.</div></div>`;
    return;
  }
  app.innerHTML = '';
  await renderReviewTab(app);
}

async function renderManualEntryPage(){
  const app = document.getElementById('app');
  if (window.currentUser.role !== 'admin') {
    app.innerHTML = `<div class="panel"><div class="empty">Report Manual Entry is only available to admin accounts.</div></div>`;
    return;
  }
  app.innerHTML = '';
  await renderReviewManual(app);
}

// Companies now only manage from here (the standalone Companies page
// was deleted per user's request - every other part of the app that
// used to link into it or into a per-company detail page now goes
// straight to that company's Survey Report instead, via
// goToCompanySurveyData()). Deliberately minimal - name, sector, and a
// delete button - not the old page's full filter/sort/column-picker
// table, since browsing/analyzing companies now happens from Survey
// Report's own company picker.
let settingsSelectedCompanyIds = new Set();
let settingsCompaniesList = [];

let settingsCoYear = '';            // '' = every year (Delete then removes whole companies)
let settingsCoData = {companies: [], years: []};
let settingsCoExpanded = new Set();

function jsStr(v){ return escapeHtml(String(v == null ? '' : v)).replace(/\\/g, '\\\\').replace(/'/g, "\\'"); }

async function renderSettingsCompaniesPanel(){
  const body = document.getElementById('settingsCompaniesBody');
  if (!body) return; // Companies tab isn't the active Settings tab right now - nothing to refresh
  let data = null;
  try {
    const res = await fetch('/api/companies/files');
    if (res.ok) data = await res.json();
  } catch (e) { /* fall back to the plain list below */ }
  if (!data) {
    const list = await (await fetch('/api/companies')).json();
    data = {companies: list.map(c => ({company_id: c.id, name: c.name, sector: c.sector, years: [], files: []})), years: []};
  }
  settingsCoData = data;
  if (settingsCoYear && !(data.years || []).includes(settingsCoYear)) settingsCoYear = '';
  const visible = settingsCoYear ? data.companies.filter(c => c.years.includes(settingsCoYear)) : data.companies;
  settingsCompaniesList = visible.map(c => ({id: c.company_id, name: c.name, sector: c.sector}));
  // Drop selections for companies that are no longer listed (just deleted, or hidden by the year filter)
  const live = new Set(settingsCompaniesList.map(c => c.id));
  settingsSelectedCompanyIds = new Set([...settingsSelectedCompanyIds].filter(id => live.has(id)));
  renderCompaniesActions();
  const sub = document.getElementById('settingsCoSub');
  if (sub) {
    const nFiles = data.companies.reduce((a, c) => a + (c.files || []).length, 0);
    sub.textContent = `${data.companies.length} ${data.companies.length === 1 ? 'company' : 'companies'} · ${nFiles} report file${nFiles === 1 ? '' : 's'} · ${(data.years || []).length} year${(data.years || []).length === 1 ? '' : 's'} of data`;
  }
  if (!visible.length) {
    body.innerHTML = settingsCoYear
      ? blEmpty('building', 'No companies for ' + settingsCoYear, 'No company has data for this year. Choose another year or All years.')
      : blEmpty('building', 'No companies yet', 'Upload an annual report or add a company to get started.', `<button onclick="openAddCompanyModal()">${blIcon('plus')}Add company</button>`);
    renderCompaniesToolbar();
    return;
  }
  body.innerHTML = `<div class="st-co-head"><span></span><span>Company</span><span>Years on file</span><span>Files</span><span style="text-align:right;">Actions</span></div>
    <div id="settingsCoRows">${visible.map(coCardHtml).join('')}</div>
    <div id="settingsCoNoMatch" style="display:none;">${blEmpty('search', 'No match', 'No company matches that search.')}</div>`;
  renderCompaniesToolbar();
  stFilterCompanies();
}

let settingsCoQuery = '';
function stFilterCompanies(){
  const q = settingsCoQuery.trim().toLowerCase();
  let shown = 0;
  document.querySelectorAll('#settingsCoRows .st-co').forEach(el => {
    const hit = !q || (el.dataset.search || '').includes(q);
    el.style.display = hit ? '' : 'none';
    if (hit) shown++;
  });
  const none = document.getElementById('settingsCoNoMatch');
  if (none) none.style.display = shown ? 'none' : 'block';
}

function coFileRowHtml(c, f){
  const fy = f.fiscal_year || '';
  const name = f.filename ? escapeHtml(f.filename) : 'Typed in manually (no report file)';
  const when = f.uploaded_at ? new Date(f.uploaded_at).toLocaleDateString('en-US', {year:'numeric', month:'short', day:'numeric'}) : '';
  const badges = [];
  if (f.has_survey) badges.push('<span class="co-badge">Survey</span>');
  if (f.has_financials) badges.push('<span class="co-badge">Financials</span>');
  if (f.text_stored) badges.push('<span class="co-badge ok">Report text stored</span>');
  if (f.scored_fields) badges.push(`<span class="co-badge ${f.reviewed_fields >= f.scored_fields ? 'ok' : 'warn'}">${f.reviewed_fields}/${f.scored_fields} reviewed</span>`);
  const canOpen = f.has_survey && fy;
  return `
    <div class="co-file">
      <div class="co-file-main ${canOpen ? 'clickable' : ''}" ${canOpen ? `onclick="goToCompanySurveyData(${c.company_id}, '${jsStr(fy)}')" title="Open this company's ${escapeHtml(fy)} survey report"` : ''}>
        <span class="co-file-name">${name}</span>
        <span class="co-file-meta">${fy ? `<b>${escapeHtml(fy)}</b>` : 'No year'}${when ? ' &middot; ' + when : ''}${f.pages ? ' &middot; ' + f.pages + ' pages' : ''}</span>
      </div>
      <div class="co-file-badges">${badges.join('')}</div>
      ${f.has_survey && f.scored_fields ? `<button class="secondary co-file-btn" onclick="openFieldReview(${c.company_id}, '${jsStr(fy)}')">Review</button>` : ''}
    </div>`;
}

function coCardHtml(c){
  const files = settingsCoYear ? c.files.filter(f => f.fiscal_year === settingsCoYear) : c.files;
  const open = settingsCoExpanded.has(c.company_id);
  const delLabel = settingsCoYear ? 'Delete ' + escapeHtml(settingsCoYear) + ' data' : 'Delete company';
  const delClick = settingsCoYear
    ? `deleteYearForCompanies([${c.company_id}], '${jsStr(settingsCoYear)}')`
    : `deleteCompany(${c.company_id}, '${jsStr(c.name)}')`;
  const sel = settingsSelectedCompanyIds.has(c.company_id);
  const years = (c.years || []).slice().sort();
  const yearsHtml = years.length ? years.map(y => `<span class="st-year">${escapeHtml(y)}</span>`).join('') : '<span class="bl-faint">No data yet</span>';
  return `
    <div class="st-co co-card ${sel ? 'selected' : ''}" id="stco_${c.company_id}" data-search="${escapeHtml(((c.name || '') + ' ' + (c.sector || '')).toLowerCase())}">
      <div class="st-co-row">
        <input type="checkbox" class="co-check st-check" data-id="${c.company_id}" ${sel ? 'checked' : ''} onchange="toggleCompanySelected(${c.company_id}, this.checked)" aria-label="Select ${escapeHtml(c.name)}">
        <div class="st-co-name">${blAvatar(c.name)}<div>
          <span class="bl-strong" onclick="goToCompanySurveyData(${c.company_id})" title="Open ${escapeHtml(c.name)}">${escapeHtml(c.name)}</span>
          <span class="bl-faint">${c.sector ? escapeHtml(c.sector) : 'No sector set'}</span></div></div>
        <div class="st-years">${yearsHtml}</div>
        <div><button class="st-co-files ${open ? 'open' : ''}" id="cochev_${c.company_id}" onclick="toggleCompanyFiles(${c.company_id})">${blIcon('chevron')}${files.length} file${files.length === 1 ? '' : 's'}</button></div>
        <div class="st-co-act">
          <button class="secondary sm" onclick="goToCompanySurveyData(${c.company_id})">Open</button>
          <div class="bl-menu" style="margin:0;"><button class="secondary sm bl-dots" onclick="blToggleMenu(event, this)" aria-label="More">⋯</button><div class="bl-menu-list">
            <button onclick="goToCompanySurveyData(${c.company_id})">Open survey report</button>
            <button onclick="toggleCompanyFiles(${c.company_id})">Show / hide files</button>
            <button class="danger" onclick="${delClick}">${delLabel}</button>
          </div></div>
        </div>
      </div>
      <div class="co-files" id="cof_${c.company_id}" style="display:${open ? 'block' : 'none'};">
        ${files.length ? files.map(f => coFileRowHtml(c, f)).join('')
          : `<div class="co-nofiles">No files on record${settingsCoYear ? ' for ' + escapeHtml(settingsCoYear) : ''}.</div>`}
      </div>
    </div>`;
}

function toggleCompanyFiles(id){
  if (settingsCoExpanded.has(id)) settingsCoExpanded.delete(id); else settingsCoExpanded.add(id);
  const box = document.getElementById('cof_' + id), chev = document.getElementById('cochev_' + id);
  if (box) box.style.display = settingsCoExpanded.has(id) ? 'block' : 'none';
  if (chev) chev.classList.toggle('open', settingsCoExpanded.has(id));
  document.querySelectorAll('.bl-menu.open').forEach(m => m.classList.remove('open'));
}

function setCompaniesYear(y){
  settingsCoYear = y || '';
  renderSettingsCompaniesPanel();
}

// Header actions: year selector + Add company. The delete actions live in the footer bar.
function renderCompaniesActions(){
  const el = document.getElementById('settingsCompaniesActions');
  if (!el) return;
  const y = settingsCoYear;
  const years = settingsCoData.years || [];
  el.innerHTML = `
    <select class="bl-input st-sel" onchange="setCompaniesYear(this.value)" aria-label="Year">
      <option value="">All years</option>
      ${years.map(v => `<option value="${escapeHtml(v)}" ${v === y ? 'selected' : ''}>${escapeHtml(v)}</option>`).join('')}
    </select>
    <button onclick="openAddCompanyModal()">${blIcon('plus')}Add company</button>`;
  const foot = document.getElementById('settingsCompaniesFoot');
  if (!foot) return;
  const n = settingsSelectedCompanyIds.size;
  const total = settingsCompaniesList.length;
  if (!total) { foot.innerHTML = ''; return; }
  foot.innerHTML = `<div class="st-foot">
    <span>${n ? `<b style="color:var(--text);">${n}</b> of ${total} selected` : `${total} ${total === 1 ? 'company' : 'companies'}${y ? ' with ' + escapeHtml(y) + ' data' : ''}`}</span>
    <div class="st-bulk">
      <button class="secondary sm bl-btn-outline-danger" ${n ? '' : 'disabled'} onclick="deleteSelectedCompanies()">${blIcon('trash')} ${y ? 'Delete ' + escapeHtml(y) + ' for selected' : 'Delete selected'}${n ? ` (${n})` : ''}</button>
      <button class="secondary sm" style="color:var(--red);" onclick="deleteAllCompanies()">${y ? 'Delete ' + escapeHtml(y) + ' for all' : 'Delete all'}</button>
    </div></div>`;
}

function renderCompaniesToolbar(){
  const bar = document.getElementById('settingsCompaniesToolbar');
  renderCompaniesActions();
  if (!bar) return;
  const total = settingsCompaniesList.length;
  const n = settingsSelectedCompanyIds.size;
  if (!total) { bar.style.display = 'none'; return; }
  bar.style.display = '';
  if (!bar.querySelector('#stCoSearch')) {
    bar.innerHTML = `
      <label class="bl-search">${blIcon('search')}<input id="stCoSearch" placeholder="Search companies or sectors" value="${escapeHtml(settingsCoQuery)}" oninput="settingsCoQuery=this.value;stFilterCompanies()"></label>
      <label class="co-selectall"><input type="checkbox" class="st-check" id="coSelectAll" onchange="toggleSelectAllCompanies(this.checked)"> Select all</label>`;
  }
  const all = document.getElementById('coSelectAll');
  if (all) { all.checked = n === total; all.indeterminate = n > 0 && n < total; }
  document.querySelectorAll('#settingsCoRows .st-co').forEach(el => {
    const id = +el.id.replace('stco_', '');
    el.classList.toggle('selected', settingsSelectedCompanyIds.has(id));
  });
}

// Delete ONE year of data for the chosen companies (ids = null means every company listed under that year).
async function deleteYearForCompanies(ids, year){
  const all = ids === null;
  const names = settingsCompaniesList.filter(c => all || ids.includes(c.id)).map(c => c.name);
  if (!names.length) return;
  const preview = names.slice(0, 6).join(', ') + (names.length > 6 ? `, and ${names.length - 6} more` : '');
  const what = `all ${year} data - survey values, directors, financial statements, report files and extraction traces -`;
  if (all) {
    const typed = prompt(`This permanently deletes ${what} for all ${names.length} companies that have it. The companies and their other years are kept. This can't be undone.\n\nType DELETE ALL to confirm.`);
    if (typed === null) return;
    if (typed.trim() !== 'DELETE ALL') { alert('Not deleted - you need to type DELETE ALL exactly.'); return; }
  } else if (!confirm(`Delete ${what} for ${preview}? The ${names.length === 1 ? 'company and its' : 'companies and their'} other years are kept. This can't be undone.`)) {
    return;
  }
  try {
    const res = await fetch('/api/companies/delete-year', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(all ? {fiscal_year: year, all: true} : {fiscal_year: year, ids})
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok && !(data.deleted && data.deleted.length)) {
      const firstErr = data.failed && data.failed[0] ? data.failed[0].error : '';
      alert(data.error || firstErr || `Delete failed (status ${res.status}).`);
      return;
    }
    const gone = (data.deleted || []).length;
    let msg = `Deleted ${year} for ${gone} ${gone === 1 ? 'company' : 'companies'}.`;
    if ((data.skipped || []).length) msg += ` ${data.skipped.length} had no ${year} data.`;
    if ((data.failed || []).length) msg += `\n${data.failed.length} could not be deleted:\n` + data.failed.map(f => `#${f.id}: ${f.error}`).join('\n');
    if (srCompanyId && (data.deleted || []).some(d => d.id === srCompanyId)) { srFiscalYear = null; srDataCache = null; }
    settingsSelectedCompanyIds = new Set();
    settingsStatusCache = null;
    if (data.failed && data.failed.length) alert(msg); else showToast(msg);
    await renderSettingsCompaniesPanel();
  } catch (err) {
    console.error('Delete year failed:', err);
    alert('Delete failed - check the browser console for details.');
  }
}

function toggleCompanySelected(id, on){
  if (on) settingsSelectedCompanyIds.add(id); else settingsSelectedCompanyIds.delete(id);
  renderCompaniesToolbar();
}
function toggleSelectAllCompanies(on){
  settingsSelectedCompanyIds = on ? new Set(settingsCompaniesList.map(c => c.id)) : new Set();
  document.querySelectorAll('.co-check').forEach(cb => { cb.checked = on; });
  renderCompaniesToolbar();
}

async function bulkDeleteCompanies(payload, confirmMsg){
  if (!confirm(confirmMsg)) return;
  try {
    const res = await fetch('/api/companies/bulk-delete', {
      method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok && !(data.deleted && data.deleted.length)) {
      const firstErr = data.failed && data.failed[0] ? data.failed[0].error : '';
      alert(data.error || firstErr || `Delete failed (status ${res.status}).`);
      return;
    }
    const gone = new Set(data.deleted || []);
    allCompaniesCache = allCompaniesCache.filter(c => !gone.has(c.id));
    if (gone.has(srCompanyId)) { srCompanyId = null; srFiscalYear = null; }
    settingsSelectedCompanyIds = new Set();
    if (data.failed && data.failed.length) {
      alert(`Deleted ${gone.size}. ${data.failed.length} could not be deleted:\n` +
            data.failed.map(f => `#${f.id}: ${f.error}`).join('\n'));
    }
    await renderSettingsCompaniesPanel();
  } catch (err) {
    console.error('Bulk delete failed:', err);
    alert('Delete failed — check the browser console for details.');
  }
}
function deleteSelectedCompanies(){
  const ids = [...settingsSelectedCompanyIds];
  if (!ids.length) return;
  if (settingsCoYear) { deleteYearForCompanies(ids, settingsCoYear); return; }
  const names = settingsCompaniesList.filter(c => settingsSelectedCompanyIds.has(c.id)).map(c => c.name);
  const preview = names.slice(0, 8).join(', ') + (names.length > 8 ? `, and ${names.length - 8} more` : '');
  bulkDeleteCompanies({ids}, `Delete ${ids.length} ${ids.length === 1 ? 'company' : 'companies'} (${preview}) and all of their saved data? This can't be undone.`);
}
function deleteAllCompanies(){
  const total = settingsCompaniesList.length;
  if (!total) return;
  if (settingsCoYear) { deleteYearForCompanies(null, settingsCoYear); return; }
  const typed = prompt(`This permanently deletes ALL ${total} companies and every survey, director, remuneration and import record attached to them. This can't be undone.\n\nType DELETE ALL to confirm.`);
  if (typed === null) return;
  if (typed.trim() !== 'DELETE ALL') { alert('Not deleted — you need to type DELETE ALL exactly.'); return; }
  bulkDeleteCompanies({all: true}, `Last check: delete all ${total} companies now?`);
}

// ---------------------------------------------------------------------------
// Finish Review - the page an admin lands on from a company's review progress on the Dashboard Overview.
// Lists every extracted field of one company + year that nobody has reviewed yet, with the value, how
// confident the reader was, the source sentence and (when the report text is stored) where the value is in
// the report, so each can be approved, corrected or rejected without opening the annual report.
// ---------------------------------------------------------------------------
let frCompanyId = null, frYear = null, frFilter = 'pending';
let frRow = null, frCompany = null, frYears = [], frCompanies = [], frExplain = {}, frSelected = new Set();

function openFieldReview(companyId, fiscalYear){
  if (window.currentUser.role !== 'admin') { goToCompanySurveyData(companyId); return; }
  frCompanyId = Number(companyId); frYear = fiscalYear || null; frFilter = 'pending'; frSelected = new Set();
  currentPage = 'field-review'; currentCompanyId = null;
  renderNav(); render(); closeSidebar();
}

function frBack(){ return `<span class="ov-panel-link tl-back" onclick="goTo('overview')">&larr; Back to Dashboard Overview</span>`; }

async function renderFieldReviewPage(){
  const app = document.getElementById('app');
  if (window.currentUser.role !== 'admin') {
    app.innerHTML = `<div class="panel"><div class="empty">Finishing a review is only available to admin accounts.</div></div>`;
    return;
  }
  if (!frCompanyId) { app.innerHTML = `${frBack()}<div class="panel"><div class="empty">Pick a company from the Dashboard Overview to review.</div></div>`; return; }
  frCompanies = await safeJson(await fetch('/api/survey/companies'), []);
  const entry = frCompanies.find(c => c.company_id === frCompanyId);
  if (!entry) { app.innerHTML = `${frBack()}<div class="panel"><div class="empty">This company has no survey data to review yet.</div></div>`; return; }
  frYears = (entry.fiscal_years || []).slice().sort().reverse();
  if (!frYear || !frYears.includes(frYear)) frYear = entry.latest_fiscal_year || frYears[0];
  await frLoad();
}

async function frLoad(){
  const app = document.getElementById('app');
  app.innerHTML = '<div class="empty">Loading...</div>';
  const fy = encodeURIComponent(frYear);
  const [r1, r2] = await Promise.all([
    fetch(`/api/survey/companies/${frCompanyId}/${fy}`),
    fetch(`/api/extraction-report/explain?company_id=${frCompanyId}&fiscal_year=${fy}`).catch(() => null),
  ]);
  const data = await safeJson(r1, null);
  if (!data) { app.innerHTML = `${frBack()}<div class="panel"><div class="empty">Could not load ${escapeHtml(frYear)} for this company.</div></div>`; return; }
  const ex = r2 ? await safeJson(r2, null) : null;
  frRow = data.survey_data; frCompany = data.company; frExplain = {};
  ((ex && ex.fields) || []).forEach(f => { frExplain[f.field] = f; });
  frDraw();
}

function frLabel(field){
  const m = MAPPING_FIELDS.find(x => x.field === field);
  return m ? m.label : field.replace(/_/g, ' ').replace(/^\w/, c => c.toUpperCase());
}
function frSectionOf(field){ const m = MAPPING_FIELDS.find(x => x.field === field); return m ? m.section : ''; }

function frStats(){
  const conf = frRow.field_confidence || {}, rev = frRow.field_review_status || {};
  const scored = Object.keys(conf);
  const pending = scored.filter(f => !(f in rev));
  const reviewed = scored.filter(f => f in rev);
  const missing = MAPPING_FIELDS.filter(m => (frRow[m.field] === null || frRow[m.field] === undefined) && !(m.field in conf)).map(m => m.field);
  return {scored, pending, reviewed, missing, pct: scored.length ? Math.round(reviewed.length / scored.length * 100) : 100};
}

function frConfPill(c){
  if (c === undefined || c === null) return '';
  const cls = c >= 0.75 ? 'fr-ok' : c >= 0.45 ? 'fr-warn' : 'fr-bad';
  const word = c >= 0.75 ? 'High' : c >= 0.45 ? 'Medium' : 'Low';
  return `<span class="${cls}" style="font-size:12px;font-weight:600;">${word} confidence (${c})</span>`;
}

function frEvidenceHtml(field){
  const ex = frExplain[field];
  if (!ex) return '';
  let h = '';
  if (ex.verified === true) h += `<div class="fr-ev"><span class="fr-ok">&#10004; Found in the report text</span></div>`;
  else if (ex.verified === false) h += `<div class="fr-ev"><span class="fr-warn">Not found word-for-word in the report text &mdash; the value was derived, so check the source above.</span></div>`;
  (ex.evidence || []).slice(0, 2).forEach(e => {
    h += `<div class="fr-ev"><b>Page ${escapeHtml(e.page)}</b> &ldquo;${escapeHtml(e.snippet)}&rdquo;</div>`;
  });
  if (ex.verified === null && !(ex.evidence || []).length && ex.reason && /not stored yet/.test(ex.reason)) {
    h += `<div class="fr-ev">The report text for this file is not stored yet, so there is no page evidence. Run Diagnose once on the Extraction report page.</div>`;
  }
  return h;
}

function frCardHtml(field, mode){
  const sd = frRow, label = escapeHtml(frLabel(field)), section = escapeHtml(frSectionOf(field));
  const conf = (sd.field_confidence || {})[field];
  const src = (sd.field_sources || {})[field];
  const val = mappingDisplayValue(sd, field);
  const valHtml = (val === null || val === undefined || val === '') ? '<span style="color:var(--text-faint);">No value</span>' : escapeHtml(val);
  if (mode === 'missing') {
    const ex = frExplain[field];
    return `<div class="fr-card missing">
      <div class="fr-top"><div><div class="fr-label">${label}</div><div class="fr-section">${section}</div></div><span class="fr-bad" style="font-size:12px;font-weight:600;">Not found</span></div>
      ${ex && ex.reason ? `<div class="fr-src">${escapeHtml(ex.reason)}</div>` : ''}
      ${frEvidenceHtml(field)}
      ${ex && ex.action ? `<div class="fr-src fr-warn">What to do: ${escapeHtml(ex.action)}</div>` : ''}
      <div class="fr-actions"><button class="secondary" onclick="goTo('manual-entry')">Enter in Manual Entry</button></div>
    </div>`;
  }
  if (mode === 'reviewed') {
    const st = (sd.field_review_status || {})[field];
    const corr = (sd.field_review_corrections || {})[field];
    const stTxt = st === 'rejected' ? '<span class="fr-bad">Rejected</span>' : corr ? '<span class="fr-warn">Corrected</span>' : '<span class="fr-ok">Approved</span>';
    return `<div class="fr-card reviewed">
      <div class="fr-top"><div><div class="fr-label">${label}</div><div class="fr-section">${section}</div></div><span style="font-size:12px;font-weight:600;">${stTxt}</span></div>
      <div class="fr-value">${valHtml}</div>
      ${corr ? `<div class="fr-src">Was ${escapeHtml(corr.extracted_value)} when extracted${corr.reviewed_by ? ' &middot; by ' + escapeHtml(corr.reviewed_by) : ''}.</div>` : ''}
    </div>`;
  }
  return `<div class="fr-card pending" id="frc_${field}">
    <div class="fr-top">
      <label class="fr-check">
        <input type="checkbox" ${frSelected.has(field) ? 'checked' : ''} onchange="frToggle('${field}', this.checked)">
        <span><span class="fr-label">${label}</span><span class="fr-section" style="display:block;">${section}</span></span>
      </label>
      ${frConfPill(conf)}
    </div>
    <div class="fr-value">${valHtml}</div>
    ${src ? `<div class="fr-src">Source: ${escapeHtml(src)}</div>` : ''}
    ${frEvidenceHtml(field)}
    <div class="fr-actions">
      <button class="btn-primary-cta" style="margin:0;" onclick="frAct('${field}','approve')">Approve</button>
      <button class="secondary" onclick="frCorrect('${field}')">Correct</button>
      <button class="secondary" style="color:var(--red);" onclick="frReject('${field}')">Reject</button>
    </div>
  </div>`;
}

function frDraw(){
  const app = document.getElementById('app');
  const st = frStats();
  const done = st.pending.length === 0;
  const chip = (id, label, n) => `<button class="tl-chip ${frFilter === id ? 'active' : ''}" onclick="frSetFilter('${id}')">${label} (${n})</button>`;
  const list = frFilter === 'pending' ? st.pending : frFilter === 'reviewed' ? st.reviewed : frFilter === 'missing' ? st.missing : st.pending.concat(st.reviewed, st.missing);
  const cards = (frFilter === 'all'
    ? st.pending.map(f => frCardHtml(f, 'pending')).concat(st.reviewed.map(f => frCardHtml(f, 'reviewed')), st.missing.map(f => frCardHtml(f, 'missing')))
    : list.map(f => frCardHtml(f, frFilter))).join('');
  const nextCo = frCompanies.find(c => c.company_id !== frCompanyId && c.review_status !== 'completed');
  const yearOpts = frYears.map(y => `<option value="${escapeHtml(y)}" ${y === frYear ? 'selected' : ''}>${escapeHtml(y)}</option>`).join('');
  const n = frSelected.size;
  app.innerHTML = `
    ${frBack()}
    <div class="panel fr-head">
      <div class="fr-title">
        <h2>${escapeHtml(frCompany ? frCompany.name : '')}${frCompany && frCompany.sector ? ` <span style="font-size:13px;color:var(--text-faint);font-weight:400;">&middot; ${escapeHtml(frCompany.sector)}</span>` : ''}</h2>
        <div class="fr-tools">
          <select onchange="frSwitchYear(this.value)">${yearOpts}</select>
          <button class="secondary" onclick="goToCompanySurveyData(${frCompanyId}, '${jsStr(frYear)}')">View survey report</button>
        </div>
      </div>
      <div class="fr-bar"><span class="${done ? 'done' : ''}" style="width:${st.pct}%;"></span></div>
      <div class="fr-sub">${st.reviewed.length} of ${st.scored.length} extracted fields reviewed (${st.pct}%)${st.missing.length ? ` &middot; ${st.missing.length} fields not found in the report` : ''}</div>
      <div class="tl-chips" style="margin:0;">
        ${chip('pending', 'Needs review', st.pending.length)}${chip('reviewed', 'Reviewed', st.reviewed.length)}${chip('missing', 'Not found', st.missing.length)}${chip('all', 'All', st.scored.length + st.missing.length)}
      </div>
      ${frFilter === 'pending' && st.pending.length ? `
      <div class="fr-tools">
        <button class="secondary" onclick="frSelectHigh()">Select high-confidence</button>
        <button class="secondary" onclick="frSelectAll()">Select all shown</button>
        <button class="btn-primary-cta" style="margin:0;" ${n ? '' : 'disabled'} onclick="frApproveSelected()">Approve selected${n ? ` (${n})` : ''}</button>
        <button class="secondary" onclick="frNext()">Jump to first</button>
      </div>` : ''}
    </div>
    ${done ? `<div class="fr-done"><span class="fr-ok"><b>Every extracted field for ${escapeHtml(frYear)} has been reviewed.</b></span>
      <span style="display:flex;gap:8px;flex-wrap:wrap;">
        ${nextCo ? `<button class="btn-primary-cta" style="margin:0;" onclick="openFieldReview(${nextCo.company_id})">Next: ${escapeHtml(nextCo.company_name)}</button>` : ''}
        <button class="secondary" onclick="goTo('overview')">Back to Overview</button></span></div>` : ''}
    ${cards || `<div class="panel" style="margin-top:10px;"><div class="empty">Nothing in this list.</div></div>`}`;
}

function frSetFilter(f){ frFilter = f; frDraw(); }
function frSwitchYear(y){ frYear = y; frSelected = new Set(); frLoad(); }
function frToggle(field, on){ if (on) frSelected.add(field); else frSelected.delete(field); frDraw(); }
function frSelectAll(){ frSelected = new Set(frStats().pending); frDraw(); }
function frSelectHigh(){
  const conf = frRow.field_confidence || {};
  frSelected = new Set(frStats().pending.filter(f => conf[f] >= 0.75 && frRow[f] !== null && frRow[f] !== undefined));
  frDraw();
}
function frNext(){ const el = document.querySelector('.fr-card.pending'); if (el) el.scrollIntoView({behavior: 'smooth', block: 'center'}); }

async function frAct(field, action, corrected){
  const body = {field, action};
  if (action === 'correct') body.corrected_value = corrected;
  const res = await fetch(`/api/survey-data/${frCompanyId}/${encodeURIComponent(frYear)}/review`, {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
  const out = await safeJson(res, null);
  if (out && out.ok) { frRow = {...frRow, ...out.survey_data}; frSelected.delete(field); frDraw(); }
  else showToast('Could not save that review - please try again.');
}
function frCorrect(field){
  const cur = frRow[field];
  const next = prompt('Corrected value:', cur === null || cur === undefined ? '' : cur);
  if (next === null || next.trim() === '') return;
  const num = Number(next);
  frAct(field, 'correct', Number.isNaN(num) ? next : num);
}
function frReject(field){
  if (!confirm(`Reject "${frLabel(field)}"? The value is cleared so nobody relies on it.`)) return;
  frAct(field, 'reject');
}
async function frApproveSelected(){
  const fields = [...frSelected];
  if (!fields.length) return;
  if (!confirm(`Approve ${fields.length} field${fields.length === 1 ? '' : 's'} as correct? Only do this for values you have checked.`)) return;
  const res = await fetch(`/api/survey-data/${frCompanyId}/${encodeURIComponent(frYear)}/review-bulk`, {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({fields})});
  const out = await safeJson(res, null);
  if (out && out.ok) {
    frRow = {...frRow, ...out.survey_data}; frSelected = new Set();
    if ((out.skipped || []).length) showToast(`${out.approved.length} approved; ${out.skipped.length} skipped (no value).`);
    frDraw();
  } else showToast('Could not approve those fields - please try again.');
}

// Import Activity - inlined here from the old standalone Reports page
// (deleted per user's request), same data (/api/import-jobs), same
// admin-only extraction-score column.
let stActJobs = [], stActFilter = 'all', stActQuery = '';
const ST_ACT_STATUS = {saved:['green', 'Saved'], failed:['red', 'Failed'], pending:['amber', 'Pending'], parsed:['blue', 'Parsed'], reviewed:['blue', 'Reviewed']};
function stActPill(st){
  const [tone, label] = ST_ACT_STATUS[st] || ['faint', st || 'Unknown'];
  return `<span class="bl-pill bl-${tone}">${escapeHtml(label)}</span>`;
}
function stWhen(iso){
  if (!iso) return '<span class="bl-faint">-</span>';
  const d = new Date(iso + (/[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? '' : 'Z'));
  return `${d.toLocaleDateString('en-GB', {day:'numeric', month:'short', year:'numeric'})}<div class="bl-faint">${d.toLocaleTimeString('en-GB', {hour:'2-digit', minute:'2-digit'})}</div>`;
}
function stDuration(a, b){
  if (!a || !b) return '';
  const s = Math.max(0, (new Date(b) - new Date(a)) / 1000);
  return s < 60 ? `${Math.round(s)}s` : s < 3600 ? `${Math.round(s / 60)} min` : `${(s / 3600).toFixed(1)} h`;
}
function stScore(j){
  if (j.extraction_score === null || j.extraction_score === undefined) return '<span class="bl-faint">Not scored</span>';
  const v = Math.round(j.extraction_score), low = j.extraction_score_low;
  const col = low ? 'var(--red)' : v >= 85 ? 'var(--green)' : 'var(--amber)';
  return `<div class="st-score" ${low ? 'title="Below the extraction-quality threshold - consider re-uploading after a parser fix"' : ''}><div class="st-score-bar"><i style="width:${Math.min(100, v)}%;background:${col};"></i></div><span class="bl-mono" style="color:${col};font-weight:600;">${v}</span></div>`;
}
async function renderSettingsActivityPanel(){
  const body = document.getElementById('settingsActivityBody');
  if (!body) return; // Import Activity tab isn't the active Settings tab right now - nothing to refresh
  const res = await fetch('/api/import-jobs');
  stActJobs = await res.json();
  const jobs = stActJobs;
  const n = s => jobs.filter(j => j.status === s).length;
  const scored = jobs.filter(j => j.extraction_score != null);
  const avg = scored.length ? Math.round(scored.reduce((a, j) => a + j.extraction_score, 0) / scored.length) : null;
  const low = jobs.filter(j => j.extraction_score_low).length;
  const isAdmin = jobs.some(j => 'extraction_score' in j);
  body.innerHTML = `
    <div class="bl-stats">
      ${stStat('upload', 'blue', 'Imports', stNum(jobs.length), 'Latest 200 uploads and manual entries')}
      ${stStat('check', 'green', 'Saved', stNum(n('saved')), jobs.length ? Math.round(n('saved') / jobs.length * 100) + '% of imports' : '')}
      ${stStat('alert', 'red', 'Failed', stNum(n('failed')), n('failed') ? 'See the error on each row' : 'No failed imports')}
      ${isAdmin ? stStat('trend', 'amber', 'Average extraction score', avg == null ? '<span class="bl-faint">-</span>' : avg + '<span class="bl-faint" style="font-size:13px;font-weight:500;"> / 100</span>', low ? `${low} below the quality threshold` : `${scored.length} scored report${scored.length === 1 ? '' : 's'}`)
        : stStat('clock', 'amber', 'In progress', stNum(n('pending') + n('parsed') + n('reviewed')), 'Not saved yet')}
    </div>
    <div class="panel bl-flush">
      <div class="bl-card-head padded" style="margin-bottom:12px;"><div><div class="bl-card-title">Import activity</div><div class="st-sub">Every scan, parse and save attempt, newest first.</div></div></div>
      ${jobs.length ? `<div class="st-toolbar" style="border-top:1px solid var(--border);">
        <label class="bl-search">${blIcon('search')}<input placeholder="Search company or period" value="${escapeHtml(stActQuery)}" oninput="stActQuery=this.value;stRenderActivityRows()"></label>
        <div class="st-seg" id="stActSeg"></div></div>
      <div id="stActTable"></div>` : blEmpty('upload', 'No import activity yet', 'Each report upload or manual entry is listed here with its status and extraction score.')}
    </div>`;
  if (jobs.length) stRenderActivityRows();
}
function stRenderActivityRows(){
  const box = document.getElementById('stActTable'), seg = document.getElementById('stActSeg');
  if (!box) return;
  const jobs = stActJobs;
  const groups = [['all', 'All', jobs.length], ['saved', 'Saved', jobs.filter(j => j.status === 'saved').length],
                  ['failed', 'Failed', jobs.filter(j => j.status === 'failed').length],
                  ['open', 'In progress', jobs.filter(j => !['saved', 'failed'].includes(j.status)).length]];
  seg.innerHTML = groups.filter(g => g[0] === 'all' || g[2]).map(([k, l, c]) => `<button class="${stActFilter === k ? 'active' : ''}" onclick="stActFilter='${k}';stRenderActivityRows()">${l}<span>${c}</span></button>`).join('');
  const q = stActQuery.trim().toLowerCase();
  const list = jobs.filter(j => (stActFilter === 'all' || (stActFilter === 'open' ? !['saved', 'failed'].includes(j.status) : j.status === stActFilter))
    && (!q || `${j.company_name || ''} ${j.period_label || ''}`.toLowerCase().includes(q)));
  const isAdmin = jobs.some(j => 'extraction_score' in j);
  if (!list.length) { box.innerHTML = blEmpty('search', 'Nothing to show', 'No import matches this filter.'); return; }
  box.innerHTML = `<div class="bl-table-wrap"><table class="bl-table"><thead><tr><th>Company</th><th>Period</th><th>Status</th><th>Started</th><th>Took</th><th>Source</th>${isAdmin ? '<th>Extraction score</th>' : ''}</tr></thead><tbody>
    ${list.map(j => `<tr>
      <td><div class="st-user">${blAvatar(j.company_name || '?', 'sm')}<div>${j.company_name ? `<span class="bl-strong bl-linkish" style="cursor:pointer;" onclick="goToCompanySurveyData(${j.company_id})">${escapeHtml(j.company_name)}</span>` : '<span class="bl-faint">No company</span>'}
        ${j.error_message ? `<div class="st-err" title="${escapeHtml(j.error_message)}">${escapeHtml(j.error_message)}</div>` : ''}</div></div></td>
      <td class="nw">${j.period_label ? `<span class="st-year">${escapeHtml(j.period_label)}</span>` : '<span class="bl-faint">-</span>'}</td>
      <td>${stActPill(j.status)}</td>
      <td class="nw">${stWhen(j.started_at)}</td>
      <td class="nw bl-faint">${stDuration(j.started_at, j.finished_at) || '-'}</td>
      <td class="nw">${j.source_url ? `<a class="st-link" href="${escapeHtml(j.source_url)}" target="_blank" rel="noopener">${blIcon('doc')}PDF</a>` : '<span class="bl-faint">Manual entry</span>'}</td>
      ${isAdmin ? `<td>${stScore(j)}</td>` : ''}
    </tr>`).join('')}</tbody></table></div>
    ${list.length > 0 ? `<div class="st-foot"><span>Showing ${list.length} of ${jobs.length}</span></div>` : ''}`;
}

// ---------- Settings › Enquiries (super admin): messages from the website's Contact page ----------
let enqData = {enquiries: [], counts: {}}, enqFilter = 'new';
const ENQ_STATUS = {new: ['amber', 'New'], replied: ['blue', 'Replied'], closed: ['faint', 'Closed']};
async function renderEnquiriesPanel(){
  const body = document.getElementById('settingsEnquiriesBody');
  if (!body) return;
  try { enqData = await blGet('/api/admin/enquiries'); }
  catch (e) { body.innerHTML = `<div class="panel">${blEmpty('alert', 'Could not load enquiries', escapeHtml(e.message))}</div>`; return; }
  const c = enqData.counts || {};
  const total = (c.new || 0) + (c.replied || 0) + (c.closed || 0);
  if (enqFilter !== 'all' && !c[enqFilter] && total) enqFilter = 'all';
  const list = enqData.enquiries.filter(e => enqFilter === 'all' || e.status === enqFilter);
  body.innerHTML = `
    <div class="bl-stats">
      ${stStat('inbox', 'amber', 'New', stNum(c.new || 0), 'Waiting for a reply')}
      ${stStat('check', 'blue', 'Replied', stNum(c.replied || 0), 'Answered, still open')}
      ${stStat('clock', 'green', 'Closed', stNum(c.closed || 0), 'Done')}
      ${stStat('users', 'red', 'All enquiries', stNum(total), 'From the website Contact page')}
    </div>
    <div class="panel bl-flush">
      <div class="bl-card-head padded" style="margin-bottom:12px;flex-wrap:wrap;"><div><div class="bl-card-title">Enquiries</div>
        <div class="st-sub">Each message is also emailed to your contact address, and the sender gets an automatic acknowledgement.</div></div>
        <div class="st-seg">${[['new', 'New'], ['replied', 'Replied'], ['closed', 'Closed'], ['all', 'All']].map(([k, l]) =>
          `<button class="${enqFilter === k ? 'active' : ''}" onclick="enqFilter='${k}';renderEnquiriesPanel()">${l}<span>${k === 'all' ? total : (c[k] || 0)}</span></button>`).join('')}</div></div>
      ${list.length ? `<div class="bl-table-wrap"><table class="bl-table"><thead><tr><th>From</th><th>Topic and message</th><th>Received</th><th>Status</th><th></th></tr></thead><tbody>
        ${list.map(e => `<tr class="bl-click" onclick="enqOpen(${e.id})">
          <td><div class="st-user">${blAvatar(e.name)}<div><span class="bl-strong">${escapeHtml(e.name)}</span><div class="bl-faint">${escapeHtml(e.email)}</div>
            ${e.organisation || e.phone ? `<div class="bl-faint">${escapeHtml([e.organisation, e.phone].filter(Boolean).join(' · '))}</div>` : ''}</div></div></td>
          <td style="max-width:420px;"><span class="bl-strong">${escapeHtml(e.topic || 'Enquiry')}</span><div class="bl-faint enq-preview">${escapeHtml(e.message)}</div></td>
          <td class="nw">${stWhen(e.created_at)}</td>
          <td><span class="bl-pill bl-${ENQ_STATUS[e.status][0]}">${ENQ_STATUS[e.status][1]}</span>${e.note ? `<div class="bl-faint" title="${escapeHtml(e.note)}">📝 note</div>` : ''}</td>
          <td class="bl-actions" onclick="event.stopPropagation()"><a class="secondary sm st-mail-btn" href="mailto:${escapeHtml(e.email)}?subject=${encodeURIComponent('Re: ' + (e.topic || 'your enquiry'))}" onclick="enqSet(${e.id}, 'replied', true)">Reply</a></td>
        </tr>`).join('')}</tbody></table></div>`
        : blEmpty('inbox', enqFilter === 'new' ? 'No new enquiries' : 'Nothing here', total ? 'Choose another filter to see older enquiries.' : 'Messages sent from the Contact page of your website appear here.')}
    </div>`;
}
function enqOpen(id){
  const e = enqData.enquiries.find(x => x.id === id);
  if (!e) return;
  blModal({title: e.topic || 'Enquiry', wide: true,
    intro: `<div class="enq-from"><b>${escapeHtml(e.name)}</b> · <a href="mailto:${escapeHtml(e.email)}">${escapeHtml(e.email)}</a>${e.phone ? ` · <a href="tel:${escapeHtml(e.phone)}">${escapeHtml(e.phone)}</a>` : ''}${e.organisation ? ` · ${escapeHtml(e.organisation)}` : ''}
      <div class="bl-faint">Received ${stWhen(e.created_at).replace('<div class="bl-faint">', ' at ').replace('</div>', '')}</div></div>
      <div class="enq-msg">${escapeHtml(e.message)}</div>
      <a class="st-mail-btn" style="display:inline-flex;margin-top:12px;" href="mailto:${escapeHtml(e.email)}?subject=${encodeURIComponent('Re: ' + (e.topic || 'your enquiry'))}">Reply by email</a>`,
    fields: [{name: 'status', label: 'Status', type: 'select', value: e.status, options: [['new', 'New'], ['replied', 'Replied'], ['closed', 'Closed']]},
             {name: 'note', label: 'Internal note', type: 'textarea', value: e.note || '', placeholder: 'Only staff see this', full: true}],
    submitLabel: 'Save',
    onSubmit: async v => {
      const res = await fetch(`/api/admin/enquiries/${id}`, {method: 'PATCH', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(v)});
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || 'Could not save.');
      showToast('Enquiry updated.');
      await renderEnquiriesPanel();
    }});
}
async function enqSet(id, status, quiet){
  const e = enqData.enquiries.find(x => x.id === id);
  if (!e || e.status !== 'new') return;
  await fetch(`/api/admin/enquiries/${id}`, {method: 'PATCH', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({status})});
  setTimeout(renderEnquiriesPanel, 300);
}

// ---------- Settings › Emails (super admin): email set-up, contact details and every email the app sent ----------
const MAIL_KIND = {verify: 'Confirm email', reset: 'Password reset', invite: 'Invitation', password_changed: 'Password changed',
  enquiry: 'Enquiry to you', enquiry_ack: 'Enquiry receipt', test: 'Test'};
const MAIL_STATUS = {sent: ['green', 'Sent'], failed: ['red', 'Failed'], not_configured: ['amber', 'Not sent: email not set up']};
async function renderEmailsPanel(){
  const body = document.getElementById('settingsEmailsBody');
  if (!body) return;
  let d;
  try { d = await blGet('/api/admin/mail'); }
  catch (e) { body.innerHTML = `<div class="panel">${blEmpty('alert', 'Could not load', escapeHtml(e.message))}</div>`; return; }
  const c = d.contact || {};
  const row = (label, val, secret) => `<div class="mail-row"><span class="bl-faint">${label}</span><span>${val ? escapeHtml(val) : '<span class="bl-warn">Not set</span>'}</span><code>${secret}</code></div>`;
  body.innerHTML = `
    <div class="bl-grid-2">
      <div class="panel ${d.configured ? '' : 'bl-setup-card'}">
        <div class="bl-card-head"><div><div class="bl-card-title">Sending email</div>
          <div class="st-sub">${d.configured ? `Emails go out from <b style="color:var(--text);">${escapeHtml(d.sender)}</b> through ${escapeHtml(d.host)}:${escapeHtml(String(d.port))}.`
            : 'Not set up yet. Until it is, sign-up links, password resets and invitations are not emailed: they are listed below for you to pass on.'}</div></div>
          <span class="bl-pill bl-${d.configured ? 'green' : 'amber'}">${d.configured ? 'Connected' : 'Not set up'}</span></div>
        ${d.configured ? '' : `<div class="st-sub" style="color:var(--text-dim);line-height:1.7;">Add these in Replit › Tools › Secrets, then restart the app:<br>
          <code>MAIL_HOST</code> e.g. smtp.zoho.com · <code>MAIL_PORT</code> 465 or 587 · <code>MAIL_USERNAME</code> the mailbox ·
          <code>MAIL_PASSWORD</code> its (app) password · <code>MAIL_FROM</code> e.g. Remuneration Practice &lt;info@yourdomain.co.ke&gt;</div>`}
        <div class="mail-test"><input class="bl-input" id="mailTestTo" type="email" placeholder="Send a test email to…" value="${escapeHtml(window.currentUser.email || '')}">
          <button class="secondary" onclick="mailTest(this)">Send test</button></div>
        <div id="mailTestOut" class="st-sub" style="margin-top:8px;"></div>
        <div class="st-sub" style="margin-top:10px;">New sign-ups must confirm their email: <b style="color:var(--text);">${d.verification_required ? 'Yes' : 'No (EMAIL_VERIFICATION=off)'}</b></div>
      </div>
      <div class="panel">
        <div class="bl-card-head"><div><div class="bl-card-title">Contact details</div><div class="st-sub">Shown on the website, in emails and on invoices. Change them in Secrets.</div></div></div>
        ${row('Email', c.email, 'CONTACT_EMAIL')}${row('Phone', c.phone, 'CONTACT_PHONE')}${row('WhatsApp', c.whatsapp ? '+' + c.whatsapp : '', 'CONTACT_WHATSAPP')}
        ${row('Address', c.address, 'CONTACT_ADDRESS')}${row('Office hours', c.hours, 'CONTACT_HOURS')}
      </div>
    </div>
    <div class="panel bl-flush">
      <div class="bl-card-head padded" style="margin-bottom:12px;"><div><div class="bl-card-title">Emails sent</div><div class="st-sub">The latest 200. Click one to read it, including any link inside.</div></div>
        <span class="bl-faint">${stNum(d.counts.sent)} sent · ${stNum(d.counts.failed)} failed · ${stNum(d.counts.not_configured)} not sent</span></div>
      ${d.emails.length ? `<div class="bl-table-wrap"><table class="bl-table"><thead><tr><th>To</th><th>Subject</th><th>Type</th><th>Status</th><th>When</th></tr></thead><tbody>
        ${d.emails.map(m => `<tr class="bl-click" onclick="mailOpen(${m.id})"><td class="bl-strong">${escapeHtml(m.to)}</td><td>${escapeHtml(m.subject)}</td>
          <td class="nw"><span class="bl-tag" style="margin:0;">${escapeHtml(MAIL_KIND[m.kind] || m.kind || '-')}</span></td>
          <td class="nw"><span class="bl-pill bl-${(MAIL_STATUS[m.status] || ['faint'])[0]}" ${m.error ? `title="${escapeHtml(m.error)}"` : ''}>${(MAIL_STATUS[m.status] || [0, m.status])[1]}</span></td>
          <td class="nw">${stWhen(m.created_at)}</td></tr>`).join('')}</tbody></table></div>`
        : blEmpty('inbox', 'No emails yet', 'Confirmation links, password resets, invitations and enquiry emails are listed here.')}
    </div>`;
}
async function mailOpen(id){
  let m;
  try { m = await blGet(`/api/admin/mail/${id}`); } catch (e) { return; }
  const text = escapeHtml(m.body_text || '').replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
  blModal({title: m.subject, wide: true,
    intro: `<div class="bl-faint">To ${escapeHtml(m.to)} · ${(MAIL_STATUS[m.status] || [0, m.status])[1]}${m.error ? ' · ' + escapeHtml(m.error) : ''}</div><div class="enq-msg">${text}</div>
      ${m.status !== 'sent' ? '<div class="bl-faint" style="margin-top:8px;">Links are personal: only pass one to the person it was meant for.</div>' : ''}`,
    submitLabel: 'Close', onSubmit: async () => {}});
}
async function mailTest(btn){
  const out = document.getElementById('mailTestOut');
  btn.disabled = true; out.textContent = 'Sending…';
  const res = await fetch('/api/admin/mail/test', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({to: document.getElementById('mailTestTo').value})});
  const d = await res.json().catch(() => ({}));
  btn.disabled = false;
  out.innerHTML = !res.ok ? `<span class="bl-neg">${escapeHtml(d.error || 'Failed.')}</span>`
    : d.status === 'sent' ? '<span class="bl-ok">Sent. Check that inbox (and its spam folder).</span>'
    : d.status === 'failed' ? `<span class="bl-neg">Could not send: ${escapeHtml(d.error || '')}</span>` : '<span class="bl-warn">Not sent: email is not set up yet.</span>';
  renderEmailsPanel();
}

// ---------- User Management (Settings, admin only - the route itself
// is also require_role('admin')-gated in app.py, so this panel never
// even loads for a non-admin who reaches this far) ----------
let umUsers = [], umQuery = '';
async function renderUserManagementPanel(){
  const body = document.getElementById('userManagementBody');
  if (!body) return;
  if (!window.currentUser.is_super_admin) {
    body.innerHTML = `<div class="panel">${blEmpty('shield', 'Super admins only', 'Only a super admin can manage user accounts.')}</div>`;
    return;
  }
  try {
    const res = await fetch('/api/users');
    umUsers = await safeJson(res, []);
  } catch (e) { umUsers = []; }
  const admins = umUsers.filter(u => u.role === 'admin').length;
  const supers = umUsers.filter(u => u.is_super_admin).length;
  const mfa = umUsers.filter(u => u.mfa_enabled).length;
  const orgs = new Set(umUsers.map(u => (u.organization || '').trim().toLowerCase()).filter(Boolean)).size;
  body.innerHTML = `
    <div class="bl-stats">
      ${stStat('users', 'blue', 'Accounts', stNum(umUsers.length), `${orgs} organisation${orgs === 1 ? '' : 's'}`)}
      ${stStat('shield', 'amber', 'Admins', stNum(admins), `${supers} super admin${supers === 1 ? '' : 's'}`)}
      ${stStat('users', 'green', 'Users', stNum(umUsers.length - admins), 'Read-only access to reports')}
      ${stStat('key', 'red', 'Two-step sign-in', stNum(mfa), umUsers.length ? `${Math.round(mfa / umUsers.length * 100)}% of accounts` : '')}
    </div>
    <div class="panel bl-flush">
      <div class="bl-card-head padded" style="flex-wrap:wrap;margin-bottom:12px;">
        <div><div class="bl-card-title">User accounts</div><div class="st-sub">Change roles, reset passwords and remove accounts.</div></div>
        <div class="bl-head-act"><button onclick="umOpenCreate()">${blIcon('plus')}Create account</button></div>
      </div>
      <div class="st-toolbar" style="border-top:1px solid var(--border);">
        <label class="bl-search">${blIcon('search')}<input placeholder="Search name, email or organisation" value="${escapeHtml(umQuery)}" oninput="umQuery=this.value;umRenderRows()"></label>
      </div>
      <div id="umRows"></div>
    </div>`;
  umRenderRows();
}
function umRenderRows(){
  const box = document.getElementById('umRows');
  if (!box) return;
  const q = umQuery.trim().toLowerCase();
  const list = umUsers.filter(u => !q || `${u.name} ${u.email} ${u.organization || ''} ${u.job_title || ''}`.toLowerCase().includes(q));
  if (!umUsers.length) { box.innerHTML = blEmpty('users', 'No accounts yet', 'Create the first account for a colleague or client.', `<button onclick="umOpenCreate()">${blIcon('plus')}Create account</button>`); return; }
  if (!list.length) { box.innerHTML = blEmpty('search', 'No match', 'No account matches that search.'); return; }
  const me = window.currentUser.id;
  box.innerHTML = `<div class="bl-table-wrap"><table class="bl-table"><thead><tr><th>Name</th><th>Organisation</th><th>Role</th><th>Security</th><th>Joined</th><th></th></tr></thead><tbody>
    ${list.map(u => {
      const nm = jsStr(u.name);
      return `<tr>
      <td><div class="st-user">${blAvatar(u.name)}<div><span class="bl-strong bl-linkish" style="cursor:pointer;" title="Edit account" onclick="umEditUser(${u.id})">${escapeHtml(u.name)}</span>${u.id === me ? '<span class="bl-tag">You</span>' : ''}<div class="bl-faint" title="${escapeHtml(u.email)}">${escapeHtml(u.email)}</div></div></div></td>
      <td>${u.organization ? escapeHtml(u.organization) : '<span class="bl-faint">-</span>'}${u.job_title ? `<div class="bl-faint">${escapeHtml(u.job_title)}</div>` : ''}</td>
      <td class="nw"><select class="bl-input st-sel" onchange="umChangeRole(${u.id}, this.value)" aria-label="Role for ${escapeHtml(u.name)}">
          <option value="user" ${u.role === 'user' ? 'selected' : ''}>User</option>
          <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option>
        </select>${u.is_super_admin ? '<span class="bl-pill bl-amber" style="margin-left:8px;">Super admin</span>' : ''}</td>
      <td class="nw">${u.email_verified === false ? `<span class="bl-pill bl-amber" title="The person has not clicked the confirmation or invitation link yet">Email not confirmed</span>`
        : u.mfa_enabled ? `<span class="bl-pill bl-green">2-step on</span>` : `<span class="bl-pill bl-faint">Password only</span>`}</td>
      <td class="nw bl-faint">${u.created_at ? new Date(u.created_at + (/[zZ]$/.test(u.created_at) ? '' : 'Z')).toLocaleDateString('en-GB', {day:'numeric', month:'short', year:'numeric'}) : '-'}</td>
      <td class="bl-actions"><div class="bl-menu"><button class="secondary sm bl-dots" onclick="blToggleMenu(event, this)" aria-label="More">⋯</button><div class="bl-menu-list">
        <button onclick="umEditUser(${u.id})">Edit account</button>
        <button onclick="umEmailLink(${u.id}, 'send-reset', '${nm}')">Email a password reset link</button>
        <button onclick="umResetPassword(${u.id}, '${nm}')">Set a password myself</button>
        ${u.email_verified === false ? `<button onclick="umEmailLink(${u.id}, 'send-invite', '${nm}')">Send the invitation again</button>
          <button onclick="umMarkVerified(${u.id})">Mark email as confirmed</button>` : ''}
        ${u.role === 'admin' ? `<button onclick="umToggleSuper(${u.id}, ${u.is_super_admin ? 'false' : 'true'})">${u.is_super_admin ? 'Remove super admin' : 'Make super admin'}</button>` : ''}
        ${u.id !== me ? `<button class="danger" onclick="umDeleteUser(${u.id}, '${nm}')">Delete account</button>` : ''}
      </div></div></td></tr>`; }).join('')}
  </tbody></table></div>
  <div class="st-foot"><span>Showing ${list.length} of ${umUsers.length} account${umUsers.length === 1 ? '' : 's'}</span></div>`;
}

async function umToggleSuper(userId, on){
  const res = await fetch(`/api/users/${userId}/super-admin`, {method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify({is_super_admin: on})});
  const d = await res.json().catch(() => ({}));
  if (!res.ok) { alert(d.error || 'Could not change super admin status.'); return; }
  showToast(on ? 'Made super admin.' : 'Super admin removed.');
  await renderUserManagementPanel();
}

async function umChangeRole(userId, role){
  try {
    const res = await fetch(`/api/users/${userId}/role`, {
      method: 'PATCH', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({role}),
    });
    const data = await res.json();
    if (!res.ok) { alert(data.error || 'Could not update role.'); }
    else showToast('Role updated.');
    await renderUserManagementPanel();
  } catch (e) { alert('Could not update role.'); await renderUserManagementPanel(); }
}

function umResetPassword(userId, name){
  blModal({title: 'Reset password', intro: `Set a new password for <b>${escapeHtml(name)}</b>. Share it with them privately; they can change it after signing in.`,
    fields: [{name: 'password', label: 'New password', type: 'password', required: true, full: true, hint: 'At least 6 characters.'}],
    submitLabel: 'Reset password',
    onSubmit: async v => {
      const res = await fetch(`/api/users/${userId}/reset-password`, {
        method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({password: v.password})});
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Could not reset password.');
      showToast(`Password reset for ${name}.`);
    }});
}

function umDeleteUser(userId, name){
  blConfirm('Delete account', `Delete the account for <b>${escapeHtml(name)}</b>? They will no longer be able to sign in. This can't be undone.`, 'Delete account', async () => {
    const res = await fetch(`/api/users/${userId}`, {method: 'DELETE'});
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Could not delete account.');
    showToast(`Deleted ${name}.`);
    await renderUserManagementPanel();
  });
}

function umEditUser(userId){
  const u = umUsers.find(x => x.id === userId);
  if (!u) return;
  blModal({title: 'Edit account', intro: `Update <b>${escapeHtml(u.name)}</b>'s details. They sign in with the new email from now on; their password stays the same.`, wide: true,
    fields: [
      {name: 'name', label: 'Full name', value: u.name, required: true},
      {name: 'email', label: 'Email (used to sign in)', type: 'email', value: u.email, required: true},
      {name: 'organization', label: 'Organisation / company', value: u.organization || ''},
      {name: 'job_title', label: 'Job title', value: u.job_title || ''},
      {name: 'phone', label: 'Phone', value: u.phone || '', full: true},
    ],
    submitLabel: 'Save changes',
    onSubmit: async v => {
      const res = await fetch(`/api/users/${userId}`, {method: 'PATCH', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(v)});
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Could not save the changes.');
      if (userId === window.currentUser.id) { window.currentUser.name = data.name; window.currentUser.email = data.email; }
      showToast(`Saved ${data.name}'s details.`);
      await renderUserManagementPanel();
    }});
}

// Email a reset / invitation link. When email is not set up (or failed), show the link so it can be passed on by hand.
function umShowLinkResult(r, name, what){
  if (r.status === 'sent') { showToast(`Emailed the ${what} link to ${name}.`); return; }
  blModal({title: r.status === 'failed' ? 'The email could not be sent' : 'Email is not set up yet',
    intro: `${r.status === 'failed' ? 'Sending failed (see Settings › Emails for the reason).' : 'Add the MAIL_ secrets to send emails automatically (Settings › Emails).'}
      Send this ${what} link to <b>${escapeHtml(name)}</b> yourself, for example on WhatsApp. It is personal: anyone with it can set the password.
      <div style="margin-top:12px;display:flex;gap:8px;"><input class="bl-input" id="umLink" readonly value="${escapeHtml(r.link || '')}" onclick="this.select()">
      <button class="secondary sm" onclick="navigator.clipboard && navigator.clipboard.writeText(document.getElementById('umLink').value);showToast('Link copied.')">Copy</button></div>`,
    submitLabel: 'Done', onSubmit: async () => {}});
}
async function umEmailLink(userId, kind, name){
  const res = await fetch(`/api/users/${userId}/${kind}`, {method: 'POST'});
  const d = await res.json().catch(() => ({}));
  if (!res.ok) { alert(d.error || 'Could not send the link.'); return; }
  umShowLinkResult(d, name, kind === 'send-invite' ? 'invitation' : 'password reset');
}
async function umMarkVerified(userId){
  const res = await fetch(`/api/users/${userId}/verify-email`, {method: 'POST'});
  if (!res.ok) { alert('Could not update the account.'); return; }
  showToast('Email marked as confirmed.');
  await renderUserManagementPanel();
}

function umOpenCreate(){
  blModal({title: 'Create account', intro: 'The new person signs in with this email and password.', wide: true,
    fields: [
      {name: 'name', label: 'Full name', required: true},
      {name: 'email', label: 'Email', type: 'email', required: true},
      {name: 'organization', label: 'Organisation / company', required: true},
      {name: 'job_title', label: 'Job title', required: true},
      {name: 'role', label: 'Role', type: 'select', value: 'user', options: [['user', 'User - reads reports'], ['admin', 'Admin - uploads and manages data']]},
      {name: 'password', label: 'Password (optional)', type: 'password', hint: 'Leave empty and we email them a link to choose their own (recommended). Or type one (at least 6 characters) to share yourself.'},
    ],
    submitLabel: 'Create account',
    onSubmit: async v => {
      const res = await fetch('/api/users', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(v)});
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Could not create account.');
      await renderUserManagementPanel();
      if (data.invite) setTimeout(() => umShowLinkResult(data.invite, v.name, 'invitation'), 50);
      else showToast(`Account created for ${v.name}.`);
    }});
}

async function umCreateUser(){
  const name = document.getElementById('um-name').value.trim();
  const email = document.getElementById('um-email').value.trim();
  const password = document.getElementById('um-password').value;
  const role = document.getElementById('um-role').value;
  const organization = document.getElementById('um-organization').value.trim();
  const job_title = document.getElementById('um-job-title').value.trim();
  const errEl = document.getElementById('um-error');
  errEl.textContent = '';
  if (!name || !email || !password || !organization || !job_title) {
    errEl.textContent = 'Name, email, password, organization and job title are all required.'; return;
  }
  try {
    const res = await fetch('/api/users', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({name, email, password, role, organization, job_title}),
    });
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error || 'Could not create account.'; return; }
    await renderUserManagementPanel();
  } catch (e) { errEl.textContent = 'Could not create account.'; }
}


function renderCalculatedMetrics(metrics){
  if (!metrics || !Object.keys(metrics).length) return '';
  const cards = Object.entries(metrics).map(([key, val]) => `
    <div class="stat-card">
      <div class="stat-card-body">
        <div class="stat-label">${METRIC_LABELS[key] || key}</div>
        <div class="stat-value" style="font-size:17px;">${fmt(val, 2)}${PCT_METRICS.has(key) ? '%' : ''}</div>
      </div>
    </div>`).join('');
  return `<div class="stat-grid" style="margin-bottom:16px;">${cards}</div>`;
}

function renderSegments(segments){
  const rows = segments.map(s => `
    <tr>
      <td>${escapeHtml(s.segment_name)}</td>
      <td class="amount">${fmtAmount(s.revenue)}</td>
      <td class="amount">${fmtAmount(s.operating_profit)}</td>
    </tr>`).join('');
  return `
    <div class="subhead">Segments</div>
    <table>
      <thead><tr><th>Segment</th><th class="amount">Revenue</th><th class="amount">Operating Profit</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

function renderOperationalMetrics(metrics){
  const rows = metrics.map(m => `
    <tr><td>${escapeHtml(m.metric_name)}</td><td class="amount">${fmtAmount(m.value)} ${escapeHtml(m.unit || '')}</td></tr>`).join('');
  return `<div class="subhead">Operational KPIs</div><table><tbody>${rows}</tbody></table>`;
}

function renderNotes(notes){
  const items = notes.map(n => `
    <div style="margin-bottom:10px;">
      <div style="font-weight:600;font-size:12.5px;">${escapeHtml(n.title || 'Note')}${n.page ? ` <span class="badge">p.${n.page}</span>` : ''}</div>
      <div style="font-size:12px;color:var(--text-dim);margin-top:2px;">${escapeHtml(n.content || '')}</div>
    </div>`).join('');
  return `<div class="subhead">Notes</div>${items}`;
}

/* ---------- REPORT BUILDER (manual entry, any number of line items per statement) ---------- */

function renderReportBuilder(){
  return `<div id="report-builder-panel">${renderReportBuilderInner()}</div>`;
}

function renderReportBuilderInner(){
  const tabs = Object.keys(STATEMENT_LABELS).map(t =>
    `<button class="tab-btn ${t === builderTab ? 'active' : ''}" onclick="switchBuilderTab('${t}')">${STATEMENT_LABELS[t]}</button>`
  ).join('');

  return `
    <input id="builder-period" placeholder="Period (e.g. FY2025)" value="${escapeHtml(builderPeriod)}"
      oninput="builderPeriod=this.value" style="margin-bottom:12px;">
    <div class="tab-bar">${tabs}</div>
    <div id="builder-rows">${renderBuilderRows()}</div>
    <button class="secondary" onclick="addBuilderRow()">+ Add Line Item</button>
    <button onclick="saveBuilderReport()">Save Report</button>
    <div id="builder-error" class="error"></div>
  `;
}

function refreshBuilderPanel(){
  const el = document.getElementById('report-builder-panel');
  if (el) el.innerHTML = renderReportBuilderInner();
}

function switchBuilderTab(t){ builderTab = t; refreshBuilderPanel(); }

function addBuilderRow(){
  builderRows[builderTab].push({ label: '', amount: '' });
  refreshBuilderPanel();
}
function removeBuilderRow(i){
  builderRows[builderTab].splice(i, 1);
  refreshBuilderPanel();
}
function updateBuilderRow(i, field, val){
  builderRows[builderTab][i][field] = val;
}

function renderBuilderRows(){
  const rows = builderRows[builderTab];
  if (!rows.length) {
    return `<div class="empty">No line items yet for ${STATEMENT_LABELS[builderTab]}. Click "+ Add Line Item".</div>`;
  }
  return rows.map((r, i) => `
    <div class="builder-row">
      <input placeholder="Label (e.g. Revenue, Employee costs...)" value="${escapeHtml(r.label)}"
        oninput="updateBuilderRow(${i},'label',this.value)">
      <input placeholder="Amount" type="number" step="any" value="${r.amount ?? ''}"
        oninput="updateBuilderRow(${i},'amount',this.value)">
      <button class="secondary" onclick="removeBuilderRow(${i})">Remove</button>
    </div>`).join('');
}

async function saveBuilderReport(){
  const errorEl = document.getElementById('builder-error');
  errorEl.textContent = '';
  const period = document.getElementById('builder-period').value.trim();
  if (!period) { errorEl.textContent = 'Period is required (e.g. FY2025).'; return; }

  const statements = {};
  for (const [stmtType, rows] of Object.entries(builderRows)) {
    const items = rows
      .filter(r => r.label && r.amount !== '' && r.amount !== null && r.amount !== undefined)
      .map((r, idx) => ({ label: r.label, amount: parseFloat(r.amount), order_index: idx }));
    if (items.length) statements[stmtType] = { line_items: items };
  }
  if (!Object.keys(statements).length) { errorEl.textContent = 'Add at least one line item before saving.'; return; }

  const res = await fetch('/api/import/nse/save', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ company_id: currentCompanyId, period, statements })
  });
  const data = await res.json();
  if (!res.ok) { errorEl.textContent = data.error || 'Save failed.'; return; }

  currentPeriodLabel = period;
  await renderCompanyDetail(currentCompanyId);
}

function fmt(val, decimals = 1){
  return (val === null || val === undefined) ? '-' : Number(val).toFixed(decimals);
}
function saSectorCell(s, key){
  // A sector average needs 2+ reporting companies (survey_aggregate.MIN_COMPANIES_FOR_AVERAGE). A sector with
  // exactly one reporting company still shows that company's figure, clearly labelled, instead of "Not available".
  const v = s['avg_' + key];
  if (v !== null && v !== undefined) return fmtAmount(v);
  const one = s['single_' + key];
  if (s['avg_' + key + '_company_count'] === 1 && one !== null && one !== undefined)
    return `${fmtAmount(one)} <span style="color:var(--text-faint);font-size:10px;" title="Only one company in this sector reports this figure, so it is not an average">(1 company)</span>`;
  return naSpan('No company in this sector reports this figure');
}
function saNotApplicable(label){
  return `<span style="color:var(--text-faint);font-style:italic;" title="${escapeHtml(label || 'Not applicable')}">Not applicable</span>`;
}
function naSpan(label){
  // Shared "genuinely not computable from filed data" marker - used
  // throughout the Intelligence Report instead of a fabricated number
  // wherever the backend sends null for a field it has no honest basis
  // to estimate (market cap, dividend yield, forward-looking risk
  // categories, scenario forecasts, etc).
  return `<span class="na" style="color:var(--text-faint);font-style:italic;" title="${escapeHtml(label || 'Not available from filed data')}">Not available</span>`;
}
// ---------- Amounts are ALWAYS written out in full ----------
// No "K"/"M"/"B"/"T" suffixes, no "millions"/"billions" wording, no rounding to a
// shorter figure. Every figure the database holds in a scaled unit (thousands, millions,
// billions) is multiplied back up to whole currency units before it is shown,
// e.g. 211.8 (billions) -> 211,800,000,000.
const UNIT_MULTIPLIERS = {
  '': 1, 'unit': 1, 'units': 1, 'one': 1, 'ones': 1,
  'thousand': 1e3, 'thousands': 1e3,
  'million': 1e6, 'millions': 1e6,
  'billion': 1e9, 'billions': 1e9,
  'trillion': 1e12, 'trillions': 1e12,
};
function unitMultiplier(unit){
  const m = UNIT_MULTIPLIERS[String(unit === null || unit === undefined ? '' : unit).trim().toLowerCase()];
  return m === undefined ? 1 : m;
}
// val is stored in `unit`; prints the whole-currency figure with thousands separators.
// Keeps up to 2 decimal places only when the figure genuinely has them (averages).
function fmtFull(val, unit){
  if (val === null || val === undefined || val === '') return '-';
  const raw = Number(val);
  if (!Number.isFinite(raw)) return '-';
  const num = Math.round(raw * unitMultiplier(unit) * 100) / 100;   // also removes float noise (211.8*1e9)
  const formatted = Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  return num < 0 ? `-${formatted}` : formatted;
}
// Already whole currency units (director pay averages, retainers, allowances...).
function fmtAmount(val){ return fmtFull(val, 'units'); }
// Stored in MILLIONS: every survey_aggregate performance figure (turnover / net profit / market cap averages).
function fmtMillions(val){ return fmtFull(val, 'millions'); }
// Financials.revenue / net_income are kept AS PRINTED in each filing (thousands for some filers, millions
// for others) and the printed scale is not stored on those rows, so these are written out in full exactly
// as stored - never abbreviated, never guessed up to a different scale.
function fmtMoney(val){ return fmtAmount(val); }
// Per-company Survey Report figures: the unit each company's own filing used. Set on every
// Survey Report load (see renderSurveyReportPage).
let FILED_UNIT_CTX = 'units';   // director_rows / benefits "as filed": director_figures_unit, else whole currency
function fmtFiled(val){ return fmtFull(val, FILED_UNIT_CTX); }
function timeAgo(isoString){
  if (!isoString) return '';
  const then = new Date(isoString);
  const diffMs = Date.now() - then.getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min${mins===1?'':'s'} ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hour${hrs===1?'':'s'} ago`;
  const days = Math.floor(hrs / 24);
  return `${days} day${days===1?'':'s'} ago`;
}
const AVATAR_COLORS = ['#48cfa0','#3ddc84','#ffb020','#ff6161','#b79bfc','#26c6da','#f472b6','#94b8a6'];
function coAvatarColor(name){
  const str = name || '?';
  let hash = 0;
  for (let i = 0; i < str.length; i++) hash = str.charCodeAt(i) + ((hash << 5) - hash);
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}
function coInitials(name){
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  return parts.length > 1 ? (parts[0][0] + parts[1][0]).toUpperCase() : name.slice(0, 2).toUpperCase();
}
function scoreBandLabel(band){
  return band === 'strong' ? 'Strong' : band === 'moderate' ? 'Moderate' : band === 'weak' ? 'Weak' : '';
}
function escapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str == null ? '' : str;
  return div.innerHTML;
}

// ============================================================================
// Billing & Plan (billing.py). Members see their plan, invoices, payment and
// colleagues; super admins get the billing console (customers, plans, invoices).
// A thin banner under the top bar carries trial / overdue / read-only notices.
// ============================================================================
window.billingStatus = null;
let blState = {tab: 'overview', orgId: null, interval: 12, plans: null, admin: null, invFilter: 'open'};

const BL_STATUS = {
  trialing: ['Free trial', 'blue'], active: ['Active', 'green'], past_due: ['Overdue', 'amber'],
  read_only: ['Read-only', 'red'], pending: ['Awaiting payment', 'amber'], cancelled: ['Cancelled', 'red'],
  expired: ['Ended', 'red'], no_plan: ['No plan', 'faint'], open: ['Open', 'amber'], paid: ['Paid', 'green'], void: ['Void', 'faint'],
};
function blPill(st){
  const [label, col] = BL_STATUS[st] || [st || '—', 'faint'];
  return `<span class="bl-pill bl-${col}">${escapeHtml(label)}</span>`;
}
function blMoney(v, cur){ return `${escapeHtml(cur || 'KES')} ${Number(v || 0).toLocaleString('en-KE', {maximumFractionDigits: 0})}`; }
function blDate(iso){
  if (!iso) return '—';
  const d = new Date(/[zZ]|[+-]\d\d:\d\d$/.test(iso) ? iso : iso + 'Z');
  return isNaN(d) ? '—' : d.toLocaleDateString('en-GB', {day: '2-digit', month: 'short', year: 'numeric'});
}
// Download allowances by kind (billing.download_kind): null = unlimited, 0 = not included.
const BL_TIER_LINES = {professional: ['Company reports & survey analytics', 'Documents & report downloads'],
  team: ['Company reports & survey analytics', 'Intelligence report & rankings', 'Data quality & source evidence'],
  enterprise: ['Everything in Team', 'All countries & custom analysis']};
const BL_DL = [['report_downloads_per_month', 'report', 'Report downloads (PDF, Word)', 'reports'],
               ['data_downloads_per_month', 'data', 'Data downloads (CSV, Excel)', 'data files'],
               ['bulk_downloads_per_month', 'bulk', 'Bulk downloads (ZIP, whole portfolio)', 'bulk files']];
function blDlNone(limit){ return limit !== null && limit !== undefined && limit !== '' && Number(limit) === 0; }
function blDlLine(limit, noun){
  if (limit === null || limit === undefined || limit === '') return `Unlimited ${noun}`;
  if (blDlNone(limit)) return `<span class="bl-no">No ${noun}</span>`;
  return `${limit} ${noun} a month`;
}
function blDlFacts(p){ return BL_DL.map(([f, , , noun]) => `<li class="${blDlNone(p[f]) ? 'bl-li-no' : ''}">${blDlLine(p[f], noun)}</li>`).join(''); }
function blPer(months){ return months === 1 ? 'month' : months === 12 ? 'year' : `${months} months`; }
async function blJson(res){ try { return await res.json(); } catch (e) { return {}; } }
async function blSend(method, url, body){
  const res = await fetch(url, {method, headers: {'Content-Type': 'application/json'}, body: body === undefined ? undefined : JSON.stringify(body)});
  const data = await blJson(res);
  if (!res.ok) throw new Error(data.error || 'Something went wrong - please try again.');
  return data;
}

// ---- status + banner --------------------------------------------------------
let billingFlight = null, billingLoadedAt = 0, billingUserKey = '';
async function loadBillingStatus(force=true){
  const u = window.currentUser;
  if (!u || u.role !== 'user' || !u.logged_in) return;
  const key = String(u.id || u.email || '');
  if (billingFlight && billingUserKey === key) return billingFlight;
  if (!force && billingUserKey === key && Date.now()-billingLoadedAt < 30000) return;
  billingUserKey = key;
  const task = (async () => {
  try {
    const res = await fetch('/api/billing/me');
    const data = res.ok ? await res.json() : null;
    if (window.currentUser !== u) return;
    window.billingStatus = data; billingLoadedAt = data ? Date.now() : 0;
  } catch (e) { if (window.currentUser === u) window.billingStatus = null; }
  if (window.currentUser !== u) return;
  renderBillingBanner();
  if (window.currentUser.role === 'user') {
    renderNav();
    const pd = PAGES.find(p => p.id === currentPage);
    if (pd && !pageAllowed(pd) && document.getElementById('app').dataset.lockedFor !== currentPage) render();
  }
  })();
  billingFlight = task;
  try { await task; } finally { if (billingFlight === task) billingFlight = null; }
}
function renderBillingBanner(){
  const el = document.getElementById('billingBanner');
  if (!el) return;
  const b = window.billingStatus;
  if (!b || !b.signed_in || b.staff || !b.enforced || !b.banner || currentPage === 'billing' || currentPage === 'home') { el.innerHTML = ''; return; }
  const tone = b.level === 'full' ? (b.status === 'trialing' ? 'blue' : 'amber') : 'red';
  el.innerHTML = `<div class="bl-banner bl-banner-${tone}"><span>${escapeHtml(b.banner)}</span>
    <button class="secondary" onclick="goTo('billing')">${b.level === 'none' && !b.organisation ? 'See plans' : 'Billing & Plan'}</button></div>`;
}

// ---- page router ------------------------------------------------------------
async function renderBillingPage(){
  const app = document.getElementById('app');
  setPageActions(null);
  renderBillingBanner();
  const u = window.currentUser;
  if (u.role === 'admin') {
    if (!u.is_super_admin) {
      app.innerHTML = `<div class="panel"><div class="empty">Billing is managed by a super admin.</div></div>`;
      return;
    }
    await blRenderAdmin();
    return;
  }
  await loadBillingStatus();
  await blRenderCustomer();
}

// ============================================================================
// Customer view
// ============================================================================
async function blLoadPlans(){
  if (!blState.plans) {
    const res = await fetch('/api/billing/plans');
    blState.plans = res.ok ? await res.json() : {plans: []};
  }
  return blState.plans;
}

async function blRenderCustomer(){
  const app = document.getElementById('app');
  const b = window.billingStatus || {};
  const P = await blLoadPlans();
  const org = b.organisation, sub = b.subscription, owner = b.org_role === 'owner' || !org;
  const openInv = (b.invoices || []).filter(i => i.status === 'open');
  let html = '';

  if (b.banner && b.enforced) {
    const tone = b.level === 'full' ? (b.status === 'trialing' ? 'blue' : 'amber') : 'red';
    html += `<div class="bl-banner bl-banner-${tone}" style="margin-bottom:16px;"><span>${escapeHtml(b.banner)}</span></div>`;
  }

  if (org && sub) {
    const plan = sub.plan || {};
    const until = b.status === 'trialing' ? sub.trial_end : sub.current_period_end;
    html += `<div class="panel bl-summary">
      <div class="bl-sum-main">
        <div class="bl-faint">${escapeHtml(org.name)}</div>
        <div class="bl-plan-name">${escapeHtml(plan.name || 'Plan')} ${blPill(b.status)}</div>
        <div class="bl-faint">${blMoney(plan.price, plan.currency)} per ${blPer(plan.interval_months)} · excl. VAT</div>
      </div>
      <div class="bl-sum-facts">
        <div><span>${b.status === 'trialing' ? 'Trial ends' : sub.cancel_at_period_end ? 'Ends' : 'Renews'}</span><b>${blDate(until)}</b></div>
        <div><span>Users</span><b>${b.seats_used} of ${b.seats}</b></div>

        <div><span>Payment</span><b>${sub.auto_renew_card ? escapeHtml(sub.card_label || 'Card on file') + ' (auto-renew)' : 'Invoice'}</b></div>
      </div>
      ${owner && ['trialing', 'active', 'past_due'].includes(b.status) ? `<div class="bl-sum-act">
        ${sub.cancel_at_period_end
          ? `<button class="secondary" onclick="blCancel(true)">Keep my plan</button>`
          : `<button class="secondary bl-danger" onclick="blCancel(false)">${b.status === 'trialing' ? 'End trial' : 'Cancel at end of period'}</button>`}
      </div>` : ''}
      ${b.downloads ? `<div class="bl-usage">${BL_DL.map(([f, k, label]) => { const u = b.downloads[k] || {}; const lim = u.limit;
          const pct = lim ? Math.min(100, (u.used || 0) / lim * 100) : 0;
          return `<div class="bl-usage-row"><span>${escapeHtml(label)}</span><b>${lim === 0 ? 'Not included' : (u.used || 0) + (lim == null ? ' this month · unlimited' : ' of ' + lim + ' this month')}</b>
            ${lim ? `<div class="bl-seat-bar wide"><i style="width:${pct}%;${pct >= 100 ? 'background:var(--red)' : pct >= 80 ? 'background:var(--amber)' : ''}"></i></div>` : ''}</div>`; }).join('')}</div>` : ''}
    </div>`;
  }

  if (openInv.length) {
    html += `<div class="panel" style="margin-top:16px;"><div class="panel-head"><h2>To pay</h2></div>
      ${openInv.map(i => blInvoiceRow(i, b.online_payment)).join('')}
      ${!b.online_payment ? `<div class="bl-faint" style="margin-top:10px;">Pay by bank transfer or M-Pesa using the details on the invoice, quoting the invoice number. Access updates as soon as we record the payment.</div>` : ''}
    </div>`;
  }

  html += blPlansPanel(P, b, owner);

  if (org && owner) html += blColleaguesPanel(b) + blDetailsPanel(org);

  const history = (b.invoices || []).filter(i => i.status !== 'open');
  if (history.length) {
    html += `<div class="panel" style="margin-top:16px;"><div class="panel-head"><h2>Invoice history</h2></div>
      ${history.map(i => blInvoiceRow(i, false)).join('')}</div>`;
  }
  app.innerHTML = html;
}

function blInvoiceRow(i, canPayOnline){
  const owed = Math.max(0, i.total - (i.amount_paid || 0));
  return `<div class="bl-inv-row">
    <div><b>${escapeHtml(i.number)}</b> ${blPill(i.status)}<div class="bl-faint">${escapeHtml(i.description)}</div></div>
    <div class="bl-inv-amt">${blMoney(i.total, i.currency)}<div class="bl-faint">${i.status === 'open' ? 'Due ' + blDate(i.due_at) : i.status === 'paid' ? 'Paid ' + blDate(i.paid_at) : ''}${i.status === 'open' && i.amount_paid ? ' · ' + blMoney(owed, i.currency) + ' left' : ''}</div></div>
    <div class="bl-inv-act">
      ${i.status === 'open' && canPayOnline ? `<button onclick="blPayNow(${i.id}, this)">Pay now</button>` : ''}
      <button class="secondary" onclick="window.open('/billing/invoice/${i.id}', '_blank')">View / print</button>
    </div></div>`;
}

function blPlansPanel(P, b, owner){
  const plans = (P.plans || []).filter(p => p.active);
  const intervals = [...new Set(plans.filter(p => p.self_serve).map(p => p.interval_months))].sort((a, c) => a - c);
  const sug = blState.suggest && plans.find(p => p.code === blState.suggest);
  if (sug && !blState.suggestApplied) { blState.interval = sug.interval_months; blState.suggestApplied = true; }
  if (!intervals.includes(blState.interval) && intervals.length) blState.interval = intervals[intervals.length - 1];
  const shown = plans.filter(p => !p.self_serve || p.interval_months === blState.interval);
  const currentPlanId = b.subscription && ['trialing', 'active', 'past_due'].includes(b.status) ? b.subscription.plan.id : null;
  const trialNote = (!b.organisation || !b.organisation.trial_used) && P.trial_days
    ? `Start with a ${P.trial_days}-day free trial - no payment needed until it ends.` : '';
  const needOrg = !b.organisation;
  return `<div class="panel" style="margin-top:16px;">
    <div class="panel-head"><h2>${currentPlanId ? 'Change plan' : 'Choose a plan'}</h2>
      ${intervals.length > 1 ? `<div class="bl-toggle">${intervals.map(m => `<button class="secondary ${m === blState.interval ? 'active' : ''}" onclick="blState.interval=${m};blRenderCustomer()">${m === 1 ? 'Monthly' : m === 12 ? 'Annual' : m + ' months'}</button>`).join('')}</div>` : ''}
    </div>
    ${trialNote ? `<div class="bl-faint" style="margin:-6px 0 12px;">${escapeHtml(trialNote)}</div>` : ''}
    ${needOrg ? `<div class="grid" style="margin-bottom:14px;">
        <input id="bl-org-name" placeholder="Organisation name" value="${escapeHtml(window.currentUser.organization || '')}">
        <input id="bl-org-pin" placeholder="KRA PIN (for invoices, optional)">
      </div>` : ''}
    <div class="bl-plans">
      ${shown.map(p => `<div class="bl-plan ${p.id === currentPlanId ? 'current' : ''} ${blState.suggest === p.code ? 'suggest' : ''}">
        <div class="bl-plan-title">${escapeHtml(p.name.replace(/ - (monthly|annual)$/i, ''))}</div>
        <div class="bl-plan-price">${p.self_serve ? blMoney(p.price, p.currency) : 'From ' + blMoney(p.price, p.currency)}<span>/${blPer(p.interval_months)}</span></div>
        <div class="bl-faint bl-plan-desc">${escapeHtml(p.description || '')}</div>
        <ul class="bl-plan-facts">
          <li>${p.seats} user${p.seats === 1 ? '' : 's'}</li>
          ${(BL_TIER_LINES[p.tier] || []).map(t => `<li>${escapeHtml(t)}</li>`).join('')}
          ${blDlFacts(p)}
        </ul>
        ${p.id === currentPlanId ? `<button class="secondary" disabled>Your plan</button>`
          : !p.self_serve ? (P.contact_email ? `<button class="secondary" onclick="location.href='mailto:${escapeHtml(P.contact_email)}?subject=${encodeURIComponent(p.name + ' quote')}'">Contact us</button>` : `<button class="secondary" disabled>Ask us for a quote</button>`)
          : owner ? `<button onclick="blSubscribe('${escapeHtml(p.code)}', this)">${currentPlanId ? 'Switch to this plan' : 'Choose'}</button>`
          : `<button class="secondary" disabled>Ask your account owner</button>`}
      </div>`).join('')}
    </div>
    <div class="bl-faint" style="margin-top:10px;">Prices exclude VAT${P.vat_rate ? ' (' + Math.round(P.vat_rate * 100) + '% added on invoices)' : ''}. A new plan starts once its first invoice is paid; your current plan keeps working until then.</div>
    <div id="bl-plan-error" class="error"></div>
  </div>`;
}

function blColleaguesPanel(b){
  const free = Math.max(0, (b.seats || 0) - (b.seats_used || 0));
  return `<div class="panel" style="margin-top:16px;"><div class="panel-head"><h2>Colleagues</h2><span class="bl-faint">${b.seats_used} of ${b.seats} users</span></div>
    ${(b.members || []).map(m => `<div class="bl-inv-row"><div><b>${escapeHtml(m.name)}</b> ${m.org_role === 'owner' ? '<span class="doc-badge">Account owner</span>' : ''}<div class="bl-faint">${escapeHtml(m.email)}</div></div><div></div>
      <div class="bl-inv-act">${m.org_role !== 'owner' ? `<button class="secondary bl-danger" onclick="blRemoveMember(${m.id}, '${escapeHtml(m.name).replace(/'/g, "\\'")}')">Remove</button>` : ''}</div></div>`).join('')}
    ${free ? `<div style="margin-top:14px;"><div class="bl-faint" style="margin-bottom:8px;">Add a colleague (${free} seat${free === 1 ? '' : 's'} free). Each person signs in with their own email; one sign-in at a time per account.</div>
      <div class="grid"><input id="bl-m-name" placeholder="Full name"><input id="bl-m-email" type="email" placeholder="Email">
      <input id="bl-m-job" placeholder="Job title"><input id="bl-m-pass" type="password" placeholder="Temporary password (min 6)"></div>
      <button style="margin-top:10px;" onclick="blAddMember(this)">Add colleague</button><div id="bl-m-error" class="error"></div></div>`
      : `<div class="bl-faint" style="margin-top:10px;">All seats are in use. Remove someone or move to a larger plan to add colleagues.</div>`}
  </div>`;
}

function blDetailsPanel(org){
  return `<div class="panel" style="margin-top:16px;"><div class="panel-head"><h2>Billing details</h2><span class="bl-faint">Printed on your invoices</span></div>
    <div class="grid">
      <input id="bl-d-name" placeholder="Organisation name" value="${escapeHtml(org.name || '')}">
      <input id="bl-d-email" type="email" placeholder="Billing email" value="${escapeHtml(org.billing_email || '')}">
      <input id="bl-d-pin" placeholder="KRA PIN" value="${escapeHtml(org.kra_pin || '')}">
      <input id="bl-d-phone" placeholder="Phone" value="${escapeHtml(org.phone || '')}">
    </div>
    <input id="bl-d-address" placeholder="Postal / physical address" style="width:100%;margin-top:10px;" value="${escapeHtml(org.address || '')}">
    <button style="margin-top:10px;" onclick="blSaveDetails(this)">Save details</button><div id="bl-d-error" class="error"></div>
  </div>`;
}

async function blSubscribe(code, btn){
  const err = document.getElementById('bl-plan-error');
  err.textContent = '';
  const body = {plan_code: code};
  const nameEl = document.getElementById('bl-org-name');
  if (nameEl) {
    if (!nameEl.value.trim()) { err.textContent = 'Enter your organisation\'s name first.'; nameEl.focus(); return; }
    body.organisation = {name: nameEl.value.trim(), kra_pin: (document.getElementById('bl-org-pin').value || '').trim()};
  }
  btn.disabled = true;
  try {
    const d = await blSend('POST', '/api/billing/subscribe', body);
    showToast(d.trial ? 'Your free trial has started.' : 'Plan chosen - pay the invoice to start it.');
    await loadCurrentUser(); updateUserBadge();
    await renderBillingPage();
  } catch (e) { err.textContent = e.message; btn.disabled = false; }
}

async function blPayNow(invoiceId, btn){
  btn.disabled = true; btn.textContent = 'Opening payment page…';
  try {
    const d = await blSend('POST', `/api/billing/invoices/${invoiceId}/pay`);
    location.href = d.authorization_url;
  } catch (e) { alert(e.message); btn.disabled = false; btn.textContent = 'Pay now'; }
}

async function blCancel(undo){
  const run = async () => { await blSend('POST', '/api/billing/cancel', {undo}); await renderBillingPage(); };
  if (undo) { try { await run(); } catch (e) { showToast(e.message); } return; }
  blConfirm('Cancel plan', 'Cancel your plan? You keep full access until the end of the period you have paid for, and nothing more is charged.', 'Cancel plan', run);
}

async function blAddMember(btn){
  const err = document.getElementById('bl-m-error');
  err.textContent = '';
  btn.disabled = true;
  try {
    await blSend('POST', '/api/billing/organisation/members', {
      name: document.getElementById('bl-m-name').value.trim(), email: document.getElementById('bl-m-email').value.trim(),
      job_title: document.getElementById('bl-m-job').value.trim(), password: document.getElementById('bl-m-pass').value});
    showToast('Colleague added. Share their email and temporary password with them.');
    await renderBillingPage();
  } catch (e) { err.textContent = e.message; btn.disabled = false; }
}

async function blRemoveMember(id, name){
  blConfirm('Remove colleague', `Remove <b>${escapeHtml(name)}</b>? Their account stays, but it loses access through your organisation and frees a seat.`, 'Remove',
    async () => { await blSend('DELETE', `/api/billing/organisation/members/${id}`); await renderBillingPage(); });
}

async function blSaveDetails(btn){
  const err = document.getElementById('bl-d-error');
  err.textContent = '';
  btn.disabled = true;
  try {
    await blSend('PATCH', '/api/billing/organisation', {
      name: document.getElementById('bl-d-name').value, billing_email: document.getElementById('bl-d-email').value,
      kra_pin: document.getElementById('bl-d-pin').value, phone: document.getElementById('bl-d-phone').value,
      address: document.getElementById('bl-d-address').value});
    showToast('Billing details saved.');
  } catch (e) { err.textContent = e.message; }
  btn.disabled = false;
}

// ============================================================================
// Super admin console
// ============================================================================
const BL_TABS = [['overview', 'Overview'], ['customers', 'Customers'], ['invoices', 'Invoices'], ['plans', 'Plans']];
const BL_METHODS = [['bank_transfer', 'Bank transfer'], ['mpesa', 'M-Pesa'], ['cheque', 'Cheque'], ['other', 'Other']];
const BL_ICON = {
  users: '<svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  trend: '<svg viewBox="0 0 24 24"><path d="m22 7-8.5 8.5-5-5L2 17"/><path d="M16 7h6v6"/></svg>',
  calendar: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
  wallet: '<svg viewBox="0 0 24 24"><path d="M20 12V8H6a2 2 0 0 1 0-4h12v4"/><path d="M4 6v12a2 2 0 0 0 2 2h14v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/></svg>',
  alert: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>',
  doc: '<svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8"/></svg>',
  plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
  search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>',
  check: '<svg viewBox="0 0 24 24"><path d="M20 6 9 17l-5-5"/></svg>',
  back: '<svg viewBox="0 0 24 24"><path d="m15 18-6-6 6-6"/></svg>',
  card: '<svg viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>',
  tag: '<svg viewBox="0 0 24 24"><path d="M20.59 13.41 13.42 20.58a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><path d="M7 7h.01"/></svg>',
  building: '<svg viewBox="0 0 24 24"><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01"/></svg>',
  database: '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/><path d="M3 12c0 1.66 4 3 9 3s9-1.34 9-3"/></svg>',
  refresh: '<svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-2.64-6.36L21 8"/><path d="M21 3v5h-5"/></svg>',
  shield: '<svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>',
  upload: '<svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5M12 3v12"/></svg>',
  spark: '<svg viewBox="0 0 24 24"><path d="M12 3l1.9 5.8L20 10.7l-5.6 2.7L12 21l-2.4-7.6L4 10.7l6.1-1.9z"/></svg>',
  key: '<svg viewBox="0 0 24 24"><circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/></svg>',
  clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>',
  inbox: '<svg viewBox="0 0 24 24"><path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>',
  chevron: '<svg viewBox="0 0 24 24"><path d="m9 18 6-6-6-6"/></svg>',
  trash: '<svg viewBox="0 0 24 24"><path d="M3 6h18M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>',
  link: '<svg viewBox="0 0 24 24"><path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>',
};
function blIcon(name){ return `<span class="bl-ic">${BL_ICON[name] || ''}</span>`; }
function blInitials(name){
  const parts = (name || '?').replace(/[^A-Za-z0-9 ]/g, ' ').trim().split(/\s+/).filter(Boolean);
  return ((parts[0] || '?')[0] + (parts.length > 1 ? parts[1][0] : '')).toUpperCase();
}
function blAvatar(name, size){ return `<span class="bl-avatar${size ? ' ' + size : ''}">${escapeHtml(blInitials(name))}</span>`; }
function blIsOverdue(i){ return i.status === 'open' && i.due_at && new Date(i.due_at + (/[zZ]$/.test(i.due_at) ? '' : 'Z')) < new Date(); }
function blInvPill(i){ return blIsOverdue(i) ? `<span class="bl-pill bl-red">Overdue</span>` : blPill(i.status); }
function blEmpty(icon, title, text, actionHtml){
  return `<div class="bl-empty">${blIcon(icon)}<div class="bl-empty-title">${escapeHtml(title)}</div><div class="bl-faint">${text}</div>${actionHtml ? `<div style="margin-top:14px;">${actionHtml}</div>` : ''}</div>`;
}

// ---- modal ------------------------------------------------------------------
// fields: [{name, label, type:'text'|'number'|'email'|'date'|'select'|'textarea'|'checkbox', value, options:[[v,l]], placeholder, hint, required, full}]
function blModal({title, intro, fields, submitLabel, danger, onSubmit, wide}){
  blCloseModal();
  const wrap = document.createElement('div');
  wrap.className = 'bl-modal-overlay';
  wrap.id = 'blModal';
  const field = f => {
    const id = 'blf-' + f.name;
    const val = f.value == null ? '' : f.value;
    let input;
    if (f.type === 'select') input = `<select id="${id}" class="bl-input">${f.options.map(([v, l]) => `<option value="${escapeHtml(v)}" ${String(v) === String(val) ? 'selected' : ''}>${escapeHtml(l)}</option>`).join('')}</select>`;
    else if (f.type === 'textarea') input = `<textarea id="${id}" class="bl-input" rows="3" placeholder="${escapeHtml(f.placeholder || '')}">${escapeHtml(val)}</textarea>`;
    else if (f.type === 'checkbox') return `<label class="bl-check ${f.full ? 'full' : ''}"><input type="checkbox" id="${id}" ${val ? 'checked' : ''}><span><b>${escapeHtml(f.label)}</b>${f.hint ? `<small>${escapeHtml(f.hint)}</small>` : ''}</span></label>`;
    else input = `<input id="${id}" class="bl-input" type="${f.type || 'text'}" value="${escapeHtml(val)}" placeholder="${escapeHtml(f.placeholder || '')}" ${f.type === 'number' ? 'min="0" step="any"' : ''}>`;
    return `<label class="bl-field ${f.full ? 'full' : ''}"><span>${escapeHtml(f.label)}${f.required ? ' <i>*</i>' : ''}</span>${input}${f.hint ? `<small>${escapeHtml(f.hint)}</small>` : ''}</label>`;
  };
  wrap.innerHTML = `<div class="bl-modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">
    <div class="bl-modal-head"><h3>${escapeHtml(title)}</h3><button class="bl-x" aria-label="Close" onclick="blCloseModal()">&times;</button></div>
    ${intro ? `<div class="bl-modal-intro">${intro}</div>` : ''}
    ${fields && fields.length ? `<div class="bl-form">${fields.map(field).join('')}</div>` : ''}
    <div class="error" id="blModalError"></div>
    <div class="bl-modal-foot"><button class="secondary" onclick="blCloseModal()">Cancel</button>
      <button id="blModalSubmit" class="${danger ? 'bl-btn-danger' : ''}">${escapeHtml(submitLabel || 'Save')}</button></div>
  </div>`;
  document.body.appendChild(wrap);
  wrap.addEventListener('mousedown', e => { if (e.target === wrap) blCloseModal(); });
  const first = wrap.querySelector('input:not([type=checkbox]),select,textarea');
  if (first) setTimeout(() => first.focus(), 30);
  const submit = async () => {
    const vals = {};
    (fields || []).forEach(f => {
      const el = document.getElementById('blf-' + f.name);
      vals[f.name] = f.type === 'checkbox' ? el.checked : el.value.trim();
    });
    const missing = (fields || []).find(f => f.required && !vals[f.name]);
    const err = document.getElementById('blModalError');
    if (missing) { err.textContent = `${missing.label} is required.`; return; }
    const btn = document.getElementById('blModalSubmit');
    btn.disabled = true; err.textContent = '';
    try { await onSubmit(vals); blCloseModal(); }
    catch (e) { err.textContent = e.message; btn.disabled = false; }
  };
  document.getElementById('blModalSubmit').onclick = submit;
  wrap.addEventListener('keydown', e => {
    if (e.key === 'Escape') blCloseModal();
    if (e.key === 'Enter' && e.target.tagName === 'INPUT') submit();
  });
}
function blCloseModal(){ const m = document.getElementById('blModal'); if (m) m.remove(); }
function blConfirm(title, message, label, onYes){
  blModal({title, intro: message, submitLabel: label, danger: true, onSubmit: onYes});
}

// ---- shell -------------------------------------------------------------------
async function blRenderAdmin(){
  rpHeaderSelect('section','Billing section',BL_TABS.map(([id,label])=>({id,label})),blState.tab,blGoTab);
  const app = document.getElementById('app');
  app.innerHTML = `<div class="bl-console">
    <div id="blAdminBody"><div class="bl-loading"><span></span><span></span><span></span></div></div></div>`;
  try {
    if (blState.tab === 'overview') await blAdminOverview();
    else if (blState.tab === 'customers') await (blState.orgId ? blAdminOrg(blState.orgId) : blAdminCustomers());
    else if (blState.tab === 'invoices') await blAdminInvoices();
    else await blAdminPlans();
  } catch (e) {
    document.getElementById('blAdminBody').innerHTML = `<div class="panel">${blEmpty('alert', 'Could not load this page', escapeHtml(e.message))}</div>`;
  }
}
function blGoTab(k){ blState.tab = k; blState.orgId = null; blRenderAdmin(); }
function blOpenOrg(id){ blState.tab = 'customers'; blState.orgId = id; blRenderAdmin(); }
async function blGet(url){
  const res = await fetch(url);
  const d = await blJson(res);
  if (!res.ok) throw new Error(d.error || 'Could not load.');
  return d;
}
function blHeader(title, sub, actions){
  return `<div class="bl-head"><div><h2>${escapeHtml(title)}</h2>${sub ? `<div class="bl-faint">${sub}</div>` : ''}</div><div class="bl-head-act">${actions || ''}</div></div>`;
}
function blMoneyMap(m){
  const keys = Object.keys(m || {}).filter(k => m[k]);
  return keys.length ? keys.map(k => blMoney(m[k], k)).join(' + ') : 'KES 0';
}

// ---- Overview ----------------------------------------------------------------
async function blAdminOverview(){
  const d = await blGet('/api/admin/billing/overview');
  blState.admin = d;
  const paying = (d.by_status.active || 0) + (d.by_status.past_due || 0);
  const overdueTotal = {};
  d.overdue_invoices.forEach(i => { overdueTotal[i.currency] = (overdueTotal[i.currency] || 0) + i.balance; });
  const stat = (icon, tone, label, value, sub) => `<div class="bl-stat"><div class="bl-stat-top"><span class="bl-stat-icon bl-${tone}">${blIcon(icon)}</span><span>${label}</span></div>
      <div class="bl-stat-value">${value}</div><div class="bl-faint">${sub || '&nbsp;'}</div></div>`;
  const pending = d.setup.filter(s => !s.done);
  const required = d.setup.filter(s => !s.optional);
  const doneCount = required.filter(s => s.done).length;

  document.getElementById('blAdminBody').innerHTML = `
    ${blHeader('Billing overview', `Billing checks are <b class="${d.enforced ? 'bl-ok' : 'bl-warn'}">${d.enforced ? 'on' : 'off'}</b> · Online payment ${d.online_payment ? '<b class="bl-ok">connected</b>' : '<b class="bl-warn">not connected</b>'} · VAT ${d.vat_rate ? Math.round(d.vat_rate * 100) + '%' : 'not charged'} · ${d.trial_days}-day trial · ${d.grace_days}-day grace`,
      `<button class="secondary" onclick="blRunSweep(this)">Run renewals now</button><button onclick="blNewCustomer()">${blIcon('plus')}New customer</button>`)}

    ${pending.length ? `<div class="panel bl-setup-card">
      <div class="bl-setup-top"><div><div class="bl-card-title">Get ready to charge customers</div><div class="bl-faint">${doneCount} of ${required.length} steps done</div></div>
        <div class="bl-progress"><i style="width:${Math.round(doneCount / required.length * 100)}%"></i></div></div>
      <ol class="bl-steps">${d.setup.map(s => `<li class="${s.done ? 'done' : ''}"><span class="bl-step-dot">${s.done ? blIcon('check') : ''}</span>
        <div><b>${escapeHtml(s.label)}</b>${s.optional ? '<span class="bl-tag" style="margin-left:6px;">optional</span>' : ''}${s.done ? '' : `<div class="bl-faint">${escapeHtml(s.hint)}</div>`}</div></li>`).join('')}</ol>
    </div>` : ''}

    <div class="bl-stats">
      ${stat('users', 'blue', 'Paying customers', paying, `${d.by_status.trialing || 0} on free trial · ${d.customers_total} in total`)}
      ${stat('trend', 'green', 'Monthly recurring revenue', blMoneyMap(d.mrr), 'Annual plans spread per month')}
      ${stat('calendar', 'blue', 'Annual run rate', blMoneyMap(d.arr), 'MRR × 12')}
      ${stat('wallet', 'green', 'Collected, last 30 days', blMoneyMap(d.collected_30d), `${d.recent_payments.length ? 'Last payment ' + blDate(d.recent_payments[0].paid_at) : 'No payments yet'}`)}
      ${stat('alert', Object.keys(overdueTotal).length ? 'red' : 'amber', 'Outstanding', blMoneyMap(d.outstanding), Object.keys(overdueTotal).length ? `<span class="bl-neg">${blMoneyMap(overdueTotal)} overdue</span>` : 'Nothing overdue')}
    </div>

    <div class="bl-grid-2">
      <div class="panel"><div class="bl-card-head"><div class="bl-card-title">Revenue collected</div><span class="bl-faint">Last 6 months</span></div>${blRevenueChart(d.revenue_by_month)}</div>
      <div class="panel"><div class="bl-card-head"><div class="bl-card-title">Customers by status</div><span class="panel-link" onclick="blGoTab('customers')">View all</span></div>${blStatusBreakdown(d.by_status, d.customers_total)}</div>
    </div>

    <div class="bl-grid-2">
      <div class="panel"><div class="bl-card-head"><div class="bl-card-title">Renewals and trial ends</div><span class="bl-faint">Next 30 days</span></div>
        ${d.upcoming_renewals.length ? `<table class="bl-table compact"><tbody>${d.upcoming_renewals.map(r => `<tr class="bl-click" onclick="blOpenOrg(${r.organisation_id})">
          <td>${blAvatar(r.organisation, 'sm')}<span class="bl-strong">${escapeHtml(r.organisation)}</span><div class="bl-faint bl-indent">${escapeHtml(r.plan)}${r.cancelling ? ' · cancelling' : r.auto_renew_card ? ' · card auto-renew' : ''}</div></td>
          <td class="num">${blMoney(r.price, r.currency)}<div class="bl-faint">${r.status === 'trialing' ? 'Trial ends' : 'Renews'} ${blDate(r.date)}</div></td></tr>`).join('')}</tbody></table>`
          : blEmpty('calendar', 'Nothing due', 'No plan renews or trial ends in the next 30 days.')}</div>
      <div class="panel"><div class="bl-card-head"><div class="bl-card-title">Overdue invoices</div><span class="panel-link" onclick="blState.invFilter='overdue';blGoTab('invoices')">View all</span></div>
        ${d.overdue_invoices.length ? `<table class="bl-table compact"><tbody>${d.overdue_invoices.slice(0, 6).map(i => `<tr class="bl-click" onclick="blOpenOrg(${i.organisation_id})">
          <td><span class="bl-strong">${escapeHtml(i.number)}</span><div class="bl-faint">${escapeHtml(i.organisation)}</div></td>
          <td class="num"><span class="bl-neg">${blMoney(i.balance, i.currency)}</span><div class="bl-faint">${i.days ? i.days + ' day' + (i.days === 1 ? '' : 's') + ' late' : 'Due today'}</div></td></tr>`).join('')}</tbody></table>`
          : blEmpty('check', 'All caught up', 'No invoice is past its due date.')}</div>
    </div>

    <div class="panel"><div class="bl-card-head"><div class="bl-card-title">Recent payments</div></div>
      ${d.recent_payments.length ? `<table class="bl-table"><thead><tr><th>Customer</th><th>Method</th><th>Reference</th><th>Date</th><th class="num">Amount</th></tr></thead><tbody>
        ${d.recent_payments.map(p => `<tr><td>${blAvatar(p.organisation, 'sm')}<span class="bl-strong">${escapeHtml(p.organisation || '')}</span></td>
          <td>${escapeHtml((BL_METHODS.find(m => m[0] === p.method) || [0, p.method === 'paystack' ? 'Paystack' : p.method])[1])}</td>
          <td class="bl-mono">${escapeHtml(p.reference || '—')}</td><td>${blDate(p.paid_at)}</td><td class="num bl-pos">${blMoney(p.amount, p.currency)}</td></tr>`).join('')}</tbody></table>`
        : blEmpty('wallet', 'No payments yet', 'Payments appear here as soon as they are recorded or arrive through Paystack.')}
    </div>`;
}

function blRevenueChart(months){
  const cur = (() => { const c = {}; months.forEach(m => Object.keys(m.amounts || {}).forEach(k => { c[k] = (c[k] || 0) + (Number(m.amounts[k]) || 0); }));
    return Object.keys(c).sort((a, b) => c[b] - c[a])[0] || 'KES'; })();
  const vals = months.map(m => m.amounts[cur] || 0);
  const max = Math.max(...vals);
  if (!max) return blEmpty('trend', 'No revenue yet', 'Monthly totals appear here once payments come in.');
  const nice = (() => { if (!max) return 1; const p = Math.pow(10, Math.floor(Math.log10(max))); return Math.ceil(max / p) * p; })();
  const W = 520, H = 190, L = 56, B = 26, T = 12, bw = (W - L - 10) / months.length;
  const y = v => T + (H - T - B) * (1 - v / nice);
  const short = v => v >= 1e6 ? (v / 1e6).toFixed(v % 1e6 ? 1 : 0) + 'M' : v >= 1e3 ? Math.round(v / 1e3) + 'k' : String(v);
  const grid = (max ? [0, .5, 1] : [0]).map(f => `<line x1="${L}" x2="${W - 6}" y1="${y(nice * f)}" y2="${y(nice * f)}" class="bl-gridline"/><text x="${L - 8}" y="${y(nice * f) + 4}" text-anchor="end" class="bl-axis">${short(nice * f)}</text>`).join('');
  const bars = vals.map((v, i) => {
    const x = L + i * bw + bw * .2, w = bw * .6, top = y(v);
    return `<g><title>${months[i].label}: ${cur} ${v.toLocaleString('en-KE')}</title>
      <rect x="${x}" y="${top}" width="${w}" height="${Math.max(0, H - B - top)}" rx="4" class="bl-bar ${i === vals.length - 1 ? 'now' : ''}"/>
      ${v ? `<text x="${x + w / 2}" y="${top - 5}" text-anchor="middle" class="bl-axis strong">${short(v)}</text>` : ''}
      <text x="${x + w / 2}" y="${H - 8}" text-anchor="middle" class="bl-axis">${months[i].label}</text></g>`;
  }).join('');
  return `<svg class="bl-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Revenue collected per month in ${cur}">${grid}${bars}</svg>
    <div class="bl-faint" style="margin-top:4px;">Amounts in ${escapeHtml(cur)}, as received (VAT included).</div>`;
}

function blStatusBreakdown(by, total){
  const order = ['active', 'trialing', 'past_due', 'pending', 'read_only', 'expired', 'cancelled', 'no_plan'];
  const tone = {active: 'green', trialing: 'blue', past_due: 'amber', pending: 'amber', read_only: 'red', expired: 'red', cancelled: 'faint', no_plan: 'faint'};
  const rows = order.filter(k => by[k]);
  if (!total) return blEmpty('users', 'No customers yet', 'Add your first customer, or let members sign up and pick a plan.', `<button onclick="blNewCustomer()">${blIcon('plus')}New customer</button>`);
  return `<div class="bl-stack">${rows.map(k => `<i class="bl-seg-${tone[k]}" style="width:${by[k] / total * 100}%" title="${escapeHtml((BL_STATUS[k] || [k])[0])}: ${by[k]}"></i>`).join('')}</div>
    <div class="bl-legend">${rows.map(k => `<div><span class="bl-dot bl-seg-${tone[k]}"></span>${escapeHtml((BL_STATUS[k] || [k])[0])}<b>${by[k]}</b><span class="bl-faint">${Math.round(by[k] / total * 100)}%</span></div>`).join('')}</div>`;
}

async function blRunSweep(btn){
  btn.disabled = true;
  try { const r = await blSend('POST', '/api/admin/billing/sweep'); showToast(`${r.renewal_invoices} renewal invoice(s) raised, ${r.cards_charged} card(s) charged.`); await blRenderAdmin(); }
  catch (e) { showToast(e.message); btn.disabled = false; }
}

// ---- Customers ---------------------------------------------------------------
async function blAdminCustomers(){
  const d = await blGet('/api/admin/billing/overview');
  blState.customers = d.organisations;
  blState.custFilter = blState.custFilter || '';
  blState.custQuery = blState.custQuery || '';
  document.getElementById('blAdminBody').innerHTML = `
    ${blHeader('Customers', `${d.organisations.length} organisation${d.organisations.length === 1 ? '' : 's'}${d.members_without_org ? ` · <span class="bl-warn">${d.members_without_org} member account(s) not yet in an organisation</span>` : ''}`,
      `<button onclick="blNewCustomer()">${blIcon('plus')}New customer</button>`)}
    <div class="panel bl-flush">
      <div class="bl-toolbar">
        <div class="bl-search">${blIcon('search')}<input placeholder="Search by name or email" value="${escapeHtml(blState.custQuery)}" oninput="blState.custQuery=this.value;blCustomerRows()"></div>
        <div class="bl-seg" id="blCustSeg"></div>
      </div>
      <div id="blCustTable"></div>
    </div>`;
  blCustomerRows();
}
function blCustomerRows(){
  const all = blState.customers || [];
  const groups = [['', 'All'], ['active', 'Active'], ['trialing', 'Trial'], ['past_due', 'Overdue'], ['pending', 'Awaiting payment'], ['read_only', 'Read-only'], ['inactive', 'Ended']];
  const match = (o, k) => !k || (k === 'inactive' ? ['expired', 'cancelled', 'no_plan'].includes(o.status) : o.status === k);
  document.getElementById('blCustSeg').innerHTML = groups.map(([k, l]) => {
    const n = all.filter(o => match(o, k)).length;
    return (k && !n) ? '' : `<button class="${blState.custFilter === k ? 'active' : ''}" onclick="blState.custFilter='${k}';blCustomerRows()">${l}<span>${n}</span></button>`;
  }).join('');
  const q = blState.custQuery.toLowerCase();
  const rows = all.filter(o => match(o, blState.custFilter) && (!q || (o.name + ' ' + (o.billing_email || '')).toLowerCase().includes(q)));
  const el = document.getElementById('blCustTable');
  const tb = el.parentElement.querySelector('.bl-toolbar');
  if (tb) tb.style.display = all.length ? '' : 'none';
  if (!all.length) { el.innerHTML = blEmpty('users', 'No customers yet', 'Create an organisation for each client, then add their users and start a plan. Members who sign up can also choose a plan themselves.', `<button onclick="blNewCustomer()">${blIcon('plus')}New customer</button>`); return; }
  if (!rows.length) { el.innerHTML = blEmpty('search', 'No matches', 'Try a different search or filter.'); return; }
  el.innerHTML = `<table class="bl-table"><thead><tr><th>Organisation</th><th>Plan</th><th>Status</th><th>Renews / ends</th><th>Users</th><th class="num">Balance due</th></tr></thead><tbody>
    ${rows.map(o => `<tr class="bl-click" onclick="blOpenOrg(${o.id})">
      <td>${blAvatar(o.name)}<span class="bl-strong">${escapeHtml(o.name)}</span><div class="bl-faint bl-indent">${escapeHtml(o.billing_email || 'No billing email')}</div></td>
      <td>${o.plan ? escapeHtml(o.plan) : '<span class="bl-faint">—</span>'}${o.auto_renew_card ? `<span class="bl-tag" title="Card saved for automatic renewal">${blIcon('card')}auto</span>` : ''}</td>
      <td>${blPill(o.status)}</td><td>${blDate(o.period_end)}</td>
      <td>${o.seats ? `<div class="bl-seats"><div class="bl-seat-bar"><i style="width:${Math.min(100, o.seats_used / o.seats * 100)}%"></i></div>${o.seats_used}/${o.seats}</div>` : `<span class="bl-faint">${o.seats_used}</span>`}</td>
      <td class="num">${o.balance_due ? `<span class="bl-strong">${blMoney(o.balance_due, o.currency)}</span>` : '<span class="bl-faint">—</span>'}</td></tr>`).join('')}
  </tbody></table>`;
}

function blNewCustomer(){
  blModal({title: 'New customer', intro: 'Create the organisation that will be billed. You can add its users and start a plan next.',
    fields: [{name: 'name', label: 'Organisation name', required: true, full: true, placeholder: 'e.g. KCB Group PLC'},
      {name: 'billing_email', label: 'Billing email', type: 'email', placeholder: 'accounts@company.co.ke'},
      {name: 'phone', label: 'Phone', placeholder: '+254 7..'},
      {name: 'kra_pin', label: 'KRA PIN', placeholder: 'P051234567X'},
      {name: 'country', label: 'Country', value: 'Kenya'},
      {name: 'address', label: 'Address', full: true, placeholder: 'P.O. Box, town'}],
    submitLabel: 'Create customer',
    onSubmit: async v => { const o = await blSend('POST', '/api/admin/billing/orgs', v); showToast('Customer created.'); blOpenOrg(o.id); }});
}

// ---- Customer detail ---------------------------------------------------------
async function blAdminOrg(orgId){
  const [d, plans] = await Promise.all([blGet(`/api/admin/billing/orgs/${orgId}`), blGet('/api/admin/billing/plans')]);
  blState.org = d; blState.allPlans = plans;
  const o = d.organisation, sub = d.subscription, st = sub ? d.status : 'no_plan';
  const plan = sub && sub.plan;
  const until = sub ? (st === 'trialing' ? sub.trial_end : sub.current_period_end) : null;
  const cur = plan ? plan.currency : ((d.invoices[0] || {}).currency || 'KES');
  const meta = [o.billing_email, o.phone, o.kra_pin ? 'KRA PIN ' + o.kra_pin : '', o.country].filter(Boolean).map(escapeHtml).join(' · ');
  document.getElementById('blAdminBody').innerHTML = `
    <button class="bl-back" onclick="blGoTab('customers')">${blIcon('back')}Customers</button>
    <div class="panel bl-org-head">
      ${blAvatar(o.name, 'lg')}
      <div class="bl-org-id"><div class="bl-org-name">${escapeHtml(o.name)} ${blPill(st)}</div><div class="bl-faint">${meta || 'No contact details yet'}</div></div>
      <div class="bl-head-act"><button class="secondary" onclick="blEditOrg()">Edit details</button><button class="secondary" onclick="blNewInvoice()">${blIcon('doc')}New invoice</button><button onclick="blChangePlan()">${sub ? 'Change plan' : 'Start a plan'}</button></div>
    </div>

    <div class="bl-stats three">
      <div class="bl-stat"><div class="bl-stat-top"><span class="bl-stat-icon bl-blue">${blIcon('tag')}</span><span>Plan</span></div>
        <div class="bl-stat-value sm">${plan ? escapeHtml(plan.name) : 'No plan'}</div>
        <div class="bl-faint">${plan ? `${blMoney(plan.price, plan.currency)} / ${blPer(plan.interval_months)}${until ? ` · ${st === 'trialing' ? 'trial ends' : sub.cancel_at_period_end ? 'ends' : 'renews'} ${blDate(until)}` : ''}` : 'Start a plan to give this customer access'}</div></div>
      <div class="bl-stat"><div class="bl-stat-top"><span class="bl-stat-icon bl-blue">${blIcon('users')}</span><span>Users</span></div>
        <div class="bl-stat-value sm">${d.seats_used}${d.seats ? ' of ' + d.seats : ''}</div>
        ${d.seats ? `<div class="bl-seat-bar wide"><i style="width:${Math.min(100, d.seats_used / d.seats * 100)}%"></i></div>` : '<div class="bl-faint">Seats come with the plan</div>'}</div>
      <div class="bl-stat"><div class="bl-stat-top"><span class="bl-stat-icon ${d.balance_due ? 'bl-amber' : 'bl-green'}">${blIcon('wallet')}</span><span>Balance due</span></div>
        <div class="bl-stat-value sm ${d.balance_due ? '' : 'bl-pos'}">${blMoney(d.balance_due, cur)}</div>
        <div class="bl-faint">${sub && sub.card_label ? escapeHtml(sub.card_label) + ' saved for renewals' : 'Invoice billing'}</div></div>
    </div>

    <div class="panel bl-flush">
      <div class="bl-card-head padded"><div class="bl-card-title">Invoices</div><button class="secondary sm" onclick="blNewInvoice()">${blIcon('plus')}New invoice</button></div>
      ${d.invoices.length ? blInvoiceTable(d.invoices, false) : blEmpty('doc', 'No invoices yet', 'Starting a plan raises its first invoice. One-off items such as a report can be invoiced with New invoice.')}
    </div>

    <div class="bl-grid-2">
      <div class="panel"><div class="bl-card-head"><div class="bl-card-title">Users</div><button class="secondary sm" onclick="blAddUser()">${blIcon('plus')}Add user</button></div>
        ${d.members.length ? d.members.map(m => `<div class="bl-person">${blAvatar(m.name, 'sm')}<div><span class="bl-strong">${escapeHtml(m.name)}</span>${m.org_role === 'owner' ? ' <span class="bl-tag">Account owner</span>' : ''}<div class="bl-faint">${escapeHtml(m.email)}</div></div>
          <div class="bl-row-act">${m.org_role !== 'owner' ? `<button class="bl-link" onclick="blAssign(${o.id}, '${escapeHtml(m.email)}', 'owner')">Make owner</button>` : ''}<button class="bl-link danger" onclick="blUnassign(${o.id}, ${m.id}, '${escapeHtml(m.name).replace(/'/g, "\\'")}')">Remove</button></div></div>`).join('')
          : blEmpty('users', 'No users yet', 'Add the member accounts that should use this subscription. The first one you mark as owner can manage colleagues and payment.')}
      </div>
      <div class="panel"><div class="bl-card-head"><div class="bl-card-title">Plan history</div></div>
        ${d.subscriptions.length ? `<ol class="bl-timeline">${d.subscriptions.map(s => {
          const es = s.effective_status;
          const live = ['trialing', 'active', 'past_due', 'read_only', 'pending', 'expired'].includes(es);
          return `<li><div class="bl-strong">${escapeHtml(s.plan ? s.plan.name : '')} ${blPill(es)}</div>
            <div class="bl-faint">${es === 'trialing' || (es === 'expired' && s.trial_end && !s.current_period_end) ? 'Trial until ' + blDate(s.trial_end) : s.current_period_end ? blDate(s.current_period_start) + ' – ' + blDate(s.current_period_end) : 'Starts when the first invoice is paid'}${s.seats_override ? ' · ' + s.seats_override + ' users agreed' : ''}${s.cancel_at_period_end ? ' · cancels at period end' : ''}</div>
            ${live ? `<div class="bl-row-act left"><button class="bl-link" onclick="blAddDays(${s.id}, '${es === 'trialing' || (es === 'expired' && s.trial_end && !s.current_period_end) ? 'extend_trial_days' : 'extend_days'}')">Add free days</button>
              <button class="bl-link" onclick="blSeats(${s.id}, ${s.seats})">Change users</button>
              <button class="bl-link danger" onclick="blCancelSub(${s.id})">Cancel now</button></div>` : ''}</li>`; }).join('')}</ol>`
          : blEmpty('tag', 'No plan yet', 'Use Start a plan to begin a trial, invoice a plan, or give complimentary access.')}
      </div>
    </div>
    ${o.notes ? `<div class="panel"><div class="bl-card-title" style="margin-bottom:6px;">Internal notes</div><div class="bl-faint" style="white-space:pre-wrap;">${escapeHtml(o.notes)}</div></div>` : ''}`;
}

function blInvoiceTable(list, showCustomer){
  return `<table class="bl-table"><thead><tr><th>Invoice</th>${showCustomer ? '<th>Customer</th>' : ''}<th>Due</th><th class="num">Total</th><th class="num">Balance</th><th>Status</th><th></th></tr></thead><tbody>
    ${list.map(i => {
      const owed = i.status === 'open' ? Math.max(0, i.total - (i.amount_paid || 0)) : 0;
      return `<tr>
      <td><span class="bl-strong bl-mono">${escapeHtml(i.number)}</span>${i.etims_number ? `<span class="bl-tag" title="KRA eTIMS number">eTIMS</span>` : ''}<div class="bl-faint bl-clip" title="${escapeHtml(i.description)}">${escapeHtml(i.description)}</div><div class="bl-faint">Issued ${blDate(i.issued_at)}</div></td>
      ${showCustomer ? `<td class="nw"><span class="bl-linkish" onclick="blOpenOrg(${i.organisation_id})">${escapeHtml(i.organisation || '')}</span></td>` : ''}
      <td class="nw ${blIsOverdue(i) ? 'bl-neg' : ''}">${blDate(i.due_at)}</td>
      <td class="num">${blMoney(i.total, i.currency)}${i.vat_amount ? `<div class="bl-faint">incl. VAT ${blMoney(i.vat_amount, i.currency)}</div>` : ''}</td>
      <td class="num">${owed ? `<span class="bl-strong">${blMoney(owed, i.currency)}</span>` : '<span class="bl-faint">—</span>'}</td>
      <td>${blInvPill(i)}</td>
      <td class="bl-actions">${i.status === 'open' ? `<button class="sm" onclick="blRecordPayment(${i.id})">Record payment</button>` : ''}
        <div class="bl-menu"><button class="secondary sm bl-dots" onclick="blToggleMenu(event, this)" aria-label="More">⋯</button><div class="bl-menu-list">
          <button onclick="window.open('/billing/invoice/${i.id}', '_blank')">View / print</button>
          <button onclick="blEtims(${i.id})">${i.etims_number ? 'Change' : 'Add'} eTIMS number</button>
          ${i.status === 'open' ? `<button class="danger" onclick="blVoid(${i.id}, '${escapeHtml(i.number)}')">Void invoice</button>` : ''}
        </div></div></td></tr>`; }).join('')}
  </tbody></table>`;
}
function blCloseMenus(){ document.querySelectorAll('.bl-menu.open').forEach(m => m.classList.remove('open')); }
function blToggleMenu(e, btn){
  e.stopPropagation();
  const menu = btn.parentElement;
  const open = menu.classList.contains('open');
  blCloseMenus();
  if (open) return;
  menu.classList.add('open');
  // The list floats above the page (position:fixed) so a table's scroll area can't clip it; it opens upwards
  // when there isn't room below the button.
  const list = menu.querySelector('.bl-menu-list');
  if (!list) return;
  const r = btn.getBoundingClientRect();
  list.style.position = 'fixed';
  list.style.right = 'auto';
  list.style.top = '0px'; list.style.left = '0px';
  const w = list.offsetWidth, h = list.offsetHeight;
  const left = Math.max(8, Math.min(r.right - w, window.innerWidth - w - 8));
  const below = r.bottom + 4 + h <= window.innerHeight - 8;
  list.style.left = left + 'px';
  list.style.top = (below ? r.bottom + 4 : Math.max(8, r.top - 4 - h)) + 'px';
}
document.addEventListener('click', blCloseMenus);
window.addEventListener('scroll', blCloseMenus, true);
window.addEventListener('resize', blCloseMenus);

function blFindInvoice(id){
  const lists = [(blState.org || {}).invoices || [], blState.invoices || []];
  for (const l of lists) { const f = l.find(i => i.id === id); if (f) return f; }
  return null;
}
async function blAdminRefresh(){ await blRenderAdmin(); }

function blChangePlan(){
  const d = blState.org;
  const plans = (blState.allPlans || []).filter(p => p.active);
  blModal({title: d.subscription ? 'Change plan' : 'Start a plan',
    intro: d.subscription ? 'The new plan starts when its first invoice is paid (or straight away if complimentary). The current plan keeps working until then.' : '',
    fields: [{name: 'plan_code', label: 'Plan', type: 'select', full: true, options: plans.map(p => [p.code, `${p.name} — ${blMoney(p.price, p.currency)} / ${blPer(p.interval_months)}`])},
      {name: 'mode', label: 'How it starts', type: 'select', full: true, value: 'invoice', options: [
        ['invoice', 'Invoice now — access starts when paid'], ['trial', 'Free trial first, then invoice'], ['complimentary', 'Complimentary — active now, no invoice']]},
      {name: 'seats_override', label: 'Users (optional)', type: 'number', placeholder: "Plan's number", hint: 'Only if you agreed a different number of users.'}],
    submitLabel: 'Start plan',
    onSubmit: async v => {
      await blSend('POST', `/api/admin/billing/orgs/${d.organisation.id}/plan`, {plan_code: v.plan_code, mode: v.mode, seats_override: v.seats_override ? Number(v.seats_override) : null});
      showToast('Plan started.'); await blAdminRefresh(); }});
}

function blEditOrg(){
  const o = blState.org.organisation;
  blModal({title: 'Edit customer details',
    fields: [{name: 'name', label: 'Organisation name', value: o.name, required: true, full: true},
      {name: 'billing_email', label: 'Billing email', type: 'email', value: o.billing_email},
      {name: 'phone', label: 'Phone', value: o.phone}, {name: 'kra_pin', label: 'KRA PIN', value: o.kra_pin},
      {name: 'country', label: 'Country', value: o.country}, {name: 'address', label: 'Address', value: o.address, full: true},
      {name: 'notes', label: 'Internal notes', type: 'textarea', value: o.notes, full: true, hint: 'Only visible to super admins.'}],
    onSubmit: async v => { await blSend('PATCH', `/api/admin/billing/orgs/${o.id}`, v); showToast('Saved.'); await blAdminRefresh(); }});
}

function blNewInvoice(){
  const o = blState.org.organisation;
  blModal({title: 'New one-off invoice', intro: `For ${escapeHtml(o.name)}. Use it for reports, consulting or a quoted price — plan invoices are raised automatically.`,
    fields: [{name: 'description', label: 'Description', required: true, full: true, placeholder: 'e.g. FY2025 Board Remuneration & Governance Report'},
      {name: 'amount', label: 'Amount before VAT', type: 'number', required: true},
      {name: 'currency', label: 'Currency', type: 'select', options: [['KES', 'KES'], ['USD', 'USD']]},
      {name: 'vat_rate', label: 'VAT %', type: 'number', placeholder: 'Default', hint: 'Leave blank to use the default rate.'},
      {name: 'due_days', label: 'Due in (days)', type: 'number', value: 14}],
    submitLabel: 'Create invoice',
    onSubmit: async v => {
      await blSend('POST', `/api/admin/billing/orgs/${o.id}/invoices`, {description: v.description, amount: Number(v.amount), currency: v.currency,
        vat_rate: v.vat_rate === '' ? null : Number(v.vat_rate), due_days: Number(v.due_days || 14)});
      showToast('Invoice created.'); await blAdminRefresh(); }});
}

function blAddUser(){
  const o = blState.org.organisation;
  blModal({title: 'Add user', intro: 'Add an existing member account to this customer. New accounts are created under Settings › User Management.',
    fields: [{name: 'email', label: 'Their email', type: 'email', required: true, full: true},
      {name: 'org_role', label: 'Role', type: 'select', full: true, options: [['member', 'Member — uses the app'], ['owner', 'Account owner — also manages colleagues and payment']]}],
    submitLabel: 'Add user',
    onSubmit: async v => { await blSend('POST', `/api/admin/billing/orgs/${o.id}/members`, v); showToast('User added.'); await blAdminRefresh(); }});
}

async function blAssign(orgId, email, role){
  try { await blSend('POST', `/api/admin/billing/orgs/${orgId}/members`, {email, org_role: role}); showToast('Account owner changed.'); await blAdminRefresh(); }
  catch (e) { showToast(e.message); }
}
function blUnassign(orgId, userId, name){
  blConfirm('Remove user', `Remove <b>${escapeHtml(name)}</b> from this customer? Their account is kept, but loses access through this subscription.`, 'Remove',
    async () => { await blSend('DELETE', `/api/admin/billing/orgs/${orgId}/members/${userId}`); await blAdminRefresh(); });
}

function blRecordPayment(invoiceId){
  const i = blFindInvoice(invoiceId);
  const owed = i ? Math.max(0, i.total - (i.amount_paid || 0)) : '';
  const today = new Date().toISOString().slice(0, 10);
  blModal({title: 'Record payment', intro: i ? `Invoice <b>${escapeHtml(i.number)}</b> · ${escapeHtml(i.organisation || '')} · balance ${blMoney(owed, i.currency)}` : '',
    fields: [{name: 'amount', label: `Amount received${i ? ' (' + i.currency + ')' : ''}`, type: 'number', value: owed, required: true},
      {name: 'method', label: 'Method', type: 'select', options: BL_METHODS},
      {name: 'reference', label: 'Reference', placeholder: 'Bank ref or M-Pesa code', hint: 'e.g. QK7XB12ABC'},
      {name: 'paid_at', label: 'Date received', type: 'date', value: today},
      {name: 'note', label: 'Note (optional)', full: true}],
    submitLabel: 'Record payment',
    onSubmit: async v => {
      const r = await blSend('POST', `/api/admin/billing/invoices/${invoiceId}/payments`, {...v, amount: Number(v.amount)});
      showToast(r.invoice.status === 'paid' ? 'Payment recorded — invoice paid.' : 'Part payment recorded.'); await blAdminRefresh(); }});
}

function blEtims(invoiceId){
  const i = blFindInvoice(invoiceId);
  blModal({title: 'KRA eTIMS number', intro: 'The invoice number issued by eTIMS for this invoice. It is printed on the invoice.',
    fields: [{name: 'etims_number', label: 'eTIMS invoice number', value: i ? i.etims_number : '', full: true}],
    onSubmit: async v => { await blSend('PATCH', `/api/admin/billing/invoices/${invoiceId}`, v); showToast('Saved.'); await blAdminRefresh(); }});
}

function blVoid(invoiceId, number){
  blConfirm('Void invoice', `Void <b>${escapeHtml(number)}</b>? It will no longer be owed. This cannot be undone.`, 'Void invoice',
    async () => { await blSend('PATCH', `/api/admin/billing/invoices/${invoiceId}`, {status: 'void'}); showToast('Invoice voided.'); await blAdminRefresh(); });
}

function blAddDays(subId, field){
  blModal({title: field === 'extend_trial_days' ? 'Extend free trial' : 'Add free days',
    intro: field === 'extend_trial_days' ? 'The trial end date and the first invoice move out by this many days.' : 'Extends the current paid period at no charge.',
    fields: [{name: 'days', label: 'Days', type: 'number', value: 14, required: true, full: true}],
    submitLabel: 'Add days',
    onSubmit: async v => { await blSend('PATCH', `/api/admin/billing/subscriptions/${subId}`, {[field]: Number(v.days)}); showToast('Done.'); await blAdminRefresh(); }});
}

function blSeats(subId, current){
  blModal({title: 'Change number of users', intro: 'Overrides the plan\'s number of users for this customer only. Leave blank to go back to the plan\'s number.',
    fields: [{name: 'seats', label: 'Users', type: 'number', value: current, full: true}],
    onSubmit: async v => { await blSend('PATCH', `/api/admin/billing/subscriptions/${subId}`, {seats_override: v.seats ? Number(v.seats) : null}); await blAdminRefresh(); }});
}

function blCancelSub(subId){
  blConfirm('Cancel plan now', 'Access ends immediately and any open invoices for this plan are voided. To stop at the end of the paid period instead, the customer can cancel from their own Billing page.',
    'Cancel plan', async () => { await blSend('PATCH', `/api/admin/billing/subscriptions/${subId}`, {cancel: true}); showToast('Plan cancelled.'); await blAdminRefresh(); });
}

// ---- Invoices ----------------------------------------------------------------
async function blAdminInvoices(){
  const list = await blGet('/api/admin/billing/invoices');
  blState.invoices = list;
  blState.invFilter = blState.invFilter == null ? 'open' : blState.invFilter;
  blState.invQuery = blState.invQuery || '';
  const sum = (arr, f) => { const m = {}; arr.forEach(i => { m[i.currency] = (m[i.currency] || 0) + f(i); }); return m; };
  const open = list.filter(i => i.status === 'open');
  const overdue = open.filter(blIsOverdue);
  const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
  const paidMonth = list.filter(i => i.status === 'paid' && i.paid_at && new Date(i.paid_at + 'Z') >= monthStart);
  const owed = i => Math.max(0, i.total - (i.amount_paid || 0));
  const stat = (icon, tone, label, value, sub) => `<div class="bl-stat"><div class="bl-stat-top"><span class="bl-stat-icon bl-${tone}">${blIcon(icon)}</span><span>${label}</span></div><div class="bl-stat-value sm">${value}</div><div class="bl-faint">${sub}</div></div>`;
  document.getElementById('blAdminBody').innerHTML = `
    ${blHeader('Invoices', 'Every invoice raised, with payments recorded against it.', '')}
    <div class="bl-stats">
      ${stat('wallet', 'amber', 'Outstanding', blMoneyMap(sum(open, owed)), `${open.length} open invoice${open.length === 1 ? '' : 's'}`)}
      ${stat('alert', overdue.length ? 'red' : 'green', 'Overdue', blMoneyMap(sum(overdue, owed)), overdue.length ? `${overdue.length} past due date` : 'Nothing overdue')}
      ${stat('check', 'green', 'Paid this month', blMoneyMap(sum(paidMonth, i => i.total)), `${paidMonth.length} invoice${paidMonth.length === 1 ? '' : 's'}`)}
      ${stat('doc', 'blue', 'Raised in total', String(list.length), `${list.filter(i => i.status === 'void').length} void`)}
    </div>
    <div class="panel bl-flush">
      <div class="bl-toolbar">
        <div class="bl-search">${blIcon('search')}<input placeholder="Search invoice number, customer or description" value="${escapeHtml(blState.invQuery)}" oninput="blState.invQuery=this.value;blInvoiceRows()"></div>
        <div class="bl-seg" id="blInvSeg"></div>
      </div>
      <div id="blInvTable"></div>
    </div>`;
  blInvoiceRows();
}
function blInvoiceRows(){
  const all = blState.invoices || [];
  const groups = [['open', 'Open', i => i.status === 'open'], ['overdue', 'Overdue', blIsOverdue], ['paid', 'Paid', i => i.status === 'paid'], ['void', 'Void', i => i.status === 'void'], ['', 'All', () => true]];
  document.getElementById('blInvSeg').innerHTML = groups.map(([k, l, f]) => `<button class="${blState.invFilter === k ? 'active' : ''}" onclick="blState.invFilter='${k}';blInvoiceRows()">${l}<span>${all.filter(f).length}</span></button>`).join('');
  const f = (groups.find(g => g[0] === blState.invFilter) || groups[4])[2];
  const q = blState.invQuery.toLowerCase();
  const rows = all.filter(i => f(i) && (!q || `${i.number} ${i.organisation || ''} ${i.description}`.toLowerCase().includes(q)));
  const el = document.getElementById('blInvTable');
  const tb = el.parentElement.querySelector('.bl-toolbar');
  if (tb) tb.style.display = all.length ? '' : 'none';
  if (!all.length) { el.innerHTML = blEmpty('doc', 'No invoices yet', 'Invoices are raised when a customer starts or renews a plan, or when you create a one-off invoice from a customer\'s page.'); return; }
  el.innerHTML = rows.length ? blInvoiceTable(rows, true) : blEmpty('search', blState.invFilter === 'overdue' ? 'Nothing overdue' : 'No invoices here', blState.invFilter === 'overdue' ? 'Every open invoice is still within its due date.' : 'Try another filter or search.');
}

// ---- Plans -------------------------------------------------------------------
async function blAdminPlans(){
  const plans = await blGet('/api/admin/billing/plans');
  blState.allPlans = plans;
  const card = p => `<div class="bl-plan-card ${p.active ? '' : 'off'}">
    <div class="bl-plan-card-top"><div><div class="bl-strong">${escapeHtml(p.name)}</div><div class="bl-faint bl-mono">${escapeHtml(p.code)}</div></div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;"><span class="bl-pill bl-faint">${escapeHtml((p.tier || 'professional').replace(/^./, c => c.toUpperCase()))}</span>${p.active ? (p.self_serve ? '<span class="bl-pill bl-green">On sale</span>' : '<span class="bl-pill bl-blue">By quote</span>') : '<span class="bl-pill bl-faint">Hidden</span>'}</div></div>
    <div class="bl-plan-card-price">${blMoney(p.price, p.currency)}<span> / ${blPer(p.interval_months)}</span></div>
    <div class="bl-faint bl-plan-desc">${escapeHtml(p.description || 'No description')}</div>
    <ul class="bl-plan-facts"><li>${p.seats} user${p.seats === 1 ? '' : 's'}</li>${blDlFacts(p)}
      <li>${p.interval_months === 12 ? 'Billed yearly' : p.interval_months === 1 ? 'Billed monthly' : 'Billed every ' + p.interval_months + ' months'}</li></ul>
    <div class="bl-plan-card-foot"><button class="secondary sm" onclick="blEditPlan(${p.id})">Edit</button>
      <button class="bl-link" onclick="blTogglePlan(${p.id}, ${!p.active})">${p.active ? 'Hide from sale' : 'Put on sale'}</button></div>
  </div>`;
  document.getElementById('blAdminBody').innerHTML = `
    ${blHeader('Plans and prices', 'Prices exclude VAT. A price change applies to new invoices and renewals; invoices already raised keep their price.',
      `<button onclick="blEditPlan(null)">${blIcon('plus')}New plan</button>`)}
    <div class="bl-plan-grid">${plans.map(card).join('')}</div>`;
}

function blEditPlan(id){
  const p = id ? (blState.allPlans || []).find(x => x.id === id) : {name: '', code: '', price: '', currency: 'KES', interval_months: 12, seats: 1, report_downloads_per_month: null, data_downloads_per_month: 20, bulk_downloads_per_month: 0, description: '', self_serve: true, active: true, sort_order: 100};
  const dlVal = v => v === null || v === undefined ? '' : v;
  const fields = [
    ...(id ? [] : [{name: 'code', label: 'Code', required: true, placeholder: 'e.g. east_africa_annual', hint: 'Short ID, letters and underscores. Cannot be changed later.'}]),
    {name: 'name', label: 'Name', value: p.name, required: true, full: !!id, placeholder: 'e.g. East Africa - annual'},
    {name: 'tier', label: 'Package (pages it unlocks)', type: 'select', value: p.tier || 'professional', full: true,
      options: [['professional', 'Professional — company reports, analytics, documents'], ['team', 'Team — adds intelligence report and data quality'], ['enterprise', 'Enterprise — same pages as Team, plus enterprise limits']]},
    {name: 'price', label: 'Price before VAT', type: 'number', value: p.price, required: true},
    {name: 'currency', label: 'Currency', type: 'select', value: p.currency, options: [['KES', 'KES'], ['USD', 'USD']]},
    {name: 'interval_months', label: 'Billing period', type: 'select', value: p.interval_months, options: [[1, 'Monthly'], [3, 'Quarterly'], [6, 'Every 6 months'], [12, 'Yearly']]},
    {name: 'seats', label: 'Users included', type: 'number', value: p.seats, required: true},
    {name: 'report_downloads_per_month', label: 'Report downloads a month', type: 'number', value: dlVal(p.report_downloads_per_month), placeholder: 'Unlimited', hint: 'PDF and Word reports. Blank = unlimited, 0 = not included.'},
    {name: 'data_downloads_per_month', label: 'Data downloads a month', type: 'number', value: dlVal(p.data_downloads_per_month), placeholder: 'Unlimited', hint: 'CSV and Excel files. Blank = unlimited, 0 = not included.'},
    {name: 'bulk_downloads_per_month', label: 'Bulk downloads a month', type: 'number', value: dlVal(p.bulk_downloads_per_month), placeholder: 'Unlimited', hint: 'ZIP bundles and whole-portfolio files. Blank = unlimited, 0 = not included.'},
    {name: 'sort_order', label: 'Display order', type: 'number', value: p.sort_order, hint: 'Lower numbers show first.'},
    {name: 'description', label: 'Description shown to customers', type: 'textarea', value: p.description, full: true},
    {name: 'self_serve', label: 'Customers can buy it themselves', type: 'checkbox', value: p.self_serve, hint: 'Untick for quoted plans such as Enterprise ("Contact us").', full: true},
    {name: 'active', label: 'On sale', type: 'checkbox', value: p.active, hint: 'Hidden plans keep working for existing customers.', full: true}];
  blModal({title: id ? 'Edit plan' : 'New plan', fields, wide: true, submitLabel: id ? 'Save plan' : 'Create plan',
    onSubmit: async v => {
      const body = {...v, price: Number(v.price), interval_months: Number(v.interval_months), seats: Number(v.seats),
        sort_order: Number(v.sort_order || 0)};
      BL_DL.forEach(([f]) => { body[f] = v[f] === '' ? null : Number(v[f]); });
      await blSend(id ? 'PATCH' : 'POST', id ? `/api/admin/billing/plans/${id}` : '/api/admin/billing/plans', body);
      blState.plans = null; showToast(id ? 'Plan saved.' : 'Plan created.'); await blRenderAdmin(); }});
}
async function blTogglePlan(id, on){
  try { await blSend('PATCH', `/api/admin/billing/plans/${id}`, {active: on}); blState.plans = null; await blRenderAdmin(); }
  catch (e) { showToast(e.message); }
}

// ---- Leave out what is not available ----------------------------------------------------------------------
// On the reading pages (company reports, analytics, Intelligence Report, dashboard) a figure the annual report
// does not disclose is left out instead of showing "Not available": empty rows, empty cards and panels with
// nothing left in them are removed after each render. Admin pages that exist to show gaps (Survey Mapping,
// Data Quality, Evidence, Manual Entry, Report Reviews) keep every row so missing fields stay visible there.
const FI_PRUNE_PAGES = new Set(['survey-report', 'survey-analytics', 'intelligence-layer', 'home']);
const FI_KEEP_SR_TABS = new Set(['survey-mapping', 'data-quality', 'evidence']);
function fiPruneActive(){
  if (!FI_PRUNE_PAGES.has(currentPage)) return false;
  if (currentPage === 'survey-report' && typeof srTab !== 'undefined' && FI_KEEP_SR_TABS.has(srTab)) return false;
  return true;
}
function fiOnlyNa(el, skipSel){
  // True when el shows nothing but "Not available" markers (plus labels / dashes).
  if (!el || !el.querySelector('.na')) return false;
  const c = el.cloneNode(true);
  c.querySelectorAll('.na' + (skipSel ? ',' + skipSel : '')).forEach(n => n.remove());
  return !c.textContent.replace(/[\s—–\-·:]/g, '');
}
function fiPanelEmpty(p){
  if (p.querySelector('canvas, img, select, input, textarea, button:not(.ov-panel-link):not(.panel-link), .chart, .ir-kv-row, tbody tr, .sa-bar-row, .mini-bar-col, svg.bl-chart')) return false;
  const c = p.cloneNode(true);
  c.querySelectorAll('.na, h1, h2, h3, h4, .sa-panel-title, .ir-panel-title, .ov-panel-head, .panel-head, .bl-card-head, .ov-panel-link, .panel-link, .empty').forEach(n => n.remove());
  return !c.textContent.replace(/[\s—–\-·:]/g, '');
}
function fiPruneEmpty(root){
  if (!root || !fiPruneActive()) return;
  root.querySelectorAll('.ir-kv-row').forEach(r => { if (fiOnlyNa(r, '.k')) r.remove(); });
  // A row whose figure is missing goes, even when it carries a status pill or confidence badge.
  const FI_BADGES = '.ov-status-pill, .sr-conf-badge, .doc-badge, .bl-pill, .bl-tag';
  root.querySelectorAll('tbody tr').forEach(tr => {
    const cells = [...tr.children].slice(1);
    if (!cells.length || !tr.querySelector('.na')) return;
    const blank = td => { const c = td.cloneNode(true); c.querySelectorAll('.na, ' + FI_BADGES).forEach(n => n.remove());
                          return !c.textContent.replace(/[\s—–\-·:]/g, ''); };
    if (cells.every(blank)) tr.remove();
  });
  // A column nobody has a figure for (e.g. attendance in a register where no director's attendance was filed).
  root.querySelectorAll('table').forEach(t => {
    const head = t.querySelector('thead tr'), body = [...t.querySelectorAll('tbody tr')];
    if (!head || !body.length || t.querySelector('[colspan]')) return;
    for (let i = head.children.length - 1; i > 0; i--) {
      const col = body.map(r => r.children[i]).filter(Boolean);
      if (col.length === body.length && col.every(td => fiOnlyNa(td))) {
        head.children[i].remove(); col.forEach(td => td.remove());
      }
    }
  });
  root.querySelectorAll('table').forEach(t => { const b = t.querySelector('tbody'); if (b && !b.querySelector('tr')) t.remove(); });
  root.querySelectorAll('.sa-stat-card, .sr-kpi, .stat-card, .ov-stat-card, .sr-stat-card, .sa-mini-stat, .summary-metric').forEach(card => {
    const v = card.querySelector('.sa-stat-value, .sr-kpi-value, .stat-value, .ov-stat-value, .sr-stat-value, .n, .sm-val');
    if (v && fiOnlyNa(v)) card.remove();
  });
  root.querySelectorAll('.empty').forEach(e => { if (fiOnlyNa(e)) e.remove(); });
  root.querySelectorAll('.panel').forEach(p => { if (fiPanelEmpty(p)) p.remove(); });
}
(function(){
  let queued = false;
  const run = () => { queued = false; try { fiPruneEmpty(document.getElementById('app')); } catch (e) { console.warn('prune', e); } };
  const obs = new MutationObserver(() => { if (!queued) { queued = true; requestAnimationFrame(run); } });
  const start = () => { const app = document.getElementById('app'); if (app) obs.observe(app, {childList: true, subtree: true}); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();

// Coalesce simultaneous identical admin analytics GETs; each caller receives its own Response.
(function(){
  const original = window.fetch.bind(window), pending = new Map();
  const allowed = new Set(['/api/companies','/api/survey/companies','/api/survey/overview','/api/survey-report/company-ranking','/api/intelligence-layer/historical-trends','/api/intelligence-layer/companies','/api/survey/data-quality-average','/api/survey/data-quality']);
  window.fetch = function(input, init){
    if (typeof input !== 'string' || init !== undefined || window.currentUser.role !== 'admin') return original(input, init);
    const url = new URL(input, location.href);
    if (url.origin !== location.origin || !allowed.has(url.pathname)) return original(input, init);
    const key = String(window.currentUser.id || window.currentUser.email) + ':' + url.href;
    let p = pending.get(key);
    if (!p) {
      p = original(input).finally(()=>{ if(pending.get(key)===p) pending.delete(key); });
      pending.set(key,p);
    }
    return p.then(r=>r.clone());
  };
})();

// ---- sign-in ended (left the app / too long / another device) and plan needed: watch every API response ----
// The server ends a sign-in when the app has been closed or in the background for a few minutes, after the
// maximum sign-in length, or when the account signs in on another device (session_policy.py, billing.py).
(function(){
  const _fetch = window.fetch.bind(window);
  let ended = false;
  window.fetch = async function(...args){
    const res = await _fetch(...args);
    try {
      const why = res.headers.get('X-Session-Ended');
      if (!ended && why) {
        ended = true;
        location.href = '/login?ended=' + encodeURIComponent(why) + '&next=' + encodeURIComponent('/app' + location.hash);
      } else if (res.status === 402) {
        res.clone().json().then(d => {
          if (d && d.billing) { if (typeof showToast === 'function') showToast(d.error); loadBillingStatus(); }
        }).catch(() => {});
      }
    } catch (e) {}
    return res;
  };
})();

// ---- presence: while the app is open (even in a background tab) check in every minute; when the person
// leaves - closes the tab, the browser or the phone app - the check-ins stop and the server ends the sign-in.
(function(){
  let lastPing = 0, pingBusy = false;
  const ping = () => { if (window.currentUser && window.currentUser.logged_in && !pingBusy && Date.now()-lastPing>=15000) { lastPing=Date.now(); pingBusy=true; fetch('/api/me', {cache:'no-store'}).catch(()=>{}).finally(()=>{pingBusy=false;}); } };
  setInterval(ping, 60000);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') ping(); });
  window.addEventListener('pageshow', e => { if (e.persisted) ping(); });     // returned via the back button
})();

// Back from the Paystack checkout page: /?billing=paid|pending|failed
function blHandleReturnFromPayment(){
  const params = new URLSearchParams(location.search);
  const r = params.get('billing');
  if (!r) return;
  params.delete('billing');
  history.replaceState(null, '', location.pathname + (params.toString() ? '?' + params : '') + location.hash);
  showToast(r === 'paid' ? 'Payment received - thank you. Your plan is active.'
    : r === 'pending' ? 'Payment is being confirmed. This page updates once Paystack confirms it.'
    : 'The payment did not go through. You can try again from Billing & Plan.');
  if (window.currentUser.logged_in) goTo('billing');
}

// ============================================================================
// Members' dashboard (home) and the upgrade screen for pages outside a member's package.
// ============================================================================
const HOME_CARDS = [
  {id:'survey-report', feature:'reports', icon:'doc', title:'Company reports', text:'Board, directors, pay, committees and benefits for any listed company and year.'},
  {id:'survey-analytics', feature:'analytics', icon:'trend', title:'Survey analytics', text:'Market averages, medians and quartiles for every pay element, by sector.'},
  {id:'intelligence-layer', feature:'intelligence', icon:'tag', title:'Intelligence report', text:'Benchmark a company against peers, rankings, trends and governance checks.'},
  {id:'data-quality', feature:'data_quality', icon:'check', title:'Data quality', text:'Completeness, confidence and the source page behind every figure.'},
  {id:'documents', feature:'documents', icon:'wallet', title:'Documents & downloads', text:'Board-ready PDF and Word reports, and Excel or CSV data files.'},
  {id:'billing', feature:'billing', icon:'card', title:'Billing & plan', text:'Your plan, invoices, payment and colleagues.'},
];
function hmMoney(v){
  if (v == null) return '—';
  const n = Number(v);
  return 'KES ' + Math.round(n).toLocaleString('en-US');
}
function hmGreeting(){
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
}
async function renderMemberHome(){
  const app = document.getElementById('app');
  setPageActions(null);
  app.innerHTML = '<div class="bl-loading"><span></span><span></span><span></span></div>';
  await loadBillingStatus();
  let s = {};
  try { const r = await fetch('/api/home/summary'); s = r.ok ? await r.json() : {}; } catch (e) {}
  const b = window.billingStatus || {};
  const u = window.currentUser;
  const feats = memberFeatures() || new Set();
  const free = b.tier === 'free';
  const first = (u.name || '').trim().split(/\s+/)[0] || '';
  const sub = b.subscription;
  const statusPill = b.status && !free ? blPill(b.status) : '';
  const until = sub ? (b.status === 'trialing' ? sub.trial_end : sub.current_period_end) : null;
  const kpi = (icon, tone, label, value, note) => `<div class="bl-stat"><div class="bl-stat-top"><span class="bl-stat-icon bl-${tone}">${blIcon(icon)}</span><span>${label}</span></div>
     <div class="bl-stat-value sm">${value}</div><div class="bl-faint">${note || '&nbsp;'}</div></div>`;
  const fy = s.fiscal_year ? escapeHtml(s.fiscal_year) : 'latest year';
  const med = m => m && m.median != null ? hmMoney(m.median) : '—';
  const nOf = m => m && m.companies ? `median of ${m.companies} companies` : 'not enough companies yet';
  const cards = HOME_CARDS.map(c => {
    const ok = feats.has(c.feature);
    const need = (b.feature_min_tier || {})[c.feature] || 'a paid';
    return `<div class="hm-card ${ok ? '' : 'locked'}" onclick="${ok ? `goTo('${c.id}')` : `showUpgrade('${c.id}')`}">
      <div class="hm-card-top"><span class="bl-stat-icon ${ok ? 'bl-blue' : 'bl-faint'}">${blIcon(c.icon)}</span>${ok ? '' : `<span class="bl-tag hm-lock">🔒 ${escapeHtml(need)}</span>`}</div>
      <div class="bl-strong">${c.title}</div><div class="bl-faint">${c.text}</div>
      <div class="hm-go">${ok ? 'Open →' : 'See plans →'}</div></div>`;
  }).join('');
  const dl = b.downloads ? BL_DL.map(([f, k, label]) => { const d = b.downloads[k] || {}; const lim = d.limit;
      const pct = lim ? Math.min(100, (d.used || 0) / lim * 100) : 0;
      return `<div class="hm-usage"><div><span>${escapeHtml(label.replace(/ \(.*\)/, ''))}</span><b>${lim === 0 ? 'Not included' : (d.used || 0) + (lim == null ? ' · unlimited' : ' of ' + lim)}</b></div>
        ${lim ? `<div class="bl-seat-bar wide"><i style="width:${pct}%"></i></div>` : ''}</div>`; }).join('') : '';
  const orgName = b.organisation ? b.organisation.name : (u.organization || '');
  hmHeaderState = {
    greeting: `${hmGreeting()}${first ? ', ' + escapeHtml(first) : ''}`,
    org: orgName && !/^n\/?a$/i.test(orgName.trim()) ? orgName : '',
    plan: escapeHtml(b.tier_label || (free ? 'Free account' : '')), pill: statusPill,
    until: until ? `${b.status === 'trialing' ? 'Trial ends' : sub.cancel_at_period_end ? 'Ends' : 'Renews'} ${blDate(until)}` : '',
    years: [], fy: null};
  hmRenderHeader();
  app.innerHTML = `
    ${free ? `<div class="bl-banner bl-banner-blue"><span>You're on a free account. Company reports, analytics, your company's comparison and downloads open with a plan${b.trial_days && !(b.organisation && b.organisation.trial_used) ? ` — start with a ${b.trial_days}-day free trial` : ''}.</span><button class="secondary" onclick="goTo('billing')">See plans</button></div>` : ''}
    <div id="hmCompany"></div>
    <div class="bl-card-head" style="margin:22px 0 10px;"><div class="bl-card-title">Your workspace</div><span class="bl-faint">${s.companies || 0} companies · ${s.years || 0} year${s.years === 1 ? '' : 's'}${s.first_year ? ' (' + escapeHtml(s.first_year) + '–' + escapeHtml(s.last_year) + ')' : ''}</span></div>
    <div class="hm-grid">
      <div><div class="hm-cards">${cards}</div></div>
      <div class="hm-side">
        <div class="panel"><div class="bl-card-head"><div class="bl-card-title">Your plan</div><span class="panel-link" onclick="goTo('billing')">Manage</span></div>
          <div class="bl-plan-name" style="font-size:16px;">${escapeHtml(sub && sub.plan ? sub.plan.name : b.tier_label || 'Free account')}</div>
          <div class="bl-faint" style="margin-bottom:12px;">${sub && sub.plan ? blMoney(sub.plan.price, sub.plan.currency) + ' / ' + blPer(sub.plan.interval_months) + ' · ' + (b.seats_used || 1) + ' of ' + (b.seats || 1) + ' users' : 'Headline figures only'}</div>
          ${dl ? `<div class="bl-faint" style="margin-bottom:6px;">Downloads this month</div>${dl}` : ''}
          ${free ? `<button style="width:100%;margin-top:10px;" onclick="goTo('billing')">Compare plans</button>` : ''}
        </div>
        <div class="panel"><div class="bl-card-title" style="margin-bottom:6px;">Need help?</div>
          <div class="bl-faint">Questions about the data, an Enterprise quote or an invoice? <a href="/contact" target="_blank" style="color:var(--blue);font-weight:600;">Contact us</a>.</div></div>
      </div>
    </div>`;
  if (feats.has('reports')) hmLoadCompany(); else document.getElementById('hmCompany').innerHTML = hmLockedCompany();
}

// ============================================================================
// Super admin: business dashboard (Dashboard Overview). Other admins keep the survey-progress overview.
// ============================================================================
function dbMoneyMap(m){
  const keys = Object.keys(m || {}).filter(k => m[k]);
  return keys.length ? keys.map(k => blMoney(m[k], k)).join(' + ') : 'KES 0';
}
function dbMainAmount(m){ const k = Object.keys(m || {}).sort((a, b) => (m[b] || 0) - (m[a] || 0))[0]; return k ? m[k] : 0; }
function dbAgo(iso){
  if (!iso) return '<span class="bl-faint">Never</span>';
  const d = (Date.now() - new Date(iso)) / 86400000;
  const t = d < 1 ? 'Today' : d < 2 ? 'Yesterday' : Math.floor(d) + ' days ago';
  return `<span class="${d > 21 ? 'bl-neg' : ''}">${t}</span>`;
}
function dbOpenCustomer(id){ blState.tab = 'customers'; blState.orgId = id; goTo('billing'); }

function dbRevenueChart(months){
  const cur = (() => { const c = {}; months.forEach(m => Object.keys(m.amounts || {}).forEach(k => { c[k] = (c[k] || 0) + (Number(m.amounts[k]) || 0); }));
    return Object.keys(c).sort((a, b) => c[b] - c[a])[0] || 'KES'; })();
  const vals = months.map(m => Number.isFinite(Number(m.amounts?.[cur])) ? Number(m.amounts[cur]) : 0);
  const max = Math.max(0, ...vals.filter(Number.isFinite));
  if (!months.length) return blEmpty('trend', 'No payment history', 'Monthly totals will appear when records are available.');
  const nice = (() => { if (!(max > 0)) return 1; const p = Math.pow(10, Math.floor(Math.log10(max))); return Math.ceil(max / p) * p; })();
  const W = 640, H = 210, L = 84, B = 26, T = 14, bw = (W - L - 8) / months.length;
  const y = v => T + (H - T - B) * (1 - v / nice);
  const full = v => Math.round(v).toLocaleString('en-US');
  const grid = [0, .5, 1].map(f => `<line x1="${L}" x2="${W - 4}" y1="${y(nice * f)}" y2="${y(nice * f)}" class="bl-gridline"/><text x="${L - 8}" y="${y(nice * f) + 4}" text-anchor="end" class="bl-axis">${full(nice * f)}</text>`).join('');
  const bars = vals.map((v, i) => {
    const x = L + i * bw + bw * .18, w = bw * .64, top = y(v);
    return `<g><title>${months[i].label} ${months[i].year}: ${cur} ${full(v)}</title>
      <rect x="${x}" y="${top}" width="${w}" height="${Math.max(0, H - B - top)}" rx="4" class="bl-bar ${i === vals.length - 1 ? 'now' : ''}"/>
      <text x="${x + w / 2}" y="${H - 8}" text-anchor="middle" class="bl-axis">${months[i].label}</text></g>`;
  }).join('');
  const total = vals.reduce((a, b) => a + b, 0);
  return `<svg viewBox="0 0 ${W} ${H}" class="bl-chart" role="img" aria-label="Money received per month">${grid}${bars}</svg>
    <div class="bl-faint" style="margin-top:6px;">${cur} ${full(total)} received in the last 12 months${max ? ' · hover a bar for details' : ' · no payments recorded yet'}</div>`;
}

async function renderBusinessDashboard(){
  const app = document.getElementById('app');
  setPageActions([
    {label: 'Upload Annual Reports', icon: '⭱', perm: 'admin', onClick: 'openUploadReportsModal()'},
    {label: 'Survey progress', icon: '📋', perm: 'admin', onClick: "goTo('survey-timeline')"},
    {label: 'Billing & customers', icon: '💳', perm: 'admin', onClick: "goTo('billing')"},
  ]);
  app.innerHTML = '<div class="bl-loading"><span></span><span></span><span></span></div>';
  let d;
  try { d = await blGet('/api/admin/dashboard'); }
  catch (e) { app.innerHTML = `<div class="panel">${blEmpty('alert', 'Could not load the dashboard', escapeHtml(e.message))}</div>`; return; }
  if (currentPage !== 'overview') return;
  const ytd = dbMainAmount(d.collected_ytd), ly = dbMainAmount(d.collected_last_year_same_period);
  const ytdNote = ly ? (() => { const ch = (ytd - ly) / ly * 100; return `<span class="${ch >= 0 ? 'bl-pos' : 'bl-neg'}">${ch >= 0 ? '▲' : '▼'} ${Math.abs(ch).toFixed(1)}%</span> vs same time last year`; })()
    : 'First year of sales';
  const overdue = Object.keys(d.overdue_total || {}).length;
  const live = d.paying + d.trialing;
  const tc = d.trial_conversion || {};
  const maxMix = Math.max(1, ...d.plan_mix.map(p => p.mrr));
  const s = (icon, tone, label, value, sub) => stStat(icon, tone, label, value, sub);

  const rows = d.customers.map(c => `<tr class="bl-click" onclick="dbOpenCustomer(${c.id})">
      <td><div class="st-user">${blAvatar(c.name)}<div><span class="bl-strong">${escapeHtml(c.name)}</span><div class="bl-faint">${c.plan ? escapeHtml(c.plan) : 'No plan'}</div></div></div></td>
      <td><span class="bl-pill bl-${c.tone}">${escapeHtml(c.health)}</span></td>
      <td class="num bl-mono">${c.price != null ? blMoney(c.price, c.currency) + `<div class="bl-faint">per ${c.interval_months === 1 ? 'month' : c.interval_months === 12 ? 'year' : c.interval_months + ' months'}</div>` : '<span class="bl-faint">—</span>'}</td>
      <td class="nw">${c.active_users_30d} of ${c.seats_used}<div class="bl-faint">${c.seats ? c.seats + ' seat' + (c.seats === 1 ? '' : 's') + ' on plan' : ''}</div></td>
      <td class="nw">${dbAgo(c.last_active)}<div class="bl-faint">${c.sign_ins_30d} sign-in${c.sign_ins_30d === 1 ? '' : 's'} in 30 days</div></td>
      <td class="num bl-mono">${c.downloads_month}</td>
      <td class="nw">${c.period_end ? blDate(c.period_end) + `<div class="bl-faint">${c.status === 'trialing' ? 'Trial ends' : 'Renews'}</div>` : '<span class="bl-faint">—</span>'}</td>
      <td class="num bl-mono">${c.balance_due ? `<span class="${c.overdue ? 'bl-neg' : ''}">${blMoney(c.balance_due, c.currency)}</span>` : '<span class="bl-faint">—</span>'}</td>
    </tr>`).join('');

  app.innerHTML = `<div class="st-console rp-dashboard">
    <section class="rp-dashboard-intro"><div><div class="rp-eyebrow">BUSINESS INTELLIGENCE / ADMINISTRATION</div><h2>Business performance</h2><p>Monitor subscriptions, revenue and client engagement in one place.</p></div><div class="rp-quick"><button onclick="goTo('survey-timeline')">Survey administration</button><button onclick="goTo('billing')">Manage billing</button></div></section>
    <div class="rp-section-label">Key performance indicators <span>Current reporting period</span></div>
    <div class="bl-stats db-kpis">
      ${s('users', 'blue', 'Paying customers', d.paying, `${d.trialing} on free trial · ${d.new_this_month} new this month`)}
      ${s('trend', 'green', 'Monthly recurring revenue', dbMoneyMap(d.mrr), `${dbMoneyMap(d.arr)} a year`)}
      ${s('wallet', 'green', 'Collected this year', dbMoneyMap(d.collected_ytd), ytdNote)}
      ${s('alert', overdue ? 'red' : 'amber', 'Unpaid invoices', dbMoneyMap(d.outstanding), overdue ? `<span class="bl-neg">${dbMoneyMap(d.overdue_total)} overdue</span>` : 'Nothing overdue')}
      ${s('spark', 'amber', 'Clients using the app', `${d.active_clients_30d}<span class="bl-faint" style="font-size:14px;font-weight:500;"> of ${live}</span>`, `${d.members_active_7d} people active this week · ${d.downloads_month} downloads this month`)}
    </div>

    <div class="db-grid">
      <div class="panel"><div class="bl-card-head"><div><div class="bl-card-title">Revenue performance</div><div class="st-sub">Payments by month, last 12 months</div></div>
        <span class="bl-faint">Last 30 days: <b style="color:var(--text);">${dbMoneyMap(d.collected_30d)}</b></span></div>${dbRevenueChart(d.revenue_by_month)}</div>
      <div class="panel"><div class="bl-card-head"><div><div class="bl-card-title">Revenue by subscription plan</div><div class="st-sub">Monthly recurring revenue by plan</div></div></div>
        ${d.plan_mix.length ? `<div class="db-mix">${d.plan_mix.map(p => `<div class="db-mix-row">
            <div class="db-mix-top"><span class="bl-strong">${escapeHtml(p.plan)}</span><span class="bl-mono">${blMoney(p.mrr, p.currency)}</span></div>
            <div class="db-mix-bar"><i style="width:${Math.max(3, p.mrr / maxMix * 100)}%"></i></div>
            <div class="bl-faint">${p.customers} customer${p.customers === 1 ? '' : 's'}</div></div>`).join('')}</div>`
          : blEmpty('tag', 'No paying customers yet', 'Once a customer pays, their plan shows here.')}
        <div class="db-conv">
          <div><span class="bl-faint">Trials that became paying</span><b>${tc.pct != null ? tc.pct + '%' : '—'}</b></div>
          <div class="bl-faint">${tc.trials ? `${tc.converted} of ${tc.trials} free trial${tc.trials === 1 ? '' : 's'}` : 'No free trials yet'}</div>
        </div>
      </div>
    </div>

    <div class="panel bl-flush">
      <div class="bl-card-head padded" style="margin-bottom:12px;flex-wrap:wrap;">
        <div><div class="bl-card-title">Customer health</div><div class="st-sub">Who is using what they pay for. Customers needing attention come first; click one to open it.</div></div>
        <div class="bl-head-act">${d.at_risk ? `<span class="bl-pill bl-red">${d.at_risk} need${d.at_risk === 1 ? 's' : ''} attention</span>` : (d.customers.length ? '<span class="bl-pill bl-green">All healthy</span>' : '<span class="bl-pill">No customers enrolled</span>')}</div>
      </div>
      ${rows ? `<div class="bl-table-wrap"><table class="bl-table"><thead><tr><th>Customer</th><th>Health</th><th class="num">Plan price</th><th>Active users</th><th>Last active</th><th class="num">Downloads</th><th>Renews / ends</th><th class="num">Owes</th></tr></thead><tbody>${rows}</tbody></table></div>`
        : blEmpty('users', 'No customers yet', 'Customers appear here once they sign up or you add them under Billing & Plan.', `<button onclick="goTo('billing')">Open Billing & Plan</button>`)}
    </div>

    <div class="bl-grid-2">
      <div class="panel"><div class="bl-card-head"><div><div class="bl-card-title">Coming up</div><div class="st-sub">Renewals and trial ends in the next 30 days</div></div></div>
        ${d.upcoming.length ? `<table class="bl-table compact"><tbody>${d.upcoming.map(r => `<tr class="bl-click" onclick="dbOpenCustomer(${r.organisation_id})">
          <td><div class="st-user">${blAvatar(r.organisation, 'sm')}<div><span class="bl-strong">${escapeHtml(r.organisation)}</span><div class="bl-faint">${escapeHtml(r.plan || '')}</div></div></div></td>
          <td><span class="bl-pill bl-${r.tone}">${escapeHtml(r.health)}</span></td>
          <td class="num">${blMoney(r.price, r.currency)}<div class="bl-faint">${r.status === 'trialing' ? 'Trial ends' : 'Renews'} ${blDate(r.date)}</div></td></tr>`).join('')}</tbody></table>`
          : blEmpty('calendar', 'Nothing due', 'No plan renews and no trial ends in the next 30 days.')}
        ${d.overdue_invoices.length ? `<div class="bl-card-title" style="margin:18px 0 8px;font-size:13px;">Overdue invoices</div><table class="bl-table compact"><tbody>${d.overdue_invoices.map(i => `<tr class="bl-click" onclick="dbOpenCustomer(${i.organisation_id})">
          <td><span class="bl-strong bl-mono">${escapeHtml(i.number)}</span><div class="bl-faint">${escapeHtml(i.organisation)}</div></td>
          <td class="num"><span class="bl-neg">${blMoney(i.balance, i.currency)}</span><div class="bl-faint">${i.days ? i.days + ' day' + (i.days === 1 ? '' : 's') + ' late' : 'Due today'}</div></td></tr>`).join('')}</tbody></table>` : ''}
      </div>
      <div class="panel"><div class="bl-card-head"><div><div class="bl-card-title">What clients are looking at</div><div class="st-sub">Company reports opened and downloaded by clients, last 30 days</div></div></div>
        ${d.most_viewed.length ? (() => { const mx = Math.max(...d.most_viewed.map(v => v.views)); return `<div class="db-mix">${d.most_viewed.map(v => `<div class="db-mix-row bl-click" onclick="goToCompanySurveyData(${v.company_id})">
            <div class="db-mix-top"><span class="bl-strong">${escapeHtml(v.name)}</span><span class="bl-faint">${v.users} client user${v.users === 1 ? '' : 's'}</span></div>
            <div class="db-mix-bar"><i style="width:${Math.max(4, v.views / mx * 100)}%;background:var(--amber);"></i></div></div>`).join('')}</div>`; })()
          : blEmpty('search', 'Nothing yet', 'When clients open or download a company report it is counted here (once per person per day), so you can see which companies are in demand.')}
        <div class="db-conv"><div><span class="bl-faint">Client accounts</span><b>${d.members_total}</b></div><div class="bl-faint">${d.members_active_7d} active in the last 7 days</div></div>
      </div>
    </div></div>`;
}

// ============================================================================
// Member dashboard: my company vs the market, and the market's headlines.
// ============================================================================
let hmCompanyFy = null;
let hmHeaderState = null;
// Member dashboard: greeting, plan and the year picker sit in the top bar, next to the profile.
function hmRenderHeader(){
  const h = hmHeaderState;
  if (!h || currentPage !== 'home') return;
  const yearSel = h.years && h.years.length ? `<label class="hm-top-year"><span>Year</span><select onchange="hmLoadCompany(this.value)" aria-label="Financial year">
      ${h.years.slice().reverse().map(y => `<option value="${escapeHtml(y)}" ${y === h.fy ? 'selected' : ''}>${escapeHtml(y)}</option>`).join('')}</select></label>` : '';
  setPageActions(null, yearSel);
  // One name only: on the dashboard the profile itself carries the greeting and the plan.
  const nameEl = document.getElementById('userNameLabel'), roleEl = document.getElementById('userRoleLabel');
  if (nameEl) nameEl.innerHTML = h.greeting;
  if (roleEl) roleEl.innerHTML = `<span class="hm-top-plan">${h.plan ? `<b>${h.plan}</b>` : ''}${h.pill}${h.until ? `<span>${escapeHtml(h.until)}</span>` : ''}</span>`;
}
function hmFmt(kind, v){
  if (v == null) return '<span class="bl-faint">—</span>';
  if (kind === 'money') return 'KES ' + Math.round(v).toLocaleString('en-US');
  if (kind === 'pct') return Number(v).toLocaleString('en-US', {maximumFractionDigits: 2}) + '%';
  return Number(v).toLocaleString('en-US', {maximumFractionDigits: 1});
}
function hmFmtText(kind, v){ return hmFmt(kind, v).replace(/<[^>]+>/g, ''); }
function hmVerdict(m){
  const p = m.percentile;
  if (p == null) return null;
  const [label, band] = p >= 75 ? ['Top quartile', 4] : p >= 55 ? ['Above median', 3] : p > 45 ? ['Around median', 2] : p > 25 ? ['Below median', 1] : ['Bottom quartile', 0];
  let tone = 'blue';
  if (m.good_high === true) tone = band >= 3 ? 'green' : band <= 1 ? 'red' : 'blue';
  return {label, tone};
}
function hmChange(m){
  if (m.change_pts != null) return `<span class="${m.change_pts > 0 ? 'bl-pos' : m.change_pts < 0 ? 'bl-neg' : 'bl-faint'}">${m.change_pts > 0 ? '▲' : m.change_pts < 0 ? '▼' : '='} ${Math.abs(m.change_pts)} pts</span>`;
  if (m.change_pct != null) return `<span class="${m.change_pct > 0 ? 'bl-pos' : m.change_pct < 0 ? 'bl-neg' : 'bl-faint'}">${m.change_pct > 0 ? '▲' : m.change_pct < 0 ? '▼' : '='} ${Math.abs(m.change_pct)}%</span>`;
  return '<span class="bl-faint">—</span>';
}
function hmTrack(m){
  if (m.percentile == null) return '<span class="bl-faint">Not enough companies</span>';
  const v = hmVerdict(m);
  return `<div class="hm-track" title="Higher than ${m.percentile}% of the companies that disclose it">
      <div class="hm-track-bar"><span class="hm-track-mid"></span><i class="hm-dot hm-dot-${v.tone}" style="left:${Math.min(98, Math.max(2, m.percentile))}%"></i></div>
      <span class="bl-pill bl-${v.tone}">${v.label}</span></div>`;
}
function hmInsights(d){
  const n = d.companies;
  const pick = d.metrics.filter(m => m.value != null && m.percentile != null && m.companies >= 4)
    .sort((a, b) => Math.abs(b.percentile - 50) - Math.abs(a.percentile - 50)).slice(0, 4);
  return pick.map(m => {
    const v = hmVerdict(m);
    const pos = m.rank === 1 ? `The highest of ${m.companies} companies`
      : m.rank === m.companies ? `The lowest of ${m.companies} companies`
      : m.percentile >= 50 ? `Higher than ${m.percentile}% of companies` : `Lower than ${100 - m.percentile}% of companies`;
    return `<div class="hm-insight hm-insight-${v.tone}">
      <div class="bl-faint">${escapeHtml(m.label)}</div>
      <div class="hm-insight-v">${hmFmt(m.kind, m.value)}</div>
      <div class="hm-insight-t">${pos}</div>
      <div class="bl-faint">Market median ${hmFmtText(m.kind, m.median)}${m.sector_median != null ? ` · sector ${hmFmtText(m.kind, m.sector_median)}` : ''}</div></div>`;
  }).join('');
}
const HM_GROUPS = [['pay', 'Board and executive pay'], ['board', 'Board and governance'], ['company', 'Company and people']];

function hmCompanyPicker(choices, current){
  const bySector = {};
  (choices || []).forEach(c => { (bySector[c.sector || 'Other'] = bySector[c.sector || 'Other'] || []).push(c); });
  return `<select id="hmPick" class="bl-input" style="max-width:360px;">
    <option value="">Choose your company…</option>
    ${Object.keys(bySector).sort().map(s => `<optgroup label="${escapeHtml(s)}">${bySector[s].map(c => `<option value="${c.id}" ${c.id === current ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('')}</optgroup>`).join('')}
  </select>`;
}
async function hmSaveCompany(id){
  if (!id) return;
  const r = await fetch('/api/home/my-company', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({company_id: Number(id)})});
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { showToast(d.error || 'Could not save your company.'); return; }
  hmCompanyFy = null;
  showToast(d.for === 'organisation' ? 'Saved for everyone in your organisation.' : 'Saved.');
  await hmLoadCompany();
}
function hmChangeCompany(){
  const box = document.getElementById('hmChange');
  if (box) box.style.display = box.style.display === 'none' ? 'flex' : 'none';
}
async function hmLoadCompany(fy){
  const box = document.getElementById('hmCompany');
  if (!box) return;
  if (fy) hmCompanyFy = fy;
  box.innerHTML = '<div class="panel"><div class="bl-loading"><span></span><span></span><span></span></div></div>';
  const r = await fetch('/api/home/company' + (hmCompanyFy ? '?fiscal_year=' + encodeURIComponent(hmCompanyFy) : ''));
  const d = await r.json().catch(() => ({}));
  if (r.status === 402) { box.innerHTML = hmLockedCompany(); return; }
  if (!r.ok) { box.innerHTML = `<div class="panel">${blEmpty('alert', 'Could not load your comparison', escapeHtml(d.error || ''))}</div>`; return; }
  if (hmHeaderState) { hmHeaderState.years = d.company ? d.years : []; hmHeaderState.fy = d.company ? d.fiscal_year : null; hmRenderHeader(); }
  if (!d.company) {
    box.innerHTML = `<div class="panel hm-pick">
      <span class="bl-stat-icon bl-blue" style="width:44px;height:44px;">${blIcon('building')}</span>
      <div style="flex:1;min-width:240px;">
        <div class="bl-card-title">See where your company stands</div>
        <div class="st-sub">Choose your company once. Your dashboard then shows its board pay and governance against every listed company and its sector: median, quartile and rank, and the change on last year.${d.error ? ` <span class="bl-neg">${escapeHtml(d.error)}</span>` : ''}</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;">${hmCompanyPicker(d.choices)}<button onclick="hmSaveCompany(document.getElementById('hmPick').value)">Show my comparison</button></div>
      </div></div>`;
    return;
  }
  const c = d.company;
  const groups = HM_GROUPS.map(([g, title]) => {
    const ms = d.metrics.filter(m => m.group === g && (m.value != null || m.median != null));
    if (!ms.length) return '';
    return `<tr class="hm-group"><td colspan="6">${title}</td></tr>` + ms.map(m => `<tr>
      <td class="bl-strong">${escapeHtml(m.label)}</td>
      <td class="num bl-mono hm-you">${hmFmt(m.kind, m.value)}${m.rank && m.value != null ? `<div class="bl-faint">#${m.rank} of ${m.companies}</div>` : ''}</td>
      <td class="num bl-mono">${hmFmt(m.kind, m.median)}${m.p25 != null ? `<div class="bl-faint">${hmFmtText(m.kind, m.p25)} – ${hmFmtText(m.kind, m.p75)}</div>` : ''}</td>
      <td class="num bl-mono">${hmFmt(m.kind, m.sector_median)}</td>
      <td>${m.value != null ? hmTrack(m) : '<span class="bl-faint">Not disclosed</span>'}</td>
      <td class="num nw">${hmChange(m)}</td></tr>`).join('');
  }).join('');
  const shown = d.metrics.filter(m => m.value != null).length;
  box.innerHTML = `<div class="panel bl-flush hm-co">
    <div class="hm-co-head">
      <div class="st-user">${blAvatar(c.name, 'lg')}<div style="margin-left:14px;">
        <div class="bl-faint">Your company</div>
        <div class="hm-co-name">${escapeHtml(c.name)}</div>
        <div class="bl-faint">${escapeHtml(c.sector || '')} · compared with ${d.companies} listed companies${d.sector_companies > 1 ? ` and ${d.sector_companies} in its sector` : ''}</div></div></div>
      <div class="bl-head-act">
        <button class="secondary sm" onclick="goToCompanySurveyData(${c.id}, '${escapeHtml(d.fiscal_year)}')">Full report</button>
        <button class="secondary sm" onclick="hmChangeCompany()">Change</button>
      </div>
    </div>
    <div id="hmChange" class="hm-change" style="display:none;">${hmCompanyPicker(d.choices, c.id)}<button class="sm" onclick="hmSaveCompany(document.getElementById('hmPick').value)">Save</button><span class="bl-faint">Changes it for everyone in your organisation.</span></div>
    ${shown ? `<div class="hm-insights">${hmInsights(d)}</div>` : ''}
    <div class="bl-table-wrap"><table class="bl-table hm-table"><thead><tr><th>${escapeHtml(d.fiscal_year)}</th><th class="num">${escapeHtml(c.name)}</th><th class="num">Market median<div style="text-transform:none;font-weight:500;letter-spacing:0;">middle half</div></th><th class="num">Sector median</th><th>Position in the market</th><th class="num">vs ${escapeHtml(d.previous_year || 'last year')}</th></tr></thead>
      <tbody>${groups}</tbody></table></div>
    <div class="st-foot"><span>${shown} of ${d.metrics.length} measures disclosed by ${escapeHtml(c.name)} for ${escapeHtml(d.fiscal_year)}. Pay in KES; a dash means not disclosed or too few companies to compare.</span></div>
  </div>`;
}
function hmLockedCompany(){
  return `<div class="panel hm-pick hm-locked">
    <span class="bl-stat-icon bl-amber" style="width:44px;height:44px;">${blIcon('building')}</span>
    <div style="flex:1;min-width:240px;">
      <div class="bl-card-title">See where your company stands <span class="bl-tag hm-lock">🔒 Professional</span></div>
      <div class="st-sub">Pick your company and see its chair and director fees, CEO pay, board make-up and attendance against every listed company and its sector: median, quartile, rank and the change on last year.</div>
      <div style="margin-top:12px;"><button onclick="goTo('billing')">See plans</button></div>
    </div></div>`;
}
function hmHeadlines(h){
  if (!h || !h.items || !h.items.length) return '';
  const tiles = h.items.map(it => {
    const ch = it.change_pts != null ? {v: it.change_pts, t: Math.abs(it.change_pts) + ' pts'} : it.change_pct != null ? {v: it.change_pct, t: Math.abs(it.change_pct) + '%'} : null;
    return `<div class="bl-stat hm-head">
      <div class="bl-faint" style="font-weight:600;">${escapeHtml(it.label)}</div>
      <div class="bl-stat-value sm" style="margin:8px 0 4px;">${hmFmt(it.kind, it.median)}</div>
      ${ch ? `<div class="hm-chg ${ch.v > 0 ? 'up' : ch.v < 0 ? 'down' : ''}">${ch.v > 0 ? '▲' : ch.v < 0 ? '▼' : '='} ${ch.t} <span class="bl-faint">vs ${escapeHtml(h.previous_year)}</span></div>
        <div class="bl-faint" style="margin-top:4px;">Rose at ${it.rose} and fell at ${it.fell} of ${it.like_for_like} companies</div>`
        : `<div class="bl-faint">Median of ${it.companies} companies</div>`}
    </div>`;
  }).join('');
  return `<div class="bl-card-head" style="margin:22px 0 10px;"><div><div class="bl-card-title">The market · ${escapeHtml(h.fiscal_year)}${h.previous_year ? ' vs ' + escapeHtml(h.previous_year) : ''}</div>
      <div class="st-sub">Median across listed companies. The change compares the same companies in both years.</div></div></div>
    <div class="hm-heads">${tiles}</div>`;
}

function showUpgrade(pageId){
  currentPage = pageId;
  renderNav();
  render();
  closeSidebar();
}
function renderUpgradePanel(p){
  const app = document.getElementById('app');
  setPageActions(null);
  const need = pageLockedTier(p);
  const what = (HOME_CARDS.find(c => c.id === p.id) || {}).text || '';
  app.dataset.lockedFor = p.id;
  app.innerHTML = `<div class="panel hm-upgrade">
    <div class="hm-upgrade-ic">🔒</div>
    <h2>${escapeHtml(p.label)} is part of the ${escapeHtml(need)} plan</h2>
    <p class="bl-faint">${escapeHtml(what)}</p>
    <p class="bl-faint">Your current package: <b>${escapeHtml((window.billingStatus || {}).tier_label || 'Free account')}</b>.${window.billingStatus && window.billingStatus.org_role && window.billingStatus.org_role !== 'owner' ? ' Ask your account owner to upgrade.' : ''}</p>
    <div class="bl-head-act" style="justify-content:center;margin-top:16px;"><button class="secondary" onclick="goTo('home')">Back to dashboard</button><button onclick="goTo('billing')">See plans and upgrade</button></div>
  </div>`;
}

(async function boot(){
  await loadCurrentUser();
  if (window.currentUser.role === 'user') currentPage = 'home';
  const wanted = (location.hash || '').replace('#', '');
  if (wanted && PAGES.some(p => p.id === wanted)) currentPage = wanted;
  if (new URLSearchParams(location.search).get('welcome')) {
    setTimeout(() => typeof showToast === 'function' && showToast('Your email is confirmed. Welcome to Remuneration Practice!'), 800);
    try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) {}
  }
  const choose = new URLSearchParams(location.search).get('choose');
  if (choose) { blState.suggest = choose; currentPage = 'billing'; history.replaceState(null, '', location.pathname); }
  updateUserBadge();
  renderNav();
  render();
  blHandleReturnFromPayment();
})();

// ---- live updates (SSE) ----
// One persistent connection to the backend. The moment a filing is
// auto-imported (or anything else is saved), the server pushes a small
// "data changed" message and we quietly re-render the current page -
// no manual refresh, no polling timer.
let _lastLiveRefresh = 0;
function connectLiveUpdates(){
  const es = new EventSource('/api/events');
  es.onmessage = (evt) => {
    let msg;
    try { msg = JSON.parse(evt.data); } catch { return; }
    if (msg.type !== 'data_changed') return;
    ilTrendsCache = null; srSurveyAvgCache = null;

    // Don't yank the page out from under someone mid-edit in the report builder.
    if (builderRows && Object.values(builderRows).some(rows => rows.length)) return;

    // A batch auto-import can fire several events in a row - no need to
    // re-render on every single one.
    const now = Date.now();
    if (now - _lastLiveRefresh < 2000) return;
    _lastLiveRefresh = now;

    showToast(msg.data && msg.data.needs_review
      ? `New filing imported for ${escapeHtml(msg.data.period || 'a period')} — some figures look unusual, check Reports.`
      : 'Dashboard updated with new data.');
    render();
  };
  // EventSource reconnects on its own after a drop; nothing to do here.
}

// Any write from a non-super admin comes back 202 {pending_approval:true}: tell them it is waiting.
(function(){
  const _f = window.fetch;
  window.fetch = async function(){
    const r = await _f.apply(this, arguments);
    const method = (arguments[1] && arguments[1].method || 'GET').toUpperCase();
    if (r.ok && !['GET','HEAD','OPTIONS'].includes(method)) { ilTrendsCache = null; srSurveyAvgCache = null; }
    if (r.status === 202) {
      r.clone().json().then(d => { if (d && d.pending_approval) showToast('Sent to a super admin for approval - nothing is saved until it is approved.'); }).catch(() => {});
    }
    return r;
  };
})();

function showToast(text){
  let el = document.getElementById('liveToast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'liveToast';
    el.style.cssText = 'position:fixed;bottom:20px;right:20px;background:#1f372b;color:#fff;padding:10px 16px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.35);z-index:9999;font-size:13px;max-width:320px;transition:opacity .3s;opacity:0;';
    document.body.appendChild(el);
  }
  el.textContent = text;
  el.style.opacity = '1';
  clearTimeout(el._hideTimer);
  el._hideTimer = setTimeout(() => { el.style.opacity = '0'; }, 4500);
}

window.addEventListener('load', () => setTimeout(connectLiveUpdates, 3000), {once:true});

// V5: comparison requests are opt-in, never part of initial navigation.
function rpCompare(body, scope, years, companyId, companyRows=[]){
  const options = [...new Set(fullYears(years))].filter(y=>/^FY\d{4}$/.test(y)).sort().reverse();
  body.innerHTML = `<div class="panel"><h3>${scope==='company'?'Financial Year Comparison':scope==='survey'?'Multi-Year Survey Comparison':'Comparative Intelligence'}</h3><p>Choose 2–10 financial years. Missing figures are not zero.</p><div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center">${options.map((y,i)=>`<label><input type="checkbox" data-year="${y}" ${i<2?'checked':''}> ${escapeHtml(y)}</label>`).join('')}</div><div style="display:flex;flex-wrap:wrap;gap:10px;margin:16px 0">${scope!=='company'?'<select data-cohort aria-label="Company cohort"><option value="all">All reporting companies</option><option value="matched">Same companies in all selected years</option></select>':''}${scope==='intelligence'?`<select data-sector aria-label="Sector"><option value="">All sectors</option>${[...new Set(companyRows.map(r=>r.sector).filter(Boolean))].sort().map(s=>`<option>${escapeHtml(s)}</option>`).join('')}</select><select data-companies multiple aria-label="Companies (optional)" title="Ctrl-click to select multiple companies">${companyRows.map(r=>`<option value="${Number(r.company_id)}">${escapeHtml(r.name)}</option>`).join('')}</select>`:''}<button class="btn" data-run>Compare years</button><select data-format aria-label="Export format"><option>pdf</option><option>docx</option><option>xlsx</option></select><select data-detail aria-label="Report detail"><option value="full">Comprehensive</option><option value="summary">Comparison matrix only</option></select><button class="btn" data-export>Download comparison</button></div><div data-result></div></div>`;
  const result=body.querySelector('[data-result]'); let seq=0;
  function query(){
    const selected=[...body.querySelectorAll('[data-year]:checked')].map(e=>e.dataset.year);
    if(selected.length<2||selected.length>10){showToast('Select 2–10 financial years.');return null;}
    const q=new URLSearchParams(); selected.forEach(y=>q.append('year',y));
    if(companyId)q.append('company_id',companyId);
    const cohort=body.querySelector('[data-cohort]'); if(cohort)q.set('cohort',cohort.value);
    const sector=body.querySelector('[data-sector]'); if(sector&&sector.value)q.set('sector',sector.value);
    const cs=body.querySelector('[data-companies]'); if(cs)[...cs.selectedOptions].forEach(o=>q.append('company_id',o.value));
    q.set('detail',body.querySelector('[data-detail]').value);return q;
  }
  const f=v=>v===null||v===undefined?'Not available':typeof v==='number'?v.toLocaleString(undefined,{maximumFractionDigits:2}):typeof v==='boolean'?(v?'Yes':'No'):String(v);
  body.querySelector('[data-run]').onclick=async()=>{
    const q=query();if(!q)return;const token=++seq;result.textContent='Loading comparison…';
    try{const res=await fetch('/api/comparisons/'+scope+'?'+q);const d=await res.json();if(token!==seq||!result.isConnected)return;if(!res.ok)throw Error(d.error||'Comparison failed');
      result.innerHTML=`<h3>${escapeHtml(d.title)}</h3><p>${d.years.map(escapeHtml).join(' · ')}</p><div data-advanced></div><input data-filter placeholder="Filter comparison metrics" aria-label="Filter comparison metrics"><div style="overflow:auto;max-height:620px"><table style="width:100%;border-collapse:collapse"><thead><tr>${['Metric',...d.years,'Change','Change %','CAGR %'].map(v=>`<th style="padding:9px;text-align:left;position:sticky;top:0;background:var(--bg-panel,#172a22)">${escapeHtml(v)}</th>`).join('')}</tr></thead><tbody></tbody></table></div><details><summary>Methodology and coverage</summary>${Object.entries(d.methodology).map(([k,v])=>`<p><strong>${escapeHtml(k)}:</strong> ${escapeHtml(v)}</p>`).join('')}</details>`;
      const tb=result.querySelector('tbody');const draw=()=>{const text=result.querySelector('[data-filter]').value.toLowerCase();tb.innerHTML=d.rows.filter(r=>r.metric.toLowerCase().includes(text)).map(r=>`<tr>${[r.metric.replaceAll('_',' '),...r.values,r.change,r.change_pct==null?null:f(r.change_pct)+'%',r.cagr==null?null:f(r.cagr)+'%'].map(v=>`<td style="padding:8px;border-bottom:1px solid var(--border,#294337)">${escapeHtml(f(v))}</td>`).join('')}</tr>`).join('');};result.querySelector('[data-filter]').oninput=draw;draw(); rpAdvanced(result.querySelector('[data-advanced]'),d,f);
    }catch(e){if(token===seq&&result.isConnected)result.textContent=e.message;}
  };
  body.querySelector('[data-export]').onclick=async()=>{
    const q=query();if(!q)return;const btn=body.querySelector('[data-export]');btn.disabled=true;const ext=body.querySelector('[data-format]').value;q.set('format',ext);
    try{const base='/api/comparisons/'+scope;const res=await fetch(base+'/jobs?'+q,{method:'POST',credentials:'same-origin'});const d=await res.json();if(!res.ok)throw Error(d.error||'Queue failed');
      for(let i=0;i<300;i++){await new Promise(r=>setTimeout(r,2000));const rr=await fetch(base+'/jobs/'+encodeURIComponent(d.job),{cache:'no-store'});const j=await rr.json();if(!rr.ok||j.status==='failed')throw Error(j.error||'Report generation failed');btn.textContent='Report: '+j.status;if(j.status==='ready'){await docDownload(base+'/export.'+ext+'?job='+encodeURIComponent(d.job));return;}}
      throw Error('Report did not finish within 10 minutes.');
    }catch(e){showToast(e.message);}finally{btn.disabled=false;btn.textContent='Download comparison';}
  };
}
function rpAdvanced(el,d,f){
  const metrics=d.rows.filter(r=>r.values.some(v=>typeof v==='number'&&Number.isFinite(v))&& !r.metric.includes('Director register'));
  el.innerHTML=`<div class="panel" style="margin:12px 0"><label>Historical trend <select data-trend aria-label="Trend metric"></select></label><div data-plot></div></div><details><summary>Historical ranking movements (${(d.rankings||[]).length})</summary><div style="overflow:auto;max-height:350px" data-ranks></div></details><details><summary>Director identity candidates (${(d.director_matches||[]).length})</summary><div data-identities></div></details>`;
  const sel=el.querySelector('[data-trend]');metrics.forEach((r,i)=>sel.add(new Option(r.metric.replaceAll('_',' '),i)));
  const plot=()=>{const r=metrics[Number(sel.value)];const p=el.querySelector('[data-plot]');if(!r){p.textContent='No numerical data';return;}const vs=r.values.filter(v=>typeof v==='number'&&Number.isFinite(v));let lo=Math.min(...vs,0),hi=Math.max(...vs,0);if(hi===lo)hi=lo+1;const x=i=>65+i*650/Math.max(1,d.years.length-1),y=v=>25+(hi-v)*150/(hi-lo);let lines='';r.values.forEach((v,i)=>{if(typeof v!=='number'||!Number.isFinite(v))return;if(i&&typeof r.values[i-1]==='number'&&Number.isFinite(r.values[i-1]))lines+=`<line x1="${x(i-1)}" y1="${y(r.values[i-1])}" x2="${x(i)}" y2="${y(v)}" stroke="#48c89e" stroke-width="3"/>`;lines+=`<circle cx="${x(i)}" cy="${y(v)}" r="5" fill="#48c89e"><title>${escapeHtml(d.years[i]+': '+f(v))}</title></circle>`;});p.innerHTML=`<svg viewBox="0 0 780 220" role="img" aria-label="Historical trend" style="width:100%;max-height:280px"><text x="4" y="20" fill="currentColor" font-size="12">${escapeHtml(f(hi))}</text><text x="4" y="185" fill="currentColor" font-size="12">${escapeHtml(f(lo))}</text>${lines}${d.years.map((yr,i)=>`<text x="${x(i)}" y="205" text-anchor="middle" fill="currentColor" font-size="12">${escapeHtml(yr)}</text>`).join('')}</svg>`;};sel.onchange=plot;plot();
  el.querySelector('[data-ranks]').innerHTML=(d.rankings||[]).map(r=>`<p>${escapeHtml(r.company+' · '+r.metric+' · '+(r.currency||'')+' · '+d.years.map(y=>y+': '+f(r.ranks[y])).join(' | ')+' · movement '+f(r.movement))}</p>`).join('');
  el.querySelector('[data-identities]').innerHTML=(d.director_matches||[]).map(r=>`<p>${escapeHtml(r.normalized_name+' · '+r.table_kind+' · '+r.status+' · '+Object.entries(r.years).map(([y,v])=>y+': '+v.filed_name+' ('+v.role+')').join(' | '))}</p>`).join('');
}
