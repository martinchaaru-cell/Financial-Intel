"""
Full statement-aware PDF extraction, used by the manual upload flow
(/api/import/upload-batch in app.py - see there for the single adapter
every company's uploads go through, regardless of the report's own
format or layout).

Walks every relevant page, buckets lines under whichever financial
statement heading they fall under, and extracts EVERY numeric line on
that statement - not just a five-item allowlist - preserving the page
number and (where we recognize the label) a normalized_name for
cross-company comparison.

Still explicitly heuristic and best-effort: every saved line item carries
its own confidence score rather than being screened out before saving -
see the module docstring on /api/import/upload-batch in app.py for how
that's surfaced to the user (Source Evidence).
"""

import re
import io
import hashlib
import threading
from collections import Counter, OrderedDict
import pdfplumber
import canonical_extended as _ext

try:
    import pypdf
except ImportError:  # pragma: no cover - pypdf is in requirements.txt
    pypdf = None

# ---------- STATEMENT HEADING DETECTION ----------

STATEMENT_HEADINGS = {
    'income_statement': [
        # (?:other\s+)? - a real filing (Equity Group Holdings 2024)
        # reports OCI as its OWN standalone statement immediately after
        # profit-or-loss, headed "Consolidated statement of OTHER
        # comprehensive income" - without this, that heading matched
        # nothing and its lines fell through to whatever bucket the
        # previous statement left current_stmt pointed at.
        r"statement\s+of\s+(?:other\s+)?comprehensive\s+income",
        r"statement\s+of\s+profit\s+or\s+loss",
        r"income\s+statement",
    ],
    'balance_sheet': [
        r"statement\s+of\s+financial\s+position",
        r"balance\s+sheet",
    ],
    'cash_flow': [
        # \s* (not \s+) between "cash" and "flow(s)" - confirmed on a
        # real KCB filing that prints this heading as one word,
        # "Consolidated statement of cashflows", alongside other filings
        # that space it normally ("statement of cash flows").
        r"statement\s+of\s+cash\s*flows?",
    ],
    'equity': [
        r"statement\s+of\s+changes\s+in\s+equity",
    ],
}
_HEADING_RES = {
    stmt: [re.compile(p, re.IGNORECASE) for p in patterns]
    for stmt, patterns in STATEMENT_HEADINGS.items()
}

# A real statement heading is just the heading text (optionally with
# "(Continued)") - nothing else on the line. A table-of-contents entry
# has the SAME heading text but with trailing page numbers tacked on
# ("Consolidated Statement of Financial Position 75 - 76"), which is
# what makes the TOC page get misread as the start of the real
# statement, pulling every front-matter line after it in as if it were
# balance-sheet data. Any digit on a heading-matching line is that
# signal - a genuine heading line never contains one.
_HEADING_HAS_DIGIT_RE = re.compile(r"\d")

# Lines that end a statement's numeric section even without hitting the
# next heading (notes sections, page furniture) - stop pulling line items
# once one of these appears, so we don't scrape footnote numbers.
_SECTION_STOP_RES = [
    re.compile(p, re.IGNORECASE) for p in [
        r"^\s*notes?\s+to\s+the\s+financial\s+statements",
        r"^\s*the\s+notes.*form\s+an\s+integral\s+part",
    ]
]
# Section-title style notes markers - these need the same short/ALL-CAPS
# heading test _classify_statement uses (via _looks_like_heading_line),
# unlike the two patterns above which are meant to match ordinary
# boilerplate sentences. Without that guard, a running header repeated on
# every page of this document ("...STAKEHOLDERS NOTES OF THE BOD
# INDEX...", the site nav reused as a page banner) or a stray mid-
# sentence mention could trip these.
# A numbered note heading ("1. Reporting entity", "2. Material accounting
# policies", "36. Deposits from customers") - confirmed on a real KCB
# filing to be the ONLY signal that the notes section has started on
# filings that never print a standalone "Notes to the Financial
# Statements" banner line at all (the numbered notes just start directly
# after the primary statements). Checked against every page of that
# filing's real statements (pages 73-78) with zero false positives - the
# numbering only starts exactly where the notes do. Still run through
# the same short-line heading guard as _SECTION_STOP_HEADING_RES so a
# numbered list item deep inside ordinary body prose (rare, but possible)
# doesn't trip it.
# \.? (not \.) - a real filing (Equity Group Holdings 2024) numbers its
# first note "1 Corporate information", no period after the digit at all,
# alongside others that do use one ("2. Material accounting policies") -
# both forms seen in practice, so the period is optional not required.
_NUMBERED_NOTE_HEADING_RE = re.compile(r"^\s*\d{1,2}\.?\s+[A-Z]")


# A column-header line such as "30 June 2025 30 June 2024 31 December 2024"
# (interim reports) starts with a 1-2 digit number followed by a capital
# letter, so it matched _NUMBERED_NOTE_HEADING_RE and ended the statement
# right after its own heading - every line item below it was dropped
# (Kakuzi H1 2025: balance sheet and cash flow both came back empty).
# A date row is therefore ignored by parse_financials_text ONLY while the
# section has no line items yet (the column-header zone right under the
# heading). Later in a section it still ends it, as before - some
# filings' statements only stop at such a row, and ignoring it there
# lets the statement run on into the notes.
_DATE_HEADER_RE = re.compile(
    r"^\s*\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{2,4}",
    re.IGNORECASE)


def _is_numbered_note_heading(line: str) -> bool:
    if not _NUMBERED_NOTE_HEADING_RE.match(line):
        return False
    candidate, was_doubled = _heading_candidate(line)
    return _looks_like_heading_line(candidate, was_doubled)


_SECTION_STOP_HEADING_RES = [
    re.compile(p, re.IGNORECASE) for p in [
        r"financial\s+statements\s*[-\u2013\u2014]\s*notes",
        r"^\s*notes\s*$",
    ]
]

# ---------- CANONICAL LABEL -> normalized_name ----------
# Anything not matched here is still extracted, just with
# normalized_name=None (an "unmapped" line item) - the review UI lets a
# human assign one, or leave it as a raw extra line.

CANONICAL_LINE_ITEMS = {
    'income_statement': {
        r"total\s+operating\s+income": 'revenue',
        # Anchored so a genuine revenue TOTAL line wins over a same-
        # statement component that also starts with "Revenue" (e.g.
        # "Revenue from contracts with customers" / "Revenue from other
        # sources" printed as their own lines above the real "Total
        # revenue" line, per IFRS 15 disclosure convention) - confirmed
        # on a real filing where the component line, appearing first,
        # otherwise won the seen_normalized dedupe ahead of the real
        # total a few lines later. A standalone "Revenue" total line has
        # nothing after the word itself but note refs/whitespace, so this
        # loses no genuine match.
        r"^\s*revenue\s*$": 'revenue',
        # A trading company's top line is often just "Sales" (Kakuzi) or "Turnover";
        # anchored so "Cost of sales" / "Sales tax" / "Selling costs" cannot match.
        r"^\s*(?:net\s+)?(?:sales|turnover)\s*$": 'revenue',
        r"total\s+revenue": 'revenue',
        # NSE's own statement labels its top line "Total income" (a sum of
        # transaction levies/listing fees/data-vending income, not a
        # conventional "Revenue" line) - anchored to match only the exact
        # subtotal line, not "Total comprehensive income" or "Total other
        # comprehensive income" which also contain "income" but are a
        # different figure entirely.
        r"^total\s+income$": 'revenue',
        # A bank's income statement sums net interest income + net fee
        # income + other income into a single top-line subtotal labelled
        # "Total net income" (see e.g. Equity Group's format) - it plays
        # the same role "Total operating income" does for other banks,
        # NOT the bottom-line profit figure. Ordered before the generic
        # net_income patterns below so this specific subtotal always wins
        # that match first; without it, "net\s+income" (deliberately kept
        # broad, since plenty of filings really do just say "Net income")
        # would grab it and both misreport revenue as missing and net
        # income as the wrong (much larger, pre-expense) figure.
        r"total\s+net\s+income": 'revenue',
        r"total\s+interest\s+and\s+similar\s+income": 'interest_income',
        r"interest\s+expense": 'interest_expense',
        r"cost\s+of\s+sales": 'cost_of_sales',
        r"gross\s+profit": 'gross_profit',
        r"employee\s+costs?": 'employee_costs',
        r"staff\s+costs?": 'employee_costs',
        r"depreciation": 'depreciation',
        r"amortisation|amortization": 'amortisation',
        r"finance\s+costs?": 'finance_costs',
        # "Operating profit" / "Profit from operations" - the pre-finance-
        # cost, pre-tax subtotal a P&L reports before "profit before tax"
        # (which is operating profit net of finance costs/income). Kept
        # distinct from profit_before_tax below - anchored with a
        # trailing \b so it doesn't also swallow "Operating profit margin"
        # commentary lines, and ordered before profit_before_tax since a
        # line literally reading "Operating profit before tax" (seen on
        # some filings) should still resolve to operating_profit, not be
        # shadowed by the narrower phrase.
        r"operating\s+profit\b": 'operating_profit',
        r"profit\s+from\s+operations": 'operating_profit',
        r"results?\s+from\s+operating\s+activities": 'operating_profit',
        r"profit\s+before\s+(income\s+)?tax": 'profit_before_tax',
        r"income\s+tax\s+expense": 'tax_expense',
        # Anchored against a trailing qualifier ("...from continuing
        # operations") since that's a P&L component subtotal, not the
        # true bottom line - confirmed on a real filing where "Profit
        # for the year from continuing operations" appears before the
        # real total "Profit for the period"/"Profit for the year" a few
        # lines later, and being first would otherwise win the
        # seen_normalized dedupe over the actual bottom-line figure.
        r"profit\s+for\s+the\s+(period|year)(?!\s+from\s+continuing)": 'net_income',
        r"profit\s+after\s+tax": 'net_income',
        # Anchored to the start of the line (allowing a leading bullet/
        # dash) - unanchored "net\s+profit"/"net\s+income" also matched
        # inside unrelated lines that merely contain that phrase, e.g.
        # "Share of net profit from associates accounted for using
        # equity method" (a P&L component, not the bottom-line total) -
        # confirmed on a real filing where that component line preceded
        # the real "Profit for the period" total and, being first, won
        # the seen_normalized dedupe, silently discarding the real
        # figure. A genuine net-profit/net-income total line always
        # leads with that phrase (label text before it is a note number
        # or bullet character at most), so anchoring loses no real match.
        r"^[\s\-\u2022]*net\s+profit\b": 'net_income',
        r"^[\s\-\u2022]*net\s+income\b": 'net_income',
        r"earnings\s+per\s+(ordinary\s+)?share": 'eps',
        # Weighted-average / basic shares outstanding - usually sits right
        # next to the EPS line in the P&L or its accompanying note, stated
        # as a share count rather than a currency amount. "Weighted
        # average number of (ordinary )?shares" is the IFRS-standard
        # phrasing; "shares in issue" is the more plain-language variant
        # some filings use for the same figure.
        r"weighted\s+average\s+number\s+of\s+(ordinary\s+)?shares": 'shares_outstanding',
        r"number\s+of\s+shares\s+in\s+issue": 'shares_outstanding',
    },
    'balance_sheet': {
        r"total\s+assets": 'total_assets',
        r"total\s+liabilities": 'total_liabilities',
        r"total\s+equity": 'total_equity',
        r"total\s+shareholders.\s+funds": 'total_equity',
        r"cash\s+and\s+cash\s+equivalents": 'cash_and_equivalents',
        r"trade\s+and\s+other\s+receivables": 'receivables',
        r"trade\s+and\s+other\s+payables": 'payables',
        r"inventor(y|ies)": 'inventory',
        r"total\s+current\s+assets": 'current_assets',
        r"total\s+current\s+liabilities": 'current_liabilities',
        r"property,?\s+plant\s+and\s+equipment": 'ppe',
        r"borrowings": 'borrowings',
        r"share\s+capital": 'share_capital',
        r"retained\s+earnings": 'retained_earnings',
    },
    'cash_flow': {
        # "Net cash (flows )?(generated )?from/used in operating..." - the
        # optional "flows" covers filings (e.g. KCB) that write "Net cash
        # flows from operating activities" rather than "Net cash generated
        # from operating activities"; both phrasings are common across
        # NSE filings and refer to the same cash flow statement subtotal.
        # Broadened: filings word the subtotal many ways - "Net cash
        # generated/(utilized) by operating activities" (Kakuzi), "Net
        # cash flows from/ (used in) operating activities" (KCB 2025, the
        # slash-and-space variant never matched the old, narrower pattern
        # so KCB's operating cash flow came back missing). Any "Net cash
        # ... operating/investing/financing activities" line is that
        # section's subtotal.
        r"net\s+cash\b.*\boperating\b": 'operating_cash_flow',
        r"net\s+cash\b.*\binvesting\b": 'investing_cash_flow',
        r"net\s+cash\b.*\bfinancing\b": 'financing_cash_flow',
        r"cash\s+and\s+cash\s+equivalents\s+at\s+(the\s+)?end": 'cash_end_of_period',
        r"purchase\s+of\s+property": 'capex',
    },
    'equity': {
        r"balance\s+at\s+(the\s+)?(start|beginning)": 'equity_opening_balance',
        r"balance\s+at\s+(the\s+)?end": 'equity_closing_balance',
        r"dividends?\s+paid": 'dividends_paid',
        r"total\s+comprehensive\s+income": 'total_comprehensive_income',
    },
}
_CANONICAL_RES = {
    stmt: [(re.compile(p, re.IGNORECASE), norm) for p, norm in mapping.items()]
    for stmt, mapping in CANONICAL_LINE_ITEMS.items()
}

# Figures that are genuinely allowed to be negative (a loss, a cash
# outflow) - everything else gets abs()'d even if parentheses-styled,
# since balance-sheet/income magnitudes shouldn't come out negative just
# because of accounting formatting.
_SIGNED_ALLOWED = {
    'net_income', 'operating_cash_flow', 'investing_cash_flow',
    'financing_cash_flow', 'total_comprehensive_income', 'eps',
    'dividends_paid', 'operating_profit',
}

_NUMBER_RE = re.compile(r"\(?-?\d[\d,]*\.?\d*\)?")
_LABEL_RE = re.compile(r"^[A-Za-z][A-Za-z ,&/()'-]*[A-Za-z)]")

# A thousands-grouped number: 1,234 or 1,234,567 - every comma-separated
# group after the first is exactly 3 digits. Used to tell a real amount
# ("6,047") apart from a comma-joined note list ("12,14").
_THOUSANDS_RE = re.compile(r"^\(?-?\d{1,3}(,\d{3})+(\.\d+)?\)?$")

# A single note-reference token: 1-3 bare digits, optionally with an
# "(a)" or "(b)(iii)" style sub-reference suffix. Deliberately does not
# match anything comma-grouped on its own - that's handled by the
# thousands-vs-note-list check in _strip_note_reference below.
_NOTE_TOKEN_RE = re.compile(r"^\d{1,3}(\([a-z]+\)(\([ivx]+\))?)?")


def _parse_number(token: str):
    token = token.strip()
    negative = token.startswith("(") and token.endswith(")")
    token = token.strip("()").replace(",", "")
    try:
        value = float(token)
    except ValueError:
        return None
    return -value if negative else value


def _strip_note_reference(remainder: str) -> str:
    """NSE-style statements insert a Notes column between the label and
    the actual amounts, e.g.:
        'Staff costs 8 177,359 171,841 177,359 171,841'
        'Depreciation and amortization 12,14 48,512 54,915 ...'
        "Directors' emoluments 32(a) 47,289 43,606 ..."
    Without this, the parser reads the note number itself (8, or the
    first of "12,14") as if it were the reported figure. Peel off a
    single leading note-reference token - which may itself be a
    comma-joined list of note numbers like "12,14" - before number
    extraction runs. A real thousands-grouped amount ("6,047") is left
    untouched: the distinguishing signal is that a genuine amount's
    post-comma chunk is always exactly 3 digits, checked via
    _THOUSANDS_RE, whereas a note list's chunks are 1-3 digits with no
    thousands-grouping meaning."""
    remainder = remainder.lstrip()
    m = _NOTE_TOKEN_RE.match(remainder)
    if not m:
        return remainder
    after = remainder[m.end():]
    if after[:1] != ',':
        return after.lstrip()

    next_space = remainder.find(' ')
    first_chunk = remainder[:next_space] if next_space != -1 else remainder
    if _THOUSANDS_RE.match(first_chunk):
        return remainder  # genuine thousands-grouped amount - don't strip

    # Comma-joined note list ("12,14", "6, 9, 14a") - consume each
    # further ", <note>" segment.
    rest = after
    while rest.startswith(','):
        m2 = re.match(r",\s*\d{1,3}(\([a-z]+\))?", rest)
        if not m2:
            break
        rest = rest[m2.end():]
    return rest.lstrip()


# Space-grouped thousands ("57 672", "(14 384)", "1 234 567"): some
# filers (confirmed on Absa Bank Kenya's reports, every year) group
# thousands with a space instead of a comma. The comma-only tokenizer
# above read "60 024" as TWO numbers (60 and 24) and kept the last one,
# so Absa's FY2025 total income was stored as 24 instead of 60,024 and
# profit for the year as 905 instead of 22,905 - with 0.9 confidence.
#
# The hard part is that a space is ALSO the column separator, so
# "648 128 640 100" is two numbers (648,128 and 640,100) but "15 345 320"
# may be note 15 followed by 345 and 320. The split is therefore chosen
# by scoring every legal reading of the trailing run of digit groups
# (see _value_list_plausibility), never by a fixed rule. A line with no
# possible space-grouped reading goes through the original comma-only
# code path byte-for-byte, so filings that already parsed correctly
# cannot change behaviour.
# A heading like "Bank statement of financial position" / "Company statement
# of ..." is the SEPARATE (entity-only) statement that many filers print
# right after the "Consolidated statement of ..." one (confirmed on Absa
# Bank Kenya: pages 138/139, 140/141, 142/144, 146/147). Its rows repeat the
# consolidated labels with slightly different figures, so folding them into
# the same statement produced duplicate rows ("net_interest_income_2",
# "payables_and_accruals_3", ...) and mixed group and bank figures.
# Convention (same as NSE's Group-first ordering): the consolidated
# statement wins; the entity-only one is skipped when a consolidated one
# exists, and used only if it is the sole version in the report.
_ENTITY_ONLY_HEADING_RE = re.compile(
    r"^\s*(?:the\s+)?(?:bank|company|separate|parent|standalone|stand-alone)\b", re.I)

_NOTE_XREF_RE = re.compile(r"\(\s*notes?\s*[\d,\sand&]+\)", re.I)
_NUMERIC_TOKEN_RE = re.compile(r"^\(?-?\d[\d,]*\.?\d*\)?$")
_DASH_TOKENS = frozenset({"-", "\u2013", "\u2014"})
_MONTH_NAMES = frozenset({"january", "february", "march", "april", "may", "june", "july", "august",
                    "september", "october", "november", "december"})
_DIGITS_ONLY_RE = re.compile(r"^\d+$")
_ATOM_DIGITS_RE = re.compile(r"^(?P<open>[(\-])?(?P<d>\d+)(?P<close>\))?$")
_MAX_PARTITIONS = 512


def _line_may_be_space_grouped(tokens: list) -> bool:
    """True when some digits-only token is directly followed by a digits-
    only token of exactly 3 digits - the only shape a space-grouped
    thousands number can take."""
    for a, b in zip(tokens, tokens[1:]):
        ma, mb = _ATOM_DIGITS_RE.match(a), _ATOM_DIGITS_RE.match(b)
        if ma and mb and len(mb.group('d')) == 3 and not mb.group('open'):
            return True
    return False


def _partitions_of_digit_run(groups: list):
    """Every legal way to read a run of digits-only tokens as numbers.
    A number is a head of 1-3 digits (no leading zero) followed by any
    number of exactly-3-digit groups, or a single longer token. Yields
    lists of (value, n_groups) tuples."""
    out = []

    def rec(i, acc):
        if len(out) >= _MAX_PARTITIONS:
            return
        if i == len(groups):
            out.append([list(num) for num in acc])   # deep copy: acc's inner lists are mutated as we backtrack
            return
        g = groups[i]
        # start a new number at g (a 4+ digit token is a whole number by itself)
        if not (len(g) > 1 and g.startswith('0')):
            acc.append([g])
            rec(i + 1, acc)
            acc.pop()
        # continue the previous number with g (only exact 3-digit groups,
        # and only after a head of 1-3 digits)
        if acc and len(g) == 3 and len(acc[-1][0]) <= 3:
            acc[-1].append(g)
            rec(i + 1, acc)
            acc[-1].pop()

    rec(0, [])
    return [[(float("".join(num)), len(num)) for num in part] for part in out]


def _value_list_plausibility(vals: list, expected_cols=None) -> float:
    """Score one candidate reading of a line's value columns. Filings
    print 2 value columns (current, prior) - or 4 for Group + Company -
    and one line's current and prior figures are normally within an
    order of magnitude of each other. Used only to choose between legal
    readings of the same characters."""
    n = len(vals)
    score = {2: 3.0, 4: 2.0, 1: 1.0}.get(n, 0.0)
    if expected_cols and n == expected_cols:
        score += 2.0
    if n >= 2 and vals[0] and vals[1]:
        ratio = max(abs(vals[0]), abs(vals[1])) / min(abs(vals[0]), abs(vals[1]))
        score += 1.0 if ratio <= 10 else (0.0 if ratio <= 50 else -1.0)
    # Columns of one row are normally the same order of magnitude, so a
    # reading that mixes 2-digit and 11-digit "numbers" is a mis-split
    # ("86 703 10 048 100 520" read as 86, 703, 10048100520). Small
    # penalty: it only decides between otherwise-tied readings.
    digit_counts = [len(str(int(abs(v)))) for v in vals if v]
    if len(digit_counts) >= 2:
        score -= 0.1 * (max(digit_counts) - min(digit_counts))
    return score


def _split_label_and_numbers_space_grouped(line: str, has_note_column: bool, expected_cols,
                                           allow_dash_columns: bool = False):
    """Returns (label, values) or None when the line has no space-grouped
    reading (caller then uses the original comma-only path)."""
    # "(Note 48)" / "(Notes 9, 10)" cross-references sit between the label and
    # the figures and their digits + ")" would otherwise be swallowed into the
    # value columns.
    line = _NOTE_XREF_RE.sub("", line)
    words = line.split()
    # trailing run of numeric-looking tokens = the value columns. A lone
    # dash is a nil column ("Profit for the year - - - 20 876 -").
    k = len(words)
    while k > 0 and (_NUMERIC_TOKEN_RE.match(words[k - 1]) or words[k - 1] in _DASH_TOKENS):
        k -= 1
    tail = words[k:]
    has_dash_col = allow_dash_columns and any(t in _DASH_TOKENS for t in tail) and any(t not in _DASH_TOKENS for t in tail)
    if not tail or not (_line_may_be_space_grouped(tail) or has_dash_col):
        return None
    # A year that belongs to the label ("Balance at 1 January 2024 2 716 ...",
    # "Final dividend for 2023 paid") is not a value column.
    while (len(tail) >= 3 and re.match(r"^(19|20)\d\d$", tail[0]) and k > 0
           and (words[k - 1].lower() in _MONTH_NAMES or words[k - 1].lower() in ('for', 'of', 'in', 'at', 'to'))):
        words = words[:k] + [tail[0]] + tail[1:]
        k += 1
        tail = words[k:]
    label = " ".join(words[:k]).strip(' .')

    # Split the tail into segments, keeping order. Digit groups are grouped
    # into runs; "(14 384)" and "-14 384" are SIGNED runs that can only be
    # read as one number; anything else numeric (decimals, comma-grouped)
    # is a standalone value.
    segments = []   # ('run', [groups]) | ('signed', [groups], negative) | ('one', value)
    cur = None      # dict: groups, kind ('plain'|'paren'|'dash')

    def flush():
        nonlocal cur
        if cur is None:
            return True
        if cur['kind'] == 'paren' and not cur.get('closed'):
            cur = None
            return False
        if cur['kind'] == 'plain':
            segments.append(('run', cur['groups']))
        else:
            segments.append(('signed', cur['groups'], True))
        cur = None
        return True

    for tok in tail:
        if tok in _DASH_TOKENS:
            if not flush():
                return None
            segments.append(('one', None))
            continue
        m = _ATOM_DIGITS_RE.match(tok)
        if not m:
            if not flush():
                return None
            v = _parse_number(tok)
            if v is None:
                return None
            segments.append(('one', v))
            continue
        op, d, cl = m.group('open'), m.group('d'), m.group('close')
        if op:
            if not flush():
                return None
            cur = {'groups': [d], 'kind': 'paren' if op == '(' else 'dash', 'closed': bool(cl)}
            if cl:
                if not flush():
                    return None
        elif cur is not None and cur['kind'] == 'paren' and not cur.get('closed'):
            cur['groups'].append(d)
            if cl:
                cur['closed'] = True
                if not flush():
                    return None
        elif cur is not None and cur['kind'] == 'dash' and len(d) == 3 and not cl:
            cur['groups'].append(d)
        elif cl:
            return None   # stray ")" - not a shape we understand
        else:
            if cur is not None and cur['kind'] == 'plain':
                cur['groups'].append(d)
            else:
                if not flush():
                    return None
                cur = {'groups': [d], 'kind': 'plain', 'closed': True}
    if not flush():
        return None

    import itertools
    options = []
    for seg in segments:
        kind = seg[0]
        if kind == 'run':
            options.append(_partitions_of_digit_run(seg[1]))
        elif kind == 'signed':
            groups = seg[1]
            head_ok = len(groups) == 1 or (len(groups[0]) <= 3 and all(len(g) == 3 for g in groups[1:]))
            if not head_ok or (len(groups[0]) > 1 and groups[0].startswith('0')):
                return None
            options.append([[(-float("".join(groups)), 0)]])   # 0 groups = never a Notes column
        else:
            options.append([[(seg[1], 0)]])   # standalone (decimal/comma-grouped) number
    best = None
    count = 0
    for combo in itertools.product(*options):
        count += 1
        if count > 4000:
            break
        flat = [item for part in combo for item in part]
        vals = [v for v, _ in flat]
        variants = [(False, vals)]
        # a leading bare 1-3 digit integer (single group) may be the Notes column
        first_v, first_groups = flat[0]
        if (has_note_column and len(flat) > 1 and first_groups == 1
                and float(first_v).is_integer() and 0 <= first_v <= 999):
            variants.append((True, vals[1:]))
        for stripped, cand in variants:
            key = (_value_list_plausibility(cand, expected_cols), not stripped, -len(cand))
            if best is None or key > best[0]:
                best = (key, cand)
    if best is None:
        return None
    return label, best[1]


def _split_label_and_numbers(line: str, has_note_column: bool = True, expected_cols=None,
                             allow_dash_columns: bool = False):
    """A statement line typically looks like:
        'Total operating income     6   45,231,000   38,940,000'
    label, an optional note-reference token, then the amount column(s)
    (by NSE convention: Group current, Group prior, [Company current,
    Company prior] where applicable). Splits the label off, strips any
    note reference, and returns the remaining numbers in report order.

    has_note_column / expected_cols only matter for space-grouped filings
    (see _split_label_and_numbers_space_grouped); comma-grouped lines are
    parsed exactly as before."""
    space_result = _split_label_and_numbers_space_grouped(
        line, has_note_column, expected_cols, allow_dash_columns)
    if space_result is not None:
        return space_result
    matches = list(_NUMBER_RE.finditer(line))
    if not matches:
        return None, []
    label = line[:matches[0].start()].strip(' .')
    remainder = _strip_note_reference(line[matches[0].start():])
    numbers = [_parse_number(m.group()) for m in _NUMBER_RE.finditer(remainder)]
    numbers = [n for n in numbers if n is not None]
    return label, numbers


_JUNK_LABEL_RES = [
    re.compile(p, re.IGNORECASE) for p in [
        r"^k?shs\.?[`']?\s*$",                    # "Shs." / "Kshs.`" bare currency-unit fragments
        r"^k?shs\.?\s*['\u2018\u2019]?0*\s*$",     # "Shs '000" style unit-column headers
        r"^sh\.?\s*['\u2018\u2019]?0*\s*$",        # "Sh'" / "Sh '000'" - same as above without the "k"
        r"^assets\s*k?shs\.?[`']?\s*$",            # "Assets Shs.`" - column header run-together
        r"^liabilities\s*k?shs\.?[`']?\s*$",
        r"^[a-h]\)\s*$",                           # bare lettered legend marker, e.g. "a)" alone
        r"^[a-h]\s+assets\s*$",                    # "A Assets" - lettered column header, not a
        r"^[a-h]\s+liabilities\s*$",               # real reported line item (compare "Total Assets",
        r"^assets\s*$",                            # which has a real qualifier word and is kept)
        r"^liabilities\s*$",
        r"^for\s+the\s+(year|period)\s+ended\b",   # statement period-end heading, e.g. "FOR THE
                                                    # YEAR ENDED 31 DECEMBER 2022" - the date it
                                                    # contains gets misread as an amount otherwise
        r"^at\s+\d",                               # balance-sheet-style "AT 31 DECEMBER 2022" heading
        r"^notes?\s*$",                            # bare "Notes" / "Note" column header
        r"^group\s+company\s*$",                   # "Group Company" - Bank/Company/Group column
        r"^group\s*$",                             # super-header row, and its bare single-word
        r"^company\s*$",                           # forms when it wraps onto its own line
        r"^bank\s*$",
    ]
]


def _looks_like_label(label: str) -> bool:
    if not label or not _LABEL_RE.match(label):
        return False
    stripped = label.strip()
    if len(stripped) <= 2:
        return False
    # Reject currency/unit header fragments and bare lettered legend
    # markers that tabular banking-disclosure pages (e.g. NPL schedules
    # with an "a) ... g)" column legend and a "Shs. '000" unit header
    # running through the number columns) get misread as if they were
    # real reported line items.
    if any(rx.match(stripped) for rx in _JUNK_LABEL_RES):
        return False
    return True


# A genuine statement heading in these filings is its own short, ALL-CAPS
# line ("CONSOLIDATED STATEMENT OF FINANCIAL POSITION") - never a mid-
# sentence mention. A long-form annual/integrated report runs 100-300+
# pages of narrative (highlights, strategy, sustainability, governance)
# before the actual statements, and that narrative routinely uses the
# same words in passing - "...strong balance sheet momentum and healthy
# liquidity...", "...give a true and fair view of the financial position
# of the Group...". Those lines have no digit on them either (so the
# TOC guard above doesn't catch them), and without this check one such
# sentence anywhere in the front matter flips current_stmt on early and
# every number on every page after it - for however many pages until the
# real heading is reached - gets vacuumed up as if it were that
# statement's own line items.
# 13, not 10: interim reports print long combined headings such as
# "Consolidated and separate statement of profit or loss and
# comprehensive income" (11 words, seen on Kakuzi's H1 2025 filing) - at
# 10 the income statement was silently never recognised. Longer headings
# are still corroborated by _has_nearby_note_column() before they start
# a statement section, so the wider limit doesn't reopen false positives.
_HEADING_MAX_WORDS = 13

# A heading never trails off on a dangling connector - a genuine title is
# a complete noun phrase ("... Statement of Financial Position"), while a
# narrative sentence that got line-wrapped mid-clause ("...strong balance
# sheet momentum and healthy liquidity across the") almost always ends on
# one of these. This is what actually distinguishes the two, rather than
# capitalization: headings are set in ALL CAPS in some filings' PDFs but
# plain sentence-case ("Consolidated statement of ...", capital only on
# the first word) in others, so a capitalization-ratio check can't be
# relied on to hold across different filers/years.
_HEADING_BAD_ENDINGS = {
    'the', 'a', 'an', 'of', 'and', 'or', 'in', 'on', 'at', 'to', 'for',
    'by', 'with', 'that', 'this', 'is', 'are', 'was', 'were', 'as',
}

def _dedupe_word(word: str):
    result = _dedupe_word_pairs(word)
    if result is not None:
        return result
    # A bold-rendered 'fi'/'fl' LIGATURE glyph (a single character in the
    # PDF's font) doubled by this same bold-rendering trick produces the
    # literal 4 characters "fifi"/"flfl" (the ligature's decomposed text
    # typed twice) rather than the expected paired doubling "ffii"/"ffll"
    # every ordinary character produces - confirmed on a real filing
    # (Equity Group Holdings' 2024 Integrated Report): "financial" in a
    # bold heading came through as "fifinnaanncciiaall", not
    # "ffiinnaanncciiaall", which silently failed the even/odd-index
    # check below and broke heading detection for EVERY heading
    # containing a ligature word (financial position, profit or loss,
    # cash flows) - only "equity" (no ligature) survived, so every other
    # statement's line items were wrongly absorbed into the equity
    # section. Normalize the ligature artifact back to ordinary paired
    # doubling and retry once before giving up.
    normalized = word.replace('fifi', 'ffii').replace('flfl', 'ffll')
    if normalized != word:
        return _dedupe_word_pairs(normalized)
    return None

def _dedupe_word_pairs(word: str):
    if len(word) < 2 or len(word) % 2 != 0:
        return None
    even, odd = word[0::2], word[1::2]
    return even if even == odd else None

def _dedupe_char_doubled(line: str):
    """Some filings' PDFs render bold headings as every character drawn
    twice in the content stream - "CCoonnssoolliiddaatteedd" for
    "Consolidated" - which pdfplumber then extracts literally; the single
    space between words is untouched, so this has to de-duplicate word by
    word rather than treating the whole line as one even/odd-index split
    (a single un-doubled space anywhere shifts every following
    character's parity and breaks a whole-line split). Requires nearly
    every word in the line to fit the doubled pattern before returning
    anything, so an ordinary line - short numeric fragment included -
    is never mistaken for one."""
    words = line.split(' ')
    alpha_words = [w for w in words if any(ch.isalpha() for ch in w)]
    # Was `< 2` - blocked a genuine single-word doubled heading ("NNootteess"
    # for "Notes") from ever deduping, which meant the notes-section stop
    # condition never recognized it, and extraction ran away into every
    # numbered note afterward (confirmed on Equity Group Holdings' 2024
    # filing - cash_flow ballooned to 600 line items, most of them notes
    # prose). The per-word pairwise-equality check below is already strict
    # enough on its own that a real ordinary single word essentially never
    # satisfies it by accident.
    if len(alpha_words) < 1:
        return None
    deduped, hits = [], 0
    for w in words:
        dw = _dedupe_word(w) if w else w
        if dw is not None:
            if any(ch.isalpha() for ch in w):
                hits += 1
            deduped.append(dw)
        else:
            deduped.append(w)
    if hits < len(alpha_words) - 1:
        return None
    result = ' '.join(deduped)
    # Was `< 8` - blocked a real single-word doubled heading ("NNootteess"
    # -> "Notes", 5 letters) from ever qualifying, which is what broke
    # the notes-section stop detection above. Lowered to 4: still rejects
    # a coincidental short-word accident ("AANNDD" -> "And", 3 letters)
    # while accepting genuine short section headings.
    if sum(1 for ch in result if ch.isalpha()) < 4:
        return None
    return result

def _heading_candidate(line: str):
    """The text a heading check should actually run against, and whether
    it got there by collapsing a doubled-character bold heading -
    (candidate_text, was_doubled)."""
    deduped = _dedupe_char_doubled(line)
    return (deduped, True) if deduped is not None else (line, False)

def _looks_like_heading_line(line: str, was_doubled: bool = False) -> bool:
    text = re.sub(r'\(continued\)\s*$', '', line.strip(), flags=re.IGNORECASE).strip()
    words = text.split()
    if not words or len(words) > _HEADING_MAX_WORDS:
        return False
    # 11+ word lines are only trusted as headings when they read like a
    # title: start with a capital and don't end like a sentence. Without
    # this, a wrapped notes-prose line such as "income and statement of
    # changes in equity are attributable to the following items:" (13
    # words, lowercase start) re-opened the equity section deep inside
    # the notes on a real filing and swept note tables in as line items.
    if len(words) > 10 and (not words[0][:1].isupper() or text.rstrip()[-1:] in ':;,.'):
        return False
    last_word = re.sub(r'[^a-zA-Z]', '', words[-1]).lower()
    if last_word in _HEADING_BAD_ENDINGS:
        return False
    letters = [ch for ch in text if ch.isalpha()]
    if not letters:
        return False
    # Surviving the doubled-character check above is itself strong
    # evidence this line is a specially-rendered (bold) heading, not body
    # text - ordinary prose in these PDFs is never emitted that way - so
    # a doubled line only needs the length/ending checks above.
    if was_doubled:
        return True
    # NOTE: an ALL-CAPS line is a strong positive signal but is NOT
    # required - confirmed on real filings (KCB 2024/2025) that print
    # their genuine statement headings in plain sentence-case
    # ("Consolidated statement of comprehensive income", capital only on
    # the first word). Requiring upper_ratio > 0.85 here silently
    # dropped every statement in those filings down to the fast
    # prefilter's 5-page fallback. The length + bad-ending checks above
    # are deliberately NOT enough on their own to call this a heading
    # (a narrative fragment like "Balance sheet resilience defined this
    # year's results." also passes them) - callers that go on to treat a
    # match as the start of a real statement section (parse_financials_text)
    # must additionally corroborate with _has_nearby_note_column() before
    # trusting it; the fast prefilter (_fast_prefilter_pages) doesn't need
    # that corroboration since it only produces a candidate-page shortlist,
    # not the final parse.
    return True


def _classify_statement(line: str):
    # A TOC/contents-page entry repeats the exact heading text followed by
    # a page number or page range on the same line - reject those so the
    # contents page never gets mistaken for the start of the real
    # statement (see _HEADING_HAS_DIGIT_RE's comment above).
    if _HEADING_HAS_DIGIT_RE.search(line):
        return None
    candidate, was_doubled = _heading_candidate(line)
    if not _looks_like_heading_line(candidate, was_doubled):
        return None
    for stmt, regexes in _HEADING_RES.items():
        for rx in regexes:
            if rx.search(candidate):
                return stmt
    return None


# A real audited statement's heading is followed within a line or two by
# a "Note" column header (alongside the year columns) - confirmed on
# every real KCB/NSE-convention filing checked. A pre-statement summary
# table that reuses the SAME heading wording (e.g. a "Five-Year Review"
# page in the front matter, confirmed on a real KCB filing: "Consolidated
# statement of financial position" sitting over a 5-year, no-Note-column
# KPI table, not the actual balance sheet) never has this column, because
# it isn't tied to numbered notes to the accounts at all. This is what
# lets _looks_like_heading_line() safely accept sentence-case headings
# without reopening that false positive - see its docstring note.
# A real statement's column-header line names the "Note" column on its
# own (optionally alongside a currency-unit column, e.g. " Note Kshs
# million Kshs million") - confirmed across every real statement page
# checked (KCB 2024/2025). This must NOT match a bare cross-reference
# like "(Note 46)" inside ordinary notes prose (confirmed on a real KCB
# filing: "Off balance sheet letters of credit and guarantees (Note 46)"
# sits a few lines under an unrelated "(d) Off balance sheet items"
# sub-heading that otherwise false-matches the balance_sheet pattern -
# see _has_nearby_note_column's docstring). The distinction: a genuine
# column-header line is SHORT (just column labels, no sentence content)
# and starts with "Note" as its own word, rather than merely containing
# "Note" anywhere in a longer sentence.
_NOTE_COLUMN_RE = re.compile(r"^\s*notes?\b", re.IGNORECASE)


def _has_nearby_note_column(lines: list, heading_idx: int, lookahead: int = 7) -> bool:
    for line in lines[heading_idx + 1: heading_idx + 1 + lookahead]:
        stripped = line.strip()
        # Column-header line only - short (a handful of column labels,
        # never a full sentence) and starting with "Note" as its own
        # word. The word-count cap is what rules out a "(Note 46)"
        # cross-reference sitting inside an otherwise-long sentence.
        if _NOTE_COLUMN_RE.match(stripped) and len(stripped.split()) <= 6:
            return True
    return False


# "statement of changes in equity" is specific enough on its own -
# confirmed across real filings checked, this exact phrase never turns
# up loosely in narrative/notes prose the way "balance sheet", "income
# statement" or "statement of cash flows" do (see _has_nearby_note_column's
# docstring for those). Its own real heading also often has no Note
# column in the next few lines (the statement's column headers are share
# capital/premium/retained earnings/etc, not a notes reference) so
# requiring corroboration here would create false NEGATIVES instead -
# missing the real section - without meaningfully reducing false
# positives, since there's essentially no false-positive risk for this
# heading in the first place.
_HEADINGS_NOT_REQUIRING_CORROBORATION = {'equity'}


def match_canonical_label(statement_type, label):
    """Public entry point so callers outside this module (e.g. the manual
    report builder / NSE-review save path in app.py) can resolve a
    hand-typed label like "Revenue" or "Net income" to the same
    normalized_name the PDF parser would assign - so ratios.py can find it
    regardless of whether the figure came from a parsed PDF or was typed
    in by hand."""
    return _match_canonical(statement_type, label)


def _match_canonical(stmt_type, label):
    for rx, norm_name in _CANONICAL_RES.get(stmt_type, []):
        if rx.search(label):
            return norm_name
    return None


# ---------- PERIOD DETECTION (for uploaded PDFs with no filing-title metadata) ----------
# An uploaded annual report PDF has no filing-listing title to lean on (no
# "Equity Group Holdings Plc - ... For the period ended 30 June 2026" to
# parse), so the fiscal year has to come out of the statement pages
# themselves - see detect_period_label() below.

_MONTHS = (r"(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|"
           r"jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|"
           r"nov(?:ember)?|dec(?:ember)?)")

_PERIOD_END_RES = [
    re.compile(rf"for\s+the\s+year\s+ended\s+\d{{1,2}}\s+{_MONTHS}\s+(\d{{4}})", re.IGNORECASE),
    re.compile(rf"for\s+the\s+period\s+ended\s+\d{{1,2}}\s+{_MONTHS}\s+(\d{{4}})", re.IGNORECASE),
    # Same as the two above but without the leading "for the" - some
    # reports head statement columns with just "Year ended 31 December
    # 2025" (seen on Equity Group Holdings' 2025 integrated report,
    # amongst others). Anchored to the start of the line so it doesn't
    # also match "...for the year ended..." twice.
    re.compile(rf"^\s*year\s+ended\s+\d{{1,2}}\s+{_MONTHS}\s+(\d{{4}})", re.IGNORECASE),
    re.compile(rf"^\s*period\s+ended\s+\d{{1,2}}\s+{_MONTHS}\s+(\d{{4}})", re.IGNORECASE),
    # Balance-sheet-style "AT 31 DECEMBER 2022" heading. Anchored to the
    # START of the line (so it can't match "...at 2022" buried inside a
    # wrapped narrative paragraph elsewhere in the report) but NOT to the
    # end - a real bug found on Equity Group Holdings' 2024 Integrated
    # Report: the current-year column header often continues on the same
    # line with unit labels ("At 31 December 2024 Shs' millions Shs'
    # millions...") while the prior-year header repeats bare ("At 31
    # December 2023") since the units were already stated once. The old
    # end-of-line ($) anchor matched the bare prior-year line but NOT the
    # current-year line carrying trailing units, systematically
    # under-counting the actual current year and causing detect_period_label
    # to pick the prior year instead. What still guards against a real
    # narrative match (a sentence like "At 31 December 2022 the Group's
    # liquidity position was..." wrapped onto its own line) is checked in
    # detect_period_label itself: a genuine table header's trailing text
    # is never a lowercase word or a comma.
    re.compile(rf"^at\s+\d{{1,2}}\s+{_MONTHS}\s+(\d{{4}})(?P<trailing>.*)$", re.IGNORECASE),
]
# Fallback: the report's own running header, e.g. "... INTEGRATED REPORT AND
# FINANCIAL STATEMENTS 2022" repeated on nearly every page - a much weaker
# signal (it's the *report's* cover year, not necessarily every statement's
# period end) so it's only used if nothing above matched anywhere.
_REPORT_TITLE_YEAR_RE = re.compile(
    r"(?:annual\s+report|financial\s+statements|integrated\s+report)\D{0,20}(\d{4})",
    re.IGNORECASE,
)

# Last-resort signal: a bare 4-digit year in the uploaded filename itself
# (e.g. "Equity-Group-Holdings-PLC-2024-Integrated-Report...pdf"). This is
# NOT a substitute for reading the statement pages - a file can be renamed
# or have no year in its name at all - but every comparative statement in
# a two-year report mentions the prior year almost as often as the current
# one (each line has a current-period column and a prior-period column),
# so raw occurrence-counting alone can be a near coin-flip. The filename
# year is used only to break that kind of tie, never to overrule a clear
# textual majority.
_FILENAME_YEAR_RE = re.compile(r"(20\d{2}|19\d{2})")


def _filename_year(filename: str | None) -> str | None:
    if not filename:
        return None
    years = _FILENAME_YEAR_RE.findall(filename)
    return years[-1] if years else None



_UNIT_PATTERNS = [
    ('thousands', re.compile(r"(?:shs?|kshs?|kes|ksh|sh)\s*[\u2019'`\u2018.]?\s*(?:000|thousand)s?\b|in\s+thousands|\(\s*(?:shs?|kshs?|kes)\s*'?000\s*\)|[\u2019']000\b", re.I)),
    ('millions',  re.compile(r"(?:shs?|kshs?|kes|ksh|sh)\s*[\u2019'`\u2018.]?\s*(?:m|mn|mio|million)s?\b|in\s+millions|\bmillions?\s+of\s+(?:kenya|kenyan)", re.I)),
    ('billions',  re.compile(r"(?:shs?|kshs?|kes|ksh)\s*[\u2019'`\u2018.]?\s*(?:bn|billion)s?\b|in\s+billions", re.I)),
]


def detect_statement_unit(pages_text):
    """'thousands' | 'millions' | 'billions' | None - the scale the financial
    statements are printed in ("Shs'000", "KShs million", "Shs\u2019million" column
    headers), by majority vote over header-like lines of every scanned page.
    None when no header states one; callers must then NOT assume a scale (a
    thousands filer read as millions is a 1000x error - Kakuzi, Eaagads and
    NSE report in Shs'000)."""
    votes = Counter()
    for _, text in pages_text:
        for line in (text or '').splitlines():
            if len(line) > 140:
                continue                       # column headers are short; skip narrative
            for unit, rx in _UNIT_PATTERNS:
                if rx.search(line):
                    votes[unit] += 1
                    break
    if not votes:
        return None
    (unit, n), = votes.most_common(1)
    return unit if n >= 3 else None


_INTERIM_RE = re.compile(
    r"interim\s+(?:condensed\s+)?(?:consolidated\s+)?financial\s+statements|condensed\s+interim|interim\s+report|"
    r"(?:six|6|nine|9|three|3)\s+months?\s+(?:period\s+)?(?:ended|ending|to)\s+\d{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]+\s+\d{4}", re.I)


def detect_interim_period_label(pages_text, first_pages: int = 3):
    """'H1 2025' for a six-month report, 'Q3 2025' for nine months, 'Q1 2025' for
    three months - judged from the cover / contents pages. None for an annual
    report. Periods keep their own label (the model supports 'H1 2025' style
    labels) so a half-year is never stored as a full fiscal year."""
    head = " ".join((t or '') for _, t in list(pages_text)[:first_pages])
    if not _INTERIM_RE.search(head):
        return None
    m = re.search(r"(six|6|nine|9|three|3)\s+months?\s+(?:period\s+)?(?:ended|ending|to)\s+\d{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]+\s+((?:19|20)\d{2})", head, re.I)
    if not m:
        return None
    code = {'six': 'H1', '6': 'H1', 'nine': 'Q3', '9': 'Q3', 'three': 'Q1', '3': 'Q1'}[m.group(1).lower()]
    return f"{code} {m.group(2)}"


def looks_like_interim_report(pages_text, first_pages: int = 3) -> bool:
    """A six-month / nine-month / quarterly report, judged from its first pages
    (cover + contents), not from narrative deep in an annual report. Saving one
    as a fiscal year would store half a year's profit as the full year's."""
    head = " ".join((t or '') for _, t in list(pages_text)[:first_pages])
    return bool(_INTERIM_RE.search(head))


def detect_period_label(pages_text, filename: str | None = None) -> str | None:
    """Determine the reporting fiscal year and return it as 'FY<year>'.

    Every page is scanned for statement period-end dates ('FOR THE YEAR
    ENDED 31 DECEMBER 2022', 'AT 31 DECEMBER 2022'). Two-year comparative
    statements mention both the current and prior year on almost every
    line (current-period column + prior-period column), so a naive
    "most frequent year wins" count is only a couple of matches away from
    picking the WRONG year on files where the two years are close in
    count - which is most of them. To avoid that:

      1. Count each year once per PAGE (its first match), not once per
         line. A page repeating "Year ended 31 December 2024" as a column
         header alongside a dozen "2023" comparative figures should only
         contribute one vote per year, not vote by line-item count.
      2. If that still leaves a tie or a margin of 1, prefer the higher
         year - a report's reporting year is never earlier than its
         comparative year, so on genuine ambiguity the later year is the
         better guess.
      3. If a filename year is available and matches one of the two
         leading candidates, prefer it as the final tie-breaker over the
         "prefer higher year" rule, since it's an independent signal from
         outside the document body.

    Falls back to the report's cover-page year (_REPORT_TITLE_YEAR_RE) if
    no statement-level date is found anywhere, then to the filename year.
    Returns None only if none of these signals are present at all -
    callers should treat that as 'ask the user', not guess further."""
    year_page_counts: dict[str, int] = {}
    for _, page_text in pages_text:
        years_on_this_page: set[str] = set()
        for raw_line in page_text.splitlines():
            line = raw_line.strip()
            for rx in _PERIOD_END_RES:
                m = rx.search(line)
                if m:
                    trailing = m.groupdict().get('trailing')
                    if trailing:
                        stripped = trailing.strip()
                        # Reject a genuine narrative continuation wrapped
                        # onto this line ("At 31 December 2022 the Group's
                        # liquidity..." / "At 31 December 2022, the..."),
                        # which a real table/column header never looks
                        # like - a table header's trailing text is unit
                        # labels, currency symbols, or nothing at all.
                        if stripped.startswith(',') or (stripped and stripped[0].islower()):
                            continue
                    years_on_this_page.add(m.group(1))
        for y in years_on_this_page:
            year_page_counts[y] = year_page_counts.get(y, 0) + 1

    fname_year = _filename_year(filename)

    if year_page_counts:
        ranked = sorted(year_page_counts.items(), key=lambda kv: (-kv[1], -int(kv[0])))
        top_year, top_count = ranked[0]
        if len(ranked) > 1:
            second_year, second_count = ranked[1]
            if top_count - second_count <= 1:
                # Near-tie: let a filename year decide if it names one of
                # the two contenders; otherwise fall back to the higher
                # year, per the docstring above.
                if fname_year in (top_year, second_year):
                    return f"FY{fname_year}"
                top_year = max(top_year, second_year, key=int)
        return f"FY{top_year}"

    for _, page_text in pages_text:
        m = _REPORT_TITLE_YEAR_RE.search(page_text)
        if m:
            return f"FY{m.group(1)}"

    if fname_year:
        return f"FY{fname_year}"

    return None


def detect_prior_period_label(period_label: str | None) -> str | None:
    """The comparative column a two-column statement carries (NSE's
    'amount'/'prior_amount' pair - see parse_financials_text's docstring)
    is always the fiscal year immediately before the detected one: annual
    reports show exactly one prior year of comparatives, never further
    back, and NSE's own reports mark that column with a footnote ("*
    Change in presentation of comparatives") confirming it's the prior
    FY, not an arbitrary earlier year. Only handles the 'FY<year>' shape
    detect_period_label() produces - a period label detect_period_label
    never returns (quarterly, half-year) has no defined prior label here,
    so callers should treat None as 'don't attempt a second save'."""
    m_int = re.match(r"^(H[12]|Q[1-4])\s+((?:19|20)\d{2})$", period_label or "")
    if m_int:
        return f"{m_int.group(1)} {int(m_int.group(2)) - 1}"     # the same half / quarter a year earlier
    if not period_label or not period_label.startswith('FY'):
        return None
    try:
        year = int(period_label[2:])
    except ValueError:
        return None
    return f"FY{year - 1}"


def _filename_company_candidate(filename: str | None) -> str | None:
    """Best-effort company name straight out of the uploaded filename, e.g.
    'Equity-Group-Holdings-PLC-2024-Integrated-Report...pdf' ->
    'Equity Group Holdings PLC'. Strips the extension, replaces separators
    with spaces, and cuts the string at the first token that signals
    "the report metadata starts here, not the company name" - a 4-digit
    year, or the words that head every annual-report filename pattern seen
    in practice (Integrated/Annual Report, Financial Statement(s)). This is
    ONLY meant to be used as a tie-breaker/fallback alongside content-based
    detection (see detect_company_name) - a renamed file or one with no
    year/company in its name at all simply yields None here, which callers
    should treat the same as "no filename signal available"."""
    if not filename:
        return None
    stem = re.sub(r"\.pdf$", "", filename, flags=re.IGNORECASE)
    stem = re.sub(r"[_\-]+", " ", stem).strip()
    cut_re = re.compile(
        r"\b(?:19|20)\d{2}\b|\bintegrated\b|\bannual\b|\bfinancial\b", re.IGNORECASE
    )
    m = cut_re.search(stem)
    candidate = stem[:m.start()].strip() if m else stem
    return candidate or None


def detect_company_name(pages_text, max_pages: int = 400, filename: str | None = None) -> str | None:
    """Best-effort company name from the first few pages - most annual
    reports repeat 'X PLC INTEGRATED REPORT AND FINANCIAL STATEMENTS' or
    similar as a running header, which is a more reliable signal than the
    cover page's often stylised title text/graphics.

    Different reports lay out their first few pages very differently - a
    plain annual report usually has a clean all-caps company banner right
    on page 1, but a marketing-led "integrated report" (glossy cover,
    theme tagline, table of contents) often doesn't, and the frequency
    heuristic below can latch onto an unrelated all-caps heading instead
    (e.g. a table-of-contents entry like "A MESSAGE FROM OUR GROUP
    MANAGING DIRECTOR..." matching on the word "GROUP"). To guard against
    that, every candidate found is scored against the known NSE company
    roster (company_directory.match_company) and the best-scoring one
    wins over the merely most-frequent one, whenever any candidate scores
    highly enough to be a confident real match; only falls back to
    "most frequent candidate" when nothing scores well (e.g. a company
    not yet in the roster), same as before.

    If a filename is supplied and content-based detection finds nothing
    at all (no candidate name anywhere in the scanned pages), the
    filename's own leading text (see _filename_company_candidate) is used
    as a last-resort fallback rather than returning None outright. It is
    never used to override a content-based candidate - a company's own
    report text is a stronger signal than how the file happened to be
    named on the portal it was downloaded from.
    """
    name_re = re.compile(
        r"([A-Z][A-Z .&'\-]{3,60}?(?:PLC|LIMITED|LTD|GROUP|HOLDINGS))\b",
    )
    counts = {}
    for page_num, page_text in pages_text:
        if page_num > max_pages:
            break
        for line in page_text.splitlines():
            m = name_re.search(line)
            if m:
                name = m.group(1).strip()
                counts[name] = counts.get(name, 0) + 1

    try:
        from company_directory import match_company
        best_candidate, best_candidate_score = None, 0.0
        for candidate in counts:
            _, score = match_company(candidate.title())
            if score > best_candidate_score:
                best_candidate, best_candidate_score = candidate, score
        if best_candidate is not None and best_candidate_score >= 0.75:
            return best_candidate.title()
    except ImportError:
        pass

    # The all-caps regex above only catches a repeated all-caps banner
    # header ("KCB GROUP PLC INTEGRATED REPORT..."). Some real filings
    # (confirmed on Equity Group Holdings Plc's 2024 Integrated Report)
    # never print their own name that way anywhere in the scanned pages -
    # it only appears in ordinary mixed-case body text ("Equity Group
    # Holdings Plc is regulated by..."), so `counts` above is either empty
    # or, worse, non-empty but full of unrelated all-caps phrases that
    # happen to end in GROUP/HOLDINGS/etc. (e.g. a table-of-contents
    # heading "STRUCTURE OF THE GROUP" - a real false positive this
    # exact fallback used to return, silently mislabeling the company).
    # Before trusting "most frequent all-caps candidate" at all, try a
    # direct case-insensitive literal match of each known NSE company's
    # own name/alias against the raw page text - a real name appearing
    # verbatim several times is a far stronger signal than an unrelated
    # heading that happens to fit the regex once or twice.
    try:
        from company_directory import NSE_COMPANIES
        name_hits = {}
        for page_num, page_text in pages_text:
            if page_num > max_pages:
                break
            lower_text = page_text.lower()
            for company in NSE_COMPANIES:
                for candidate_name in [company["name"]] + company.get("aliases", []):
                    if candidate_name.lower() in lower_text:
                        name_hits[company["name"]] = name_hits.get(company["name"], 0) + 1
        if name_hits:
            best_name = max(name_hits, key=name_hits.get)
            if name_hits[best_name] >= 2:
                return best_name
    except ImportError:
        pass

    if not counts:
        fname_candidate = _filename_company_candidate(filename)
        return fname_candidate

    return max(counts, key=counts.get).title()


def _derive_total_liabilities(items: list) -> dict | None:
    """NSE's own statement layout never states 'Total Liabilities' as its
    own labeled line - it only gives 'TOTAL ASSETS' and 'Total equity' /
    'TOTAL SHAREHOLDERS' FUNDS AND LIABILITIES' (equity+liabilities
    combined), leaving debt_equity/debt_assets with nothing to compute
    from downstream (ratios.py, Financial Health Score, Debt/Equity on
    every Intelligence Report tab). Where a direct 'Total Liabilities'
    line genuinely wasn't found, derive it the only way the accounting
    identity allows: total_assets - total_equity. Returns a dict with
    'amount' and/or 'prior_amount' (only the columns that were
    computable), or None if total_assets/total_equity themselves weren't
    both found for a given column."""
    by_name = {li['normalized_name']: li for li in items if li.get('normalized_name')}
    if 'total_liabilities' in by_name:
        return None  # a real line was found - never override it with a derived one

    assets = by_name.get('total_assets')
    equity = by_name.get('total_equity')
    if not assets or not equity:
        return None

    derived = {}
    if assets.get('amount') is not None and equity.get('amount') is not None:
        derived['amount'] = assets['amount'] - equity['amount']
    if assets.get('prior_amount') is not None and equity.get('prior_amount') is not None:
        derived['prior_amount'] = assets['prior_amount'] - equity['prior_amount']
    return derived or None


# "Shs\u2019million Shs\u2019million" style column headers: the count is the number of
# value columns the statement prints, which settles space-grouped ambiguity.
_UNIT_TOKEN_RE = re.compile(
    r"(?:Shs|Kshs?|KES|KSh|USD|US\$|Rs|\$|\u20ac|\u00a3)[\u2019'.]?\s?(?:million|billion|thousand|'000|000|m|bn|k)\b", re.I)
_EQUITY_BLOCK_RE = re.compile(r"\b((?:19|20)\d\d)\b")


def _is_block_header_line(current_stmt, line) -> bool:
    return bool(current_stmt == 'equity' and _EQUITY_BLOCK_RE.search(line)
                and line.lower().lstrip().startswith(('year ended', 'for the year ended', 'period ended')))


def _equity_label_key(label: str) -> str:
    return re.sub(r"[^a-z]+", " ", label.lower()).strip()


def _collapse_equity_blocks(items: list, order_counters: dict) -> None:
    """A statement of changes in equity prints one block per year ("Year
    ended 31 December 2024", then "... 2025"). Keep the latest block as the
    current period and use the earlier block's matching row (same label,
    years ignored) as prior_amount - instead of mixing both years' movements
    in one list, which produced rows like "Profit for the year" three times
    with different years' figures. Mutates `items` in place; no-op when the
    statement has fewer than two year blocks."""
    years = sorted({i['_block'] for i in items if i.get('_block')})
    if len(years) >= 2:
        latest, earlier = years[-1], years[-2]
        prior_by_key = {}
        for it in items:
            if it.get('_block') == earlier:
                prior_by_key.setdefault(_equity_label_key(it['label']), it['amount'])
        kept = []
        for it in items:
            blk = it.get('_block')
            if blk == latest or blk is None:
                if blk == latest:
                    it['prior_amount'] = prior_by_key.get(_equity_label_key(it['label']))
                    if it['normalized_name'] is None and it['prior_amount'] is not None:
                        # confidence was scored before the prior-year figure was paired in
                        it['confidence'] = _ext.structural_confidence(it['label'], it['amount'], it['prior_amount'])
                kept.append(it)
        items[:] = kept
        for n, it in enumerate(items, 1):
            it['order_index'] = n
        order_counters['equity'] = len(items)
    for it in items:
        it.pop('_block', None)


def parse_financials_text(pages_text) -> dict:
    """
    pages_text: iterable of (page_number, page_text), 1-indexed.

    Returns:
        {"statements": {
            "income_statement": {"line_items": [...]},
            "balance_sheet":    {"line_items": [...]},
            "cash_flow":        {"line_items": [...]},
            "equity":           {"line_items": [...]},
        }}

    Each line item: {label, normalized_name, amount, prior_amount, page,
    confidence, order_index}. `amount` is the current-period (first)
    column; `prior_amount` is the comparative prior-period column when
    the statement's layout has one (NSE's convention: current period,
    then prior period, per Group/Company block) - None if only one
    column was present on the line. Callers that only care about the
    current period can keep reading `amount` exactly as before;
    `prior_amount` is purely additive.

    Statements with zero recognized lines are omitted entirely.
    """
    statements = {stmt: [] for stmt in STATEMENT_HEADINGS}
    current_stmt = None
    section_has_items = False
    ext_name_counts = {stmt: {} for stmt in STATEMENT_HEADINGS}
    order_counters = {stmt: 0 for stmt in STATEMENT_HEADINGS}
    seen_normalized = {stmt: set() for stmt in STATEMENT_HEADINGS}
    seen_raw = {stmt: set() for stmt in STATEMENT_HEADINGS}
    col_votes = {stmt: Counter() for stmt in STATEMENT_HEADINGS}
    group_heading_seen = {stmt: False for stmt in STATEMENT_HEADINGS}
    entity_only_used = {stmt: False for stmt in STATEMENT_HEADINGS}
    skip_entity_rows = False
    equity_block_year = None
    hdr_cols = {}

    for page_num, page_text in pages_text:
        page_lines = [l.strip() for l in page_text.splitlines()]
        for line_idx, line in enumerate(page_lines):
            if not line:
                continue

            heading_match = _classify_statement(line)
            if heading_match:
                # Corroborate with a nearby "Note" column before trusting
                # this as the real statement's start - see
                # _has_nearby_note_column's docstring for why (a
                # front-matter summary table, or a narrative sentence
                # that happens to say e.g. "balance sheet", can otherwise
                # match now that sentence-case headings are accepted -
                # see _looks_like_heading_line's note). Without that
                # corroboration, just skip this line rather than starting
                # (or ending) a section on a false positive - a real
                # statement heading appears again, correctly corroborated,
                # once the actual statement page is reached. 'equity' is
                # exempt - see _HEADINGS_NOT_REQUIRING_CORROBORATION.
                if (heading_match in _HEADINGS_NOT_REQUIRING_CORROBORATION
                        or _has_nearby_note_column(page_lines, line_idx)):
                    current_stmt = heading_match
                    section_has_items = False
                    entity_only = bool(_ENTITY_ONLY_HEADING_RE.match(line))
                    if entity_only:
                        # skip when a consolidated version already exists
                        skip_entity_rows = group_heading_seen[heading_match]
                        if not skip_entity_rows:
                            entity_only_used[heading_match] = True
                    else:
                        if entity_only_used[heading_match]:
                            # consolidated version arrived AFTER an entity-only
                            # one was read: the consolidated one replaces it
                            statements[heading_match] = []
                            seen_normalized[heading_match] = set()
                            seen_raw[heading_match] = set()
                            ext_name_counts[heading_match] = {}
                            order_counters[heading_match] = 0
                            col_votes[heading_match] = Counter()
                            entity_only_used[heading_match] = False
                        group_heading_seen[heading_match] = True
                        skip_entity_rows = False
                continue

            if current_stmt is None:
                continue

            if any(rx.search(line) for rx in _SECTION_STOP_RES):
                current_stmt = None
                continue
            stop_candidate, stop_was_doubled = _heading_candidate(line)
            if _looks_like_heading_line(stop_candidate, stop_was_doubled) and any(rx.search(stop_candidate) for rx in _SECTION_STOP_HEADING_RES):
                current_stmt = None
                continue
            if _is_numbered_note_heading(line):
                if _DATE_HEADER_RE.match(line) and not section_has_items:
                    continue  # e.g. "30 June 2025 30 June 2024" column header under the heading
                current_stmt = None
                continue

            n_unit_tokens = len(_UNIT_TOKEN_RE.findall(line))
            if n_unit_tokens >= 2:
                hdr_cols[current_stmt] = n_unit_tokens

            # A "Notes Shs'000 Shs'000" style column-header row is not a
            # line item ("000" was being read as an amount of 0).
            if _NOTE_COLUMN_RE.match(line) and len(line.split()) <= 6:
                continue

            # Notes column expected everywhere except equity; expected_cols
            # = the value-column count this section has shown so far, which
            # settles space-grouped ambiguity ("648 128 640 100").
            votes = col_votes[current_stmt]
            expected_cols = hdr_cols.get(current_stmt)
            if expected_cols is None and sum(votes.values()) >= 3:
                expected_cols = votes.most_common(1)[0][0]
            # A statement row ENDS with its figures. A line whose last word is
            # text ("Final dividend for 2022 paid", "Proposed final dividend
            # 2023 (Note 49)") has a year or note number in its label and no
            # values - the row's numbers are printed elsewhere on the page -
            # and reading that year as an amount saved rows like
            # "Final dividend for | 2".
            _no_notes = _NOTE_XREF_RE.sub("", line).split()
            _last_tok = _no_notes[-1] if _no_notes else ""
            if not (_NUMERIC_TOKEN_RE.match(_last_tok) or _last_tok in _DASH_TOKENS):
                _is_block_header = (current_stmt == 'equity' and _EQUITY_BLOCK_RE.search(line)
                                    and line.lower().lstrip().startswith(('year ended', 'for the year ended', 'period ended')))
                if not _is_block_header:
                    continue
            elif (re.fullmatch(r"(19|20)\d\d", _last_tok) and not _is_block_header_line(current_stmt, line)
                  and (len(_no_notes) < 2 or not _NUMERIC_TOKEN_RE.match(_no_notes[-2]))):
                # a lone year at the end of the label ("Proposed final dividend 2023
                # (Note 49)") is part of the label, not a value column
                continue
            if current_stmt == 'equity':
                block_m = _EQUITY_BLOCK_RE.search(line)
                if block_m and line.lower().lstrip().startswith(('year ended', 'for the year ended', 'period ended')):
                    new_year = int(block_m.group(1))
                    if new_year != equity_block_year:
                        equity_block_year = new_year
                        ext_name_counts['equity'] = {}
                        seen_normalized['equity'] = set()
                        seen_raw['equity'] = set()
                    continue
            label, numbers = _split_label_and_numbers(
                line, has_note_column=(current_stmt != 'equity'), expected_cols=expected_cols,
                allow_dash_columns=True)
            if not numbers or not _looks_like_label(label):
                continue
            if skip_entity_rows:
                continue
            if current_stmt == 'equity' and len(numbers) >= 3:
                # multi-column changes-in-equity matrix (share capital, reserves,
                # ..., Total equity): the meaningful figure is the LAST column.
                if numbers[-1] is None:
                    continue
                numbers = [numbers[-1]]
            else:
                numbers = [0.0 if n is None else n for n in numbers]   # a dash = nil
            col_votes[current_stmt][len(numbers)] += 1

            # Running headers/footers and "as at"/"year ended" lines are not
            # line items (see canonical_extended.is_page_furniture).
            if _ext.is_page_furniture(label, numbers):
                continue

            normalized = _match_canonical(current_stmt, label)
            is_core = normalized is not None
            ext_name = None
            if not is_core:
                ext_name = _ext.match_extended(current_stmt, label)
            amount = numbers[0]  # current-period column, by NSE convention
            prior_amount = numbers[1] if len(numbers) > 1 else None

            if normalized not in _SIGNED_ALLOWED:
                amount = abs(amount)
                if prior_amount is not None:
                    prior_amount = abs(prior_amount)

            # Dedupe, two levels:
            # 1. Any exact (label, amount) repeat within a statement is
            #    dropped outright - this catches identical rows that
            #    appear more than once regardless of whether they were
            #    canonically recognized (e.g. an unmapped line repeated
            #    across a continuation page or a note cross-reference).
            raw_key = (label.strip().lower(), amount)
            if raw_key in seen_raw[current_stmt]:
                continue
            seen_raw[current_stmt].add(raw_key)

            # 2. For recognized (normalized) line items specifically, only
            #    the first occurrence is kept even if a later repeat has a
            #    different-looking label (subtotals sometimes repeat with
            #    slightly reworded text on continuation pages).
            if normalized:
                if normalized in seen_normalized[current_stmt]:
                    continue
                seen_normalized[current_stmt].add(normalized)
                confidence = 0.9
            elif ext_name:
                # Extended vocabulary names may repeat inside a statement
                # (a non-current AND a current "Lease obligations"), so a
                # repeat gets a numeric suffix rather than being dropped -
                # keeps normalized_name unique per statement, which
                # report_context and the period-compare view rely on.
                n_seen = ext_name_counts[current_stmt].get(ext_name, 0) + 1
                ext_name_counts[current_stmt][ext_name] = n_seen
                normalized = ext_name if n_seen == 1 else f'{ext_name}_{n_seen}'
                confidence = 0.85
            else:
                confidence = _ext.structural_confidence(label, amount, prior_amount)

            order_counters[current_stmt] += 1
            section_has_items = True
            statements[current_stmt].append({
                'label': label,
                'normalized_name': normalized,
                'amount': amount,
                'prior_amount': prior_amount,
                'page': page_num,
                'confidence': confidence,
                'order_index': order_counters[current_stmt],
                **({'_block': equity_block_year} if current_stmt == 'equity' else {}),
            })

    _collapse_equity_blocks(statements['equity'], order_counters)

    # Derived total_liabilities (see _derive_total_liabilities docstring) -
    # balance sheet only, added as its own synthetic line item so it flows
    # through _save_one_import's normalized_name -> flat[] pickup exactly
    # like a directly-parsed line would, just with a lower confidence
    # score and a label that says plainly it's computed, not read off the
    # page.
    bs_items = statements.get('balance_sheet', [])
    derived = _derive_total_liabilities(bs_items)
    if derived:
        order_counters['balance_sheet'] += 1
        bs_items.append({
            'label': 'Total Liabilities (derived: Total Assets − Total Equity)',
            'normalized_name': 'total_liabilities',
            'amount': derived.get('amount'),
            'prior_amount': derived.get('prior_amount'),
            'page': None,
            'confidence': 0.6,
            'order_index': order_counters['balance_sheet'],
        })

    return {
        'statements': {
            stmt: {'line_items': items} for stmt, items in statements.items() if items
        }
    }


# A "different report, different shape" guard: a scanned/image-only PDF
# (no embedded text layer) will come back with empty or near-empty text on
# every page no matter which extractor is used - there's no OCR here, so
# that case can only be reported honestly, not silently "fixed".
_MIN_CHARS_PER_PAGE_FOR_TEXT_LAYER = 20

# Hard ceiling so a genuinely pathological upload (thousands of pages,
# or a corrupt file that confuses page counting) fails fast with a clear
# message instead of hanging the request indefinitely.
_MAX_PAGES = 600


# One pypdf text pass per PDF, shared by everything that needs it.
# A single full-report upload used to read every page's text with pypdf
# SIX separate times (the statement prefilter below, then
# extract_director_remuneration, extract_market_data,
# extract_management_guidance, extract_principal_risks and
# extract_director_remuneration_detail each started from scratch) - on a
# ~130-page bank report that was ~50s of pure repeated work, and roughly
# triple that on a ~300-page one. Results are identical (same pypdf
# extract_text() per page); they're just computed once. Keyed by a hash of
# the bytes, tiny LRU (2 PDFs) so concurrent uploads can't grow memory.
_PAGE_TEXT_CACHE = OrderedDict()
_PAGE_TEXT_CACHE_LOCK = threading.Lock()
_PAGE_TEXT_CACHE_MAX = 2


def _pypdf_page_texts_cached(pdf_bytes: bytes):
    """[(page_num, text), ...] for every page via pypdf, computed once per
    distinct PDF. None if pypdf isn't installed or can't open the file
    (callers decide their own fallback)."""
    if pypdf is None:
        return None
    key = (len(pdf_bytes), hashlib.blake2b(pdf_bytes, digest_size=16).hexdigest())
    with _PAGE_TEXT_CACHE_LOCK:
        hit = _PAGE_TEXT_CACHE.get(key)
        if hit is not None:
            _PAGE_TEXT_CACHE.move_to_end(key)
            return hit
    try:
        reader = pypdf.PdfReader(io.BytesIO(pdf_bytes))
        pages = list(reader.pages)
    except Exception:
        return None
    out = []
    for i, page in enumerate(pages):
        try:
            out.append((i + 1, page.extract_text() or ""))
        except Exception:
            # A single malformed page shouldn't sink the whole pass.
            out.append((i + 1, ""))
    with _PAGE_TEXT_CACHE_LOCK:
        _PAGE_TEXT_CACHE[key] = out
        while len(_PAGE_TEXT_CACHE) > _PAGE_TEXT_CACHE_MAX:
            _PAGE_TEXT_CACHE.popitem(last=False)
    return out


def _fast_prefilter_pages(pdf_bytes: bytes, always_include: int = 5):
    """First pass with pypdf - much faster than pdfplumber's extract_text()
    but doesn't reliably reconstruct table rows (see the note on
    extract_pdf_document below), so it's only used here to guess which
    page numbers are worth the slow, accurate pass. Returns a sorted list
    of 1-indexed candidate page numbers, or None if pypdf isn't available
    (callers should fall back to scanning every page in that case, rather
    than silently returning nothing).

    Always includes the first `always_include` pages regardless of
    whether a heading was found on them - detect_company_name() reads
    from the first few pages (the cover/running header), which usually
    has no statement heading of its own and would otherwise get dropped
    by the prefilter entirely.
    """
    texts = _pypdf_page_texts_cached(pdf_bytes)
    if not texts:
        return None
    num_pages = len(texts)

    candidates = set(range(1, min(always_include, num_pages) + 1))
    for page_num, text in texts:
        for line in text.splitlines():
            if _classify_statement(line.strip()):
                # A statement's line items almost always run several pages
                # past its own heading page (continuation pages, notes-free
                # runs of numbers) - grab a generous window forward, plus
                # one page back in case the heading itself sits just before
                # the detected page due to text-extraction quirks.
                for p in range(max(1, page_num - 1), min(num_pages, page_num + 6) + 1):
                    candidates.add(p)
    return sorted(candidates)


def extract_pdf_document(pdf_bytes: bytes) -> dict:
    """The one adapter every uploaded PDF goes through, regardless of
    which company or report format it came from - a slim standalone
    financial-statements PDF, a scanned image PDF, or a dense 300-page
    integrated report all reach this same function, and it's the ONLY
    place that runs pdfplumber's slow extract_text() over an uploaded
    file. (Previously the upload route extracted page text once itself,
    for company/period detection, and then parse_financials_pdf()
    extracted it again from scratch for the actual statement parsing -
    two full slow passes over the same PDF. That doubling was the biggest
    single contributor to large uploads timing out; this function is the
    fix - one slow pass, whose output feeds both detection and parsing.)

    Returns {"pages_text": [(page_num, text), ...], "statements": {...}} -
    "pages_text" covers whichever pages were actually read (see the
    performance note below, not necessarily the full document) and is
    what detect_company_name()/detect_period_label() should be called
    with; "statements" is parse_financials_text()'s normal output.

    NOTE on performance: page-by-page pdfplumber.extract_text() is the
    slow part of an import - measured ~105s for a dense 298-page
    integrated report, almost entirely inside that one call. A PyMuPDF
    swap was tried and reverted: PyMuPDF's plain get_text() is ~55x
    faster but does NOT reconstruct table rows the way pdfplumber does -
    "Interest income 6 188,329 185,344" (one line, one row) comes back
    from PyMuPDF as four separate lines, one per column - which silently
    breaks _split_label_and_numbers() and guts extraction rather than
    just slowing it down.

    What IS done about it: pypdf (much faster, same row-splitting problem
    as PyMuPDF) runs a first pass over every page just to spot statement
    headings, then only that shortlist of candidate pages - typically a
    few dozen out of a few hundred, plus the first few pages for company
    detection - goes through the slow, accurate pdfplumber pass. A large
    integrated report's ~280 pages of narrative, governance and
    sustainability content never touch the slow extractor. If the fast
    pass can't find any headings (pypdf missing, or a layout it can't
    read at all), every page is scanned the slow way exactly as before -
    correctness never depends on the fast pass succeeding.

    This does NOT fully solve very large batches - moving big-PDF imports
    off the request/response cycle entirely (background worker + poll)
    is the real fix and hasn't been built; if a single file is still slow
    enough to hit a platform-level request timeout, that's a proxy/worker
    timeout setting to raise, not something this function can catch.
    """
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        num_pages = len(pdf.pages)
        if num_pages == 0:
            return {'pages_text': [], 'num_pages': 0, 'statements': {}}
        if num_pages > _MAX_PAGES:
            raise ValueError(
                f"PDF has {num_pages} pages, over the {_MAX_PAGES}-page limit for a single upload. "
                "Split it or upload the relevant section separately."
            )

        candidate_pages = _fast_prefilter_pages(pdf_bytes)
        page_numbers = candidate_pages if candidate_pages else range(1, num_pages + 1)

        pages_text = []
        pages_with_text = 0
        for i in page_numbers:
            try:
                page = pdf.pages[i - 1]
                # Some reports (seen in the wild: a landscape "integrated
                # report" layout, roughly double a normal portrait
                # page's width) print two independent logical report
                # pages side by side on one physical PDF page - plain
                # extract_text() reads across both halves line-by-line,
                # interleaving e.g. "Consolidated statement of profit or
                # loss" with an unrelated statement printed next to it,
                # which silently corrupts every numeric row that follows
                # (still non-empty text, so this fails silently rather
                # than raising - the only symptom is wrong/missing
                # numbers reaching parse_financials_text). Detect that
                # layout via aspect ratio and reconstruct each half
                # separately by word x-position instead of reading the
                # page as one block; a normal single-column page is
                # unaffected and costs nothing extra (extract_words() is
                # only called for pages that fail the aspect-ratio check).
                halves = _split_double_page_text(page)
                halves = [_unreverse_page_text(h) for h in halves]
                for half_text in halves:
                    pages_text.append((i, half_text))
                combined_len = sum(len(h) for h in halves)
            except Exception:
                # One unreadable page (corrupt object, unsupported font)
                # shouldn't abort the whole import - skip it and keep going.
                pages_text.append((i, ""))
                combined_len = 0
            if combined_len >= _MIN_CHARS_PER_PAGE_FOR_TEXT_LAYER:
                pages_with_text += 1

        if pages_with_text == 0:
            raise ValueError(
                "No extractable text found on any scanned page - this looks like a scanned "
                "image PDF with no embedded text layer, which isn't supported yet (no OCR)."
            )

    return {'pages_text': pages_text, 'num_pages': num_pages,
            'statements': parse_financials_text(pages_text)['statements']}


_COMMON_WORDS_FOR_REVERSAL_CHECK = {
    'the', 'and', 'of', 'in', 'to', 'for', 'on', 'director', 'directors',
    'remuneration', 'report', 'statement', 'total', 'fees', 'salary',
    'bonus', 'pension', 'committee', 'board', 'company', 'group',
    'financial', 'year', 'shareholders', 'audit', 'audited', 'not', 'are',
    'is', 'with', 'information', 'continued', 'benefits', 'allowances',
    'service', 'gratuity', 'receive', 'entitled', 'executive',
}


def _unreverse_line_if_needed(line: str) -> str:
    """Some filings (confirmed: Equity Group Holdings' 2024 Integrated
    Report, its Directors' Remuneration Report continuation pages 126-127)
    have specific lines - and specific whole table blocks - extract with
    every character in mirror-image order: "SEEF EVIECER" for "RECEIVE
    FEES", numbers and all. This is isolated to that one table's content
    stream (the page's own repeating header, "FINANCIAL STATEMENTS" etc.,
    extracts completely normally on the very same page), so this checks
    and corrects per LINE rather than assuming a whole page is affected.
    Detection: a line that reverses into something with common
    English/financial-report words it didn't have before is almost
    certainly one of these - an ordinary correctly-extracted line only
    ever loses common-word hits when reversed, never gains them.
    """
    if len(line) < 6:
        return line
    words = re.findall(r"[a-zA-Z']+", line.lower())
    if not words:
        return line
    normal_hits = sum(1 for w in words if w in _COMMON_WORDS_FOR_REVERSAL_CHECK)
    reversed_line = line[::-1]
    rev_hits = sum(1 for w in re.findall(r"[a-zA-Z']+", reversed_line.lower())
                    if w in _COMMON_WORDS_FOR_REVERSAL_CHECK)
    return reversed_line if rev_hits > normal_hits and rev_hits >= 1 else line


def _unreverse_page_text(text: str) -> str:
    return '\n'.join(_unreverse_line_if_needed(ln) for ln in text.split('\n'))


def normalize_extracted_line(line: str) -> str:
    """Single entry point for another module (document_chunk.py's
    survey/ontology pipeline, which builds its own lines directly from
    pdfplumber character data rather than going through
    extract_pdf_document() above) to get the same two corrections this
    module's own pipeline applies, including their combination - a
    real filing (Equity Group Holdings 2024) has heading lines that are
    BOTH doubled-bold AND mirror-reversed at once ("ttrrooppeerr" is
    "report" doubled, THEN reversed).

    A doubled-and-reversed word is *also* trivially valid input to the
    plain doubled-dedupe check on its own - every 2-char pair still
    matches, it just spells the word backwards ("troper") - so "did
    dedupe succeed" alone can't tell a plain-doubled line from a
    doubled-then-reversed one. When dedupe succeeds on BOTH the line
    as-is and its reversal, the two results are compared by common-word
    hits to pick the real one; when only one side dedupes, that side is
    trusted directly (no scoring needed - the strict pairwise dedupe
    check is already a reliable signal on its own for the ordinary,
    much more common, doubled-but-not-reversed case).
    """
    doubled = _dedupe_char_doubled(line)
    doubled_reversed = _dedupe_char_doubled(line[::-1])
    if doubled is not None and doubled_reversed is not None:
        def _hits(s):
            return sum(1 for w in re.findall(r"[a-zA-Z']+", s.lower())
                        if w in _COMMON_WORDS_FOR_REVERSAL_CHECK)
        return doubled_reversed if _hits(doubled_reversed) > _hits(doubled) else doubled
    if doubled is not None:
        return doubled
    if doubled_reversed is not None:
        return doubled_reversed
    return _unreverse_line_if_needed(line)


def _split_double_page_text(page) -> list:
    """Returns [text] for a normal single-column page, or [left_text,
    right_text] for a double-wide page whose two logical halves need
    reconstructing independently (see extract_pdf_document's docstring
    on why plain extract_text() silently corrupts these). Both halves
    are attributed to the same physical page number by the caller -
    that's still correct provenance, since they really are on that one
    PDF page.

    Aspect ratio (width/height) is the detection signal: a genuine
    two-logical-pages-per-sheet layout is landscape and roughly double a
    normal portrait page's proportions (confirmed on a real filing at
    1417x850 - almost exactly 2x a standard 708x850 portrait half). A
    merely-wide-but-still-single-content landscape page (a wide table,
    a chart) would need a much higher threshold to false-positive on,
    so 1.4 leaves comfortable room above normal portrait (~0.77) and
    normal landscape (~1.3) aspect ratios without also catching this
    genuinely-two-page layout's 1.67.
    """
    width, height = page.width, page.height
    if height == 0 or width / height < 1.4:
        return [page.extract_text() or '']
    words = page.extract_words()
    if not words:
        return [page.extract_text() or '']
    midpoint = width / 2
    left_words = [w for w in words if w['x0'] < midpoint]
    right_words = [w for w in words if w['x0'] >= midpoint]
    if not left_words or not right_words:
        # words all fell on one side (e.g. a full-width table spanning
        # the midpoint) - this isn't actually a two-page layout, don't
        # force a split that would just cut a real table in half
        return [page.extract_text() or '']

    def _reconstruct(ws):
        ws = sorted(ws, key=lambda w: (round(w['top'] / 3), w['x0']))
        lines = []
        cur_top = None
        cur_line = []
        for w in ws:
            if cur_top is None or abs(w['top'] - cur_top) < 3:
                cur_line.append(w)
                cur_top = w['top'] if cur_top is None else cur_top
            else:
                lines.append(' '.join(x['text'] for x in sorted(cur_line, key=lambda x: x['x0'])))
                cur_line = [w]
                cur_top = w['top']
        if cur_line:
            lines.append(' '.join(x['text'] for x in sorted(cur_line, key=lambda x: x['x0'])))
        return '\n'.join(lines)

    return [_reconstruct(left_words), _reconstruct(right_words)]


def _page_word_groups(page) -> list:
    """Same double-wide-sheet detection as _split_double_page_text above,
    but returns the raw word lists (dicts with x0/x1/top/text) per
    logical half instead of joined text - callers that need to reason
    about column positions (e.g. gap-based table reconstruction) can't
    use the joined-text version, which throws the x-positions away.

    Each word's own text is run through normalize_extracted_line() before
    being returned - pdfplumber's extract_words() can hand back an
    individual word already doubled-and-mirror-reversed (confirmed on a
    real filing: Equity Group Holdings' own Directors' Remuneration
    Report page, where extract_words() returned tokens like
    "))ddeeuunniittnnoocc((" for "(continued)" and "’’ssrroottcceerriiDD"
    for "Directors'" - not lines, individual words, already broken before
    any line-level text ever gets assembled). normalize_extracted_line()
    is a pure character-level pairwise-equality/mirror check, so it
    fixes a word this way regardless of language or whether it's a
    dictionary word - including a person's name, which an older comment
    on extract_director_remuneration (above) noted couldn't be reliably
    self-corrected without this: that was true before this fix existed,
    not after."""
    # A rotated vertical side-tab label ("Overview", "Sustainability", ...) is never real
    # table content in any filer - pdfplumber's extract_words() still returns these (its
    # vertical-text handling reads them top-to-bottom as ordinary "words"), and they land
    # far enough into a page's real column band to get mis-treated as a stray column/cell
    # ("SECURITY" from a wrapped "PENSION/ SOCIAL SECURITY" header, or a reversed-looking
    # word) rather than caught by normalize_extracted_line's mirror-repair, which only
    # fixes characters within a single already-identified upright word. Confirmed on a
    # real filing: Bamburi Cement Plc's 2025 Annual Report's rotated section tabs bleeding
    # into its own Directors' Remuneration Report page.
    width, height = page.width, page.height
    if height == 0 or width / height < 1.4:
        words = [w for w in page.extract_words() if w.get('upright', True)]
        for w in words:
            w['text'] = normalize_extracted_line(w['text'])
        return [words]
    words = [w for w in page.extract_words() if w.get('upright', True)]
    for w in words:
        w['text'] = normalize_extracted_line(w['text'])
    if not words:
        return [words]
    midpoint = width / 2
    left_words = [w for w in words if w['x0'] < midpoint]
    right_words = [w for w in words if w['x0'] >= midpoint]
    if not left_words or not right_words:
        return [words]
    return [left_words, right_words]


# ---------- DIRECTOR REMUNERATION (totals-only) ----------
#
# Deliberately scoped to ONE figure: the report's own printed grand total
# for director/executive remuneration for the period, taken only when the
# filing prints that total explicitly as its own row. Some filings (seen
# in the wild: NSE's own report) split remuneration across multiple
# tables/subtotals with no single printed grand total - reconstructing
# one there would mean deciding which subtotals to add, which is a
# judgement call this function deliberately does NOT make silently, since
# a wrong guess here would look just as authoritative as a real filed
# number. Those filings simply return no total - "not available", never
# a computed guess presented as if the company printed it.
#
# Also deliberately does NOT attempt per-director rows: names in this
# section come out individually letter-reversed on at least one real
# filing (Equity Group) in a way that doesn't reliably self-correct
# (foreign/Kenyan surnames aren't in any general English wordlist), so
# a per-director breakdown would risk showing a boardroom name garbled -
# worse than not showing it. The totals row's numbers are unaffected by
# that corruption either way (see _REMUNERATION_HEADING_RES below), so
# this is a purely lower-risk scope than the per-director table would be.
_REMUNERATION_HEADING_RES = [
    re.compile(p, re.IGNORECASE) for p in [
        r"directors?\W{0,3}remuneration\s+report",
        r"single\s+figure\s+remuneration",
    ]
]

# Some filings (confirmed on a real Equity Group filing) render this
# specific section's text with every word doubled-then-reversed by a
# pdfplumber-specific font/encoding quirk - "Directors' remuneration
# report" comes out as "’’ssrroottcceerriiDD ttrrooppeerr
# nnooiittaarreennuummeerr". pypdf reads the SAME page's text layer
# correctly (confirmed against that filing), so it's tried first here
# specifically for this section; pdfplumber is only a fallback for
# environments without pypdf installed, or pages pypdf can't read at all.
# (extract_pdf_document(), by contrast, has to use pdfplumber for the
# main statements because pypdf doesn't preserve table row structure -
# see that function's docstring - so this is a deliberate, narrow
# exception just for this section, not a wider reader swap.)
_TOTAL_ROW_LABEL_RE = re.compile(r"^\s*(?:grand\s+)?total\b", re.IGNORECASE)


def _normalize_currency_hint(raw: str) -> str:
    """'Kshs'/'Ksh'/'Shs' all mean KES - normalize to that. Previously
    did .replace('KSH','KES').replace('SHS','KES') on the upper-cased
    match, which left 'KSHS' (from 'Kshs') as 'KESS' - the first
    .replace only strips the 'KSH' prefix, and the trailing 'S' from
    the plural survives untouched. An explicit membership check avoids
    that partial-replace bug entirely."""
    up = raw.upper()
    if up in ('KSHS', 'KSH', 'SHS'):
        return 'KES'
    return up


def _looks_like_labeled_total_row(line: str) -> bool:
    """True if `line` starts with an explicit 'Total' / 'Grand Total'
    label followed by several numbers - e.g. 'GRAND TOTAL 39,165 54,510
    6,835 2,736 103,246' (confirmed on a real KCB filing). This is a
    STRONGER signal than the bare-numeric-row heuristic below - the
    filing is telling us directly which row is the total, so this is
    checked first and, when found, wins outright over any bare numeric
    row further down the page."""
    if not _TOTAL_ROW_LABEL_RE.search(line):
        return False
    numbers = [_parse_amount_token(t) for t in line.split()]
    return sum(1 for n in numbers if n is not None) >= 3


def _looks_like_all_numeric_row(line: str, min_numbers: int = 5) -> bool:
    """True if `line` is (almost) entirely numbers/dashes/currency
    punctuation - the shape of a table data row with no name attached,
    which on every real total row seen is exactly what's left once the
    row has no director name in it. min_numbers defaults to 5 (not just
    "more than one or two") specifically to avoid matching a table of
    contents' bare page numbers/ranges ("128", "129 - 132") as if they
    were a totals row - a real remuneration total row has one number per
    disclosed component (salary, fees, pension, bonus, ...) which is
    never fewer than about 5 columns on any real filing checked."""
    tokens = line.split()
    if not tokens:
        return False
    numeric_like = 0
    for t in tokens:
        stripped = t.strip(",-\u2013()")
        if stripped == '' or stripped == '-':
            numeric_like += 1
            continue
        if re.fullmatch(r"[\d,.\u2019']+", stripped):
            numeric_like += 1
    return numeric_like >= min_numbers and numeric_like == len(tokens)


def _parse_amount_token(tok: str):
    cleaned = re.sub(r"[^\d.]", "", tok)
    if not cleaned:
        return None
    try:
        return float(cleaned)
    except ValueError:
        return None


def extract_director_remuneration(pdf_bytes: bytes) -> dict | None:
    """Best-effort: the filing's OWN printed grand total for director/
    executive remuneration for its reporting period, from a "Directors'
    remuneration report" / "single figure remuneration" section.

    Returns {'total': float, 'currency_hint': str|None, 'page': int} or
    None if no such section, or no explicit total row within it, was
    found - callers should show that as "not available in this filing",
    never fall back to summing rows themselves (see module note above
    for why).
    """
    # Same pypdf-first / pdfplumber-fallback page text every other
    # extractor uses, computed once per PDF (see _pypdf_page_texts_cached).
    page_texts = _pypdf_or_pdfplumber_page_texts(pdf_bytes)

    heading_pages = []
    for pg, text in page_texts:
        lines = text.splitlines()
        for idx, line in enumerate(lines):
            if _HEADING_HAS_DIGIT_RE.search(line):
                continue  # e.g. a same-line TOC entry with a trailing page range
            if not any(rx.search(line) for rx in _REMUNERATION_HEADING_RES):
                continue
            # Guard against a TOC layout where the heading and its page
            # range are on separate lines (confirmed on a real filing:
            # "Directors' remuneration report" \n " 125 - 127") - if the
            # next non-empty line is just a bare number/page-range, this
            # is a contents entry, not the section itself.
            next_line = next((l for l in lines[idx + 1:idx + 2]), "")
            if re.fullmatch(r"\s*\d+\s*(-\s*\d+\s*)?", next_line):
                continue
            heading_pages.append(pg)
            break
    heading_pages = sorted(set(heading_pages))
    if not heading_pages:
        return None

    # Group heading hits into clusters of genuinely adjacent pages (the
    # real section) rather than treating every hit as its own independent
    # +3-page search - a passing mention of "Directors' remuneration
    # report" on an unrelated page (confirmed on a real KCB filing: an
    # auditor's-report sentence a few pages after the real table) must
    # NOT extend the scan into pages that have nothing to do with the
    # section, which is exactly how an earlier version of this function
    # picked up an unrelated statement-of-changes-in-equity row as if it
    # were the remuneration total. A gap of more than 1 page between
    # consecutive heading hits starts a new cluster.
    clusters = []
    current = [heading_pages[0]]
    for pg in heading_pages[1:]:
        if pg - current[-1] <= 1:
            current.append(pg)
        else:
            clusters.append(current)
            current = [pg]
    clusters.append(current)

    text_by_page = dict(page_texts)
    best = None
    for cluster in clusters:
        # Scan the cluster's own pages plus one page past the end, to
        # cover a table that starts right at the bottom of the heading
        # page and finishes just past it - not a wide, drift-prone
        # forward window from every individual hit.
        scan_pages = list(range(cluster[0], min(cluster[-1] + 1, len(page_texts)) + 1))

        # First, count labeled-total rows across the WHOLE cluster (not
        # just one page at a time) - a split-table filing (confirmed on
        # both a real NSE and a real KCB filing) prints a Non-Executive
        # Directors total on one page and a separate Executive Directors
        # total on the very next page, so a same-page-only check misses
        # that split. More than one labeled total anywhere in this
        # cluster means picking any single one of them would silently
        # under-report the real combined figure - exactly the ambiguity
        # this function declines to resolve on its own (see module note
        # above) - so the whole cluster yields no total rather than a
        # partial one.
        cluster_labeled_rows = []
        for pg in scan_pages:
            text = text_by_page.get(pg, "")
            if not text:
                continue
            for line in (l.strip() for l in text.splitlines() if l.strip()):
                if _looks_like_labeled_total_row(line):
                    cluster_labeled_rows.append((pg, line))
        if len(cluster_labeled_rows) > 1:
            continue
        if len(cluster_labeled_rows) == 1:
            pg, line = cluster_labeled_rows[0]
            lines = [l.strip() for l in text_by_page.get(pg, "").splitlines() if l.strip()]
            numbers = [_parse_amount_token(t) for t in line.split()]
            numbers = [n for n in numbers if n is not None]
            total_value = max(numbers)
            currency_hint = None
            idx_in_lines = lines.index(line)
            for j in range(max(0, idx_in_lines - 12), idx_in_lines):
                m = re.search(r"(Shs|KES|Kshs|USD|Ksh)\W*(?:\d|0{2,3})", lines[j], re.IGNORECASE)
                if m:
                    currency_hint = _normalize_currency_hint(m.group(1))
                    break
            best = {'total': total_value, 'currency_hint': currency_hint, 'page': pg}
            break

        # No labeled total row anywhere in this cluster - fall back to
        # the bare-numeric-row heuristic (see _looks_like_all_numeric_row's
        # docstring) on each page in the cluster.
        for pg in scan_pages:
            text = text_by_page.get(pg, "")
            if not text:
                continue
            lines = [l.strip() for l in text.splitlines() if l.strip()]
            for i in range(len(lines) - 1, -1, -1):
                if not _looks_like_all_numeric_row(lines[i]):
                    continue
                is_boundary = (i == len(lines) - 1) or not _looks_like_all_numeric_row(lines[i + 1])
                if not is_boundary:
                    continue
                # A subtotal (e.g. "all Non-Executive Directors" summed,
                # before the Executive Directors' own rows) has this exact
                # same shape - all-numeric, immediately followed by a
                # named row rather than another numeric row - so the
                # boundary check above alone can't tell a subtotal from
                # the real grand total (confirmed on a real NSE filing: a
                # NED subtotal is followed by two more named executive
                # rows, not narrative). Guard against that: if a
                # currency-unit row (e.g. "Kshs Kshs Kshs Kshs Kshs")
                # appears within the next few lines, the table is still
                # going - a real total row is always the LAST thing
                # before the table's closing narrative/footnote, with no
                # more currency-column marker after it.
                lookahead = lines[i + 1:i + 5]
                still_in_table = any(
                    re.fullmatch(r"(?:kshs|shs\W*000|kes)(?:\s*(?:kshs|shs\W*000|kes))*", l, re.IGNORECASE)
                    for l in lookahead
                )
                if still_in_table:
                    continue
                numbers = [_parse_amount_token(t) for t in lines[i].split()]
                numbers = [n for n in numbers if n is not None]
                if not numbers:
                    continue
                total_value = max(numbers)  # the Total column is always the largest figure in its own row
                currency_hint = None
                for j in range(max(0, i - 12), i):
                    m = re.search(r"(Shs|KES|Kshs|USD|Ksh)\W*\W*0{2,3}", lines[j], re.IGNORECASE)
                    if m:
                        currency_hint = _normalize_currency_hint(m.group(1))
                        break
                best = {'total': total_value, 'currency_hint': currency_hint, 'page': pg}
                break  # first (bottom-most) qualifying row on this page is the one we want
            if best:
                break
        if best:
            break
    return best


def parse_financials_pdf(pdf_bytes: bytes) -> dict:
    """Thin wrapper over extract_pdf_document() that returns just the
    parsed statements - kept for the __main__ smoke test below and any
    other caller that only needs statements, not page text. Callers that
    also need company/period detection (i.e. the upload route) should
    call extract_pdf_document() directly instead, so the PDF is only
    read once - see its docstring.
    """
    return {'statements': extract_pdf_document(pdf_bytes)['statements']}



# ---------- MARKET DATA / PRINCIPAL RISKS / MANAGEMENT GUIDANCE ----------
# Extraction for the Intelligence Report's Peer Comparison, Risk Analysis,
# and Outlook tabs. Each function returns None (or an empty list) when its
# section isn't found in a given filing - callers show that as "not
# disclosed in this filing", never fall back to a guessed figure.
#
# These target the layout of KCB's 2025 Integrated Report specifically
# (confirmed against the real filing during development). Report layout
# varies year to year and company to company - see extract_director_
# remuneration's heading-search pattern above for the general approach
# this should grow towards as more filing formats are added, once a
# standardized input format is settled on.

def _pypdf_or_pdfplumber_page_texts(pdf_bytes: bytes):
    """Shared page-text extraction: pypdf when it can open the file
    (computed once per PDF and reused - see _pypdf_page_texts_cached),
    else pdfplumber."""
    texts = _pypdf_page_texts_cached(pdf_bytes)
    if texts is not None:
        return texts
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        return [(i + 1, p.extract_text() or "") for i, p in enumerate(pdf.pages)]


def extract_market_data(pdf_bytes: bytes) -> dict | None:
    """Own-share market data from the filing's Investor Information /
    'KCB Share Information' table (share price, market cap, shareholder
    count, free float, shareholding by category), plus dividend-per-share
    and total shareholder return pulled from the statutory 'Report of the
    Directors > Dividend' section and the Outlook/Recap narrative. Every
    field is exactly what the filing prints - nothing here is derived or
    estimated. Returns None if none of this was found."""
    page_texts = _pypdf_or_pdfplumber_page_texts(pdf_bytes)
    result = {}
    # No trailing \s* here - it would swallow the separator before an
    # optional second (prior-year) number, leaving nothing for the outer
    # "\s+" between the two numbers to match against.
    num = r'(-?[\d,]+\.?\d*)%?'

    label_map = {
        r'Number of issued shares': 'shares_issued',
        # pypdf sometimes renders "Total" with a stray space after the
        # "T" (kerning/ligature artifact) - tolerate an optional space
        r'T\s?otal number of authorized shares': 'shares_authorized',
        r'Number of shareholders': 'shareholder_count',
        r'Free float': 'free_float_pct',
        r'End of period share price.*?\(Ksh\.?\)': 'share_price',
        r'Market capitali[sz]ation.*?\(Ksh\.?\s*billion\)': 'market_cap',
        r'Local Institutional Investors': 'local_institutional_pct',
        r'Local Individual Investors': 'local_individual_pct',
        r'Foreign Investors': 'foreign_investor_pct',
    }
    for pg, text in page_texts:
        if 'KCB Share Information' not in text and 'Investor Information' not in text:
            continue
        for line in text.splitlines():
            for pat, field in label_map.items():
                m = re.search(pat + r'\s+' + num + r'(?:\s+' + num + r')?', line)
                if m:
                    val = m.group(1)
                    prior = m.group(2) if m.lastindex and m.lastindex >= 2 else None
                    try:
                        result[field] = float(val.replace(',', ''))
                        if field == 'share_price' and prior:
                            result['prior_share_price'] = float(prior.replace(',', ''))
                        if field == 'shareholder_count' and prior:
                            result['prior_shareholder_count'] = float(prior.replace(',', ''))
                        result['page'] = pg
                    except ValueError:
                        pass

    # Dividend components - statutory "Report of the Directors > Dividend"
    # section. Column-wrapped text means the phrase and its number can be
    # separated by unrelated interleaved sentences from the neighbouring
    # column, so these use a wide non-greedy gap tolerance rather than
    # requiring the phrase to be contiguous.
    for pg, text in page_texts:
        if 'report of the directors' not in text.lower() or 'dividend' not in text.lower():
            continue
        blob = ' '.join(text.splitlines())
        found_any = False
        m = re.search(r'final dividend.{0,250}?of\s+K[Ss]hs?\.?\s*([\d.]+)\s*per\s*(?:ordinary\s*)?share', blob, re.I | re.S)
        if m:
            result['final_dividend_per_share'] = float(m.group(1)); found_any = True
        m = re.search(r'interim\s+dividend.{0,250}?of\s+K[Ss]hs?\.?\s*([\d.]+)\s*per\s*(?:ordinary\s*)?share', blob, re.I | re.S)
        if m:
            result['interim_dividend_per_share'] = float(m.group(1)); found_any = True
        m = re.search(r'special dividend of\s+K[Ss]hs?\.?\s*([\d.]+)\s*per\s*(?:ordinary\s*)?share', blob, re.I)
        if m:
            result['special_dividend_per_share'] = float(m.group(1)); found_any = True
        m = re.search(r'total dividends?\s+for\s+the\s+year\s+to\s+K[Ss]hs?\.?\s*([\d.]+)\s*per\s*(?:ordinary\s*)?share', blob, re.I)
        if m:
            result['dividend_per_share'] = float(m.group(1)); found_any = True
        if found_any:
            result['page'] = pg
            break
    if 'dividend_per_share' not in result:
        parts = [result.get('final_dividend_per_share'), result.get('interim_dividend_per_share'),
                  result.get('special_dividend_per_share')]
        parts = [p for p in parts if p is not None]
        if parts:
            # explicitly a sum of the filing's own printed components, not
            # a modeled/estimated total - only used when the filing itself
            # doesn't also print one combined figure
            result['dividend_per_share'] = round(sum(parts), 2)

    # Total shareholder return - only stored if the filing states the
    # number directly (never computed from share price + dividend here,
    # to avoid quietly disagreeing with the filing's own stated figure
    # if their methodology differs, e.g. compounding or timing basis).
    for pg, text in page_texts:
        m = re.search(r'total shareholder returns?\s+of\s+([\d.]+)%', text, re.I)
        if m:
            result['total_shareholder_return'] = float(m.group(1))
            break
        m = re.search(r'([\d.]+)%\s*\n?Total shareholder returns?\s+in\s+\d{4}', text, re.I)
        if m:
            result['total_shareholder_return'] = float(m.group(1))
            break

    return result if result else None


_GUIDANCE_METRICS = [
    'Non funded income ratio', 'Cost-to-income ratio', 'NPL ratio', 'Cost of risk',
    'Cost of funds', 'Net interest margin', 'Asset yield', 'Loan growth',
    'Deposit growth', 'Return on equity',
]
_GUIDANCE_HEADER_RE = re.compile(r'Key performance indicator\s+(\d{4})\s+performance\s+(\d{4})\s+guidance')
_GUIDANCE_ROW_RE = re.compile(r'(-?[\d.]+)%\*?\s+(-?[\d.]+)%\s*-\s*(-?[\d.]+)%\s*:?\s*(.*)')


def extract_management_guidance(pdf_bytes: bytes) -> list:
    """Forward-looking KPI guidance from the filing's own Outlook section
    table ('Key performance indicator | <year> performance | <next year>
    guidance'). guidance_low/guidance_high are the filing's own printed
    range - never a modeled projection. Returns [] if no such table is
    found (e.g. an interim or a filing without one)."""
    page_texts = _pypdf_or_pdfplumber_page_texts(pdf_bytes)
    result = []
    for pg, text in page_texts:
        header_m = _GUIDANCE_HEADER_RE.search(text)
        if not header_m:
            continue
        guidance_year = header_m.group(2)
        for order, line in enumerate(text.splitlines()):
            for metric in _GUIDANCE_METRICS:
                if not line.startswith(metric):
                    continue
                rest = line[len(metric):].strip()
                m = _GUIDANCE_ROW_RE.match(rest)
                if m:
                    result.append({
                        'metric_name': metric,
                        'guidance_period_label': f'FY{guidance_year}',
                        'current_value': float(m.group(1)),
                        'guidance_low': float(m.group(2)),
                        'guidance_high': float(m.group(3)),
                        'commentary': m.group(4).strip(),
                        'order_index': order,
                        'page': pg,
                    })
        if result:
            break
    return result


_ROMAN_HEADING_RE = re.compile(r'^(X{0,3}(?:IX|IV|V?I{0,3}))\.\s+(.+)$')
_KNOWN_RISK_CATEGORIES = {
    'Credit Risk', 'Capital Adequacy', 'Technology and Cybersecurity', 'Data Protection',
    'Market Risk', 'Operational Risk', 'Fraud Risk', 'Compliance Risk',
    'AML/CFT/CPF Compliance', 'Climate Risk', 'Strategic Risk', 'Conduct Risk',
    'Reputational Risk',
}


def _reconstruct_columns(page, header_footer_top_cutoff: float = 60):
    """Multi-column report pages (the 'Management of Principal Risks'
    section prints 2-4 risk write-ups side by side) interleave text
    line-by-line under plain extract_text(), scrambling one risk
    category's sentences with its neighbour's. This clusters words by
    x-position into column bands, then reconstructs each column's own
    text in correct top-to-bottom reading order."""
    words = page.extract_words()
    body_words = [w for w in words if w['top'] > header_footer_top_cutoff]
    if not body_words:
        return []
    xs = sorted(w['x0'] for w in body_words)
    groups = []
    cur = [xs[0]]
    for x in xs[1:]:
        if x - cur[-1] > 15:
            groups.append(cur)
            cur = [x]
        else:
            cur.append(x)
    groups.append(cur)
    bounds = sorted(set(round(min(g)) for g in groups))
    bounds.append(page.width + 1)
    merged = [bounds[0]]
    for b in bounds[1:]:
        if b - merged[-1] < 100:
            continue
        merged.append(b)
    bounds = merged

    col_words = {}
    for w in body_words:
        for i in range(len(bounds) - 1):
            if bounds[i] <= w['x0'] < bounds[i + 1]:
                col_words.setdefault(i, []).append(w)
                break

    columns = []
    for i in sorted(col_words.keys()):
        ws = sorted(col_words[i], key=lambda w: (round(w['top'] / 3), w['x0']))
        lines = []
        cur_top = None
        cur_line = []
        for w in ws:
            if cur_top is None or abs(w['top'] - cur_top) < 3:
                cur_line.append(w)
                cur_top = w['top'] if cur_top is None else cur_top
            else:
                lines.append(' '.join(x['text'] for x in sorted(cur_line, key=lambda x: x['x0'])))
                cur_line = [w]
                cur_top = w['top']
        if cur_line:
            lines.append(' '.join(x['text'] for x in sorted(cur_line, key=lambda x: x['x0'])))
        columns.append('\n'.join(lines))
    return columns


def extract_principal_risks(pdf_bytes: bytes) -> list:
    """The filing's own named, qualitative principal-risk categories
    (Credit Risk, Technology and Cybersecurity, Compliance Risk, Climate
    Risk, etc.) from its 'Management of Principal Risks' section, each
    with the company's own description and 'Our Mitigations' text -
    never a numeric score, since filed reports don't publish one for
    these categories. Returns [] if this section isn't found (e.g. it
    only matches the FY2025-style roman-numeral, multi-column layout
    confirmed during development - a different layout, like a two-column
    'Principal Risk | Mitigation Measures' table, returns [] rather than
    guessing at a mismatched structure)."""
    # Locate the section via the fast pypdf-based text pass first (~5x
    # faster than pdfplumber's per-page extract_text at this page count -
    # confirmed during development on a 138-page filing). pdfplumber is
    # only opened afterwards, and only for the narrow page range actually
    # needed, since its slower word-position data is what column
    # reconstruction below requires.
    page_texts = _pypdf_or_pdfplumber_page_texts(pdf_bytes)
    section_pages = [pg for pg, text in page_texts if 'management of principal risks' in text.lower()]
    if not section_pages:
        return []
    start_pg = section_pages[0]
    total_pages = len(page_texts)

    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        # scan the heading page plus a bounded run of following pages -
        # stop once two consecutive pages contribute no recognized
        # category, rather than scanning the whole document
        scan_range = range(start_pg, min(start_pg + 8, total_pages + 1))

        raw_entries = []
        for pg in scan_range:
            page = pdf.pages[pg - 1]
            cols = _reconstruct_columns(page)
            for col_text in cols:
                lines = col_text.splitlines()
                current = None
                for line in lines:
                    m = _ROMAN_HEADING_RE.match(line.strip())
                    if m and len(m.group(1)) <= 4:
                        if current:
                            raw_entries.append(current)
                        current = {'roman': m.group(1), 'category': m.group(2).strip(), 'lines': [], 'page': pg}
                    elif current is not None:
                        current['lines'].append(line)
                if current:
                    raw_entries.append(current)

        results = []
        seen_categories = set()
        for entry in raw_entries:
            category = entry['category'].rstrip('.')
            # only keep entries matching a real risk category name - this
            # is what filters out the section's own process-explanation
            # sub-headings ("I. Risk Identification, Assessment, and
            # Management") which also happen to use roman numerals
            if category not in _KNOWN_RISK_CATEGORIES:
                continue
            if category in seen_categories:
                continue
            seen_categories.add(category)
            full_text = '\n'.join(entry['lines']).replace('Ksh\n', '').strip()
            if 'Our Mitigations:' in full_text:
                description, mitigation = full_text.split('Our Mitigations:', 1)
            elif 'Mitigations:' in full_text:
                description, mitigation = full_text.split('Mitigations:', 1)
            else:
                description, mitigation = full_text, ''
            results.append({
                'category': category,
                'order_index': len(results),
                'description': re.sub(r'\s+', ' ', description).strip(),
                'mitigation': re.sub(r'\s+', ' ', mitigation).strip(),
                'page': entry['page'],
            })
        # A real "Management of Principal Risks" section discloses many
        # categories together, never just one or two - a low count here
        # means this filing uses a different layout (e.g. a two-column
        # "Principal Risk | Mitigation Measures" table) that this
        # roman-numeral/4-column parser doesn't understand, not that the
        # filing genuinely only disclosed a couple of risks. Returning a
        # partial list in that case would look like an accurate, complete
        # count when it isn't - so return [] and let the caller show
        # "not extracted from this filing" instead of a misleadingly
        # short real-looking list.
        if len(results) < 5:
            return []
        return results

if __name__ == "__main__":
    # Local smoke test with synthetic multi-statement text, to confirm the
    # section-tracking + extraction logic before ever touching a real PDF.
    sample_text = """
    STATEMENT OF COMPREHENSIVE INCOME
    Total operating income                          45,231,000   40,100,000
    Employee costs                                   (8,204,000)  (7,900,000)
    Depreciation                                     (3,102,000)  (2,850,000)
    Profit before tax                                15,900,000   13,200,000
    Income tax expense                               (2,995,500)  (2,500,000)
    Profit for the period                            12,904,500   10,700,000
    STATEMENT OF FINANCIAL POSITION
    Property, plant and equipment                    120,400,000  110,200,000
    Cash and cash equivalents                         45,000,000   38,000,000
    Total assets                                     512,400,000  480,100,000
    Trade and other payables                          22,100,000   19,800,000
    Total liabilities                               (410,100,000) (390,000,000)
    Total equity                                      102,300,000   90,100,000
    STATEMENT OF CASH FLOWS
    Net cash generated from operating activities       18,200,000   15,100,000
    Net cash used in investing activities              (9,400,000)  (8,200,000)
    NOTES TO THE FINANCIAL STATEMENTS
    1. Basis of preparation ...
    """
    result = parse_financials_text([(1, sample_text)])


def _num_or_none(s: str):
    s = s.strip()
    return None if s == '-' else float(s.replace(',', ''))


# ---------- Generic directors' remuneration table reconstruction ----------
#
# A filing's "Directors' Remuneration Report" is never one fixed shape -
# confirmed against 4 real NSE filers' own tables (KCB Group, Liberty
# Kenya Holdings, Equity Group Holdings, Absa Bank Kenya): column sets
# differ (KCB: Directors' Fees/Sitting Allowance/Other Allowances/
# Non-cash Benefit; Liberty: just Retainer Fees/Attendance Fees; Absa:
# Base Salary/Retirement Benefits/Other Employee Benefits/->subtotal/
# Cash Bonus/Deferred Bonus/->subtotal/->grand total, plus a SEPARATE
# Long-Term Incentive Plans table that rolls into a bigger "Total
# Emoluments" figure), and table structure differs too (KCB/Liberty
# split Non-Executive vs Executive into separate tables; Equity puts
# every director - executive and non-executive - in ONE combined table
# with executives flagged by an asterisk in the name column; Absa's
# non-executive side is a fee-rate schedule by committee/body rather
# than a per-director component breakdown at all). No fixed regex per
# company can cover this - instead we reconstruct whatever table is
# actually printed, generically, from word positions.
_REM_NUMERIC_CELL_RE = re.compile(r'^\(?-?[\d,]+(\.\d+)?\)?$')
_REM_DASH_RE = re.compile(r'^[-\u2013\u2014]$')
_REM_SECTION_HEADING_RE = re.compile(
    r'(?:(?:non-executive director|executive director)(?:s?)[^.]{0,90}?'
    r'(?:for the year ended|fees, allowances|remuneration for the year|remuneration \(continued\))'
    r'|\([ab]\)\s*(?:non-executive director|executive director)'
    r'|long-term incentive|share incentive|individual board member|amounts paid to individual)',
    re.I,
)
_REM_YEAR_RE = re.compile(r'(20\d{2})')
_REM_STOP_LINE_RE = re.compile(r'^(notes?:|by order|date:|statement of directors)', re.I)

# Some filings' Directors' Remuneration Report table (confirmed: Equity
# Group Holdings, every year checked) defeats pdfplumber's word-position
# extraction - _page_word_groups above ends up with names AND figures
# with every character in mirror-reversed order ("latoT" for "Total",
# "168,421" for "124,861"), because the table's own PDF content stream
# draws this specific block through a transform pdfplumber's word
# grouping doesn't handle. pypdf's extract_text() (used for
# _pypdf_or_pdfplumber_page_texts below) reads the very same table
# completely cleanly, plain names and numbers in the right order,
# confirmed across all 3 fiscal years checked - so rather than trying to
# repair pdfplumber's broken word list, the page-range AND the row
# parsing both use that clean pypdf text directly for this table (see
# _parse_remuneration_rows_from_plain_text below), skipping pdfplumber's
# word extraction for it entirely.
#
# This same forward-word set also replaces the old, much looser
# 'remuneration report' substring search for locating the section: that
# search matches a Table of Contents entry, an AGM proxy resolution, or
# an auditor's-report sentence that merely name-drops the report - all
# of which can sit hundreds of pages from the real table and, taken via
# min()/max(), were silently expanding the scan window to the ENTIRE
# document on a real 286-page filing. Deliberately a narrow set of 5
# column-header words (Salary, Fees, Pension, Bonus, Gratuity) - "Total"
# and "Expense" alone are common enough to coincidentally appear
# elsewhere (confirmed: a bank's own retail-loan-product page lists
# "Salary" and "Bonus" advance loans; an unrelated insurance note uses
# "Total" and "Expense" repeatedly) - requiring all 5 together, on one
# page, is specific enough to only ever match the real table.
_REM_REVERSED_HEADER_HINTS = {'salary', 'fees', 'pension', 'bonus', 'gratuity'}


_REM_UNIT_ONLY_RE = re.compile(r"^k?shs?\.?\s*'?\u2018?\u2019?000\u2018?\u2019?'?$", re.I)


def _cell_kind(cell: str) -> str:
    c = cell.strip()
    if _REM_DASH_RE.match(c):
        return 'dash'
    if _REM_NUMERIC_CELL_RE.match(c.replace(' ', '')):
        return 'number'
    return 'text'


def _row_numeric_ratio(cells: list) -> float:
    rest = [t for t, _x0, _x1 in cells[1:]]
    if not rest:
        return 0.0
    hits = sum(1 for c in rest if _cell_kind(c) in ('number', 'dash'))
    return hits / len(rest)


def _reconstruct_cells_by_gap(words: list, gap_threshold: float = 8.0) -> list:
    """Cluster words into visual lines by y-position, then split each
    line into cells wherever the horizontal gap between adjacent words
    exceeds gap_threshold. This reconstructs a whitespace/column-aligned
    table's rows without needing pdfplumber's line-drawing-based table
    detector - confirmed necessary on a real filing (KCB) where running
    pdfplumber's own table finder against the header banner's corrupted
    doubled-letter text produced garbage column splits, while this
    simpler column-gap approach cleanly reconstructed every row of both
    the Non-Executive and Executive remuneration tables, headers
    included.

    Returns a list of cell-lists, top-to-bottom; each cell is (text,
    x0, x1) so callers can bucket a multi-line wrapped column header
    (e.g. "Sitting" on one line, "allowance" on the line below it, both
    belonging to the same column as a data row's "Sitting Allowance"
    figures) against a real data row's column positions rather than
    guessing from cell order alone, and can also detect a single header
    word that visually spans two data columns (e.g. "Bonus" printed
    once, centered above both a "Cash" and a "Deferred" column beneath
    it - confirmed on a real filing) using its full x0-x1 width rather
    than just its start position."""
    if not words:
        return []
    words = sorted(words, key=lambda w: (round(w['top'] / 3), w['x0']))
    lines, cur, cur_top = [], [], None
    for w in words:
        if cur_top is None or abs(w['top'] - cur_top) < 3:
            cur.append(w)
            cur_top = w['top'] if cur_top is None else cur_top
        else:
            lines.append(cur)
            cur, cur_top = [w], w['top']
    if cur:
        lines.append(cur)
    out = []
    for line in lines:
        line_sorted = sorted(line, key=lambda w: w['x0'])
        cells = []
        cur_cell = [line_sorted[0]['text']]
        cur_x0, cur_x1 = line_sorted[0]['x0'], line_sorted[0]['x1']
        for w in line_sorted[1:]:
            if w['x0'] - cur_x1 > gap_threshold:
                cells.append((' '.join(cur_cell), cur_x0, cur_x1))
                cur_cell, cur_x0, cur_x1 = [w['text']], w['x0'], w['x1']
            else:
                cur_cell.append(w['text'])
                cur_x1 = w['x1']
        cells.append((' '.join(cur_cell), cur_x0, cur_x1))
        out.append(cells)
    return out


def _bucket_by_column(cells: list, ref_x0s: list) -> list:
    """Assign each (text, x0, x1) cell to whichever reference column x0
    it's closest to (by start position), joining multiple cells landing
    in the same bucket top-to-bottom. Used to align a DATA row's cells
    to reference columns when its cell count doesn't exactly match
    (e.g. a run of dashes for zero/not-applicable that still needs to
    land in the right column) - a value belongs to exactly one column,
    so nearest-start-position is the right rule here (contrast with
    _bucket_header_by_column below, which a header word can span).
    Returns a list the same length as ref_x0s."""
    out = [''] * len(ref_x0s)
    for text, x0, _x1 in cells:
        idx = min(range(len(ref_x0s)), key=lambda i: abs(ref_x0s[i] - x0))
        out[idx] = f'{out[idx]} {text}'.strip() if out[idx] else text
    return out


def _bucket_header_by_column(cells: list, ref_x0s: list) -> list:
    """Like _bucket_by_column, but for HEADER cells: a header word can
    visually span more than one data column (e.g. "Bonus" printed once,
    centered above both a "Cash" and a "Deferred" column beneath it -
    confirmed on a real filing), so this assigns a cell to every
    reference column whose own x-position actually falls within that
    cell's x0-x1 span (plus a little padding for text-vs-number
    alignment slop), not just the single nearest one. A boundary-
    midpoint version of this over-triggered on a second real filing
    with tighter column spacing, where an ordinary single-column header
    like "Directors' fees" is simply wider than its own numeric column
    and was wrongly duplicated into its neighbour - requiring the
    neighbour's own x-position to be truly inside the header's span
    (not just past a shared midpoint) avoids that false duplication
    while still catching a genuinely spanning word like "Bonus".
    Returns a list the same length as ref_x0s."""
    out = [''] * len(ref_x0s)
    for text, x0, x1 in cells:
        pad = max((x1 - x0) * 0.15, 3)
        matched = [i for i, rx in enumerate(ref_x0s) if x0 - pad <= rx <= x1 + pad]
        if not matched:
            matched = [min(range(len(ref_x0s)), key=lambda i: abs(ref_x0s[i] - x0))]
        for idx in matched:
            out[idx] = f'{out[idx]} {text}'.strip() if out[idx] else text
    return out


def _parse_remuneration_table(cell_lines: list, start_idx: int = 0) -> tuple:
    """Scan cell_lines (from _reconstruct_cells_by_gap, so cells are
    (text, x0, x1) tuples) starting at start_idx for one table: the
    first data-shaped row (a text label followed by mostly
    numbers/dashes, OR a lone-text line immediately followed by an
    all-numeric line - confirmed on a real filing: "Dr. Joseph Kinyua"
    prints alone, then its row of figures on the next line), then
    walks BACKWARD from there to find the nearest preceding text-heavy
    line(s) to serve as the header, bucketing every header-block
    line's cells against that first data row's own column x-positions
    (handles a header wrapped across several stacked lines, including
    one word spanning two columns - see _bucket_header_by_column).
    Skips a units-only header line (e.g. "Ksh '000'" repeated per
    column) so it doesn't clutter the real component labels.

    Returns (table_dict_or_None, next_idx) so callers can keep scanning
    for further tables (e.g. a second Long-Term Incentive Plans table
    further down the same page) after this one ends. table_dict is
    {'headers': [...], 'rows': [{'label','values','is_total_row'}]}."""
    n = len(cell_lines)
    i = start_idx
    data_start = None
    while i < n:
        cells = cell_lines[i]
        if len(cells) >= 2 and _row_numeric_ratio(cells) >= 0.5:
            data_start = i
            break
        if len(cells) == 1 and _cell_kind(cells[0][0]) == 'text':
            if i + 1 < n and len(cell_lines[i + 1]) >= 1 and _row_numeric_ratio(cell_lines[i + 1]) >= 0.5:
                data_start = i
                break
        i += 1
    if data_start is None:
        return None, n

    ref_row = cell_lines[data_start]
    if len(ref_row) < 2:
        # the wrapped-name case: data_start is the lone name, real
        # column positions come from the very next (all-numeric) line
        ref_row = [ref_row[0]] + list(cell_lines[data_start + 1])
    ref_x0s = [x0 for _t, x0, _x1 in ref_row[1:]]
    if not ref_x0s:
        return None, n

    # Walk backward collecting every header-block line, INCLUDING short
    # single-word lines that are really a wrapped/merged column header
    # (e.g. "Bonus" printed on its own line, spanning above two data
    # columns "Cash" and "Deferred" beneath it - confirmed on a real
    # filing) - only a genuine section/document heading line stops the
    # scan, not mere shortness.
    header_lines = []
    k = data_start - 1
    while k >= start_idx and len(header_lines) < 6:
        cells = cell_lines[k]
        if not cells:
            k -= 1
            continue
        joined = ' '.join(t for t, _x0, _x1 in cells)
        if _REM_SECTION_HEADING_RE.search(joined) or re.match(r'^\s*(?:i|ii|iii|iv|v)\.\s', joined, re.I):
            break
        if _row_numeric_ratio(cells) > 0.3:
            break
        header_lines.insert(0, cells)
        k -= 1
    if not header_lines:
        return None, n

    # A header cell is only real column-header text if it sits to the
    # right of the midpoint between the row-label column and the first
    # value column - anything left of that midpoint (e.g. "Director's
    # Name"/"Capacity") is the row-label column's own header and must
    # not get bucketed into column 1's label. A plain half-inter-column
    # margin is too tight here: a text header like "Directors' fees"
    # legitimately starts well left of its own numeric column (longer
    # left-aligned label vs a narrow right-aligned number) - confirmed
    # on a real filing where that under-cut the real first column's
    # header. Also drops a bare units marker ("Ksh '000'", "Shs")
    # repeated per column - confirmed as noise on the same filing.
    label_x0 = ref_row[0][1]
    label_cutoff = (label_x0 + ref_x0s[0]) / 2
    headers = [''] * len(ref_x0s)
    for line in header_lines:
        filtered = [(t, x0, x1) for t, x0, x1 in line
                    if x0 >= label_cutoff and not _REM_UNIT_ONLY_RE.match(t.strip())]
        if not filtered:
            continue
        bucketed = _bucket_header_by_column(filtered, ref_x0s)
        for idx, text in enumerate(bucketed):
            if text:
                headers[idx] = f'{headers[idx]} {text}'.strip() if headers[idx] else text
    if not any(headers):
        return None, n

    rows = []
    pending_label = None
    j = data_start
    while j < n:
        cells = cell_lines[j]
        if len(cells) == 1:
            text = cells[0][0].strip()
            if not text:
                j += 1
                continue
            if _REM_STOP_LINE_RE.match(text):
                break
            if _cell_kind(text) == 'text':
                # A lone text line here is ambiguous between two real,
                # opposite wrap directions seen on real filings:
                # (a) the row-label wraps BEFORE its data ("Dr. Joseph
                #     Kinyua" alone, then its figures next line) - the
                #     existing pending_label mechanism below already
                #     handles this correctly.
                # (b) the row-label wraps AFTER its data - the name's
                #     first line prints WITH its full row of figures,
                #     and only a trailing surname/middle-name wraps
                #     onto its own line afterward (confirmed on a real
                #     filing: "Dr. Joseph | - | 600 | ... | 600" then
                #     "Kimemia" alone; "Amb. Harry | ..." then "Mutuma"
                #     then "Kathurima", two wrapped lines in a row).
                # Case (b) is distinguished from a genuine annotation
                # line ("(Committee chairperson)", "Notes:") by: it
                # immediately follows an already-completed row, it has
                # no parenthesis/colon, and it's short - a real second
                # name/surname fragment, not a sentence. When it
                # matches, append it to the PREVIOUS row's label
                # in-place (not pending_label, which is for the
                # opposite/forward case) and keep scanning, since a
                # name can wrap across more than one trailing line
                # (Mutuma, then Kathurima).
                looks_like_name_continuation = (
                    rows and pending_label is None
                    and '(' not in text and ':' not in text
                    and len(text) <= 30
                    and not _REM_STOP_LINE_RE.match(text)
                )
                if looks_like_name_continuation:
                    rows[-1]['label'] = re.sub(r'\s+', ' ', f"{rows[-1]['label']} {text}").strip()
                    j += 1
                    continue
                pending_label = text
                j += 1
                continue
            break
        ratio = _row_numeric_ratio(cells)
        if ratio < 0.4 and pending_label is None:
            break
        if pending_label is not None and _cell_kind(cells[0][0]) in ('number', 'dash'):
            label = pending_label
            value_cells = cells
        else:
            label = cells[0][0].strip()
            value_cells = cells[1:]
        pending_label = None
        if not label:
            j += 1
            continue
        bucketed = _bucket_by_column(value_cells, ref_x0s)
        values = {}
        for h, v in zip(headers, bucketed):
            if not h:
                continue
            v = v.strip()
            if not v or _cell_kind(v) == 'dash':
                values[h] = None
            elif _cell_kind(v) == 'number':
                values[h] = _num_or_none(v.replace(' ', ''))
        if not values:
            j += 1
            continue
        rows.append({
            'label': re.sub(r'\s+', ' ', label).strip(),
            'values': values,
            'is_total_row': bool(re.search(r'\btotal\b', label, re.I)),
        })
        j += 1
    if not rows:
        return None, data_start
    return {'headers': [h for h in headers if h], 'rows': rows}, j


def _classify_remuneration_kind(heading_text: str) -> str:
    t = heading_text.lower()
    if 'long-term incentive' in t or 'share incentive' in t:
        return 'ltip'
    if 'individual board member' in t or 'amounts paid to individual' in t:
        return 'ned_named_totals'
    if 'non-executive' in t:
        return 'non_executive'
    if 'executive director' in t:
        return 'executive'
    if re.search(r'\bchairman\b', t) and re.search(r'\bmember\b', t):
        return 'fee_schedule'
    return 'unknown'


_REM_NAME_LINE_RE = re.compile(
    r"^(?P<name>(?:Mr|Mrs|Ms|Dr|Prof)\.?\s*[A-Za-z][A-Za-z.'\u2019\-]*(?:\s+[A-Za-z][A-Za-z.'\u2019\-]*){0,5}\*?)\s+"
    r"(?P<values>(?:-|\(?\d[\d,]*\)?)(?:\s+(?:-|\(?\d[\d,]*\)?)){1,9})\s*$"
)
_REM_ANON_TOTAL_ROW_RE = re.compile(
    r"^(?P<values>(?:-|\(?\d[\d,]*\)?)(?:\s+(?:-|\(?\d[\d,]*\)?)){2,9})\s*$"
)
_REM_YEAR_LINE_RE = re.compile(r'year\s+ended.{0,30}?(20\d{2})', re.I | re.DOTALL)


def _parse_remuneration_rows_from_plain_text(text: str) -> list:
    """Parses director remuneration rows straight from pypdf's plain
    text, for a table whose pdfplumber word-position extraction is
    broken (see _REM_REVERSED_HEADER_HINTS above) - deliberately NOT
    reusing _parse_remuneration_table's word-position machinery, since
    there are no usable word positions to reconstruct from here, only
    plain text lines that already read correctly top to bottom.

    Column order/wording varies by year (confirmed: 2025's header has
    "...Gratuity Expense allowances Leave pay...", 2024/2022 have
    "...Other allowances Gratuity Leave pay..." - Gratuity and the
    "allowances" column swap places), so rather than assume one fixed
    order, each row's own value tokens are kept positionally
    (value_1, value_2, ...) with 'Total' aliased onto the last token -
    Total is always the rightmost column and always printed, even on
    a row that's one token short of the rest (confirmed on a real
    filing - Prof. Isaac Macharia's own row), so this is never
    ambiguous even without a full header mapping.

    A bare numeric line (no name) this far down the table is the
    filing's own printed grand-total row - confirmed on a real filing,
    where the total row prints with no label at all, just the summed
    columns - and is returned with is_total_row=True.

    Returns a list of {'label', 'is_total_row', 'values', 'year'}
    dicts; 'year' is the fiscal year taken from this page's own
    "Year ended 31 December <YYYY>" line, since one page is sometimes
    the prior-year comparative table on its own (confirmed: Equity
    Group's 2024 filing prints FY2024 and FY2023 as two separate
    full-page tables, not one table with two year columns)."""
    year = None
    year_m = _REM_YEAR_LINE_RE.search(text)
    if year_m:
        year = year_m.group(1)
    rows = []
    for raw_line in text.split('\n'):
        line = raw_line.strip()
        if not line:
            continue
        line = re.sub(r'^(Mr|Mrs|Ms|Dr|Prof)\s+\.\s*', r'\1. ', line)
        m = _REM_NAME_LINE_RE.match(line)
        if m:
            name = m.group('name').strip()
            tokens = m.group('values').split()
            is_total_row = bool(re.match(r'^(total|grand total)\b', name, re.I))
        else:
            m2 = _REM_ANON_TOTAL_ROW_RE.match(line)
            if not m2:
                continue
            name = 'Total'
            tokens = m2.group('values').split()
            is_total_row = True
        values = {f'value_{i + 1}': t for i, t in enumerate(tokens)}
        values['Total'] = tokens[-1]
        rows.append({'label': name, 'is_total_row': is_total_row, 'values': values, 'year': year})
    return rows


_JUNK_DIRECTOR_NAME_RE = re.compile(
    r"integrated\s+report|annual\s+report|financial\s+statements?|\b(?:plc|ltd|limited)\b|\bshs\b|\bkshs?\b|"
    r"date\s+of\s+appointment|type\s+of\s+contract|notice\s+period|remuneration\s+report", re.I)
_NAME_MARKER_TAIL_RE = re.compile(r"[\s*\u2020\u2021\u00a7\u00b9\u00b2\u00b3\u2070-\u2079#^]+$")
_NAME_STATUS_RE = re.compile(r"\s*[(,]\s*(?:resigned|retired|appointed|deceased|alternate|effective|until|from|w\.e\.f)[^)]*\)?\s*$", re.I)
_TOTAL_COMPONENT_RE = re.compile(r"\btotal\b", re.I)


def _coerce_amount(value):
    """A remuneration cell as a float: numbers pass through; "328,920" ->
    328920.0, "(1,234)" -> -1234.0, "-" / "" / text -> None. The raw extractor
    keeps cell text as printed for some layouts (Equity Group 2024), and
    a string `total` cannot be stored in the Float column."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if not isinstance(value, str):
        return None
    t = value.strip().replace("\u00a0", " ")
    if not t or t in ("-", "\u2013", "\u2014", "nil", "Nil"):
        return None
    neg = t.startswith("(") and t.endswith(")")
    t = re.sub(r"[()\s,]", "", t)
    if t.startswith("-"):
        neg, t = True, t[1:]
    if not re.fullmatch(r"\d+(?:\.\d+)?", t):
        return None
    return -float(t) if neg else float(t)


def clean_director_detail_rows(rows: list, fiscal_year: int | None = None) -> list:
    """Validation pass over extract_director_remuneration_detail's raw rows.

    Confirmed on Absa Bank Kenya's four reports, the raw extractor returned:
      - the page footer saved as a director ("Absa Bank Kenya PLC 2025
        Integrated Report and Financial Statements", with the page
        number 127 as its "2024" pay),
      - year-only names ("2022", "2023") from the LTIP table,
      - a whole paragraph of the executives' contract table as one
        component key,
      - footnote asterisks left on names ("Patricia Ithau***"),
      - `total` empty on every row because the total column's header is
        year-suffixed ("Total Emoluments 2025 Shs"), and the printed
        final "Total" row flagged as a subtotal rather than the table's
        grand total,
      - no confidence on any row.
    Nothing here re-derives a figure: every kept number is exactly what
    the filing printed. Rows are only dropped, renamed (markers
    stripped), or have their `total` picked from a column the filing
    itself labelled "Total ...". Rows earn a confidence from whether the
    table reconciles to the filing's own printed Total row."""
    kept = []
    for row in rows or []:
        name = (row.get('director_name') or '').strip()
        comps = row.get('components') or {}
        if not name or re.fullmatch(r"(?:19|20)\d\d", name) or _JUNK_DIRECTOR_NAME_RE.search(name):
            continue
        if any(len(str(k)) > 70 for k in comps):       # a paragraph of table text, not a column header
            continue
        clean_name = _NAME_STATUS_RE.sub("", name)
        clean_name = _NAME_MARKER_TAIL_RE.sub("", clean_name).strip(" ,")
        clean_name = re.sub(r"\s*\(\s*\d{1,2}\s*\)\s*$", "", clean_name).strip(" ,")    # "Agnes Lutukai(3)" footnote number
        if not clean_name:
            continue
        r = dict(row)
        r['director_name'] = clean_name
        r['total'] = _coerce_amount(r.get('total'))
        is_total_name = bool(re.fullmatch(r"(?:grand\s+)?total(?:\s+.*)?", clean_name, re.I))
        numeric = [v for v in (_coerce_amount(x) for x in comps.values()) if v is not None]
        if not numeric and not is_total_name:
            continue                                     # nothing printed for this row
        if not is_total_name and len(clean_name.split()) > 6:
            continue                                     # a sentence, not a person
        # `total`: the column the FILING labels "Total ...", latest year first
        if r.get('total') is None and comps:
            best = None
            for k, v in comps.items():
                v = _coerce_amount(v)
                if v is None or not _TOTAL_COMPONENT_RE.search(str(k)):
                    continue
                ym = re.search(r"\b((?:19|20)\d\d)\b", str(k))
                year = int(ym.group(1)) if ym else 0
                if fiscal_year and year and year != fiscal_year:
                    continue
                if best is None or year > best[0]:
                    best = (year, v)
            if best is not None:
                r['total'] = best[1]
        # A person whose ONLY printed figure is a prior-year total (e.g. a
        # director who left during the year, shown just for comparison) has no
        # current-year remuneration to report - dropping the row keeps the
        # table reconcilable to the filing's own current-year Total row.
        if (not is_total_name and r.get('total') is None
                and any(_coerce_amount(v) is not None and _TOTAL_COMPONENT_RE.search(str(k)) for k, v in comps.items())):
            continue
        r['_is_total_name'] = is_total_name
        kept.append(r)

    # a printed final "Total" row is the table's own grand total
    groups = {}
    for r in kept:
        groups.setdefault((r.get('page'), r.get('table_kind')), []).append(r)
    for rows_in_group in groups.values():
        persons = [x for x in rows_in_group if not x['_is_total_name']]
        totals = [x for x in rows_in_group if x['_is_total_name']]
        for t in totals:
            if re.fullmatch(r"(?:grand\s+)?total", (t['director_name'] or '').strip(), re.I):
                t['is_grand_total'] = True
                t['is_total_row'] = False
        reconciles = False
        if totals and persons:
            printed = next((t.get('total') for t in totals if t.get('total') is not None), None)
            person_totals = [p.get('total') for p in persons]
            if printed is not None and all(v is not None for v in person_totals):
                reconciles = abs(sum(person_totals) - printed) <= max(1.0, len(persons))
        for x in rows_in_group:
            has_total = x.get('total') is not None
            if reconciles:
                x['confidence'] = 0.9
            elif has_total:
                x['confidence'] = 0.75
            else:
                x['confidence'] = 0.6
        # roles: a NED-only table means every named row in it is a non-executive
        for x in persons:
            if (x.get('role') in (None, 'unknown')) and x.get('table_kind') in ('ned_named_totals', 'non_executive'):
                x['role'] = 'non_executive'
    for i, r in enumerate(kept, 1):
        r.pop('_is_total_name', None)
        r['order_index'] = i
    return kept


def _is_pay_row_name(row: dict) -> bool:
    """A named pay row must be a person or a role (2+ words); a filing's own printed total rows are kept as-is.
    2026-09-28: Kenya Airways' AGM vote table ("Against", "For", "Abstain", "397") and a column heading
    ("SECURITY" in Bamburi) were stored as directors' pay rows and then became register "directors"."""
    if row.get('is_total_row') or row.get('is_grand_total'):
        return True
    words = [w for w in re.findall(r"[A-Za-z][A-Za-z'\u2019.\-]+", str(row.get('director_name') or '')) if len(w.strip('.')) >= 2]
    return len(words) >= 2


def extract_director_remuneration_detail(pdf_bytes: bytes, target_period_label: str | None = None) -> list:
    """See _extract_director_remuneration_detail_raw for the extraction
    itself; this wrapper applies clean_director_detail_rows to its output
    so every caller gets validated rows."""
    raw = [r for r in _extract_director_remuneration_detail_raw(pdf_bytes, target_period_label) if _is_pay_row_name(r)]
    # Fallback (2026-09-28): the word-position extractor above finds nothing for several real filer layouts
    # (BOC, Liberty, Sameer, KPLC, Bamburi all print a per-director NED table it can't follow). When it found
    # no named non-executive row, try the plain-text table reader in pay_rows_text.py before giving up.
    if not any(r.get('role') == 'non_executive' and not r.get('is_total_row') for r in raw):
        try:
            from pay_rows_text import extract_ned_pay_rows_text
            text_rows = extract_ned_pay_rows_text(pdf_bytes, target_period_label=target_period_label)
        except Exception:
            text_rows = []
        if text_rows:
            raw = text_rows
    fy = None
    if target_period_label:
        m = re.search(r"((?:19|20)\d\d)", target_period_label)
        fy = int(m.group(1)) if m else None
    return clean_director_detail_rows(_drop_prior_year_tables(raw, pdf_bytes, fy), fy)


def _drop_prior_year_tables(rows: list, pdf_bytes: bytes, fiscal_year) -> list:
    """A remuneration report prints the current year's table and, right after it, the
    comparative table ("Year ended 31 December 2023") - Equity Group 2024 stored both, so
    its pay tab showed 22 rows (two full boards) against a 328,920 total. A group of rows
    (one page + table kind) whose page's "year ended <date> <year>" headings name only an
    OTHER year is dropped, but only when another group of rows IS headed with the fiscal
    year - so a report with a single table is never touched."""
    if not fiscal_year or not rows:
        return rows
    texts = dict(_pypdf_page_texts_cached(pdf_bytes) or [])
    def years_on(page):
        text = texts.get(page, '')
        heads = re.findall(r"year\s+ended\s+\d{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]+\s+((?:19|20)\d{2})(.{0,36})", text, re.I | re.S)
        # the intro sentence ("... for the year ended 31 December 2024 together with the comparative
        # figures") names the current year on BOTH tables' pages; a TABLE header is followed by its
        # column labels (Shs'000, Salary, Fees, Total ...), so only those headings decide
        table_heads = [y for y, tail in heads if re.search(r"shs|kshs|kes|ksh|salary|fees|total|notes|\bsh\b", tail, re.I)]
        return {int(y) for y in (table_heads or [h[0] for h in heads])}
    groups = {}
    for r in rows:
        groups.setdefault((r.get('page'), r.get('table_kind')), []).append(r)
    status = {}
    for key in groups:
        ys = years_on(key[0])
        status[key] = 'current' if fiscal_year in ys else ('prior' if ys else 'unknown')
    if 'current' not in status.values():
        return rows
    return [r for r in rows if status[(r.get('page'), r.get('table_kind'))] != 'prior']


def _extract_director_remuneration_detail_raw(pdf_bytes: bytes, target_period_label: str | None = None) -> list:
    """Every named director/role's own remuneration row(s) from the
    filing's "Directors' Remuneration Report", reconstructed generically
    from word positions rather than assumed against one fixed column
    set - see the module note above this function for the 4 real filer
    layouts this was built and tested against. Every figure is exactly
    what the filing prints (never summed or estimated by this app); a
    filing's own printed subtotal/total rows are kept as their own rows
    (is_total_row=True) rather than collapsed away.

    Returns a flat list of dicts, one per (person or total/subtotal
    row) per sub-table on the page:
      director_name, role ('executive'|'non_executive'|'unknown'),
      table_kind ('executive'|'non_executive'|'ltip'|'ned_named_totals'|
        'fee_schedule'|'unknown' - which of possibly several sub-tables
        this row came from, e.g. Absa's separate LTIP table),
      is_grand_total, is_total_row (a printed subtotal like Absa's
        "Total Fixed Remuneration", distinct from is_grand_total which
        is the table's own final GRAND TOTAL/Total row),
      components (dict, filing's own column headers as keys - NOT
        normalized to a fixed schema, since the columns themselves
        differ by filer), total (this row's own rightmost/"Total"-
        labelled figure if the columns include one, else None),
      fiscal_year, order_index, page.

    Executives are detected by table heading OR by an asterisk/footnote
    marker on the name (Equity Group's combined-table convention) -
    when detected only by marker, role is 'executive' but table_kind
    stays whatever the single combined table's kind was classified as.
    Returns [] if no remuneration table is found on any page (e.g. an
    interim filing, or a layout this parser doesn't recognize)."""
    page_texts = _pypdf_or_pdfplumber_page_texts(pdf_bytes)

    def _page_hint_count(text):
        words = {w.strip(' .,()*\u2018\u2019').lower() for w in text.split()}
        return len(words & _REM_REVERSED_HEADER_HINTS)

    reversed_table_pages = [pg for pg, text in page_texts
                             if _page_hint_count(text) == len(_REM_REVERSED_HEADER_HINTS)]
    if reversed_table_pages:
        # The real table's own signature was found directly on these
        # exact pages - parse them straight from this same (already
        # correct) plain text rather than routing through pdfplumber's
        # word-position extraction, which is what's actually broken
        # for this table (see _REM_REVERSED_HEADER_HINTS above and
        # _parse_remuneration_rows_from_plain_text below). This also
        # sidesteps the old substring search entirely, which is prone
        # to false positives far from the real section (a Table of
        # Contents entry, an AGM proxy resolution, a sentence in the
        # auditor's report that merely name-drops "remuneration
        # report") - confirmed on a real 286-page filing where
        # trusting min()/max() over every such match expanded the
        # scan window to the entire document.
        results = []
        order = 0
        page_text_by_num = dict(page_texts)
        for pg in reversed_table_pages:
            for row in _parse_remuneration_rows_from_plain_text(page_text_by_num[pg]):
                label = row['label']
                year = row['year']
                if target_period_label and year and f'FY{year}' != target_period_label:
                    continue
                is_exec_marked = bool(re.search(r'\*', label))
                role = 'executive' if is_exec_marked else 'non_executive' if not row['is_total_row'] else 'unknown'
                is_grand_total = row['is_total_row'] and bool(re.search(r'\btotal\b', label, re.I))
                results.append({
                    'director_name': label,
                    'role': role,
                    'table_kind': 'unknown',
                    'is_grand_total': is_grand_total,
                    'is_total_row': row['is_total_row'],
                    'total': row['values'].get('Total'),
                    'components': row['values'],
                    'fiscal_year': year,
                    'order_index': order,
                    'page': pg,
                })
                order += 1
        return results

    section_pages = [pg for pg, text in page_texts
                      if 'remuneration report' in text.lower()
                      and _REM_SECTION_HEADING_RE.search(text)]
    if not section_pages:
        return []
    start_pg, end_pg = min(section_pages), max(section_pages)

    results = []
    order = 0
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        for pg in range(start_pg, min(end_pg + 1, len(pdf.pages)) + 1):
            if pg < 1 or pg > len(pdf.pages):
                continue
            page = pdf.pages[pg - 1]
            for word_group in _page_word_groups(page):
                if not word_group:
                    continue
                cell_lines = _reconstruct_cells_by_gap(word_group)
                # Find every heading line in this half/page, so a page
                # with more than one sub-table (e.g. Absa's Executive
                # table immediately followed by its LTIP table) gets
                # each one classified and parsed separately. A roman-
                # numeral list marker ("I.", "iii.") sometimes lands in
                # its own cell ahead of the heading text proper -
                # confirmed on a real filing - so a heading line can be
                # 1-2 cells, not always exactly 1; join them before
                # matching so a lone "I." doesn't get misread as data.
                heading_positions = [i for i, cells in enumerate(cell_lines)
                                      if len(cells) <= 2
                                      and _REM_SECTION_HEADING_RE.search(' '.join(t for t, _x0, _x1 in cells))]
                if not heading_positions:
                    # No distinct heading line matched at all - some
                    # filers print no separate sub-table heading, just
                    # a combined table whose own first row doubles as
                    # both the "For the year ended <date>" label and
                    # the column headers in one fused row (confirmed
                    # on a real filing: Eaagads Limited's FY2025
                    # combined Executive+Non-Executive table has no
                    # heading line at all above the Salary/Fees/
                    # Bonuses row). Only fall back to treating the
                    # whole word_group as one unclassified ('unknown')
                    # table when it genuinely contains a data-shaped
                    # row (a name followed by mostly numeric/dash
                    # cells) - the same signal _parse_remuneration_table
                    # itself looks for - so this fallback never fires
                    # on an ordinary prose page that simply lacks a
                    # recognized heading.
                    has_data_row = any(
                        len(cells) >= 2 and _row_numeric_ratio(cells) >= 0.5
                        for cells in cell_lines
                    )
                    if not has_data_row:
                        continue
                    heading_positions = [0]
                for h_idx, h_pos in enumerate(heading_positions):
                    heading_text = ' '.join(t for t, _x0, _x1 in cell_lines[h_pos])
                    kind = _classify_remuneration_kind(heading_text)
                    year_m = _REM_YEAR_RE.search(heading_text)
                    year = year_m.group(1) if year_m else None
                    if target_period_label and year and f'FY{year}' != target_period_label:
                        continue
                    scan_end = heading_positions[h_idx + 1] if h_idx + 1 < len(heading_positions) else len(cell_lines)
                    table, _ = _parse_remuneration_table(cell_lines[h_pos + 1:scan_end])
                    if not table:
                        continue
                    total_header = next((h for h in table['headers'] if h.strip().lower() == 'total'), None)
                    for row in table['rows']:
                        label = row['label']
                        is_exec_marked = bool(re.search(r'\*', label)) and kind == 'unknown'
                        role = ('executive' if kind == 'executive' or is_exec_marked
                                else 'non_executive' if kind == 'non_executive'
                                else 'unknown')
                        is_grand_total = bool(re.search(r'\bgrand total\b', label, re.I))
                        results.append({
                            'director_name': label,
                            'role': role,
                            'table_kind': kind,
                            'is_grand_total': is_grand_total,
                            'is_total_row': row['is_total_row'],
                            'total': row['values'].get(total_header) if total_header else None,
                            'components': row['values'],
                            'fiscal_year': year,
                            'order_index': order,
                            'page': pg,
                        })
                        order += 1
    return results


# ---------- STANDARD CONDENSED FORMAT (v1) ----------
# A plain-text alternative to a raw PDF, purpose-built to sidestep every
# layout problem the PDF extractors above have to work around (double-wide
# pages, Group/Company column ordering, "Note" vs "Notes" wording, roman-
# numeral multi-column risk sections, etc.). See condensed_format/SPEC.md
# for the full grammar. One file per company per fiscal year;
# ===SECTION=== markers, "Label: value" or "Label: current, prior" lines,
# "#"-prefixed comments ignored.
#
# This is deliberately NOT reusing extract_pdf_document's heading-
# detection/column-splitting machinery - that machinery exists to cope
# with messy real-world PDF text; a condensed file has none of that
# messiness by construction, so a much simpler line-based parser is both
# sufficient and less likely to misfire on this format's own edge cases
# (e.g. a still-valid negative cash-flow number shouldn't trip the PDF
# parser's parenthesized-negative heuristics meant for OCR'd statement
# text).

_CONDENSED_SECTION_RE = re.compile(r'^===([A-Z_]+)===$')
_CONDENSED_FIELD_RE = re.compile(r'^([A-Za-z][A-Za-z]*)\s*:\s*(.*)$')
_CONDENSED_RISK_HEADING_RE = re.compile(r'^\[(.+?)\]$')
_CONDENSED_REM_HEADING_RE = re.compile(r'^\[(.+?)\]\s*Total\s*:\s*([\-\d.,]+)\s*(?:;\s*(.+))?$')
_CONDENSED_GUIDANCE_RE = re.compile(
    r'^([A-Za-z][A-Za-z0-9]*)\s*:\s*current\s*=\s*([\-\d.]+)\s*,\s*low\s*=\s*([\-\d.]+)\s*,\s*high\s*=\s*([\-\d.]+)'
    r'(?:\s*,\s*commentary\s*=\s*(.+))?\s*$'
)

# Field label (as written in the condensed file) -> this app's
# normalized_name, one dict per statement section. Kept separate from
# CANONICAL_LINE_ITEMS above (which matches free-form PDF text via
# regex) since condensed field labels are an exact, fixed vocabulary by
# design - a plain dict lookup is the right tool, not another regex table.
_CONDENSED_INCOME_FIELDS = {
    'Revenue': 'revenue', 'InterestIncome': 'interest_income', 'InterestExpense': 'interest_expense',
    'CostOfSales': 'cost_of_sales', 'GrossProfit': 'gross_profit', 'EmployeeCosts': 'employee_costs',
    'Depreciation': 'depreciation', 'Amortisation': 'amortisation', 'FinanceCosts': 'finance_costs',
    'OperatingProfit': 'operating_profit', 'ProfitBeforeTax': 'profit_before_tax',
    'TaxExpense': 'tax_expense', 'NetIncome': 'net_income', 'EPS': 'eps',
    'SharesOutstanding': 'shares_outstanding',
}
_CONDENSED_BALANCE_FIELDS = {
    'TotalAssets': 'total_assets', 'TotalLiabilities': 'total_liabilities', 'TotalEquity': 'total_equity',
    'CashAndEquivalents': 'cash_and_equivalents', 'Receivables': 'receivables', 'Payables': 'payables',
    'Inventory': 'inventory', 'CurrentAssets': 'current_assets', 'CurrentLiabilities': 'current_liabilities',
    'PPE': 'ppe', 'Borrowings': 'borrowings', 'ShareCapital': 'share_capital',
    'RetainedEarnings': 'retained_earnings',
}
_CONDENSED_CASHFLOW_FIELDS = {
    'OperatingCashFlow': 'operating_cash_flow', 'InvestingCashFlow': 'investing_cash_flow',
    'FinancingCashFlow': 'financing_cash_flow', 'CashEndOfPeriod': 'cash_end_of_period',
    'Capex': 'capex',
}
_CONDENSED_STATEMENT_SECTIONS = {
    'INCOME_STATEMENT': ('income_statement', _CONDENSED_INCOME_FIELDS),
    'BALANCE_SHEET': ('balance_sheet', _CONDENSED_BALANCE_FIELDS),
    'CASH_FLOW': ('cash_flow', _CONDENSED_CASHFLOW_FIELDS),
}
_CONDENSED_MARKET_DATA_FIELDS = {
    'SharePrice': ('share_price', 'prior_share_price'),
    'MarketCap': ('market_cap', None),
    'SharesIssued': ('shares_issued', None),
    'SharesAuthorized': ('shares_authorized', None),
    'ShareholderCount': ('shareholder_count', 'prior_shareholder_count'),
    'FreeFloatPct': ('free_float_pct', None),
    'DividendPerShare': ('dividend_per_share', None),
    'InterimDividendPerShare': ('interim_dividend_per_share', None),
    'FinalDividendPerShare': ('final_dividend_per_share', None),
    'SpecialDividendPerShare': ('special_dividend_per_share', None),
    'DividendYieldPct': ('dividend_yield', None),
    'TotalShareholderReturnPct': ('total_shareholder_return', None),
    'LocalInstitutionalPct': ('local_institutional_pct', None),
    'LocalIndividualPct': ('local_individual_pct', None),
    'ForeignInvestorPct': ('foreign_investor_pct', None),
}


def _condensed_parse_numbers(raw: str):
    """'349447.2, 310904.8' -> (349447.2, 310904.8); '4.25' -> (4.25, None).
    Returns (None, None) for an empty/unparseable value rather than
    raising, so one malformed line doesn't abort the whole file - the
    caller decides whether to skip that field."""
    raw = raw.strip()
    if not raw:
        return None, None
    parts = [p.strip() for p in raw.split(',')]
    try:
        first = float(parts[0].replace(',', '')) if parts[0] not in ('', '-') else None
    except ValueError:
        return None, None
    second = None
    if len(parts) > 1 and parts[1] not in ('', '-'):
        try:
            second = float(parts[1].replace(',', ''))
        except ValueError:
            second = None
    return first, second


def is_condensed_format(text: str) -> bool:
    """True if this looks like our own condensed format rather than raw
    PDF-extracted text - checked before falling back to the PDF pipeline,
    so a condensed .txt upload never gets mistakenly run through the
    much slower/fuzzier PDF statement parser."""
    return bool(re.search(r'^===COMPANY===\s*$', text, re.MULTILINE))


def parse_condensed_filing(text: str) -> dict:
    """Parse one standard condensed filing (see condensed_format/SPEC.md).
    Returns a dict with keys: company, period, statements (same shape
    parse_financials_text's 'statements' value has, so this can feed the
    exact same save path app.py already uses for PDF uploads),
    market_data, management_guidance, principal_risks,
    director_remuneration - each None/[] if that section was omitted,
    exactly mirroring how a real filing missing that disclosure behaves.
    Raises ValueError with a line number if the file is malformed enough
    that guessing would be worse than telling the person exactly what to
    fix."""
    lines = text.splitlines()
    sections: dict = {}
    current_section = None
    current_lines: list = []

    def flush():
        if current_section is not None:
            sections.setdefault(current_section, []).extend(current_lines)

    for line in lines:
        if line.strip().startswith('#') or not line.strip():
            continue
        m = _CONDENSED_SECTION_RE.match(line.strip())
        if m:
            flush()
            current_section = m.group(1)
            current_lines = []
            continue
        current_lines.append(line.rstrip())
    flush()

    if 'COMPANY' not in sections:
        raise ValueError('Missing required ===COMPANY=== section.')
    if 'PERIOD' not in sections:
        raise ValueError('Missing required ===PERIOD=== section.')

    def parse_fields(section_lines):
        out = {}
        for line in section_lines:
            m = _CONDENSED_FIELD_RE.match(line.strip())
            if m:
                out[m.group(1)] = m.group(2).strip()
        return out

    company_fields = parse_fields(sections.get('COMPANY', []))
    period_fields = parse_fields(sections.get('PERIOD', []))
    if not company_fields.get('Name'):
        raise ValueError('===COMPANY=== section is missing required field "Name".')
    if not period_fields.get('Label'):
        raise ValueError('===PERIOD=== section is missing required field "Label".')

    company = {
        'name': company_fields.get('Name'), 'ticker': company_fields.get('Ticker'),
        'sector': company_fields.get('Sector'), 'exchange': company_fields.get('Exchange'),
        'currency': company_fields.get('Currency'), 'unit': company_fields.get('Unit'),
    }
    period = {
        'label': period_fields.get('Label'), 'fiscal_year_end': period_fields.get('FiscalYearEnd'),
        'prior_label': period_fields.get('PriorLabel'),
    }

    statements = {}
    for section_name, (stmt_type, field_map) in _CONDENSED_STATEMENT_SECTIONS.items():
        if section_name not in sections:
            continue
        fields = parse_fields(sections[section_name])
        line_items = []
        for order, (condensed_label, value) in enumerate(fields.items()):
            normalized = field_map.get(condensed_label)
            if normalized is None:
                continue  # unrecognized field label in this section - skip rather than guess
            amount, prior_amount = _condensed_parse_numbers(value)
            if amount is None:
                continue
            line_items.append({
                'label': condensed_label, 'normalized_name': normalized,
                'amount': amount, 'prior_amount': prior_amount,
                'page': None, 'confidence': 1.0,  # condensed file's own stated figure - not a parser guess
                'order_index': order,
            })
        if line_items:
            statements[stmt_type] = {'line_items': line_items}

    market_data = None
    if 'MARKET_DATA' in sections:
        fields = parse_fields(sections['MARKET_DATA'])
        md = {}
        for condensed_label, (field_name, prior_field_name) in _CONDENSED_MARKET_DATA_FIELDS.items():
            if condensed_label not in fields:
                continue
            amount, prior = _condensed_parse_numbers(fields[condensed_label])
            if amount is not None:
                md[field_name] = amount
            if prior is not None and prior_field_name:
                md[prior_field_name] = prior
        market_data = md if md else None

    management_guidance = []
    if 'MANAGEMENT_GUIDANCE' in sections:
        guidance_period_label = None
        order = 0
        for line in sections['MANAGEMENT_GUIDANCE']:
            stripped = line.strip()
            gp = _CONDENSED_FIELD_RE.match(stripped)
            if gp and gp.group(1) == 'GuidancePeriod':
                guidance_period_label = gp.group(2).strip()
                continue
            m = _CONDENSED_GUIDANCE_RE.match(stripped)
            if not m:
                continue
            metric_name, current, low, high, commentary = m.groups()
            management_guidance.append({
                'metric_name': metric_name, 'guidance_period_label': guidance_period_label,
                'current_value': float(current), 'guidance_low': float(low), 'guidance_high': float(high),
                'commentary': commentary.strip() if commentary else None, 'order_index': order, 'page': None,
            })
            order += 1

    principal_risks = []
    if 'PRINCIPAL_RISKS' in sections:
        current = None
        for order, line in enumerate(sections['PRINCIPAL_RISKS']):
            m = _CONDENSED_RISK_HEADING_RE.match(line.strip())
            if m:
                if current:
                    principal_risks.append(current)
                current = {'category': m.group(1).strip(), 'description': '', 'mitigation': '',
                           'order_index': len(principal_risks), 'page': None}
                continue
            if current is None:
                continue
            fm = _CONDENSED_FIELD_RE.match(line.strip())
            if fm and fm.group(1) in ('Description', 'Mitigation'):
                current[fm.group(1).lower()] = fm.group(2).strip()
        if current:
            principal_risks.append(current)

    director_remuneration = []
    if 'DIRECTOR_REMUNERATION' in sections:
        for order, line in enumerate(sections['DIRECTOR_REMUNERATION']):
            m = _CONDENSED_REM_HEADING_RE.match(line.strip())
            if not m:
                continue
            name_and_role, total_str, components_str = m.groups()
            role = 'non_executive'
            director_name = name_and_role.strip()
            if ',' in name_and_role:
                name_part, role_part = name_and_role.rsplit(',', 1)
                director_name = name_part.strip()
                role = 'executive' if 'executive' in role_part.lower() and 'non' not in role_part.lower() else 'non_executive'
            try:
                total = float(total_str.strip().replace(',', ''))
            except ValueError:
                continue
            # Optional breakdown after a ";" on the same line - e.g.
            # "Fees=141157, Salaries=259203, Bonuses=77033, Non-cash
            # benefits=5853" - so a condensed file can still carry the
            # filing's own component breakdown (as the real PDF path's
            # extract_director_remuneration_detail does) instead of
            # collapsing straight to just the total. Optional and
            # order-preserving (a plain dict, insertion order matches
            # the file) - a file with no ";" breakdown still parses
            # exactly as before, so this is fully backward compatible.
            components = None
            if components_str:
                components = {}
                for part in components_str.split(','):
                    if '=' not in part:
                        continue
                    key, val = part.split('=', 1)
                    key = key.strip()
                    try:
                        components[key] = float(val.strip().replace(',', ''))
                    except ValueError:
                        continue
                if not components:
                    components = None
            director_remuneration.append({
                'director_name': director_name, 'role': role,
                # table_kind drives which labelled sub-table (e.g.
                # "Non-Executive Directors' Fees" vs "Executive
                # Directors' Remuneration") the UI groups this row
                # into - see KIND_LABEL/KIND_ORDER in the remuneration
                # tab. role is already 'executive'/'non_executive' here
                # so it doubles directly as table_kind; leaving this
                # unset (as before) left every row's table_kind at the
                # DB column's None default, which the UI treats as
                # 'unknown' and dumps into one undifferentiated table.
                'table_kind': role,
                'is_grand_total': 'GRAND TOTAL' in director_name.upper(),
                'total': total, 'components': components, 'order_index': order, 'page': None,
            })

    return {
        'company': company, 'period': period, 'statements': statements,
        'market_data': market_data, 'management_guidance': management_guidance,
        'principal_risks': principal_risks, 'director_remuneration': director_remuneration,
    }

# ---------- Survey Directors' Register extraction ----------
# Feeds SurveyDirector (models_survey.py), NOT DirectorRemunerationRow.
# Deliberately narrow for its first version: only the clean
# "Name / Designation" corporate-information list pattern (see a real
# example on Eaagads Limited's FY2025 filing, page 4 of the PDF) is
# supported. Two other real layouts exist in the wild - a numbered
# photo-caption grid split across "Standing L-R"/"Seated L-R" groups
# (seen on KCB Group Plc's 2025 Integrated Report), and two-column
# narrative director bios with Age/Nationality/Appointed lines - and
# BOTH are deliberately left unsupported for now rather than risking a
# wrong parse: the photo-caption grid's numbering resets per group
# (not a clean 1..N run) and often includes non-director roles (a
# Company Secretary numbered alongside directors), and the narrative
# bio pages garble badly under column-splitting when two directors'
# bios sit side by side on the same page (confirmed on a real filing -
# "Age: 39Age: 53" with no space, unrecoverable without guessing which
# digits belong to which person). extract_survey_directors() returns
# an explicit 'unsupported_layout' reason rather than a best-effort
# guess when the clean list pattern isn't found, so a caller can show
# "not extractable yet" honestly instead of silently returning nothing
# or partial garbage.

_DIRECTORS_SECTION_RE = re.compile(r'^\s*DIRECTORS\s*$', re.MULTILINE)
_NAME_DESIGNATION_HEADER_RE = re.compile(r'^\s*Name\s+Designation\s*$', re.MULTILINE | re.IGNORECASE)
# A line ends the roster once it hits the next all-caps section header
# (SECRETARY, REGISTERED OFFICE, BANKERS, AUDITORS, etc.) or a
# footnote marker line (e.g. "*Georgian").
_ROSTER_END_RE = re.compile(r'^\s*(SECRETARY|REGISTERED OFFICE|BANKERS|LAWYERS|ADVOCATES|AUDITORS|POSTAL ADDRESS)\s*$', re.MULTILINE)
_FOOTNOTE_LINE_RE = re.compile(r'^\s*\*[A-Za-z]')

# A roster line is "<Name...> <Designation...>" with no fixed column
# boundary in plain-text form, so the split point is found via known
# designation vocabulary rather than a fixed character offset - this
# mirrors how _classify_remuneration_kind/role_title_re already
# classify role text elsewhere in this module, reusing the same
# vocabulary rather than inventing a second list.
_DESIGNATION_START_RE = re.compile(
    r'\b(Chairman|Chairperson|Chief Executive|Executive Director|Non[\s-]*Executive Director|'
    r'Independent[,]?\s*(?:non[\s-]*)?Executive Director|Managing Director|CEO)\b.*$',
    re.IGNORECASE,
)


def _classify_survey_director_role(designation_text: str) -> str:
    """'executive' | 'non_executive' | 'unknown' from a designation
    string, same convention as DirectorRemunerationRow.role. Checks
    for a non-executive marker FIRST and returns early - a phrasing
    like "Independent, non-Executive Director" contains the substring
    "Executive Director" too, so checking "executive" before
    "non-executive" would wrongly classify a non-executive director as
    executive (caught on real data: Eaagads Limited's "Independent,
    non - Executive Director" designation)."""
    d = designation_text.lower()
    if re.search(r'non[\s-]*executive', d):
        return 'non_executive'
    if 'executive' in d or d.strip() == 'ceo':
        return 'executive'
    return 'unknown'


def _classify_survey_director_independence(designation_text: str):
    """True/False/None from a designation string - None (not stated
    either way) unless the text explicitly says independent or
    explicitly says not independent."""
    d = designation_text.lower()
    if 'not independent' in d:
        return False
    if 'independent' in d:
        return True
    return None


def extract_survey_directors(pdf_bytes: bytes) -> dict:
    """Looks for a clean "DIRECTORS / Name Designation / <rows>" list
    (see module note above) anywhere in the PDF and, if found, returns
    {'directors': [...], 'page': int}, one dict per row with
    director_name, position (designation exactly as printed), role,
    independent, page - gender/nationality/appointed_date/end_of_term/
    committees are NOT populated by this pattern (that table never
    prints them) and stay None/absent, to be filled in later by a
    person or a future extractor for the richer bio-page pattern.

    If no page matches this pattern, returns
    {'directors': [], 'unsupported_layout': True} so a caller can
    distinguish "found the section but every field was empty" (not
    actually possible here, since a match requires at least one
    parsed row) from "this filing uses a different layout this
    extractor doesn't handle yet" - the two need different messaging
    to a person reviewing the result.
    """
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        for pg_idx, page in enumerate(pdf.pages, start=1):
            text = page.extract_text() or ''
            if not _DIRECTORS_SECTION_RE.search(text):
                continue
            header_m = _NAME_DESIGNATION_HEADER_RE.search(text)
            if not header_m:
                continue   # a "DIRECTORS" heading exists on this page but not in the Name/Designation table shape this function supports

            after_header = text[header_m.end():]
            end_m = _ROSTER_END_RE.search(after_header)
            roster_block = after_header[:end_m.start()] if end_m else after_header

            directors = []
            order = 0
            for line in roster_block.split('\n'):
                line = line.strip()
                if not line or _FOOTNOTE_LINE_RE.match(line):
                    continue
                desig_m = _DESIGNATION_START_RE.search(line)
                if not desig_m:
                    continue   # a line here that doesn't contain recognizable designation vocabulary is skipped, not guessed at (e.g. stray page furniture)
                name = line[:desig_m.start()].strip(' -')
                name = re.sub(r'\s*\*\s*$', '', name)   # strip a trailing footnote marker (e.g. Eaagads' "Mr. George Kapanadze *" -> the asterisk points to a footnote like "*Georgian", not part of the name)
                designation = desig_m.group(0).strip()
                if not name:
                    continue
                directors.append({
                    'director_name': name,
                    'position': designation,
                    'role': _classify_survey_director_role(designation),
                    'independent': _classify_survey_director_independence(designation),
                    'order_index': order,
                    'page': pg_idx,
                })
                order += 1

            if directors:
                return {'directors': directors, 'page': pg_idx}
            # Header found but nothing parsed cleanly under it - treat as unsupported rather than returning an empty-but-"found" result.
            break

    return {'directors': [], 'unsupported_layout': True}


# ---------- Survey director benefits extraction ----------
# Feeds SurveyDirectorBenefit (models_survey.py). Deliberately reuses
# extract_director_remuneration_detail() rather than re-parsing the PDF
# a second time - that function already finds the real remuneration
# table (whatever filer-specific column layout it has) and returns
# each director's row as {director_name, components: {label: value},
# page, ...}; this just scans those already-extracted components for
# whichever column looks like a non-cash-benefits column, by keyword,
# since the exact label text varies by filer and can itself be messy
# (confirmed on a real filing - Eaagads' true "non-cash benefits"
# column ended up labelled "Loss of office/ Estimated value for
# non-cash benefits**" due to a PDF layout quirk covered elsewhere in
# this module; matching by keyword rather than an exact label handles
# that without needing the label text itself to be clean).

_BENEFIT_COLUMN_KEYWORDS_RE = re.compile(
    r'non[\s-]*cash|benefit|housing|medical|vehicle|club|allowance(?!s?\s*$)',
    re.IGNORECASE,
)
# "allowance" alone is deliberately excluded when it's the WHOLE label
# ("Expense allowances", "Other allowances") via the negative lookahead
# above - those are cash allowances, a different, more common column
# most filings have that would otherwise swamp genuine benefit columns
# if matched this broadly. A compound label containing "benefit" or
# naming a specific in-kind category (housing/medical/vehicle/club)
# alongside "allowance" still matches normally.


def extract_survey_director_benefits(pdf_bytes: bytes, fiscal_year: str | None = None) -> list:
    """Returns a list of {director_name, position, total_amount,
    detail, page} - one dict per director who has an identifiable
    non-cash-benefit column value in the filing's remuneration table,
    INCLUDING a director whose value is explicitly nil/dash (that's a
    real, meaningful "addressed but zero" fact, not the same as "not
    found" - the caller distinguishes these by total_amount being 0.0
    vs the director simply being absent from this list at all, mirrory
    the same None-vs-absent discipline used throughout this app).
    Directors with NO identifiable benefits-shaped column at all in
    their row (the filing's table doesn't have one) are left out of
    the returned list entirely, not defaulted to 0 - 0 means "the
    filing states a nil value", not "unknown".

    fiscal_year (e.g. "FY2025"), when given, is passed straight
    through to extract_director_remuneration_detail's own
    target_period_label filter - several real filers (confirmed on
    KCB Group Plc) print BOTH the current and prior year's figures
    side by side in the same remuneration table, and without this
    filter every director appears twice with two different amounts,
    silently mixing years. Rows the underlying extractor couldn't
    attribute to a specific year (table_kind='unknown', no 'total')
    are also skipped here even when fiscal_year isn't given, since
    those are usually unrelated notes/schedules the year-agnostic
    table scan picked up, not real remuneration rows (confirmed: a
    board-retirement-date note on a separate page of the same filing)."""
    rows = extract_director_remuneration_detail(pdf_bytes, target_period_label=fiscal_year)
    out = []
    for r in rows:
        if r.get('is_total_row') or r.get('is_grand_total'):
            continue   # a table's own TOTAL row is not a director
        components = r.get('components') or {}
        if not components and r.get('total') is None and r.get('table_kind') == 'unknown':
            # No total AND no component values at all, on a row this
            # extractor couldn't even classify as executive/non-
            # executive - likely an unrelated note/schedule the year-
            # agnostic table scan picked up (confirmed on a real
            # filing: a board-retirement-date note with no
            # remuneration figures at all), not a real remuneration
            # row. A row that DOES have components but happens to lack
            # a clean 'total' (confirmed on another real filing, where
            # a messy merged column label meant the TOTAL column
            # itself wasn't cleanly identified) still has real
            # component data worth using and is NOT skipped here.
            continue
        benefit_label = None
        for label in components:
            if _BENEFIT_COLUMN_KEYWORDS_RE.search(label):
                benefit_label = label
                break
        if benefit_label is None:
            continue
        value = components[benefit_label]
        out.append({
            'director_name': r.get('director_name'),
            'position': None,   # extract_director_remuneration_detail's rows don't carry a position/title field distinct from name - left for a future join against SurveyDirector by name if needed
            'total_amount': value if value is not None else 0.0,
            'detail': None,     # this function only recovers an AMOUNT, never a description of what the benefit comprises - a filing's remuneration table doesn't usually say that inline
            'page': r.get('page'),
        })
    return out